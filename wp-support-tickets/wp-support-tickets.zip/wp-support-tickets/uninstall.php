<?php
/**
 * Uninstall — removes ALL plugin data permanently.
 * FILE: wp-support-tickets/uninstall.php
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wsts_replies" );

delete_option( 'wsts_settings' );
delete_option( 'wsts_db_version' );
delete_transient( 'wsts_dashboard_counts' );

// Remove the custom role.
remove_role( 'support_agent' );

// Remove caps from admin and editor.
foreach ( array( 'administrator', 'editor' ) as $slug ) {
    $role = get_role( $slug );
    if ( $role ) {
        foreach ( array( 'manage_tickets', 'reply_ticket', 'close_ticket', 'assign_ticket', 'delete_ticket', 'view_all_tickets', 'view_private_notes', 'edit_ticket', 'read_ticket', 'edit_tickets', 'edit_others_tickets', 'publish_tickets', 'read_private_tickets', 'delete_tickets' ) as $cap ) {
            $role->remove_cap( $cap );
        }
    }
}