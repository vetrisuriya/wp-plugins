=== WP Support Ticket System ===
Contributors:      vetrisuriya
Tags:              support, ticket, helpdesk, customer service, slack
Requires at least: 5.8
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      7.4
License:           GPL v2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A complete customer support ticket system with AJAX submission, agent roles, SLA deadlines, Slack notifications, REST API, and a front-end customer portal.

== Description ==

**WP Support Ticket System** gives your WordPress site a full helpdesk. Customers submit tickets from the front end, agents manage them in the admin, and Slack keeps your team notified instantly.

= Core Features =

* **[support_ticket_form]** — front-end ticket submission form. Guests provide name + email; logged-in users use their account details
* **[my_tickets]** — shows a logged-in customer's full ticket history in a table
* **Custom post statuses** — Open → In Progress → Resolved → Closed
* **Priority levels** — Low / Normal / High / Critical with colour-coded badges
* **SLA deadlines** — automatically calculated from priority and configurable hours (Normal 24h, High 8h, Critical 2h)
* **Departments** — optional taxonomy to route tickets to the right team
* **Agent replies** — agents reply from the WordPress admin; replies are stored in a custom `wsts_replies` database table
* **Private notes** — agents can add internal notes only visible to other agents
* **Email notifications** — agent email on every new ticket submission
* **Slack notifications** — POST to a Slack Incoming Webhook with ticket details and a "View Ticket" button
* **Support Agent role** — custom `support_agent` WordPress role with ticket management capabilities
* **REST API** — GET, view, and PATCH ticket status via `/wp-json/wp-support-tickets/v1/`
* **Transient caching** — dashboard counts cached for 5 minutes
* **Clean uninstall** — drops DB table, removes custom role and all capabilities

= Shortcodes =

`[support_ticket_form]`
`[support_ticket_form title="Contact Support"]`
`[my_tickets]`

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload Plugin**
2. Go to **Support → Settings** and configure agent email, Slack webhook, and SLA hours
3. Optionally create Departments under **Support → Departments**
4. Add `[support_ticket_form]` to your support page
5. Add `[my_tickets]` to a "My Tickets" page for logged-in customers

== Frequently Asked Questions ==

= Can guests submit tickets without logging in? =

Yes — when `[support_ticket_form]` is placed on a page, guests see Name and Email fields. Logged-in users skip those fields since their account data is used automatically.

= How does the Slack notification work? =

Go to **Support → Settings → Slack Webhook URL** and paste your Slack Incoming Webhook URL. Every new ticket submission sends a formatted message to that channel with subject, priority, customer email, and a "View Ticket" link.

= What is the Support Agent role? =

On activation, a `support_agent` WordPress role is created. Users with this role can view, reply to, and close tickets without being Administrators. Assign agents via **Users → All Users → Change role to Support Agent**.

= How are SLA deadlines calculated? =

When a ticket is submitted, the SLA deadline is calculated as: current time + SLA hours for that priority. Configure hours at **Support → Settings → SLA Configuration**.

= How do I add departments? =

Go to **Support → Departments** (under the Support CPT menu). Departments are a hierarchical taxonomy. Once created, they appear as a dropdown in the ticket submission form.

== Screenshots ==

1. Front-end ticket submission form with priority and department fields.
2. [my_tickets] customer portal showing ticket history with status badges.
3. Admin ticket list table with status tabs and SLA deadline columns.
4. Admin ticket edit screen with reply thread and status update.
5. Settings page — agent email, Slack webhook, SLA hours.

== Changelog ==

= 1.0.0 =
* Initial release. CPT (support_ticket), custom statuses, Department taxonomy, custom replies DB table, [support_ticket_form], [my_tickets], agent replies, private notes, SLA deadlines, email notifications, Slack webhook, Support Agent role, REST API, transient caching.

== Upgrade Notice ==

= 1.0.0 =
Initial release. No upgrade steps required.