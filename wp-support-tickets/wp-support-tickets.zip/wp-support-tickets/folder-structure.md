wp-support-tickets/
├── wp-support-tickets.php         ← Bootstrap
├── readme.txt                     ← WordPress.org required file
├── uninstall.php                  ← Clean up on delete
├── includes/
│   ├── class-wsts-post-type.php   ← CPT + post statuses
│   ├── class-wsts-database.php    ← Custom replies table
│   ├── class-wsts-settings.php    ← Settings API
│   ├── class-wsts-shortcode.php   ← Shortcodes
│   ├── class-wsts-ajax.php        ← AJAX handlers
│   ├── class-wsts-rest-api.php    ← REST endpoints
│   ├── class-wsts-capabilities.php← Role/caps
│   ├── class-wsts-notifications.php ← Email + Slack
│   └── class-wsts-transients.php  ← Cache helpers
├── admin/
│   ├── class-wsts-admin.php       ← Admin pages
│   ├── views/
│   │   ├── ticket-list.php
│   │   └── ticket-detail.php
│   └── assets/
│       ├── admin.css
│       └── admin.js
├── public/
│   ├── views/
│   │   ├── ticket-form.php
│   │   └── my-tickets.php
│   └── assets/
│       ├── public.css
│       └── public.js
└── languages/
    └── wp-support-tickets.pot