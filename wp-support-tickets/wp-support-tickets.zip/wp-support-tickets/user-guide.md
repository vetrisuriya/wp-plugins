# WP Support Ticket System — User Guide

## Table of Contents

- [What This Plugin Does](#what-this-plugin-does)
- [After Activation](#after-activation)
- [Step 1: Configure Settings](#step-1-configure-settings)
- [Step 2: Create Departments (Optional)](#step-2-create-departments-optional)
- [Step 3: Add Shortcodes to Pages](#step-3-add-shortcodes-to-pages)
- [Shortcode Reference](#shortcode-reference)
  - [[support_ticket_form]](#support_ticket_form)
  - [[my_tickets]](#my_tickets)
- [Ticket Workflow](#ticket-workflow)
- [Managing Tickets (Agents)](#managing-tickets-agents)
- [Support Agent Role](#support-agent-role)
- [SLA Deadlines](#sla-deadlines)
- [Slack Notifications](#slack-notifications)
- [REST API](#rest-api)
- [FAQ](#faq)

---

## What This Plugin Does

WP Support Ticket System adds a complete helpdesk to WordPress. Customers submit support tickets from your site's front end, agents manage them in wp-admin, and your team gets notified via email and Slack.

| Feature | Where |
|---|---|
| **Ticket submission form** | Any page with `[support_ticket_form]` |
| **Customer ticket history** | Any page with `[my_tickets]` |
| **Agent ticket management** | **Support** menu in wp-admin |
| **Settings** | **Support → Settings** |
| **Departments** | **Support → Departments** |

---

## After Activation

On activation the plugin:

- Creates the `wp_wsts_replies` custom database table for storing ticket replies
- Creates the **Support Agent** WordPress role
- Adds ticket management capabilities to Administrator and Editor roles
- Adds a **Support** menu to the admin sidebar

---

## Step 1: Configure Settings

Go to **Support → Settings**.

### Notifications section

| Setting | Default | Description |
|---|---|---|
| **Agent Email** | Admin email | New-ticket notification emails are sent here |
| **Slack Webhook URL** | *(empty)* | Paste a Slack Incoming Webhook URL to send ticket alerts to a Slack channel |
| **Email on New Ticket** | ✅ Checked | Uncheck to disable email notifications |

### SLA Configuration section

| Setting | Default | Description |
|---|---|---|
| **SLA Hours (Normal)** | 24 hours | Target response time for Normal priority tickets |
| **SLA Hours (High)** | 8 hours | Target response time for High priority tickets |
| **SLA Hours (Critical)** | 2 hours | Target response time for Critical priority tickets |

SLA deadlines are calculated at ticket creation time and shown as a column in the admin ticket list. Overdue tickets are highlighted in red.

Click **Save Changes**.

---

## Step 2: Create Departments (Optional)

Departments let you route tickets to the right team (e.g. Billing, Technical, Sales).

1. Go to **Support → Departments**
2. Click **Add New Department**
3. Enter a name (e.g. "Technical Support")
4. Click **Add New Department**

Departments appear as a dropdown in the `[support_ticket_form]` automatically once they exist.

---

## Step 3: Add Shortcodes to Pages

### Support / Contact page

1. Go to **Pages → Add New**
2. Title it "Contact Support" or "Submit a Ticket"
3. Add:

```
[support_ticket_form]
```

4. Publish and add to your navigation menu

### My Tickets page

1. Go to **Pages → Add New**
2. Title it "My Tickets" or "My Support Requests"
3. Add:

```
[my_tickets]
```

4. Publish — this page should only be linked from your account area since it requires login

---

## Shortcode Reference

---

### [support_ticket_form]

Displays the ticket submission form. Guest visitors see Name and Email fields in addition to the standard fields. Logged-in users skip those fields (their account data is used automatically).

**Basic usage:**

```
[support_ticket_form]
```

**All attributes:**

```
[support_ticket_form title="Contact Our Support Team"]
```

| Attribute | Default | Description |
|---|---|---|
| `title` | `"Submit a Support Ticket"` | Heading shown above the form |

**Examples:**

```
[support_ticket_form]
```
Default heading and all fields.

```
[support_ticket_form title="How Can We Help?"]
```
Custom heading.

**Fields shown in the form:**

| Field | Shown to | Required |
|---|---|---|
| Your Name | Guests only | Yes |
| Your Email | Guests only | Yes |
| Subject | Everyone | Yes |
| Department | Everyone (if departments exist) | No |
| Priority | Everyone | No (defaults to Normal) |
| Describe your issue | Everyone | Yes |

**Priority levels:**

| Priority | SLA (default) | When to use |
|---|---|---|
| **Low** | — | Minor question, no urgency |
| **Normal** | 24 hours | Standard support request |
| **High** | 8 hours | Affecting productivity |
| **Critical** | 2 hours | Site down, data loss, blocking issue |

**After submitting:**

The form hides and a success message appears: "Your ticket has been submitted. We will get back to you shortly."

The agent email and Slack channel receive a notification immediately.

---

### [my_tickets]

Displays the logged-in customer's full ticket history as a table. Non-logged-in visitors see a "Please log in" message with a login link.

**Basic usage:**

```
[my_tickets]
```

**No attributes.** The shortcode always shows the current logged-in user's tickets.

**What the table shows:**

| Column | Description |
|---|---|
| **#** | Ticket ID number |
| **Subject** | The ticket subject line |
| **Status** | Current status badge |
| **Priority** | Priority badge |
| **Replies** | Number of replies from the agent |
| **Date** | Date the ticket was submitted |

**Status badges:**

| Status | Meaning |
|---|---|
| 🔴 **Open** | Submitted, not yet assigned or replied to |
| 🟡 **In Progress** | Agent has replied at least once |
| 🟢 **Resolved** | Agent has marked the issue as fixed |
| ⚪ **Closed** | No further action — archived |

---

## Ticket Workflow

```
Customer submits form
        ↓
Ticket created (status: Open)
Agent email + Slack notification sent
        ↓
Agent reviews and replies
Status → In Progress
        ↓
Further replies between agent and customer
        ↓
Agent marks as Resolved
        ↓
Customer confirms resolution (or agent closes after N days)
Status → Closed
```

---

## Managing Tickets (Agents)

### Viewing tickets

Go to **Support → Support Tickets** in the admin. The ticket list shows:
- Ticket ID and subject (click to open)
- Priority badge (colour-coded)
- Status badge
- Customer email
- Reply count
- SLA deadline (red if overdue)
- Created date

Use the status filter tabs to view only Open, In Progress, Resolved, or Closed tickets.

### Editing a ticket / adding a reply

1. Click the ticket subject to open it in the editor
2. The ticket content (original message) is shown in the main editor area
3. Add a reply by clicking **Add Reply** at the bottom of the edit screen (added via the meta box in the standard WordPress editor)
4. To add a **Private Note** (only visible to agents, not the customer), tick the "Private note" checkbox before posting

### Updating ticket status

In the ticket edit screen, change the **Status** dropdown (in the right sidebar under "Status") and click **Update**.

Alternatively, from the ticket list, the status can be updated via the admin JS (change the status column dropdown).

### Quick status update via AJAX

When viewing the ticket edit screen, the status dropdown (`#wsts-status-select`) triggers an AJAX update when changed — no need to click "Update" for status-only changes.

---

## Support Agent Role

On activation, a **Support Agent** WordPress role is created. Users with this role can:
- View all tickets
- Reply to tickets
- Close and resolve tickets
- View private notes

They cannot:
- Change plugin settings
- Install or manage other plugins
- Access any other WordPress admin area

### Assigning the Support Agent role

1. Go to **Users → All Users**
2. Click **Edit** on the user
3. Change the **Role** dropdown to **Support Agent**
4. Click **Update User**

### Removing the role

The Support Agent role is removed automatically when the plugin is uninstalled. To manually remove it, change the user's role to Subscriber or another appropriate role before uninstalling.

---

## SLA Deadlines

SLA (Service Level Agreement) deadlines are calculated automatically when a ticket is created:

- **Critical** tickets: current time + 2 hours
- **High** tickets: current time + 8 hours
- **Normal** tickets: current time + 24 hours
- **Low** tickets: no automatic SLA applied

The deadline appears in the **SLA Due** column of the ticket list. When the deadline has passed, the cell turns **red** to alert agents.

To change the SLA hours, go to **Support → Settings → SLA Configuration**.

---

## Slack Notifications

When a new ticket is submitted, the plugin sends a rich Slack notification including:

- Priority emoji (🔴 Critical, 🟡 High, ⚪ Normal, 🔵 Low)
- Ticket ID
- Subject
- Priority level
- Customer email
- **View Ticket** button that links directly to the admin edit page

### Setting up Slack

1. In Slack, go to **Apps → Incoming Webhooks → Add New Webhook**
2. Choose the channel to receive notifications
3. Copy the Webhook URL
4. Paste it in **Support → Settings → Slack Webhook URL**
5. Click **Save Changes**

Test by submitting a test ticket from the front end.

---

## REST API

All endpoints require authentication as an Administrator or Support Agent (using WordPress Application Passwords).

### GET — List Tickets

```
GET /wp-json/wp-support-tickets/v1/tickets
```

**Query parameters:**

| Parameter | Default | Description |
|---|---|---|
| `status` | `ticket_open` | Filter: `ticket_open`, `ticket_in_progress`, `ticket_resolved`, `ticket_closed` |
| `per_page` | `20` | Results per page |

**Example:**
```
GET https://yoursite.com/wp-json/wp-support-tickets/v1/tickets?status=ticket_in_progress
```

**Response:**
```json
[
  {
    "id": 42,
    "subject": "Cannot log in to my account",
    "status": "ticket_in_progress",
    "priority": "high",
    "customer_id": 5,
    "customer_email": "jane@example.com",
    "reply_count": 2,
    "sla_deadline": "2025-06-15 10:00:00",
    "created_at": "2025-06-15 02:00:00"
  }
]
```

### GET — Single Ticket

```
GET /wp-json/wp-support-tickets/v1/tickets/{id}
```

Returns the ticket plus a `replies` array containing all non-private replies (agents see private notes too).

### PATCH — Update Status

```
PATCH /wp-json/wp-support-tickets/v1/tickets/{id}/status
```

**Body (JSON):**
```json
{ "status": "ticket_resolved" }
```

Allowed values: `ticket_open`, `ticket_in_progress`, `ticket_resolved`, `ticket_closed`.

**Response:**
```json
{ "success": true, "status": "ticket_resolved" }
```

---

## FAQ

**The ticket form shows but nothing happens when I click Submit.**

Open your browser's developer console (F12 → Network tab). If you see a 400 error, check that all required fields (Subject and Message) are filled in. If you see a 403, the nonce may have expired — refresh the page and try again. If you see a 0 or no response, check that `admin-ajax.php` is reachable on your host.

**Guests see an error "You must be logged in to submit a ticket" even though I want to allow guest tickets.**

Guest ticket submission uses the `wp_ajax_nopriv_wsts_submit_ticket` hook which fires for non-logged-in users. The plugin handles this correctly. The "must be logged in" message only appears if the AJAX action is `wsts_submit_ticket` (logged-in variant) and the user is not logged in. This should not occur in normal operation. Check whether a caching plugin is serving a cached version of the AJAX response.

**The [my_tickets] table is empty even though I submitted tickets as a logged-in user.**

The shortcode matches tickets by `_wsts_customer_id` (WordPress user ID). This is only set for logged-in submissions. If you submitted as a guest, no customer ID is stored and the tickets won't appear. Check the ticket in the admin to see if `_wsts_customer_id` is set.

**The SLA column shows "—" for some tickets.**

SLA deadlines are only set for ticket priorities that have a configured SLA hours value. Low priority tickets don't get a deadline by default. Also, tickets created before the SLA feature was configured will not have a deadline.

**Can I hide the Priority dropdown from the submission form?**

Not directly via a shortcode attribute. To remove the priority field, you would need to edit `class-wsts-shortcode.php` and remove or comment out the priority `<select>` block. All submissions default to "normal" priority when no priority is provided.

**Can I have multiple ticket forms with different departments pre-selected?**

Not via shortcode attributes in this version — the department dropdown always shows all departments. To pre-select a department, you would need a custom implementation using the REST API or a modified shortcode with a `default_department` attribute.

**How do I export tickets?**

No built-in export in this version. Use the REST API to GET all tickets and save the JSON. Or query the database directly:
```sql
SELECT p.ID, p.post_title, p.post_status, p.post_date,
       m1.meta_value AS priority,
       m2.meta_value AS customer_email
FROM wp_posts p
LEFT JOIN wp_postmeta m1 ON p.ID = m1.post_id AND m1.meta_key = '_wsts_priority'
LEFT JOIN wp_postmeta m2 ON p.ID = m2.post_id AND m2.meta_key = '_wsts_customer_email'
WHERE p.post_type = 'support_ticket'
ORDER BY p.post_date DESC;
```