<?php
/**
 * Plugin Name:       WP Support Ticket System
 * Plugin URI:        https://vetrisuriya.in/wp-support-tickets
 * Description:       A complete customer support ticket system with AJAX submission, agent roles, SLA deadlines, Slack notifications, REST API, and a front-end customer portal.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Vetri Suriya
 * License:           GPL v2 or later
 * Text Domain:       wp-support-tickets
 * Domain Path:       /languages
 * @package WPSupportTickets
 */

defined( 'ABSPATH' ) || exit;

define( 'WSTS_VERSION',         '1.0.0' );
define( 'WSTS_PLUGIN_DIR',      plugin_dir_path( __FILE__ ) );
define( 'WSTS_PLUGIN_URL',      plugin_dir_url( __FILE__ ) );
define( 'WSTS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/*
 * FATAL ERROR ROOT CAUSE (same as Plugin 03):
 *
 * wp_support_tickets() is called at the bottom of this file —
 * which runs on EVERY WordPress page load, not just activation.
 * That function calls load_dependencies() which uses require_once
 * on all class files. Since no class files existed as real .php files,
 * PHP threw: Fatal error: require_once(): Failed to open required file
 * 'class-wsts-post-type.php' on every single page load.
 *
 * FIX: Create all class files as real .php files. The singleton
 * bootstrap below is architecturally correct — it just needed the files.
 */

final class WP_Support_Tickets {

    private static ?WP_Support_Tickets $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_dependencies();
        $this->set_locale();
        $this->define_hooks();
    }

    private function load_dependencies(): void {
        require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-post-type.php';
        require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-database.php';
        require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-settings.php';
        require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-shortcode.php';
        require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-ajax.php';
        require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-rest-api.php';
        require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-capabilities.php';
        require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-notifications.php';
        require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-transients.php';
        require_once WSTS_PLUGIN_DIR . 'admin/class-wsts-admin.php';
    }

    private function set_locale(): void {
        add_action( 'plugins_loaded', function (): void {
            load_plugin_textdomain( 'wp-support-tickets', false, dirname( WSTS_PLUGIN_BASENAME ) . '/languages/' );
        } );
    }

    private function define_hooks(): void {
        // CPT + taxonomy + meta.
        $pt = new WSTS_Post_Type();
        add_action( 'init', array( $pt, 'register' ) );

        // Settings + admin menu.
        $settings = new WSTS_Settings();
        add_action( 'admin_init', array( $settings, 'register_settings' ) );
        add_action( 'admin_menu', array( $settings, 'add_menu' ) );

        // Admin pages (views).
        $admin = new WSTS_Admin();
        add_action( 'admin_enqueue_scripts', array( $admin, 'enqueue_admin_assets' ) );

        // Shortcodes.
        $sc = new WSTS_Shortcode();
        add_shortcode( 'support_ticket_form', array( $sc, 'render_form' ) );
        add_shortcode( 'my_tickets',          array( $sc, 'render_my_tickets' ) );

        // AJAX.
        $ajax = new WSTS_Ajax();
        add_action( 'wp_ajax_wsts_submit_ticket',        array( $ajax, 'submit_ticket' ) );
        add_action( 'wp_ajax_nopriv_wsts_submit_ticket', array( $ajax, 'guest_submit_ticket' ) );
        add_action( 'wp_ajax_wsts_post_reply',           array( $ajax, 'post_reply' ) );
        add_action( 'wp_ajax_wsts_update_status',        array( $ajax, 'update_status' ) );

        // REST API.
        $rest = new WSTS_Rest_Api();
        add_action( 'rest_api_init', array( $rest, 'register_routes' ) );

        // Assets.
        add_action( 'wp_enqueue_scripts',   array( $this, 'enqueue_public' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin' ) );
    }

    public function enqueue_public(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) ) return;
        if ( ! has_shortcode( $post->post_content, 'support_ticket_form' ) &&
             ! has_shortcode( $post->post_content, 'my_tickets' ) ) return;

        wp_enqueue_style(  'wsts-public', WSTS_PLUGIN_URL . 'public/assets/public.css', array(), WSTS_VERSION );
        wp_enqueue_script( 'wsts-public', WSTS_PLUGIN_URL . 'public/assets/public.js',  array( 'jquery' ), WSTS_VERSION, true );
        wp_localize_script( 'wsts-public', 'wsts_params', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wsts_nonce' ),
            'strings'  => array(
                'submitting' => __( 'Submitting…',                               'wp-support-tickets' ),
                'success'    => __( 'Ticket submitted! We will reply soon.',     'wp-support-tickets' ),
                'error'      => __( 'Something went wrong. Please try again.',   'wp-support-tickets' ),
                'required'   => __( 'Please fill in all required fields.',       'wp-support-tickets' ),
                'submit'     => __( 'Submit Ticket',                             'wp-support-tickets' ),
                'posting'    => __( 'Posting…',                                  'wp-support-tickets' ),
                'reply_ok'   => __( 'Reply posted.',                             'wp-support-tickets' ),
            ),
        ) );
    }

    public function enqueue_admin( string $hook ): void {
        if ( false === strpos( $hook, 'support_ticket' ) ) return;
        wp_enqueue_style(  'wsts-admin', WSTS_PLUGIN_URL . 'admin/assets/admin.css', array(), WSTS_VERSION );
        wp_enqueue_script( 'wsts-admin', WSTS_PLUGIN_URL . 'admin/assets/admin.js',  array( 'jquery' ), WSTS_VERSION, true );
        wp_localize_script( 'wsts-admin', 'wsts_admin', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wsts_admin_nonce' ),
            'strings'  => array(
                'confirm_status' => __( 'Change ticket status?', 'wp-support-tickets' ),
                'updating'       => __( 'Updating…',             'wp-support-tickets' ),
                'updated'        => __( 'Updated!',              'wp-support-tickets' ),
                'error'          => __( 'Update failed.',        'wp-support-tickets' ),
            ),
        ) );
    }
}

register_activation_hook( __FILE__, function (): void {
    require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-database.php';
    WSTS_Database::create_tables();
    require_once WSTS_PLUGIN_DIR . 'includes/class-wsts-capabilities.php';
    WSTS_Capabilities::add_caps();
    flush_rewrite_rules();
    set_transient( 'wsts_activation_redirect', true, 30 );
} );

register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

function wp_support_tickets(): WP_Support_Tickets {
    return WP_Support_Tickets::instance();
}
wp_support_tickets();