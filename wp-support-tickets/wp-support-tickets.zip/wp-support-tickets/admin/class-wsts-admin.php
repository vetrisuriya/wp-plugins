<?php
/**
 * Admin: dashboard page, views router, asset enqueue.
 * FILE: wp-support-tickets/admin/class-wsts-admin.php
 *
 * NOTE: Listed in the plugin structure but NEVER written in the reference file.
 * Created from scratch.
 *
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Admin {

    public function enqueue_admin_assets( string $hook ): void {
        if ( false === strpos( $hook, 'support_ticket' ) ) return;
        // Assets are enqueued by the main class; this method is for future admin-only additions.
    }
}