/* global wsts_admin, jQuery */
/* WP Support Ticket System — Admin JS
   FILE: wp-support-tickets/admin/assets/admin.js */
( function ( $ ) {
    'use strict';

    /* ── Inline status update from ticket edit screen ─────────── */
    $( document ).on( 'change', '#wsts-status-select', function () {
        var $sel      = $( this );
        var ticketId  = $sel.data( 'ticket-id' );
        var newStatus = $sel.val();
        if ( ! window.confirm( wsts_admin.strings.confirm_status ) ) {
            $sel.val( $sel.data( 'original' ) );
            return;
        }
        $sel.prop( 'disabled', true );
        $.post( wsts_admin.ajax_url, {
            action:    'wsts_update_status',
            nonce:     wsts_admin.nonce,
            ticket_id: ticketId,
            status:    newStatus,
        }, function ( res ) {
            $sel.prop( 'disabled', false );
            if ( res.success ) {
                $sel.data( 'original', newStatus );
            } else {
                alert( wsts_admin.strings.error );
                $sel.val( $sel.data( 'original' ) );
            }
        } );
    } );

    /* Store original value on page load */
    $( '#wsts-status-select' ).each( function () {
        $( this ).data( 'original', $( this ).val() );
    } );

}( jQuery ) );