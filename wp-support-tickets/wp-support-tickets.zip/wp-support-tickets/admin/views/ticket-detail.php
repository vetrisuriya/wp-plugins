<?php
/**
 * Admin view: Ticket detail with replies and status update.
 * FILE: wp-support-tickets/admin/views/ticket-detail.php
 *
 * NOTE: Listed in the plugin structure but NEVER written in the reference.
 * Created from scratch.
 *
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

function wsts_render_ticket_detail( int $ticket_id ): void {
    $post     = get_post( $ticket_id );
    if ( ! $post || 'support_ticket' !== $post->post_type ) {
        echo '<p>' . esc_html__( 'Ticket not found.', 'wp-support-tickets' ) . '</p>';
        return;
    }

    $status   = get_post_status_object( $post->post_status );
    $priority = get_post_meta( $ticket_id, '_wsts_priority', true );
    $customer = get_post_meta( $ticket_id, '_wsts_customer_email', true );
    $sla      = get_post_meta( $ticket_id, '_wsts_sla_deadline', true );
    $replies  = WSTS_Database::get_replies( $ticket_id, true );
    ?>
    <div class="wsts-ticket-detail">
        <div class="wsts-ticket-header">
            <h2>#<?php echo absint( $ticket_id ); ?> — <?php echo esc_html( $post->post_title ); ?></h2>
            <div class="wsts-ticket-meta" style="display:flex;gap:1rem;flex-wrap:wrap;margin-top:.5rem;font-size:.875rem;color:#64748b;">
                <span><strong><?php esc_html_e( 'Status:', 'wp-support-tickets' ); ?></strong>
                    <span class="wsts-status wsts-status--<?php echo esc_attr( $post->post_status ); ?>"><?php echo esc_html( $status ? $status->label : $post->post_status ); ?></span>
                </span>
                <span><strong><?php esc_html_e( 'Priority:', 'wp-support-tickets' ); ?></strong>
                    <span class="wsts-priority wsts-priority--<?php echo esc_attr( $priority ); ?>"><?php echo esc_html( ucfirst( $priority ) ); ?></span>
                </span>
                <span><strong><?php esc_html_e( 'Customer:', 'wp-support-tickets' ); ?></strong>
                    <?php echo $customer ? '<a href="mailto:' . esc_attr( $customer ) . '">' . esc_html( $customer ) . '</a>' : '—'; ?>
                </span>
                <?php if ( $sla ) : ?>
                <span><strong><?php esc_html_e( 'SLA Due:', 'wp-support-tickets' ); ?></strong>
                    <?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' H:i', strtotime( $sla ) ) ); ?>
                </span>
                <?php endif; ?>
            </div>
        </div>

        <!-- Original message -->
        <div class="wsts-reply wsts-reply--customer" style="margin-top:1.5rem;padding:1rem;background:#f8fafc;border-left:4px solid #e2e8f0;border-radius:4px;">
            <p style="font-size:.75rem;color:#64748b;margin:0 0 .5rem;">
                <?php esc_html_e( 'Original message', 'wp-support-tickets' ); ?> — <?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' H:i', strtotime( $post->post_date ) ) ); ?>
            </p>
            <?php echo wp_kses_post( wpautop( $post->post_content ) ); ?>
        </div>

        <!-- Replies -->
        <?php foreach ( $replies as $reply ) :
            $is_agent   = $reply->is_agent_reply;
            $is_private = $reply->is_private_note;
            $bg  = $is_agent   ? '#eff6ff' : '#f0fdf4';
            $bl  = $is_agent   ? '#2271b1'  : '#059669';
            $bg  = $is_private ? '#fffbeb'  : $bg;
        ?>
        <div class="wsts-reply <?php echo $is_agent ? 'wsts-reply--agent' : 'wsts-reply--customer'; ?>" style="margin-top:1rem;padding:1rem;background:<?php echo esc_attr( $bg ); ?>;border-left:4px solid <?php echo esc_attr( $bl ); ?>;border-radius:4px;">
            <p style="font-size:.75rem;color:#64748b;margin:0 0 .5rem;">
                <strong><?php echo esc_html( $reply->author_name ?: $reply->author_email ); ?></strong>
                <?php echo $is_agent ? ' (' . esc_html__( 'Agent', 'wp-support-tickets' ) . ')' : ''; ?>
                <?php echo $is_private ? ' 🔒 ' . esc_html__( 'Private Note', 'wp-support-tickets' ) : ''; ?>
                — <?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' H:i', strtotime( $reply->created_at ) ) ); ?>
            </p>
            <?php echo wp_kses_post( wpautop( $reply->reply_content ) ); ?>
        </div>
        <?php endforeach; ?>

        <!-- Status update & reply (handled by admin meta boxes and admin.js) -->
    </div>
    <?php
}