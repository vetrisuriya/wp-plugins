<?php
/**
 * Admin view: Ticket list with status tabs and stat cards.
 * FILE: wp-support-tickets/admin/views/ticket-list.php
 *
 * NOTE: Listed in the plugin structure but NEVER written in the reference.
 * Created from scratch.
 *
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

function wsts_render_ticket_list(): void {
    $counts       = WSTS_Transients::get_dashboard_counts();
    $status_filter = sanitize_text_field( $_GET['post_status'] ?? 'ticket_open' );

    $posts = get_posts( array(
        'post_type'      => 'support_ticket',
        'post_status'    => $status_filter,
        'posts_per_page' => 50,
    ) );

    $statuses = array(
        'ticket_open'        => array( 'label' => __( 'Open',        'wp-support-tickets' ), 'color' => '#dc2626' ),
        'ticket_in_progress' => array( 'label' => __( 'In Progress', 'wp-support-tickets' ), 'color' => '#d97706' ),
        'ticket_resolved'    => array( 'label' => __( 'Resolved',    'wp-support-tickets' ), 'color' => '#059669' ),
        'ticket_closed'      => array( 'label' => __( 'Closed',      'wp-support-tickets' ), 'color' => '#64748b' ),
    );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Support Tickets', 'wp-support-tickets' ); ?></h1>

        <!-- Stat cards -->
        <div class="wsts-stat-cards" style="display:flex;gap:1rem;margin:1rem 0;flex-wrap:wrap;">
            <?php foreach ( $statuses as $slug => $info ) : ?>
            <div style="background:#fff;border:1px solid #ddd;border-top:4px solid <?php echo esc_attr( $info['color'] ); ?>;border-radius:4px;padding:1rem 1.5rem;min-width:120px;text-align:center;">
                <div style="font-size:1.75rem;font-weight:800;"><?php echo absint( $counts[ $slug ] ?? 0 ); ?></div>
                <div style="font-size:.8125rem;color:#64748b;"><?php echo esc_html( $info['label'] ); ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Status filter tabs -->
        <ul class="subsubsub">
            <?php
            $links = array();
            foreach ( $statuses as $slug => $info ) {
                $url     = add_query_arg( array( 'post_type' => 'support_ticket', 'post_status' => $slug ), admin_url( 'edit.php' ) );
                $current = $status_filter === $slug ? ' class="current"' : '';
                $links[] = '<li><a href="' . esc_url( $url ) . '"' . $current . '>' . esc_html( $info['label'] ) . ' <span class="count">(' . absint( $counts[ $slug ] ?? 0 ) . ')</span></a>';
            }
            echo implode( ' | ', $links );
            ?>
        </ul>

        <?php if ( empty( $posts ) ) : ?>
        <p style="margin-top:1rem;"><?php esc_html_e( 'No tickets found for this status.', 'wp-support-tickets' ); ?></p>
        <?php else : ?>
        <table class="wp-list-table widefat fixed striped" style="margin-top:1rem;">
            <thead>
                <tr>
                    <th style="width:40px">#</th>
                    <th><?php esc_html_e( 'Subject',  'wp-support-tickets' ); ?></th>
                    <th><?php esc_html_e( 'Priority', 'wp-support-tickets' ); ?></th>
                    <th><?php esc_html_e( 'Customer', 'wp-support-tickets' ); ?></th>
                    <th><?php esc_html_e( 'Replies',  'wp-support-tickets' ); ?></th>
                    <th><?php esc_html_e( 'SLA Due',  'wp-support-tickets' ); ?></th>
                    <th><?php esc_html_e( 'Created',  'wp-support-tickets' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $posts as $post ) :
                    $priority = get_post_meta( $post->ID, '_wsts_priority', true ) ?: 'normal';
                    $email    = get_post_meta( $post->ID, '_wsts_customer_email', true );
                    $replies  = (int) get_post_meta( $post->ID, '_wsts_reply_count', true );
                    $sla      = get_post_meta( $post->ID, '_wsts_sla_deadline', true );
                    $overdue  = $sla && strtotime( $sla ) < current_time( 'timestamp' );
                ?>
                <tr>
                    <td><a href="<?php echo esc_url( get_edit_post_link( $post->ID ) ); ?>">#<?php echo absint( $post->ID ); ?></a></td>
                    <td><a href="<?php echo esc_url( get_edit_post_link( $post->ID ) ); ?>" style="font-weight:600;"><?php echo esc_html( $post->post_title ); ?></a></td>
                    <td><span class="wsts-priority wsts-priority--<?php echo esc_attr( $priority ); ?>"><?php echo esc_html( ucfirst( $priority ) ); ?></span></td>
                    <td><?php echo $email ? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : '—'; ?></td>
                    <td><?php echo absint( $replies ); ?></td>
                    <td <?php echo $overdue ? 'style="color:#dc2626;font-weight:700;"' : ''; ?>>
                        <?php echo $sla ? esc_html( date_i18n( get_option( 'date_format' ) . ' H:i', strtotime( $sla ) ) ) : '—'; ?>
                    </td>
                    <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $post->post_date ) ) ); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php
}