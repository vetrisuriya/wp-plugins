/* global wsts_params, jQuery */
/* WP Support Ticket System — Public JS
   FILE: wp-support-tickets/public/assets/public.js */
( function ( $ ) {
    'use strict';

    /* ── Ticket form submit ──────────────────────────────────────── */
    $( '#wsts-ticket-form' ).on( 'submit', function ( e ) {
        e.preventDefault();
        var $form = $( this );
        var $msg  = $form.closest( '.wsts-ticket-form-wrap' ).find( '.wsts-form-message' );
        var $btn  = $form.find( '.wsts-submit-btn' );
        var isGuest = $form.find( 'input[name="email"]' ).length > 0;
        var subject = $form.find( 'input[name="subject"]' ).val().trim();
        var message = $form.find( 'textarea[name="message"]' ).val().trim();

        $msg.hide().removeClass( 'wsts-success wsts-error' );

        if ( ! subject || ! message ) {
            $msg.addClass( 'wsts-error' ).text( wsts_params.strings.required ).show();
            return;
        }

        var data = {
            action:     isGuest ? 'wsts_submit_ticket' : 'wsts_submit_ticket',
            nonce:      wsts_params.nonce,
            subject:    subject,
            message:    message,
            priority:   $form.find( 'select[name="priority"]' ).val() || 'normal',
            department: $form.find( 'select[name="department"]' ).val() || '',
        };
        if ( isGuest ) {
            data.name  = $form.find( 'input[name="name"]' ).val().trim();
            data.email = $form.find( 'input[name="email"]' ).val().trim();
        }

        $btn.prop( 'disabled', true ).text( wsts_params.strings.submitting );

        $.post( wsts_params.ajax_url, data, function ( res ) {
            if ( res.success ) {
                $form.hide();
                $msg.addClass( 'wsts-success' ).text( res.data.message || wsts_params.strings.success ).show();
            } else {
                $msg.addClass( 'wsts-error' ).text( ( res.data && res.data.message ) || wsts_params.strings.error ).show();
                $btn.prop( 'disabled', false ).text( 'Submit Ticket' );
            }
        } ).fail( function () {
            $msg.addClass( 'wsts-error' ).text( wsts_params.strings.error ).show();
            $btn.prop( 'disabled', false ).text( 'Submit Ticket' );
        } );
    } );

}( jQuery ) );