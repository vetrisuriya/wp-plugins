<?php
/**
 * Settings API: Email, Slack, and SLA configuration.
 * FILE: wp-support-tickets/includes/class-wsts-settings.php
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Settings {

    const OPTION_GROUP = 'wsts_settings_group';
    const OPTION_NAME  = 'wsts_settings';

    public function add_menu(): void {
        add_submenu_page( 'edit.php?post_type=support_ticket',
            __( 'Ticket Settings', 'wp-support-tickets' ),
            __( 'Settings',        'wp-support-tickets' ),
            'manage_options', 'wsts_settings', array( $this, 'render_page' )
        );
    }

    public function register_settings(): void {
        register_setting( self::OPTION_GROUP, self::OPTION_NAME, array( 'sanitize_callback' => array( $this, 'sanitize' ) ) );

        add_settings_section( 'wsts_notifications', __( 'Notifications', 'wp-support-tickets' ), null, 'wsts_settings_page' );
        add_settings_field( 'agent_email',   __( 'Agent Email',             'wp-support-tickets' ), array( $this, 'agent_email_cb'   ), 'wsts_settings_page', 'wsts_notifications' );
        add_settings_field( 'slack_webhook', __( 'Slack Webhook URL',       'wp-support-tickets' ), array( $this, 'slack_webhook_cb' ), 'wsts_settings_page', 'wsts_notifications' );
        add_settings_field( 'email_on_new',  __( 'Email on New Ticket',     'wp-support-tickets' ), array( $this, 'email_on_new_cb'  ), 'wsts_settings_page', 'wsts_notifications' );

        add_settings_section( 'wsts_sla', __( 'SLA Configuration', 'wp-support-tickets' ), null, 'wsts_settings_page' );
        add_settings_field( 'sla_hours_normal',   __( 'SLA Hours (Normal)',   'wp-support-tickets' ), array( $this, 'sla_normal_cb'   ), 'wsts_settings_page', 'wsts_sla' );
        add_settings_field( 'sla_hours_high',     __( 'SLA Hours (High)',     'wp-support-tickets' ), array( $this, 'sla_high_cb'     ), 'wsts_settings_page', 'wsts_sla' );
        add_settings_field( 'sla_hours_critical', __( 'SLA Hours (Critical)', 'wp-support-tickets' ), array( $this, 'sla_critical_cb' ), 'wsts_settings_page', 'wsts_sla' );
    }

    public function render_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Permission denied.', 'wp-support-tickets' ) );
        ?>
        <div class="wrap"><h1><?php esc_html_e( 'Support Ticket Settings', 'wp-support-tickets' ); ?></h1>
        <form method="post" action="options.php">
            <?php settings_fields( self::OPTION_GROUP ); do_settings_sections( 'wsts_settings_page' ); submit_button(); ?>
        </form></div>
        <?php
    }

    public function agent_email_cb():   void { $o = self::get_options(); echo '<input type="email" name="' . esc_attr( self::OPTION_NAME ) . '[agent_email]" value="' . esc_attr( $o['agent_email'] ) . '" class="regular-text">'; }
    public function slack_webhook_cb(): void { $o = self::get_options(); echo '<input type="url" name="' . esc_attr( self::OPTION_NAME ) . '[slack_webhook]" value="' . esc_attr( $o['slack_webhook'] ) . '" class="large-text"><p class="description">' . esc_html__( 'Slack Incoming Webhook URL for new-ticket notifications.', 'wp-support-tickets' ) . '</p>'; }
    public function email_on_new_cb():  void { $o = self::get_options(); echo '<input type="checkbox" name="' . esc_attr( self::OPTION_NAME ) . '[email_on_new]" value="1"' . checked( 1, $o['email_on_new'], false ) . '>'; }
    public function sla_normal_cb():    void { $o = self::get_options(); echo '<input type="number" min="1" max="168" name="' . esc_attr( self::OPTION_NAME ) . '[sla_hours_normal]" value="' . esc_attr( $o['sla_hours_normal'] ) . '" class="small-text"> ' . esc_html__( 'hours', 'wp-support-tickets' ); }
    public function sla_high_cb():      void { $o = self::get_options(); echo '<input type="number" min="1" max="48" name="' . esc_attr( self::OPTION_NAME ) . '[sla_hours_high]" value="' . esc_attr( $o['sla_hours_high'] ) . '" class="small-text"> ' . esc_html__( 'hours', 'wp-support-tickets' ); }
    public function sla_critical_cb():  void { $o = self::get_options(); echo '<input type="number" min="1" max="24" name="' . esc_attr( self::OPTION_NAME ) . '[sla_hours_critical]" value="' . esc_attr( $o['sla_hours_critical'] ) . '" class="small-text"> ' . esc_html__( 'hours', 'wp-support-tickets' ); }

    public function sanitize( $input ): array {
        return array(
            'agent_email'        => sanitize_email( $input['agent_email'] ?? '' ),
            'slack_webhook'      => esc_url_raw( $input['slack_webhook'] ?? '' ),
            'email_on_new'       => isset( $input['email_on_new'] ) ? 1 : 0,
            'sla_hours_normal'   => absint( $input['sla_hours_normal'] ?? 24 ),
            'sla_hours_high'     => absint( $input['sla_hours_high'] ?? 8 ),
            'sla_hours_critical' => absint( $input['sla_hours_critical'] ?? 2 ),
        );
    }

    public static function get_options(): array {
        return wp_parse_args( get_option( self::OPTION_NAME, array() ), array(
            'agent_email'        => get_option( 'admin_email' ),
            'slack_webhook'      => '',
            'email_on_new'       => 1,
            'sla_hours_normal'   => 24,
            'sla_hours_high'     => 8,
            'sla_hours_critical' => 2,
        ) );
    }
}