<?php
/**
 * REST API: Ticket endpoints.
 * FILE: wp-support-tickets/includes/class-wsts-rest-api.php
 * Routes: GET /tickets | GET /tickets/{id} | PATCH /tickets/{id}/status
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Rest_Api {

    const NAMESPACE = 'wp-support-tickets/v1';

    public function register_routes(): void {
        register_rest_route( self::NAMESPACE, '/tickets', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_tickets' ),
            'permission_callback' => array( $this, 'agent_permission' ),
            'args'                => array(
                'status'   => array( 'type' => 'string',  'default' => 'ticket_open', 'sanitize_callback' => 'sanitize_text_field' ),
                'per_page' => array( 'type' => 'integer', 'default' => 20,            'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( self::NAMESPACE, '/tickets/(?P<id>\d+)', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_ticket' ),
            'permission_callback' => array( $this, 'ticket_owner_or_agent' ),
        ) );
        register_rest_route( self::NAMESPACE, '/tickets/(?P<id>\d+)/status', array(
            'methods'             => WP_REST_Server::EDITABLE,
            'callback'            => array( $this, 'update_status' ),
            'permission_callback' => array( $this, 'agent_permission' ),
        ) );
    }

    public function get_tickets( WP_REST_Request $request ): WP_REST_Response {
        $posts = get_posts( array( 'post_type' => 'support_ticket', 'post_status' => $request->get_param( 'status' ), 'posts_per_page' => $request->get_param( 'per_page' ) ) );
        return rest_ensure_response( array_map( array( $this, 'prepare_ticket' ), $posts ) );
    }

    public function get_ticket( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $post = get_post( absint( $request->get_param( 'id' ) ) );
        if ( ! $post || 'support_ticket' !== $post->post_type ) {
            return new WP_Error( 'wsts_not_found', __( 'Ticket not found.', 'wp-support-tickets' ), array( 'status' => 404 ) );
        }
        $data              = $this->prepare_ticket( $post );
        $data['replies']   = WSTS_Database::get_replies( $post->ID, current_user_can( 'manage_tickets' ) );
        return rest_ensure_response( $data );
    }

    public function update_status( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $id     = absint( $request->get_param( 'id' ) );
        $status = sanitize_text_field( $request->get_param( 'status' ) );
        $allowed = array( 'ticket_open', 'ticket_in_progress', 'ticket_resolved', 'ticket_closed' );
        if ( ! in_array( $status, $allowed, true ) ) {
            return new WP_Error( 'wsts_invalid_status', __( 'Invalid status.', 'wp-support-tickets' ), array( 'status' => 400 ) );
        }
        wp_update_post( array( 'ID' => $id, 'post_status' => $status ) );
        WSTS_Transients::invalidate();
        return rest_ensure_response( array( 'success' => true, 'status' => $status ) );
    }

    public function agent_permission(): bool { return current_user_can( 'manage_tickets' ); }

    public function ticket_owner_or_agent( WP_REST_Request $request ): bool {
        if ( current_user_can( 'manage_tickets' ) ) return true;
        $customer_id = (int) get_post_meta( absint( $request->get_param( 'id' ) ), '_wsts_customer_id', true );
        return is_user_logged_in() && get_current_user_id() === $customer_id;
    }

    private function prepare_ticket( WP_Post $post ): array {
        return array(
            'id'             => $post->ID,
            'subject'        => $post->post_title,
            'status'         => $post->post_status,
            'priority'       => get_post_meta( $post->ID, '_wsts_priority',       true ),
            'customer_id'    => (int) get_post_meta( $post->ID, '_wsts_customer_id',   true ),
            'customer_email' => get_post_meta( $post->ID, '_wsts_customer_email',  true ),
            'reply_count'    => (int) get_post_meta( $post->ID, '_wsts_reply_count',   true ),
            'sla_deadline'   => get_post_meta( $post->ID, '_wsts_sla_deadline',    true ),
            'created_at'     => $post->post_date,
        );
    }
}