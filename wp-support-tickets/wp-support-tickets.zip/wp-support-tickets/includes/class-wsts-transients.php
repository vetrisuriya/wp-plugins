<?php
/**
 * Transient-based caching for dashboard counts.
 * FILE: wp-support-tickets/includes/class-wsts-transients.php
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Transients {

    public static function get_dashboard_counts(): array {
        $cached = get_transient( 'wsts_dashboard_counts' );
        if ( false !== $cached ) return $cached;

        $statuses = array( 'ticket_open', 'ticket_in_progress', 'ticket_resolved', 'ticket_closed' );
        $counts   = array();
        foreach ( $statuses as $status ) {
            $q              = new WP_Query( array( 'post_type' => 'support_ticket', 'post_status' => $status, 'fields' => 'ids' ) );
            $counts[$status] = $q->found_posts;
        }

        set_transient( 'wsts_dashboard_counts', $counts, 5 * MINUTE_IN_SECONDS );
        return $counts;
    }

    public static function invalidate(): void {
        delete_transient( 'wsts_dashboard_counts' );
    }
}