<?php
/**
 * Notifications: email + Slack via WordPress HTTP API.
 * FILE: wp-support-tickets/includes/class-wsts-notifications.php
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Notifications {

    public function on_new_ticket( int $ticket_id ): void {
        $ticket  = get_post( $ticket_id );
        $options = WSTS_Settings::get_options();
        if ( $options['email_on_new'] )        $this->send_agent_email( $ticket, $options );
        if ( ! empty( $options['slack_webhook'] ) ) $this->send_slack_notification( $ticket, $options );
    }

    private function send_agent_email( WP_Post $ticket, array $options ): void {
        $priority = get_post_meta( $ticket->ID, '_wsts_priority', true );
        $customer = get_post_meta( $ticket->ID, '_wsts_customer_email', true );
        $subject  = sprintf( __( '[%1$s] New Support Ticket: %2$s', 'wp-support-tickets' ), strtoupper( $priority ), $ticket->post_title );
        $body     = sprintf(
            __( "A new support ticket has been submitted.\n\nFrom: %1\$s\nSubject: %2\$s\nPriority: %3\$s\nTicket ID: #%4\$d\n\nView ticket in admin: %5\$s", 'wp-support-tickets' ),
            $customer, $ticket->post_title, $priority, $ticket->ID,
            admin_url( 'post.php?post=' . $ticket->ID . '&action=edit' )
        );
        wp_mail( $options['agent_email'], $subject, $body );
    }

    private function send_slack_notification( WP_Post $ticket, array $options ): void {
        $priority = get_post_meta( $ticket->ID, '_wsts_priority', true );
        $customer = get_post_meta( $ticket->ID, '_wsts_customer_email', true );
        $emoji    = array( 'low' => ':blue_circle:', 'normal' => ':white_circle:', 'high' => ':yellow_circle:', 'critical' => ':red_circle:' );
        $color    = array( 'critical' => 'danger', 'high' => 'warning', 'normal' => 'good', 'low' => 'good' );
        $payload  = array(
            'text'        => sprintf( '%s *New Support Ticket (#%d)*', $emoji[ $priority ] ?? ':white_circle:', $ticket->ID ),
            'attachments' => array( array(
                'color'  => $color[ $priority ] ?? 'good',
                'fields' => array(
                    array( 'title' => 'Subject',  'value' => $ticket->post_title, 'short' => true ),
                    array( 'title' => 'Priority', 'value' => ucfirst( $priority ), 'short' => true ),
                    array( 'title' => 'Customer', 'value' => $customer, 'short' => true ),
                ),
            ) ),
        );
        $response = wp_remote_post( $options['slack_webhook'], array(
            'method'  => 'POST',
            'timeout' => 15,
            'headers' => array( 'Content-Type' => 'application/json' ),
            'body'    => wp_json_encode( $payload ),
        ) );
        if ( is_wp_error( $response ) ) {
            error_log( '[WSTS] Slack webhook failed: ' . $response->get_error_message() ); // phpcs:ignore
        }
    }
}