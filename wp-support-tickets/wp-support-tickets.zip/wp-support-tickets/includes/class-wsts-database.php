<?php
/**
 * Custom DB table for ticket replies.
 * FILE: wp-support-tickets/includes/class-wsts-database.php
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Database {

    const TABLE_NAME = 'wsts_replies';

    public static function create_tables(): void {
        global $wpdb;
        $table           = $wpdb->prefix . self::TABLE_NAME;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( "CREATE TABLE {$table} (
  id              bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ticket_id       bigint(20) unsigned NOT NULL,
  user_id         bigint(20) unsigned NOT NULL DEFAULT 0,
  author_name     varchar(100) NOT NULL DEFAULT '',
  author_email    varchar(200) NOT NULL DEFAULT '',
  reply_content   longtext NOT NULL,
  is_agent_reply  tinyint(1) NOT NULL DEFAULT 0,
  is_private_note tinyint(1) NOT NULL DEFAULT 0,
  created_at      datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY  (id),
  KEY ticket_id (ticket_id),
  KEY user_id (user_id),
  KEY is_agent_reply (is_agent_reply)
) {$charset_collate};" );
        update_option( 'wsts_db_version', '1.0.0' );
    }

    public static function insert_reply( array $data ): int|false {
        global $wpdb;
        $user = wp_get_current_user();
        $result = $wpdb->insert( // phpcs:ignore
            $wpdb->prefix . self::TABLE_NAME,
            array(
                'ticket_id'       => absint( $data['ticket_id'] ),
                'user_id'         => absint( $data['user_id'] ?? $user->ID ),
                'author_name'     => sanitize_text_field( $data['author_name'] ?? $user->display_name ),
                'author_email'    => sanitize_email( $data['author_email'] ?? $user->user_email ),
                'reply_content'   => wp_kses_post( $data['content'] ),
                'is_agent_reply'  => absint( $data['is_agent'] ?? 0 ),
                'is_private_note' => absint( $data['is_private'] ?? 0 ),
                'created_at'      => current_time( 'mysql' ),
            ),
            array( '%d', '%d', '%s', '%s', '%s', '%d', '%d', '%s' )
        );
        if ( $result ) {
            $count = (int) get_post_meta( $data['ticket_id'], '_wsts_reply_count', true );
            update_post_meta( $data['ticket_id'], '_wsts_reply_count', $count + 1 );
            update_post_meta( $data['ticket_id'], '_wsts_last_reply_at', current_time( 'mysql' ) );
            return $wpdb->insert_id;
        }
        return false;
    }

    public static function get_replies( int $ticket_id, bool $include_private = false ): array {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        $where = $include_private ? 'ticket_id = %d' : 'ticket_id = %d AND is_private_note = 0';
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at ASC", $ticket_id ) ) ?: array(); // phpcs:ignore
    }

    public static function get_customer_ticket_ids( int $user_id, string $status = '' ): array {
        return get_posts( array(
            'post_type'   => 'support_ticket',
            'post_status' => $status ?: array( 'ticket_open', 'ticket_in_progress', 'ticket_resolved', 'ticket_closed' ),
            'meta_query'  => array( array( 'key' => '_wsts_customer_id', 'value' => $user_id ) ),
            'fields'      => 'ids',
        ) ) ?: array();
    }
}