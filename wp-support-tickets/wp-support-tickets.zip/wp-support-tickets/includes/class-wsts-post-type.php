<?php
/**
 * Register Support Ticket CPT, custom post statuses, Department taxonomy, and meta fields.
 * FILE: wp-support-tickets/includes/class-wsts-post-type.php
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Post_Type {

    public function register(): void {
        $this->register_post_type();
        $this->register_post_statuses();
        $this->register_taxonomy();
        $this->register_meta_fields();
        $this->add_admin_columns();
    }

    private function register_post_type(): void {
        register_post_type( 'support_ticket', array(
            'labels' => array(
                'name'               => __( 'Support Tickets', 'wp-support-tickets' ),
                'singular_name'      => __( 'Support Ticket',  'wp-support-tickets' ),
                'menu_name'          => __( 'Support',         'wp-support-tickets' ),
                'add_new'            => __( 'New Ticket',      'wp-support-tickets' ),
                'add_new_item'       => __( 'Create New Ticket','wp-support-tickets' ),
                'edit_item'          => __( 'Edit Ticket',     'wp-support-tickets' ),
                'not_found'          => __( 'No tickets found.','wp-support-tickets' ),
                'not_found_in_trash' => __( 'No tickets in trash.','wp-support-tickets' ),
            ),
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'show_in_rest'       => true,
            'menu_icon'          => 'dashicons-sos',
            'capability_type'    => array( 'ticket', 'tickets' ),
            'map_meta_cap'       => true,
            'supports'           => array( 'title', 'editor', 'author', 'custom-fields' ),
            'has_archive'        => false,
        ) );
    }

    private function register_post_statuses(): void {
        $statuses = array(
            'ticket_open'        => _x( 'Open',        'ticket status', 'wp-support-tickets' ),
            'ticket_in_progress' => _x( 'In Progress', 'ticket status', 'wp-support-tickets' ),
            'ticket_resolved'    => _x( 'Resolved',    'ticket status', 'wp-support-tickets' ),
            'ticket_closed'      => _x( 'Closed',      'ticket status', 'wp-support-tickets' ),
        );
        foreach ( $statuses as $status => $label ) {
            register_post_status( $status, array(
                'label'                     => $label,
                'public'                    => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                'label_count'               => _n_noop( $label . ' <span class="count">(%s)</span>', $label . ' <span class="count">(%s)</span>', 'wp-support-tickets' ),
            ) );
        }
    }

    private function register_taxonomy(): void {
        register_taxonomy( 'ticket_department', 'support_ticket', array(
            'label'        => __( 'Department', 'wp-support-tickets' ),
            'hierarchical' => true,
            'public'       => false,
            'show_ui'      => true,
            'show_in_rest' => true,
            'rewrite'      => false,
        ) );
    }

    private function register_meta_fields(): void {
        $fields = array(
            '_wsts_priority'       => 'string',
            '_wsts_customer_id'    => 'integer',
            '_wsts_customer_email' => 'string',
            '_wsts_order_id'       => 'integer',
            '_wsts_assigned_to'    => 'integer',
            '_wsts_sla_deadline'   => 'string',
            '_wsts_last_reply_at'  => 'string',
            '_wsts_reply_count'    => 'integer',
        );
        foreach ( $fields as $key => $type ) {
            register_post_meta( 'support_ticket', $key, array(
                'single'        => true,
                'type'          => $type,
                'show_in_rest'  => true,
                'auth_callback' => fn() => current_user_can( 'manage_tickets' ),
            ) );
        }
    }

    private function add_admin_columns(): void {
        add_filter( 'manage_support_ticket_posts_columns',       array( $this, 'columns' ) );
        add_action( 'manage_support_ticket_posts_custom_column', array( $this, 'column_content' ), 10, 2 );
    }

    public function columns( array $cols ): array {
        return array(
            'cb'              => $cols['cb'],
            'title'           => __( 'Subject',   'wp-support-tickets' ),
            'wsts_priority'   => __( 'Priority',  'wp-support-tickets' ),
            'wsts_status'     => __( 'Status',    'wp-support-tickets' ),
            'wsts_customer'   => __( 'Customer',  'wp-support-tickets' ),
            'wsts_replies'    => __( 'Replies',   'wp-support-tickets' ),
            'wsts_sla'        => __( 'SLA Due',   'wp-support-tickets' ),
            'date'            => __( 'Created',   'wp-support-tickets' ),
        );
    }

    public function column_content( string $col, int $post_id ): void {
        switch ( $col ) {
            case 'wsts_priority':
                $p = get_post_meta( $post_id, '_wsts_priority', true ) ?: 'normal';
                echo '<span class="wsts-priority wsts-priority--' . esc_attr( $p ) . '">' . esc_html( ucfirst( $p ) ) . '</span>';
                break;
            case 'wsts_status':
                $post   = get_post( $post_id );
                $status = get_post_status_object( $post->post_status );
                echo '<span class="wsts-status wsts-status--' . esc_attr( $post->post_status ) . '">' . esc_html( $status ? $status->label : $post->post_status ) . '</span>';
                break;
            case 'wsts_customer':
                $email = get_post_meta( $post_id, '_wsts_customer_email', true );
                echo $email ? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : '—';
                break;
            case 'wsts_replies':
                echo absint( get_post_meta( $post_id, '_wsts_reply_count', true ) );
                break;
            case 'wsts_sla':
                $deadline = get_post_meta( $post_id, '_wsts_sla_deadline', true );
                if ( $deadline ) {
                    $overdue = strtotime( $deadline ) < current_time( 'timestamp' );
                    echo '<span class="' . ( $overdue ? 'wsts-sla-overdue' : '' ) . '">' . esc_html( date_i18n( get_option( 'date_format' ) . ' H:i', strtotime( $deadline ) ) ) . '</span>';
                } else {
                    echo '—';
                }
                break;
        }
    }
}