<?php
/**
 * Shortcodes: [support_ticket_form] and [my_tickets]
 * FILE: wp-support-tickets/includes/class-wsts-shortcode.php
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Shortcode {

    /** [support_ticket_form title="Submit a Support Ticket"] */
    public function render_form( $atts ): string {
        $atts  = shortcode_atts( array( 'title' => __( 'Submit a Support Ticket', 'wp-support-tickets' ) ), $atts, 'support_ticket_form' );
        $depts = get_terms( array( 'taxonomy' => 'ticket_department', 'hide_empty' => false ) );

        ob_start();
        ?>
        <div class="wsts-ticket-form-wrap">
            <h2 class="wsts-form-title"><?php echo esc_html( $atts['title'] ); ?></h2>
            <div class="wsts-form-message" role="alert" aria-live="polite" style="display:none;"></div>
            <form id="wsts-ticket-form" class="wsts-form">
                <?php if ( ! is_user_logged_in() ) : ?>
                <div class="wsts-form-field">
                    <label><?php esc_html_e( 'Your Name', 'wp-support-tickets' ); ?> <span class="wsts-req">*</span></label>
                    <input type="text" name="name" required autocomplete="name">
                </div>
                <div class="wsts-form-field">
                    <label><?php esc_html_e( 'Your Email', 'wp-support-tickets' ); ?> <span class="wsts-req">*</span></label>
                    <input type="email" name="email" required autocomplete="email">
                </div>
                <?php endif; ?>
                <div class="wsts-form-field">
                    <label><?php esc_html_e( 'Subject', 'wp-support-tickets' ); ?> <span class="wsts-req">*</span></label>
                    <input type="text" name="subject" required placeholder="<?php esc_attr_e( 'Briefly describe your issue', 'wp-support-tickets' ); ?>">
                </div>
                <?php if ( ! empty( $depts ) && ! is_wp_error( $depts ) ) : ?>
                <div class="wsts-form-field">
                    <label><?php esc_html_e( 'Department', 'wp-support-tickets' ); ?></label>
                    <select name="department">
                        <option value=""><?php esc_html_e( 'Select Department', 'wp-support-tickets' ); ?></option>
                        <?php foreach ( $depts as $dept ) : ?>
                            <option value="<?php echo esc_attr( $dept->term_id ); ?>"><?php echo esc_html( $dept->name ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="wsts-form-field">
                    <label><?php esc_html_e( 'Priority', 'wp-support-tickets' ); ?></label>
                    <select name="priority">
                        <option value="low"><?php    esc_html_e( 'Low',      'wp-support-tickets' ); ?></option>
                        <option value="normal" selected><?php esc_html_e( 'Normal',   'wp-support-tickets' ); ?></option>
                        <option value="high"><?php   esc_html_e( 'High',     'wp-support-tickets' ); ?></option>
                        <option value="critical"><?php esc_html_e( 'Critical','wp-support-tickets' ); ?></option>
                    </select>
                </div>
                <div class="wsts-form-field">
                    <label><?php esc_html_e( 'Describe your issue', 'wp-support-tickets' ); ?> <span class="wsts-req">*</span></label>
                    <textarea name="message" rows="6" required placeholder="<?php esc_attr_e( 'Please provide as much detail as possible…', 'wp-support-tickets' ); ?>"></textarea>
                </div>
                <div class="wsts-form-field">
                    <button type="submit" class="wsts-submit-btn"><?php esc_html_e( 'Submit Ticket', 'wp-support-tickets' ); ?></button>
                </div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    /** [my_tickets] — logged-in customer's ticket history. */
    public function render_my_tickets( $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<p class="wsts-notice">' .
                esc_html__( 'Please log in to view your tickets.', 'wp-support-tickets' ) .
                ' <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">' .
                esc_html__( 'Log in', 'wp-support-tickets' ) . '</a></p>';
        }

        $ticket_ids = WSTS_Database::get_customer_ticket_ids( get_current_user_id() );

        ob_start();
        if ( empty( $ticket_ids ) ) {
            echo '<p class="wsts-notice">' . esc_html__( 'You have not submitted any tickets yet.', 'wp-support-tickets' ) . '</p>';
        } else {
            ?>
            <div class="wsts-my-tickets-wrap">
                <table class="wsts-my-tickets">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( '#',        'wp-support-tickets' ); ?></th>
                            <th><?php esc_html_e( 'Subject',  'wp-support-tickets' ); ?></th>
                            <th><?php esc_html_e( 'Status',   'wp-support-tickets' ); ?></th>
                            <th><?php esc_html_e( 'Priority', 'wp-support-tickets' ); ?></th>
                            <th><?php esc_html_e( 'Replies',  'wp-support-tickets' ); ?></th>
                            <th><?php esc_html_e( 'Date',     'wp-support-tickets' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $ticket_ids as $id ) :
                        $post     = get_post( $id );
                        $status   = get_post_status_object( $post->post_status );
                        $priority = get_post_meta( $id, '_wsts_priority', true );
                        $replies  = (int) get_post_meta( $id, '_wsts_reply_count', true );
                    ?>
                    <tr>
                        <td>#<?php echo absint( $id ); ?></td>
                        <td><?php echo esc_html( $post->post_title ); ?></td>
                        <td><span class="wsts-status wsts-status--<?php echo esc_attr( $post->post_status ); ?>"><?php echo esc_html( $status ? $status->label : $post->post_status ); ?></span></td>
                        <td><span class="wsts-priority wsts-priority--<?php echo esc_attr( $priority ); ?>"><?php echo esc_html( ucfirst( $priority ) ); ?></span></td>
                        <td><?php echo absint( $replies ); ?></td>
                        <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $post->post_date ) ) ); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php
        }
        return ob_get_clean();
    }
}