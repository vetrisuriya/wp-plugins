<?php
/**
 * AJAX: ticket submission, replies, status updates.
 * FILE: wp-support-tickets/includes/class-wsts-ajax.php
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Ajax {

    public function submit_ticket(): void {
        check_ajax_referer( 'wsts_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => __( 'You must be logged in to submit a ticket.', 'wp-support-tickets' ) ) );
        }

        $user     = wp_get_current_user();
        $subject  = sanitize_text_field( wp_unslash( $_POST['subject']  ?? '' ) );
        $message  = wp_kses_post( wp_unslash( $_POST['message']  ?? '' ) );
        $priority = sanitize_text_field( wp_unslash( $_POST['priority'] ?? 'normal' ) );
        $dept     = absint( $_POST['department'] ?? 0 );
        $order_id = absint( $_POST['order_id']   ?? 0 );

        if ( ! $subject || ! $message ) {
            wp_send_json_error( array( 'message' => __( 'Subject and message are required.', 'wp-support-tickets' ) ) );
        }
        if ( ! in_array( $priority, array( 'low', 'normal', 'high', 'critical' ), true ) ) $priority = 'normal';

        $ticket_id = wp_insert_post( array(
            'post_type'    => 'support_ticket',
            'post_status'  => 'ticket_open',
            'post_title'   => $subject,
            'post_content' => $message,
            'post_author'  => $user->ID,
        ) );

        if ( is_wp_error( $ticket_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Could not create ticket. Please try again.', 'wp-support-tickets' ) ) );
        }

        update_post_meta( $ticket_id, '_wsts_priority',       $priority );
        update_post_meta( $ticket_id, '_wsts_customer_id',    $user->ID );
        update_post_meta( $ticket_id, '_wsts_customer_email', $user->user_email );
        update_post_meta( $ticket_id, '_wsts_reply_count',    0 );
        if ( $order_id ) update_post_meta( $ticket_id, '_wsts_order_id', $order_id );
        if ( $dept )     wp_set_post_terms( $ticket_id, array( $dept ), 'ticket_department' );

        $opts      = WSTS_Settings::get_options();
        $sla_hours = $opts[ 'sla_hours_' . $priority ] ?? $opts['sla_hours_normal'];
        update_post_meta( $ticket_id, '_wsts_sla_deadline',
            gmdate( 'Y-m-d H:i:s', strtotime( "+{$sla_hours} hours", current_time( 'timestamp' ) ) )
        );

        ( new WSTS_Notifications() )->on_new_ticket( $ticket_id );
        WSTS_Transients::invalidate();

        wp_send_json_success( array(
            'message'   => __( 'Your ticket has been submitted. We will get back to you shortly.', 'wp-support-tickets' ),
            'ticket_id' => $ticket_id,
        ) );
    }

    public function guest_submit_ticket(): void {
        check_ajax_referer( 'wsts_nonce', 'nonce' );

        $name    = sanitize_text_field( wp_unslash( $_POST['name']    ?? '' ) );
        $email   = sanitize_email(      wp_unslash( $_POST['email']   ?? '' ) );
        $subject = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );
        $message = wp_kses_post(        wp_unslash( $_POST['message'] ?? '' ) );

        if ( ! $name || ! is_email( $email ) || ! $subject || ! $message ) {
            wp_send_json_error( array( 'message' => __( 'All fields are required.', 'wp-support-tickets' ) ) );
        }

        $ticket_id = wp_insert_post( array(
            'post_type'    => 'support_ticket',
            'post_status'  => 'ticket_open',
            'post_title'   => $subject,
            'post_content' => $message,
            'post_author'  => 0,
        ) );

        if ( is_wp_error( $ticket_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Could not create ticket.', 'wp-support-tickets' ) ) );
        }

        update_post_meta( $ticket_id, '_wsts_customer_email', $email );
        update_post_meta( $ticket_id, '_wsts_priority',       'normal' );

        ( new WSTS_Notifications() )->on_new_ticket( $ticket_id );

        wp_send_json_success( array( 'message' => __( 'Your ticket has been submitted. We will reply to your email shortly.', 'wp-support-tickets' ) ) );
    }

    public function post_reply(): void {
        check_ajax_referer( 'wsts_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => __( 'Login required.', 'wp-support-tickets' ) ) );
        }

        $ticket_id  = absint( $_POST['ticket_id'] ?? 0 );
        $content    = wp_kses_post( wp_unslash( $_POST['content'] ?? '' ) );
        $is_private = ( isset( $_POST['is_private'] ) && current_user_can( 'manage_tickets' ) ) ? 1 : 0;

        if ( ! $ticket_id || ! $content ) {
            wp_send_json_error( array( 'message' => __( 'Ticket ID and content are required.', 'wp-support-tickets' ) ) );
        }

        $customer_id = (int) get_post_meta( $ticket_id, '_wsts_customer_id', true );
        $is_agent    = current_user_can( 'manage_tickets' );
        $is_owner    = get_current_user_id() === $customer_id;

        if ( ! $is_agent && ! $is_owner ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-support-tickets' ) ) );
        }

        $reply_id = WSTS_Database::insert_reply( array(
            'ticket_id'  => $ticket_id,
            'content'    => $content,
            'is_agent'   => $is_agent ? 1 : 0,
            'is_private' => $is_private,
        ) );

        if ( ! $reply_id ) {
            wp_send_json_error( array( 'message' => __( 'Failed to post reply.', 'wp-support-tickets' ) ) );
        }

        if ( $is_agent ) {
            wp_update_post( array( 'ID' => $ticket_id, 'post_status' => 'ticket_in_progress' ) );
        }

        wp_send_json_success( array( 'message' => __( 'Reply posted.', 'wp-support-tickets' ) ) );
    }

    public function update_status(): void {
        check_ajax_referer( 'wsts_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_tickets' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-support-tickets' ) ) );
        }

        $ticket_id = absint( $_POST['ticket_id'] ?? 0 );
        $status    = sanitize_text_field( wp_unslash( $_POST['status'] ?? '' ) );
        $allowed   = array( 'ticket_open', 'ticket_in_progress', 'ticket_resolved', 'ticket_closed' );

        if ( ! $ticket_id || ! in_array( $status, $allowed, true ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid data.', 'wp-support-tickets' ) ) );
        }

        wp_update_post( array( 'ID' => $ticket_id, 'post_status' => $status ) );
        WSTS_Transients::invalidate();

        wp_send_json_success( array( 'message' => __( 'Status updated.', 'wp-support-tickets' ), 'status' => $status ) );
    }
}