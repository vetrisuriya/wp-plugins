<?php
/**
 * Capabilities: Agent vs Customer roles.
 * FILE: wp-support-tickets/includes/class-wsts-capabilities.php
 * @package WPSupportTickets
 */
defined( 'ABSPATH' ) || exit;

class WSTS_Capabilities {

    public static function add_caps(): void {
        $admin_caps = array(
            'manage_tickets', 'reply_ticket', 'close_ticket', 'assign_ticket',
            'delete_ticket', 'view_all_tickets', 'view_private_notes',
            'edit_ticket', 'read_ticket', 'edit_tickets', 'edit_others_tickets',
            'publish_tickets', 'read_private_tickets', 'delete_tickets',
        );
        foreach ( array( 'administrator', 'editor' ) as $role_name ) {
            $role = get_role( $role_name );
            if ( $role ) {
                foreach ( $admin_caps as $cap ) $role->add_cap( $cap );
            }
        }
        if ( ! get_role( 'support_agent' ) ) {
            add_role( 'support_agent', __( 'Support Agent', 'wp-support-tickets' ), array(
                'read'             => true,
                'manage_tickets'   => true,
                'reply_ticket'     => true,
                'close_ticket'     => true,
                'view_all_tickets' => true,
                'edit_tickets'     => true,
                'edit_ticket'      => true,
                'read_ticket'      => true,
            ) );
        }
        $subscriber = get_role( 'subscriber' );
        if ( $subscriber ) $subscriber->add_cap( 'submit_ticket' );
    }

    public static function remove_caps(): void {
        remove_role( 'support_agent' );
        foreach ( array( 'administrator', 'editor' ) as $role_name ) {
            $role = get_role( $role_name );
            if ( $role ) {
                $role->remove_cap( 'manage_tickets' );
                $role->remove_cap( 'view_all_tickets' );
            }
        }
    }
}