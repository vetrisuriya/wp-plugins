wp-stats-counter/
├── wp-stats-counter.php    ← wpsc-wp-stats-counter.php
├── block.json              ← wpsc-block.json  (at root — paths correct)
├── uninstall.php / readme.txt / package.json
├── build/
│   ├── index.js            ← wpsc-build-index.js      (all bugs fixed)
│   ├── index.asset.php
│   ├── view.js             ← wpsc-build-view.js        (vanilla JS)
│   ├── view.asset.php
│   ├── style-index.css     ← wpsc-build-style-index.css
│   └── editor.css          ← wpsc-build-editor.css
└── src/
    ├── index.js            ← wpsc-src-index.js         (registerBlockStyle fixed)
    ├── edit.js             ← copy from reference + 2 fixes
    ├── save.js             ← wpsc-src-save.js
    ├── view.js             ← wpsc-src-view.js           (Interactivity API ESM)
    ├── transforms.js       ← wpsc-src-transforms.js
    ├── editor.scss         ← copy from reference as-is
    └── style.scss          ← copy from reference as-is