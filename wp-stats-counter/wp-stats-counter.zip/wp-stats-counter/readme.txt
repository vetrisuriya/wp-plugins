=== WP Animated Stats Counter Block ===
Contributors:      yourname
Tags:              stats counter, animated counter, numbers, gutenberg block, scroll animation
Requires at least: 6.4
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      8.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Animated number counters that count up when scrolled into view. No jQuery, no external library.

== Description ==

**WP Animated Stats Counter Block** adds a "by the numbers" grid to any page — perfect for landing pages, portfolio sites, nonprofit impact sections, and SaaS pricing pages.

= Key Features =

* **Scroll-triggered animation** — IntersectionObserver fires the counter when 30% of the block enters the viewport
* **easeOutCubic easing** — fast start, satisfying slow finish
* **Per-stat configuration** — prefix ($, €), suffix (%, +, hr), decimal places, thousands separator
* **Inline editing** — click any stat card to edit its label and description on the canvas
* **Sidebar number editing** — set the target value, prefix, and suffix from Inspector Controls
* **1–6 columns** — responsive grid with CSS custom property `--stat-columns`
* **Four Block Styles** — Minimal (default), Cards, Gradient Background, Bordered
* **Block Transforms** — convert Heading blocks to stats and stats back to Headings
* **Three Block Patterns** — Business Stats, Nonprofit Impact, SaaS Metrics (pre-filled)
* **prefers-reduced-motion** — shows final values immediately for users who prefer no motion
* **Accessible** — `aria-live="polite"` on number containers; screen readers announce final value
* **Zero external dependencies** — vanilla JS + Web APIs only
* **No build step required** — ships with pre-compiled `build/` directory

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload Plugin**
2. In the block editor, search for **Stats Counter**
3. Insert the block — three default stats appear (Customers, Uptime, Support)
4. Click any stat card and edit the label inline; open the sidebar to change the number, prefix, and suffix
5. Click **+ Add Stat** to add more cards

== Frequently Asked Questions ==

= Do I need Node.js to use this plugin? =
No. The plugin ships with a pre-compiled `build/` directory. Upload and activate — it works immediately.

= How does the scroll animation work? =
The IntersectionObserver API watches the block wrapper. When 30% of the block becomes visible in the viewport, the `requestAnimationFrame` count-up loop starts. It uses an easeOutCubic curve: fast start that slows near the end.

= What happens on browsers without IntersectionObserver? =
The counter runs immediately on DOMContentLoaded as a fallback.

= What if the user has prefers-reduced-motion enabled? =
The final values are shown immediately with no animation — the CSS `animation:none` and the JS `duration:1` fallback work together.

= Can I change the animation speed? =
Yes — open the **Animation** panel in the right sidebar and adjust the **Animation Duration (ms)** slider (500–5000ms).

= How do I convert existing Heading blocks into a Stats Counter? =
Select multiple Heading blocks (Shift+click), then click **Transform to → Stats Counter** in the block toolbar. The plugin parses numbers from the heading text.

== Changelog ==

= 1.0.0 =
* Initial release. Scroll-triggered counter animation. 4 Block Styles. Block Transforms (from/to Headings). 3 Block Patterns. prefers-reduced-motion support. Accessible aria-live. Zero external JS dependencies.