# WP Animated Stats Counter Block — User Guide

## Table of Contents

- [Why This Block Exists](#why-this-block-exists)
- [Folder Structure](#folder-structure)
- [Installation](#installation)
- [How to Use the Block](#how-to-use-the-block)
  - [Inserting the Block](#inserting-the-block)
  - [Adding Stats](#adding-stats)
  - [Editing Each Stat](#editing-each-stat)
  - [Columns & Alignment](#columns--alignment)
  - [Animation Settings](#animation-settings)
- [Inspector Controls Reference](#inspector-controls-reference)
- [Block Styles](#block-styles)
- [Block Patterns](#block-patterns)
- [Block Transforms](#block-transforms)
- [How the Animation Works](#how-the-animation-works)
- [Accessibility & Reduced Motion](#accessibility--reduced-motion)
- [For Developers — Build from Source](#for-developers--build-from-source)
- [FAQ](#faq)

---

## Why This Block Exists

Landing pages need "by the numbers" sections — **10,000+ Customers**, **99% Uptime**, **48hr Support** — but WordPress has no native animated counter block. Without this plugin, editors paste numbers into Heading blocks and lose:

- Scroll-triggered animation (counter runs on page load, not when visible)
- Prefix control (`$`, `€`, `£`)
- Suffix control (`+`, `%`, `K`, `hr`)
- Decimal places and thousands separator formatting
- Ability to re-style without re-entering data

Third-party counter plugins typically bundle jQuery CountUp.js on every page. This block uses **zero external JavaScript** — just the Web APIs (`IntersectionObserver` + `requestAnimationFrame`) already in every modern browser.

---

## Folder Structure

```
wp-stats-counter/
├── wp-stats-counter.php        ← wpsc-wp-stats-counter.php
├── block.json                  ← wpsc-block.json  (standalone, at root)
├── uninstall.php               ← wpsc-uninstall.php
├── readme.txt                  ← wpsc-readme.txt
├── package.json                ← wpsc-package.json  (uuid dep included)
│
├── build/                      (pre-compiled — no npm needed)
│   ├── index.js                ← wpsc-build-index.js     (all 3 bugs fixed)
│   ├── index.asset.php         ← wpsc-build-index.asset.php
│   ├── view.js                 ← wpsc-build-view.js      (vanilla JS)
│   ├── view.asset.php          ← wpsc-build-view.asset.php
│   ├── style-index.css         ← wpsc-build-style-index.css
│   └── editor.css              ← wpsc-build-editor.css
│
└── src/                        (JSX source — for developers who run npm build)
    ├── index.js                ← wpsc-src-index.js     (registerBlockStyle FIXED)
    ├── edit.js                 ← from reference .md    (apply fixes listed below)
    ├── save.js                 ← wpsc-src-save.js
    ├── view.js                 ← wpsc-src-view.js      (Interactivity API ESM)
    ├── transforms.js           ← wpsc-src-transforms.js
    ├── editor.scss             ← from reference .md
    └── style.scss              ← from reference .md
```

---

## Installation

1. Build the `wp-stats-counter/` folder with the structure above
2. ZIP the entire folder
3. Go to **Plugins → Add New → Upload Plugin**
4. Upload and click **Install Now → Activate Plugin**

No `npm install` needed — the `build/` directory is pre-compiled and ready to use.

---

## How to Use the Block

### Inserting the Block

1. Open any post or page in the block editor
2. Click the **+** inserter and search for **Stats Counter**
3. Insert — three pre-filled stats appear: `10,000+ Happy Customers`, `99.9% Uptime`, `48hr Support Response`

**Or via Block Patterns:** Go to the Patterns tab in the inserter → **Stats Counter** category → choose from Business Stats, Nonprofit Impact, or SaaS Metrics.

### Adding Stats

Click **+ Add Stat** below the grid to add a new blank card. The new card is immediately selected for editing in the sidebar.

To remove a card: hover over it — a red **×** button appears in the top-right corner. Click it to remove.

### Editing Each Stat

**On canvas (label + description):**
Click any stat card to select it, then click directly on the label or description text to edit inline.

**In Inspector Controls sidebar (number + formatting):**
Click a stat card → the "Edit: [Label]" panel opens in the right sidebar with:

| Field | What it controls |
|---|---|
| **Number Value** | The target number the counter animates to |
| **Prefix** | Text before the number (e.g. `$`, `€`, `£`) |
| **Suffix** | Text after the number (e.g. `+`, `%`, `hr`, `K`) |
| **Decimal Places** | 0 for whole numbers, 1 for `99.9`, 2 for `4.99` |
| **Thousands Separator** | Format `10000` as `10,000` |

### Columns & Alignment

**Columns (1–6):** Inspector Controls → Layout → Columns slider.  
**Quick column select:** Block toolbar → Grid icon dropdown → pick 1–6.

The grid uses CSS `--stat-columns` custom property so it responds automatically to the chosen count.

**Number Alignment:** Left, Centre, or Right — applied to both the number row and the label text below it.

### Animation Settings

Open **Animation** in Inspector Controls:

- **Animate on scroll** — On (default) triggers the count-up when the block scrolls into view. Off = animate immediately on page load.
- **Animation Duration (ms)** — 2000ms (2 seconds) is the recommended default. Range: 500–5000ms.

---

## Inspector Controls Reference

| Panel | Setting | Default | Description |
|---|---|---|---|
| Layout | **Columns** | 3 | Cards per row. 1–6. Responsive grid on mobile. |
| Layout | **Number Alignment** | Center | Left / Center / Right |
| Animation | **Animate on scroll** | On | IntersectionObserver scroll trigger |
| Animation | **Animation Duration (ms)** | 2000 | Count-up speed |
| Edit: [Label] | **Number Value** | 0 | Target number |
| Edit: [Label] | **Prefix** | "" | Before the number |
| Edit: [Label] | **Suffix** | "" | After the number |
| Edit: [Label] | **Decimal Places** | 0 | Decimal precision |
| Edit: [Label] | **Thousands Separator** | On | 10000 → 10,000 |

---

## Block Styles

Click the **Styles icon** in the block toolbar (paint/circle icon).

| Style | Appearance |
|---|---|
| **Minimal** (default) | Numbers and labels with no background. Inherits theme colours. |
| **Cards** | Each stat in a white rounded card with a soft drop shadow. |
| **Gradient Background** | Entire block wrapped in an indigo-to-dark-blue gradient with white text. |
| **Bordered** | Each stat card with a solid `currentColor` border and 8px radius. |

---

## Block Patterns

Pre-filled patterns in the Patterns tab under **Stats Counter**:

| Pattern | Columns | Pre-filled |
|---|---|---|
| **Business Stats — 4 Metrics** | 4 | 10,000+ Customers, 99.9% Uptime, 48hr Support, 4.9/5 Rating |
| **Nonprofit Impact Numbers** | 3 | 50,000+ Lives, 120 Countries, $5,000,000 Raised |
| **SaaS Metrics** | 3 | 1,000,000+ API Calls, 99.99% Availability, 12ms Response |

---

## Block Transforms

### Heading blocks → Stats Counter

1. Select multiple **Heading blocks** in the editor (Shift+click or use List View Ctrl+click)
2. Block toolbar shows **Transform to…**
3. Click **Stats Counter**

Each heading's first number becomes the stat value; remaining text becomes the label.

Example: `Heading: "10,000 Customers"` → `value: 10000`, `label: "Customers"`.

The transform is **approximate** — always review values after transforming, especially for headings with complex formatting.

### Stats Counter → Group of Headings

Select the Stats Counter block → **Transform to → Group**. Each stat becomes an h3 Heading formatted as `{prefix}{value}{suffix} {label}`.

---

## How the Animation Works

### 1. Server side (render)

`save.js` outputs the final formatted values as the initial text content of each `.stat-value` span. Without JavaScript, the page shows the correct final numbers.

Each stat card also carries data attributes:
```html
<div class="stat-item"
     data-stat-value="10000"
     data-stat-decimals="0"
     data-stat-separator="true">
```

The block wrapper has:
```html
<div data-wp-interactive="wp-stats-counter/counter"
     data-wp-context='{"duration":2000,"animateOnScroll":true,"animated":false}'
     data-wp-init="callbacks.initObserver">
```

### 2. Client side (build/view.js)

On `DOMContentLoaded`:
1. Finds all `[data-wp-interactive="wp-stats-counter/counter"]` wrappers
2. Reads the JSON from `data-wp-context`
3. Checks `prefers-reduced-motion` — if true, shows final values immediately
4. If `animateOnScroll: false` — starts animation immediately
5. Otherwise sets up an `IntersectionObserver` with `threshold: 0.3`

On intersection (30% visible):
1. Reads `data-stat-value`, `data-stat-decimals`, `data-stat-separator` from each `.stat-item`
2. Starts `requestAnimationFrame` loop with `startTime = performance.now()`
3. Each frame: `progress = elapsed / duration`, `eased = easeOutCubic(progress)`
4. Updates `.stat-value` textContent with `formatNumber(target × eased, ...)`
5. At `progress === 1`: snaps to exact final values (avoids floating-point drift)

### 3. easeOutCubic explained

```
easeOutCubic(t) = 1 - (1 - t)³
```

At t=0.1 → eased=0.271 (27% done in 10% of time — fast start)  
At t=0.5 → eased=0.875 (87% done at halfway — already slowing)  
At t=0.9 → eased=0.999 (virtually at end — smooth stop)

This is what makes counter animations feel satisfying rather than mechanical. Never use linear easing for number animations.

---

## Accessibility & Reduced Motion

### `aria-live="polite"`

Each `.stat-number` has `aria-live="polite"`. Screen readers announce the final value after the animation completes — not every intermediate step (which would be chaotic).

### prefers-reduced-motion

Users who enable reduced motion in OS settings (Windows: Reduce animations; macOS: Reduce motion) receive final values immediately:

```css
@media (prefers-reduced-motion: reduce) {
    .wp-block-wp-stats-counter-counter .stat-value {
        transition: none !important;
        animation:  none !important;
    }
}
```

```js
// In build/view.js
var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (prefersReduced) {
    runCountUp(block, 1); // duration = 1ms → instant snap to final values
    return;
}
```

---

## For Developers — Build from Source

### Requirements

- Node.js 18+, npm 8+

### Setup

```bash
cd wp-content/plugins/wp-stats-counter
npm install          # installs @wordpress/scripts + uuid
npm run build        # → build/index.js, build/view.js, build/style-index.css, build/editor.css
npm run start        # Watch mode (rebuilds on file save)
```

### Fixes to apply to `src/edit.js` before building

Copy `edit.js` from the reference file (`WP_Block_07_Stats_Counter.md`), then:

**Fix 1 — Add stability comment above experimental import:**
```js
// NOTE: __experimentalNumberControl may change in future WordPress releases.
// Stable alternative: <TextControl type="number" ... />
// Monitor: https://github.com/WordPress/gutenberg/blob/trunk/packages/components/CHANGELOG.md
import { __experimentalNumberControl as NumberControl } from '@wordpress/components';
```

**Fix 2 — uuid is now in package.json, no code change needed:**
```js
import { v4 as uuidv4 } from 'uuid'; // ← works after npm install
```

The block name in `edit.js` uses `my-blocks/stats-counter` in the reference — update to `wp-stats-counter/counter` to match the standalone plugin.

### Copying editor.scss and style.scss

Copy both SCSS files from the reference `.md` file as-is — they are correct. The `@wordpress/scripts` build compiles them automatically.

---

## FAQ

**The counter doesn't animate — numbers stay static.**
Open DevTools → Console. Check for 404 errors on `build/view.js`. Confirm the file exists at `wp-stats-counter/build/view.js`. Also inspect the block wrapper element — it should have `data-wp-interactive="wp-stats-counter/counter"` and `data-wp-context` attributes.

**The counter runs immediately, not on scroll.**
Check that `animateOnScroll: true` is in the `data-wp-context` attribute. If the attribute says `false`, the `animateOnScroll` block attribute may have been toggled off in the editor sidebar.

**The number shows `NaN` or `0`.**
Inspect a `.stat-item` element — confirm `data-stat-value` is a valid number (not empty, not a string like `"10,000"`). The value stored in the block attribute should always be a raw number (`10000`), not formatted.

**Block Styles panel is empty in the editor.**
This was Bug 1 — `registerBlockStyle()` was called with an array. Make sure you are using `wpsc-build-index.js` (pre-compiled, fixed) or apply the fix to `src/index.js`.

**The Block Transform didn't parse the number correctly.**
The regex `/[\d,.]+/` extracts the first sequence of digits and commas. It won't handle `10K` or `$1M`. After transforming, manually correct the value in the sidebar for each stat that didn't parse correctly.

**How do I make the counter start earlier (trigger sooner)?**
In `build/view.js`, change the `threshold: 0.3` (30% visible) to `threshold: 0.1` (10% visible). This triggers the animation earlier as the block enters the viewport.