<?php
/**
 * Plugin Name:       WP Animated Stats Counter Block
 * Plugin URI:        https://example.com/wp-stats-counter
 * Description:       Animated number counters that count up when scrolled into view. Scroll-triggered via IntersectionObserver, easeOutCubic animation, prefix/suffix/decimals/separator support. Zero external dependencies.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            Your Name
 * Author URI:        https://example.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-stats-counter
 * Domain Path:       /languages
 *
 * @package WP_Stats_Counter
 */

defined( 'ABSPATH' ) || exit;

define( 'WPASC_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPASC_URL', plugin_dir_url( __FILE__ ) );
define( 'WPASC_VER', '1.0.0' );

/**
 * Register the block.
 *
 * block.json is at the PLUGIN ROOT — all file:// paths resolve correctly:
 *   "editorScript":    "file:./build/index.js"  → wp-stats-counter/build/index.js  ✅
 *   "viewScriptModule":"file:./build/view.js"   → wp-stats-counter/build/view.js   ✅
 *   "style":           "file:./build/style-index.css"                               ✅
 *   "editorStyle":     "file:./build/editor.css"                                    ✅
 *
 * NOTE: The reference placed block.json inside blocks/stats-counter/ as part of
 * a multi-block my-blocks/ plugin. As a standalone plugin, block.json at root
 * is cleaner and avoids nested path resolution issues seen in Blocks 01–03.
 */
add_action( 'init', 'wpasc_register_block' );
function wpasc_register_block(): void {
    register_block_type( WPASC_DIR . 'block.json' );

    load_plugin_textdomain(
        'wp-stats-counter',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );
}

/**
 * Register block patterns.
 */
add_action( 'init', 'wpasc_register_patterns' );
function wpasc_register_patterns(): void {
    register_block_pattern_category(
        'wp-stats-counter',
        array( 'label' => __( 'Stats Counter', 'wp-stats-counter' ) )
    );

    register_block_pattern(
        'wp-stats-counter/business-stats',
        array(
            'title'       => __( 'Business Stats — 4 Metrics', 'wp-stats-counter' ),
            'description' => __( 'Four key business metrics: customers, uptime, support speed, rating.', 'wp-stats-counter' ),
            'categories'  => array( 'wp-stats-counter', 'featured' ),
            'content'     => '<!-- wp:wp-stats-counter/counter {"columns":4,"animationDuration":2000,"stats":[{"id":"b1","value":10000,"prefix":"","suffix":"+","separator":true,"decimals":0,"label":"Customers Served","description":""},{"id":"b2","value":99.9,"prefix":"","suffix":"%","separator":false,"decimals":1,"label":"Uptime SLA","description":""},{"id":"b3","value":48,"prefix":"","suffix":"hr","separator":false,"decimals":0,"label":"Support Response","description":""},{"id":"b4","value":4.9,"prefix":"","suffix":"/5","separator":false,"decimals":1,"label":"Average Rating","description":""}]} /-->',
        )
    );

    register_block_pattern(
        'wp-stats-counter/impact-numbers',
        array(
            'title'       => __( 'Nonprofit Impact Numbers', 'wp-stats-counter' ),
            'description' => __( 'Three impact stats: lives, countries, funds raised.', 'wp-stats-counter' ),
            'categories'  => array( 'wp-stats-counter' ),
            'content'     => '<!-- wp:wp-stats-counter/counter {"columns":3,"stats":[{"id":"n1","value":50000,"prefix":"","suffix":"+","separator":true,"decimals":0,"label":"Lives Impacted","description":""},{"id":"n2","value":120,"prefix":"","suffix":"","separator":false,"decimals":0,"label":"Countries Reached","description":""},{"id":"n3","value":5000000,"prefix":"$","suffix":"","separator":true,"decimals":0,"label":"Funds Raised","description":""}]} /-->',
        )
    );

    register_block_pattern(
        'wp-stats-counter/saas-metrics',
        array(
            'title'       => __( 'SaaS Metrics', 'wp-stats-counter' ),
            'categories'  => array( 'wp-stats-counter' ),
            'content'     => '<!-- wp:wp-stats-counter/counter {"columns":3,"stats":[{"id":"m1","value":1000000,"prefix":"","suffix":"+","separator":true,"decimals":0,"label":"API Calls Daily","description":""},{"id":"m2","value":99.99,"prefix":"","suffix":"%","separator":false,"decimals":2,"label":"Availability","description":""},{"id":"m3","value":12,"prefix":"","suffix":"ms","separator":false,"decimals":0,"label":"Avg Response Time","description":""}]} /-->',
        )
    );
}