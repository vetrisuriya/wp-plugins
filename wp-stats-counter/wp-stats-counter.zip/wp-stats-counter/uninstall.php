<?php
/**
 * uninstall.php — Runs when the plugin is deleted from WordPress Plugins screen.
 * FILE: wp-stats-counter/uninstall.php
 *
 * Counter data is stored in post_content as block comment delimiters.
 * No custom database tables or options stored in v1.0.0 — nothing to clean up.
 *
 * @package WP_Stats_Counter
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
// No DB cleanup required for v1.0.0. Add cleanup here for future options.