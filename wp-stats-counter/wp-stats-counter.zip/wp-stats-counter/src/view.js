/**
 * src/view.js — Frontend Interactivity API store for Stats Counter.
 * FILE: wp-stats-counter/src/view.js
 *
 * WordPress Interactivity API (WP 6.5+) — loaded as ES Module.
 * Registered via block.json "viewScriptModule" field.
 * Loaded ONLY on pages that contain the block — zero overhead elsewhere.
 *
 * For sites running WP < 6.5 or for the pre-compiled build,
 * build/view.js provides a vanilla JS fallback with identical behaviour.
 *
 * HOW IT WORKS:
 *  1. data-wp-init="callbacks.initObserver" on the block wrapper calls
 *     initObserver() immediately after Interactivity API hydrates the element.
 *  2. initObserver() sets up an IntersectionObserver via getElement().ref
 *  3. When 30% of the block is visible, runCountUp() fires.
 *  4. runCountUp() reads data-stat-value from each .stat-item and uses
 *     requestAnimationFrame + easeOutCubic to animate .stat-value text.
 *  5. ctx.animated prevents the animation from re-triggering.
 *  6. The callback return function disconnects the observer on SPA navigation.
 */
import { store, getContext, getElement } from '@wordpress/interactivity';

function easeOutCubic( t ) {
    return 1 - Math.pow( 1 - t, 3 );
}

function formatNumber( value, decimals, separator ) {
    if ( separator ) {
        return value.toLocaleString( 'en-US', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals,
        } );
    }
    return value.toFixed( decimals );
}

store( 'wp-stats-counter/counter', {
    callbacks: {
        initObserver() {
            const ctx     = getContext();
            const { ref } = getElement();

            if ( ! ctx.animateOnScroll ) {
                this.callbacks.runCountUp.call( this );
                return;
            }

            const observer = new IntersectionObserver(
                ( entries ) => {
                    entries.forEach( ( entry ) => {
                        if ( entry.isIntersecting && ! ctx.animated ) {
                            this.callbacks.runCountUp.call( this );
                            observer.unobserve( ref );
                        }
                    } );
                },
                { threshold: 0.3 }
            );

            observer.observe( ref );

            return () => observer.disconnect();
        },

        runCountUp() {
            const ctx      = getContext();
            const { ref }  = getElement();
            const items    = [ ...ref.querySelectorAll( '.stat-item' ) ];
            const duration = ctx.duration || 2000;

            if ( ! items.length ) return;

            const targets = items.map( ( el ) => ( {
                target:    parseFloat( el.dataset.statValue )    || 0,
                decimals:  parseInt( el.dataset.statDecimals, 10 ) || 0,
                separator: el.dataset.statSeparator === 'true',
                el:        el.querySelector( '.stat-value' ),
            } ) );

            ctx.animated = true;
            const startTime = performance.now();

            function tick( now ) {
                const elapsed  = now - startTime;
                const progress = Math.min( elapsed / duration, 1 );
                const eased    = easeOutCubic( progress );

                targets.forEach( ( { target, decimals, separator, el } ) => {
                    if ( el ) el.textContent = formatNumber( target * eased, decimals, separator );
                } );

                if ( progress < 1 ) {
                    requestAnimationFrame( tick );
                } else {
                    targets.forEach( ( { target, decimals, separator, el } ) => {
                        if ( el ) el.textContent = formatNumber( target, decimals, separator );
                    } );
                }
            }

            requestAnimationFrame( tick );
        },
    },
} );