/**
 * src/index.js — Block registration entry point (JSX source).
 * FILE: wp-stats-counter/src/index.js
 *
 * MISSING FROM REFERENCE — created from scratch.
 * Compiled to: build/index.js by @wordpress/scripts
 *
 * BUG FIX: Reference called registerBlockStyle( name, [ array ] ) — invalid.
 * Fixed to individual calls below.
 */
import { registerBlockType, registerBlockStyle } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';

import Edit       from './edit';
import save       from './save';
import transforms from './transforms';
import metadata   from '../block.json';
import './style.scss';
import './editor.scss';

/* ── Block Styles — FIXED: one call per style, not an array ─────── */
registerBlockStyle( 'wp-stats-counter/counter', {
    name:      'minimal',
    label:     __( 'Minimal', 'wp-stats-counter' ),
    isDefault: true,
} );
registerBlockStyle( 'wp-stats-counter/counter', {
    name:  'cards',
    label: __( 'Cards', 'wp-stats-counter' ),
} );
registerBlockStyle( 'wp-stats-counter/counter', {
    name:  'gradient',
    label: __( 'Gradient Background', 'wp-stats-counter' ),
} );
registerBlockStyle( 'wp-stats-counter/counter', {
    name:  'bordered',
    label: __( 'Bordered', 'wp-stats-counter' ),
} );

/* ── Register block ─────────────────────────────────────────────── */
registerBlockType( metadata.name, {
    edit: Edit,
    save,
    transforms,
} );