/**
 * src/transforms.js — Block transforms for Stats Counter.
 * FILE: wp-stats-counter/src/transforms.js
 *
 * BUG FIX vs REFERENCE:
 *   uuid imported but NOT in package.json. Fixed: uuid added to package.json.
 *   If you prefer no external dep, replace uuidv4() with the inline generator
 *   used in build/index.js.
 *
 * WHAT THIS ENABLES:
 *   FROM: Select multiple Heading blocks → Transform to → Stats Counter
 *         Each heading's numeric content becomes a stat value; remaining text → label.
 *   TO:   Stats Counter → Transform to → Group of Heading blocks (explode back).
 */
import { createBlock } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import { v4 as uuidv4 } from 'uuid'; // npm install uuid — already in package.json

const transforms = {
    from: [
        {
            type:         'block',
            blocks:       [ 'core/heading' ],
            isMultiBlock: true,
            transform( headings ) {
                const stats = headings.map( ( heading ) => {
                    const text     = heading.attributes.content || '';
                    const numMatch = text.match( /[\d,.]+/ );
                    const value    = numMatch ? parseFloat( numMatch[0].replace( /,/g, '' ) ) : 0;
                    const label    = text.replace( /[\d,.]+/, '' ).trim();
                    return {
                        id:          uuidv4(),
                        value,
                        prefix:      '',
                        suffix:      '',
                        separator:   true,
                        decimals:    0,
                        label,
                        description: '',
                    };
                } );

                return createBlock( 'wp-stats-counter/counter', { stats } );
            },
        },
    ],
    to: [
        {
            type:   'block',
            blocks: [ 'core/group' ],
            transform( { stats } ) {
                const innerBlocks = stats.map( ( stat ) =>
                    createBlock( 'core/heading', {
                        content: `${ stat.prefix }${ stat.value }${ stat.suffix } ${ stat.label }`,
                        level:   3,
                    } )
                );
                return createBlock( 'core/group', {}, innerBlocks );
            },
        },
    ],
};

export default transforms;