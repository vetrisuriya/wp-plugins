/**
 * src/save.js — Static save component for Stats Counter block.
 * FILE: wp-stats-counter/src/save.js
 *
 * Dynamic block? NO — save() outputs static HTML with Interactivity API
 * data attributes. The view.js script reads these at runtime to animate.
 *
 * Returning null is NOT used here (unlike Blocks 04 pricing table) because
 * we need the static HTML for: (a) SEO-readable final values, (b) no-JS fallback.
 */
import { useBlockProps, RichText } from '@wordpress/block-editor';

export default function save( { attributes } ) {
    const {
        stats,
        columns,
        animationDuration,
        animateOnScroll,
        numberAlign,
    } = attributes;

    if ( ! stats?.length ) return null;

    const blockProps = useBlockProps.save( {
        className: `columns-${ columns } align-${ numberAlign }`,
        style:     { '--stat-columns': columns },
        'data-wp-interactive': 'wp-stats-counter/counter',
        'data-wp-context':     JSON.stringify( {
            duration:        animationDuration,
            animateOnScroll,
            animated:        false,
        } ),
        'data-wp-init': 'callbacks.initObserver',
    } );

    return (
        <div { ...blockProps }>
            <div className="stats-grid">
                { stats.map( ( stat, index ) => {
                    const formatted = stat.separator
                        ? stat.value.toLocaleString( 'en-US', {
                            minimumFractionDigits: stat.decimals,
                            maximumFractionDigits: stat.decimals,
                          } )
                        : stat.value.toFixed( stat.decimals );

                    return (
                        <div
                            key={ stat.id }
                            className="stat-item"
                            data-stat-value={ stat.value }
                            data-stat-decimals={ stat.decimals }
                            data-stat-separator={ stat.separator ? 'true' : 'false' }
                        >
                            <div className="stat-number" aria-live="polite">
                                <span className="stat-prefix">{ stat.prefix }</span>
                                <span className="stat-value" data-index={ index }>
                                    { formatted }
                                </span>
                                <span className="stat-suffix">{ stat.suffix }</span>
                            </div>
                            <RichText.Content
                                tagName="p"
                                className="stat-label"
                                value={ stat.label }
                            />
                            { stat.description && (
                                <RichText.Content
                                    tagName="p"
                                    className="stat-description"
                                    value={ stat.description }
                                />
                            ) }
                        </div>
                    );
                } ) }
            </div>
        </div>
    );
}