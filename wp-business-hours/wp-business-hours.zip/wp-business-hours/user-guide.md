# WP Business Hours Block — User Guide

## Table of Contents

- [Why This Block Exists](#why-this-block-exists)
- [Folder Structure](#folder-structure)
- [Installation](#installation)
- [How to Use the Block](#how-to-use-the-block)
  - [Inserting the Block](#inserting-the-block)
  - [Setting Hours for Each Day](#setting-hours-for-each-day)
  - [Marking a Day as Closed](#marking-a-day-as-closed)
  - [Time Format](#time-format)
  - [Open/Closed Badge](#openclosed-badge)
  - [Schema.org Markup](#schemaorg-markup)
- [Inspector Controls Reference](#inspector-controls-reference)
- [Block Styles](#block-styles)
- [Block Variations](#block-variations)
- [How ServerSideRender Works](#how-serversideliverrender-works)
- [How "Open Now" Is Calculated](#how-open-now-is-calculated)
- [Timezone Handling](#timezone-handling)
- [Schema.org Output](#schemaorg-output)
- [For Developers — Build from Source](#for-developers--build-from-source)
- [FAQ](#faq)

---

## Why This Block Exists

Restaurants, clinics, salons, retail stores, gyms, and service businesses all need to show their hours. Without this block, editors:

- Type hours as plain text in a list or table — no structure, no schema, breaks on theme change
- Have no "Open Now" indicator tied to real time
- Have no today's row highlighting
- Get no Google Knowledge Panel rich snippet (requires `schema.org openingHoursSpecification`)
- Break when server timezone ≠ business timezone
- Must update hours on multiple pages manually

This block solves all of it using PHP server-side rendering (`render.php`) — the output is generated fresh on every page request so the "Open Now" badge is always accurate.

---

## Folder Structure

```
wp-business-hours/
├── wp-business-hours.php        ← wpbh-wp-business-hours.php
├── block.json                   ← wpbh-block.json  (at root — FIXED)
├── render.php                   ← wpbh-render.php  (bugs fixed)
├── uninstall.php                ← wpbh-uninstall.php
├── readme.txt                   ← wpbh-readme.txt
├── package.json                 ← wpbh-package.json
│
├── build/
│   ├── index.js                 ← wpbh-build-index.js     (all bugs fixed)
│   ├── index.asset.php          ← wpbh-build-index.asset.php
│   ├── style-index.css          ← wpbh-build-style-index.css
│   └── editor.css               ← wpbh-build-editor.css
│
└── src/
    ├── index.js                 ← wpbh-src-index.js  (registerBlockStyle FIXED)
    ├── edit.js                  ← from reference .md (remove TimePicker import)
    ├── save.js                  ← wpbh-src-save.js
    ├── style.scss               ← from reference .md
    └── editor.scss              ← from reference .md
```

---

## Installation

1. Arrange all files in the structure above
2. ZIP the `wp-business-hours/` folder
3. Go to **Plugins → Add New → Upload Plugin**
4. Upload and click **Install Now → Activate Plugin**

No `npm install` needed — the `build/` directory is pre-compiled.

---

## How to Use the Block

### Inserting the Block

1. Open any post or page in the block editor
2. Click the **+** inserter and search for **Business Hours**
3. Insert — the default schedule appears (Mon–Fri 9–5, Sat 10–14, Sunday closed)
4. The editor shows a **live preview** using `ServerSideRender` — you see the exact HTML that will appear on the frontend including the current Open/Closed badge

**Or via Block Variations:**
- **Mon–Fri 9–5** — Monday through Friday 9am to 5pm, Saturday and Sunday closed
- **Restaurant Hours** — Closed Monday, open Tue–Sun with late evening hours

### Setting Hours for Each Day

1. Click the block to select it
2. Open **Inspector Controls** (right sidebar)
3. Open the **Opening Hours** panel
4. For each day, enter the **Open** and **Close** times using the time picker
5. Times are stored in 24-hour format (`09:00`) internally — the display format is controlled separately

### Marking a Day as Closed

In the **Opening Hours** panel, toggle the **Closed** switch next to any day. The time fields hide and the day shows the "Closed" label in the rendered output.

### Time Format

In the **Business Info** panel, choose:

- **12-hour (9:00 AM)** — Shows times as `9:00 AM` / `5:00 PM`
- **24-hour (09:00)** — Shows times as `09:00` / `17:00`

Hours are always stored internally in 24-hour `HH:MM` format regardless of the display setting. This ensures accurate Open/Closed comparison in PHP.

### Open/Closed Badge

The badge shows "Open Now" (green with pulsing dot) or "Closed Now" (red). Toggle it on/off with the **Show Open / Closed Badge** setting in Inspector Controls.

The badge is computed server-side using PHP `DateTime` — it is always accurate at the moment the page is requested.

### Schema.org Markup

Toggle **Output Schema.org Markup** to enable/disable the `<script type="application/ld+json">` that is injected into the page. This makes the business eligible for Google's Hours rich result in search.

Set the **Business Name (for schema)** field to override the site name in the schema output. Leave blank to use `get_bloginfo('name')` automatically.

---

## Inspector Controls Reference

| Panel | Setting | Default | Description |
|---|---|---|---|
| Business Info | **Business Name (for schema)** | "" | Name in schema.org JSON-LD. Blank = site name. |
| Business Info | **"Closed" Label** | "Closed" | Text shown for days marked as closed |
| Business Info | **Time Format** | 12h | 12-hour (9:00 AM) or 24-hour (09:00) |
| Business Info | **Show Open / Closed Badge** | On | Green/red status badge above the table |
| Business Info | **Output Schema.org Markup** | On | JSON-LD `LocalBusiness` schema in page source |
| Opening Hours | **Monday–Sunday** | See defaults | Open/Close time inputs + Closed toggle per day |

---

## Block Styles

Select the block and click the **Styles** icon in the block toolbar.

| Style | Layout |
|---|---|
| **Table** (default) | Standard two-column `<table>` — day name on left, hours on right |
| **List** | Flex row per day, dotted separator lines between rows |
| **Day Cards** | CSS Grid of cards — one card per day, today highlighted with border |
| **Compact** | Same as Table but smaller font and tighter padding |

---

## Block Variations

Pre-configured hour sets in the block inserter:

| Variation | Schedule |
|---|---|
| **Mon–Fri 9–5** | Monday–Friday 9:00–17:00 open; Saturday–Sunday closed |
| **Restaurant Hours** | Monday closed; Tue–Wed–Thu 11:00–22:00; Fri–Sat 11:00–23:00; Sun 10:00–21:00 |

---

## How ServerSideRender Works

When you view the block in the editor, you see a live preview generated by PHP — not a JavaScript mock. Here's the flow:

```
Editor: user changes an attribute (e.g. toggles a Closed day)
   ↓
ServerSideRender detects attribute change
   ↓
REST API call:
  GET /wp-json/wp/v2/block-renderer/wp-business-hours/hours?attributes={...}
   ↓
WordPress runs render.php with the current attributes + server time
   ↓
render.php outputs HTML (badge, table rows, today highlight, schema JSON)
   ↓
REST API returns the HTML
   ↓
ServerSideRender injects the HTML into the editor canvas
   ↓
Editor shows exact frontend output including real Open/Closed status
```

This is the correct approach for any block whose output depends on:
- Current time / date (this block's use case)
- Logged-in user state
- Post meta or custom fields
- External API calls

---

## How "Open Now" Is Calculated

The calculation is entirely server-side PHP in `render.php`:

```php
$tz          = wp_timezone();                    // Site's configured timezone
$now         = new DateTime( 'now', $tz );       // Current time in that timezone
$current_day = strtolower( $now->format( 'l' ) ); // 'monday', 'tuesday', etc.
$current_hm  = $now->format( 'H:i' );           // '14:35' — 24h format

$today   = $hours[ $current_day ];
$is_open = ( $current_hm >= $today['open'] && $current_hm < $today['close'] );
```

Hours are compared as strings (`'14:35' >= '09:00'`). This works correctly for 24-hour format strings — lexicographic comparison of zero-padded time strings is equivalent to numeric comparison.

---

## Timezone Handling

`wp_timezone()` returns a `DateTimeZone` object from WordPress **Settings → General → Timezone**. The web server may be hosted in UTC or any timezone, but the business hours are compared in the site's configured timezone — so "Open Now" is accurate regardless of server location.

For multi-location businesses (e.g. a chain with stores in different cities), a `timezone` attribute is included in block.json but the UI for setting it is not exposed in the current Inspector Controls. Developers can add a `TextControl` in `src/edit.js` and pass the value — `render.php` already reads and applies it.

---

## Schema.org Output

When enabled, the block injects this into the page source:

```json
{
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "Your Business Name",
    "openingHoursSpecification": [
        {
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": "https://schema.org/Monday",
            "opens": "09:00",
            "closes": "17:00"
        }
    ]
}
```

**Rules for valid schema.org hours:**
- `dayOfWeek` must be the full schema.org URL (`https://schema.org/Monday`, not just `"Monday"`)
- `opens`/`closes` must be 24-hour format (`"09:00"`, not `"9:00 AM"`)
- Closed days are omitted from the `openingHoursSpecification` array
- The display `timeFormat` setting does NOT affect schema values

**Validate:** https://search.google.com/test/rich-results

---

## For Developers — Build from Source

### Requirements
- Node.js 18+, npm 8+

### Setup

```bash
cd wp-content/plugins/wp-business-hours
npm install
npm run build    # → build/index.js, build/style-index.css, build/editor.css
npm run start    # Watch mode
```

### Fixes to apply to `src/edit.js` before building

Copy `edit.js` from `WP_Block_09_Business_Hours.md`, then:

**Remove the unused import:**
```js
// ❌ Remove this line
import { __experimentalTimePicker as TimePicker } from '@wordpress/components';
```

**Update block name in ServerSideRender:**
```js
// Change from:
<ServerSideRender block="my-blocks/business-hours" ... />
// To:
<ServerSideRender block="wp-business-hours/hours" ... />
```

**Update text domain throughout:** Change all `'my-blocks'` → `'wp-business-hours'`.

---

## FAQ

**The editor shows "Preview error" instead of the block.**
The `ServerSideRender` REST API call failed. Common causes: `render.php` has a PHP syntax error, the block isn't registered correctly, or the REST API is blocked by a security plugin. Check **Tools → Site Health** and look for REST API warnings.

**The "Open Now" badge shows the wrong status.**
Check **Settings → General → Timezone** — this is the timezone `wp_timezone()` uses. If the site is set to UTC but the business is in EST, the comparison will be 5 hours off.

**Schema.org not validated by Google's Rich Results Test.**
Confirm `showSchema: true` (Inspector Controls → Business Info → Output Schema.org Markup). View the page source and search for `application/ld+json`. Common schema errors: missing `https://schema.org/` prefix on `dayOfWeek`, or only closed days included (all days closed = empty `openingHoursSpecification` array = no schema output).

**The Block Styles panel shows nothing (no Table/List/Cards options).**
This was Bug 1 — `registerBlockStyle()` was called with an array. Use `wpbh-build-index.js` (pre-compiled, fixed). Or apply the fix to `src/index.js` and rebuild.

**`wpbh_format_time` causes a fatal "Cannot redeclare function" error.**
This was Bug 3 from the reference. The fixed `render.php` wraps the function in `if ( ! function_exists('wpbh_format_time') )`. If you are still seeing this, ensure you are using `wpbh-render.php` (the fixed version), not the original reference code.