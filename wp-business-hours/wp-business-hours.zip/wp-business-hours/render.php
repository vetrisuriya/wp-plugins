<?php
/**
 * render.php — Server-side render template for the Business Hours block.
 * FILE: wp-business-hours/render.php
 *
 * Referenced by block.json: "render": "file:./render.php"
 * WordPress passes these variables automatically:
 *   $attributes (array)  — block attributes (sanitized by WP from block.json schema)
 *   $content    (string) — inner block content (unused — this block has no InnerBlocks)
 *   $block      (WP_Block) — block instance
 *
 * This callback runs for BOTH:
 *   1. Frontend page rendering on every page request
 *   2. ServerSideRender REST API calls from the block editor preview
 *
 * WHY DYNAMIC (render.php instead of static save()):
 * ──────────────────────────────────────────────────────────────────
 * The "Open Now / Closed" badge and today's highlighted row depend on
 * the current server time. A static save() generates HTML at edit time
 * and stores it in the database — that HTML would be wrong for visitors
 * at any other time. render.php executes fresh on every request, computes
 * the current time vs hours, and outputs the correct badge every time.
 * ──────────────────────────────────────────────────────────────────
 *
 * @package WP_Business_Hours
 */

defined( 'ABSPATH' ) || exit;

// ── Pull attributes ────────────────────────────────────────────────
$hours         = $attributes['hours']        ?? array();
$show_badge    = (bool) ( $attributes['showBadge']   ?? true  );
$show_schema   = (bool) ( $attributes['showSchema']  ?? true  );
$time_format   = $attributes['timeFormat']   ?? '12h';
$closed_label  = sanitize_text_field( $attributes['closedLabel']  ?? __( 'Closed', 'wp-business-hours' ) );
$business_name = sanitize_text_field( $attributes['businessName'] ?? get_bloginfo( 'name' ) );
$tz_override   = sanitize_text_field( $attributes['timezone']     ?? '' );

// ── Determine the business timezone ───────────────────────────────
// wp_timezone() uses WordPress Settings → General → Timezone.
// The optional timezone attribute lets multi-location sites override
// the timezone per-block without changing site-wide settings.
try {
    $tz = $tz_override ? new DateTimeZone( $tz_override ) : wp_timezone();
} catch ( Exception $e ) {
    $tz = wp_timezone();
}

$now         = new DateTime( 'now', $tz );
$current_day = strtolower( $now->format( 'l' ) ); // e.g. 'monday'
$current_hm  = $now->format( 'H:i' );             // e.g. '14:35'

// ── Determine Open/Closed status ──────────────────────────────────
$today   = $hours[ $current_day ] ?? null;
$is_open = false;

if ( $today && ! $today['closed'] && ! empty( $today['open'] ) && ! empty( $today['close'] ) ) {
    $is_open = ( $current_hm >= $today['open'] && $current_hm < $today['close'] );
}

// ── Day name map — translatable with context ───────────────────────
$day_names = array(
    'monday'    => _x( 'Monday',    'day of week', 'wp-business-hours' ),
    'tuesday'   => _x( 'Tuesday',   'day of week', 'wp-business-hours' ),
    'wednesday' => _x( 'Wednesday', 'day of week', 'wp-business-hours' ),
    'thursday'  => _x( 'Thursday',  'day of week', 'wp-business-hours' ),
    'friday'    => _x( 'Friday',    'day of week', 'wp-business-hours' ),
    'saturday'  => _x( 'Saturday',  'day of week', 'wp-business-hours' ),
    'sunday'    => _x( 'Sunday',    'day of week', 'wp-business-hours' ),
);

/**
 * Format HH:MM time string for display.
 *
 * BUG FIX vs REFERENCE: Wrapped in function_exists() guard.
 * The reference defined my_blocks_format_time() in the global namespace
 * with no guard — would fatal on double-include or name collision.
 *
 * @param string $time_string  e.g. "09:00"
 * @param string $format       '12h' or '24h'
 * @return string
 */
if ( ! function_exists( 'wpbh_format_time' ) ) {
    function wpbh_format_time( string $time_string, string $format ): string {
        if ( empty( $time_string ) ) {
            return '';
        }
        $dt = DateTime::createFromFormat( 'H:i', $time_string );
        if ( ! $dt ) {
            return esc_html( $time_string );
        }
        // date_i18n() respects WordPress locale for AM/PM and month/day names.
        return esc_html( date_i18n( '12h' === $format ? 'g:i A' : 'H:i', $dt->getTimestamp() ) );
    }
}

// ── Wrapper attributes ─────────────────────────────────────────────
// get_block_wrapper_attributes() merges block supports (color, spacing)
// and any custom class names added by the editor. Without this call,
// color and spacing support settings are silently ignored.
$wrapper_attrs = get_block_wrapper_attributes( array(
    'class' => 'wpbh-block',
) );

// ── Build schema.org openingHoursSpecification ─────────────────────
$schema_day_map = array(
    'monday'    => 'Monday',
    'tuesday'   => 'Tuesday',
    'wednesday' => 'Wednesday',
    'thursday'  => 'Thursday',
    'friday'    => 'Friday',
    'saturday'  => 'Saturday',
    'sunday'    => 'Sunday',
);

$opening_hours_spec = array();
foreach ( $hours as $day_key => $day ) {
    if ( empty( $day['closed'] ) && ! empty( $day['open'] ) && ! empty( $day['close'] ) ) {
        $opening_hours_spec[] = array(
            '@type'     => 'OpeningHoursSpecification',
            'dayOfWeek' => 'https://schema.org/' . ( $schema_day_map[ $day_key ] ?? '' ),
            'opens'     => $day['open'],
            'closes'    => $day['close'],
        );
    }
}

$schema = array(
    '@context'                  => 'https://schema.org',
    '@type'                     => 'LocalBusiness',
    'name'                      => $business_name,
    'openingHoursSpecification' => $opening_hours_spec,
);
?>
<div <?php echo wp_kses_data( $wrapper_attrs ); ?>>

    <?php if ( $show_badge ) : ?>
    <div class="bh-badge <?php echo esc_attr( $is_open ? 'bh-badge--open' : 'bh-badge--closed' ); ?>"
         aria-live="polite"
         aria-label="<?php echo esc_attr( $is_open ? __( 'Currently open', 'wp-business-hours' ) : __( 'Currently closed', 'wp-business-hours' ) ); ?>">
        <span class="bh-badge__dot" aria-hidden="true"></span>
        <?php if ( $is_open ) : ?>
            <?php esc_html_e( 'Open Now', 'wp-business-hours' ); ?>
        <?php else : ?>
            <?php esc_html_e( 'Closed Now', 'wp-business-hours' ); ?>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <table class="bh-table"
           role="table"
           aria-label="<?php esc_attr_e( 'Business hours', 'wp-business-hours' ); ?>">
        <tbody>
        <?php foreach ( $day_names as $day_key => $day_label ) :
            $day       = $hours[ $day_key ] ?? array( 'open' => '', 'close' => '', 'closed' => true );
            $is_today  = ( $day_key === $current_day );
            $is_closed = ! empty( $day['closed'] );

            $row_classes = array_filter( array(
                'bh-row',
                $is_today  ? 'bh-row--today'  : '',
                $is_closed ? 'bh-row--closed' : 'bh-row--open',
            ) );
        ?>
            <tr class="<?php echo esc_attr( implode( ' ', $row_classes ) ); ?>">
                <th class="bh-day" scope="row">
                    <?php echo esc_html( $day_label ); ?>
                    <?php if ( $is_today ) : ?>
                        <span class="bh-today-marker screen-reader-text">
                            <?php esc_html_e( '(today)', 'wp-business-hours' ); ?>
                        </span>
                    <?php endif; ?>
                </th>
                <td class="bh-time">
                    <?php if ( $is_closed ) : ?>
                        <span class="bh-closed"><?php echo esc_html( $closed_label ); ?></span>
                    <?php else : ?>
                        <time class="bh-open" datetime="<?php echo esc_attr( $day['open'] ?? '' ); ?>">
                            <?php echo wpbh_format_time( $day['open'] ?? '', $time_format ); ?>
                        </time>
                        <span class="bh-separator" aria-hidden="true">–</span>
                        <time class="bh-close" datetime="<?php echo esc_attr( $day['close'] ?? '' ); ?>">
                            <?php echo wpbh_format_time( $day['close'] ?? '', $time_format ); ?>
                        </time>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <?php if ( $show_schema && ! empty( $opening_hours_spec ) ) : ?>
    <script type="application/ld+json">
        <?php
        // wp_json_encode() safely encodes UTF-8; JSON_UNESCAPED_SLASHES prevents
        // URL escaping; NOT wrapped in esc_html() — that would corrupt the JSON.
        echo wp_json_encode( $schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        ?>
    </script>
    <?php endif; ?>

</div>