=== WP Business Hours Block ===
Contributors:      yourname
Tags:              business hours, opening hours, schedule, open closed, schema.org, gutenberg block
Requires at least: 6.4
Tested up to:      6.7
Stable tag:        1.4
Requires PHP:      8.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Business hours block with live Open/Closed badge, today highlighting, timezone awareness, and schema.org markup.

== Description ==

**WP Business Hours Block** adds a structured, server-side-rendered business hours table to any WordPress page.

= Features =

* **Live "Open Now / Closed" badge** — computed fresh on every page request using server time
* **Today's row highlighted** — PHP date functions detect the current day in the site's timezone
* **Timezone aware** — uses `wp_timezone()` to respect WordPress Settings → General → Timezone
* **schema.org JSON-LD** — `openingHoursSpecification` output for Google rich results
* **ServerSideRender preview** — editor shows the exact PHP-rendered output including live time status
* **12h / 24h time format** — toggle between `9:00 AM` and `09:00` display
* **Custom "Closed" label** — localizable label for closed days
* **Business name for schema** — separate from site name for multi-page businesses
* **2 Block Variations** — Mon–Fri 9–5 and Restaurant Hours presets
* **4 Block Styles** — Table, List, Day Cards, Compact
* **No build step required** — pre-compiled `build/` directory included

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload Plugin**
2. In the block editor, search for **Business Hours**
3. Insert the block — default Mon–Fri 9–5, Saturday 10–14, Sunday closed
4. Open the **Inspector Controls** sidebar to edit hours for each day

== Frequently Asked Questions ==

= Why is the "Open Now" badge a PHP render and not JavaScript? =
Because the block uses a PHP `render_callback` (via `"render": "file:./render.php"` in block.json), the HTML is generated fresh on every page request. The server knows the current time, compares it to the stored hours, and outputs the correct badge. No client-side JavaScript is needed for the badge itself.

= Why does the editor show a live preview of today's hours? =
The editor uses `ServerSideRender`, which calls the WordPress REST API (`/wp-json/wp/v2/block-renderer/wp-business-hours/hours`) with the current attributes. WordPress executes the same `render.php` callback and returns the rendered HTML — including the correct badge for the current time.

= Does this output schema.org markup for Google? =
Yes. When "Output Schema.org Markup" is enabled, the block outputs `<script type="application/ld+json">` containing a `LocalBusiness` schema with `openingHoursSpecification` for each open day. Validate at https://search.google.com/test/rich-results.

== Changelog ==

= 1.0.0 =
* Initial release. ServerSideRender preview. Open/Closed badge with pulsing dot. Today row highlighting. schema.org JSON-LD. wp_timezone() for accuracy. 12h/24h formats. 4 Block Styles. 2 Block Variations.