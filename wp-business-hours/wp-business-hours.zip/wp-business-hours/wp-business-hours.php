<?php
/**
 * Plugin Name:       WP Business Hours Block
 * Plugin URI:        https://example.com/wp-business-hours
 * Description:       Display business opening hours with live Open/Closed badge, today highlighting, schema.org JSON-LD, and ServerSideRender preview in the editor.
 * Version:           1.4
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            Your Name
 * Author URI:        https://example.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-business-hours
 * Domain Path:       /languages
 *
 * @package WP_Business_Hours
 */

defined( 'ABSPATH' ) || exit;

define( 'WPBH_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPBH_URL', plugin_dir_url( __FILE__ ) );
define( 'WPBH_VER', '1.4' );

/**
 * Register the block.
 *
 * block.json is at plugin ROOT. The "render" field points to render.php:
 *   "render": "file:./render.php"
 * WordPress reads block.json, registers the editor script/styles, and
 * uses render.php as the PHP callback for both:
 *   - Frontend page rendering
 *   - ServerSideRender REST API calls from the block editor
 *
 * No render_callback is needed here — block.json "render" handles it.
 *
 * PATH FIX vs REFERENCE:
 * ──────────────────────────────────────────────────────────────────
 * Reference placed block.json inside blocks/business-hours/ as part
 * of the my-blocks multi-block plugin. As a standalone plugin, block.json
 * lives at the plugin root so all file:// paths resolve correctly.
 * ──────────────────────────────────────────────────────────────────
 */
add_action( 'init', 'wpbh_register_block' );
function wpbh_register_block(): void {
    register_block_type( WPBH_DIR . 'block.json' );

    load_plugin_textdomain(
        'wp-business-hours',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );
}