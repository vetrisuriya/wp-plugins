/**
 * src/index.js — Block registration entry point (JSX source).
 * FILE: wp-business-hours/src/index.js
 *
 * BUGS FIXED vs REFERENCE:
 *   Bug 1 — registerBlockStyle( name, [array] ) → invalid.
 *            Fixed to 4 individual calls.
 *   Bug 2 — __experimentalTimePicker was imported in edit.js but never used.
 *            Removed from edit.js (see src/edit.js).
 */
import { registerBlockType, registerBlockStyle } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import Edit     from './edit';
import metadata from '../block.json';
import './style.scss';
import './editor.scss';

registerBlockType( metadata.name, {
    edit: Edit,
    save: () => null, // Dynamic block — render.php handles all output.
    variations: [
        {
            name:       'mon-fri',
            title:      __( 'Mon–Fri 9–5', 'wp-business-hours' ),
            icon:       'clock',
            attributes: {
                hours: {
                    monday:    { open: '09:00', close: '17:00', closed: false },
                    tuesday:   { open: '09:00', close: '17:00', closed: false },
                    wednesday: { open: '09:00', close: '17:00', closed: false },
                    thursday:  { open: '09:00', close: '17:00', closed: false },
                    friday:    { open: '09:00', close: '17:00', closed: false },
                    saturday:  { open: '09:00', close: '17:00', closed: true  },
                    sunday:    { open: '09:00', close: '17:00', closed: true  },
                },
            },
            isActive: ( { hours } ) => !!(
                hours?.saturday?.closed && hours?.sunday?.closed
            ),
        },
        {
            name:       'restaurant',
            title:      __( 'Restaurant Hours', 'wp-business-hours' ),
            icon:       'food',
            attributes: {
                hours: {
                    monday:    { open: '11:00', close: '22:00', closed: true  },
                    tuesday:   { open: '11:00', close: '22:00', closed: false },
                    wednesday: { open: '11:00', close: '22:00', closed: false },
                    thursday:  { open: '11:00', close: '23:00', closed: false },
                    friday:    { open: '11:00', close: '23:00', closed: false },
                    saturday:  { open: '10:00', close: '23:00', closed: false },
                    sunday:    { open: '10:00', close: '21:00', closed: false },
                },
                timeFormat: '12h',
            },
        },
    ],
} );

/* ── Block Styles — FIXED: one call per style, NOT an array ─────── */
registerBlockStyle( 'wp-business-hours/hours', { name: 'table',   label: __( 'Table',     'wp-business-hours' ), isDefault: true } );
registerBlockStyle( 'wp-business-hours/hours', { name: 'list',    label: __( 'List',      'wp-business-hours' ) } );
registerBlockStyle( 'wp-business-hours/hours', { name: 'cards',   label: __( 'Day Cards', 'wp-business-hours' ) } );
registerBlockStyle( 'wp-business-hours/hours', { name: 'compact', label: __( 'Compact',   'wp-business-hours' ) } );