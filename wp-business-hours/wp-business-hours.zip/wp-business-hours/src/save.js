/**
 * src/save.js — Save component for Business Hours block.
 * FILE: wp-business-hours/src/save.js
 *
 * Returns null — this is a DYNAMIC BLOCK.
 *
 * The "Open Now / Closed" badge and today's row highlighting depend on
 * the current server time at the moment of each page request. A static
 * save() function would hard-code stale time-based content into the database.
 *
 * render.php executes fresh on every page load and every ServerSideRender
 * REST API preview request from the editor.
 */
export default function save() {
    return null;
}