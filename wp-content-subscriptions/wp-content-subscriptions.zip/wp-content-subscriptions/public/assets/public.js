/* global wcsm_params, jQuery */
/**
 * WP Content Subscription Manager — Public JavaScript
 * FILE: wp-content-subscriptions/public/assets/public.js
 */
( function ( $ ) {
    'use strict';

    var $form   = $( '#wcsm-subscribe-form' );
    var $msg    = $form.find( '.wcsm-message' );

    $form.on( 'submit', function ( e ) {
        e.preventDefault();

        var $btn     = $form.find( '.wcsm-subscribe-btn' );
        var email    = $( '#wcsm-email' ).val().trim();
        var name     = $( '#wcsm-name' ).val() ? $( '#wcsm-name' ).val().trim() : '';
        var terms    = [];
        $form.find( 'input[name="terms[]"]:checked' ).each( function () {
            terms.push( $( this ).val() );
        } );

        // ── Front-end validation ─────────────────────────────────
        $msg.hide().removeClass( 'wcsm-success wcsm-error' );

        if ( ! email || ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( email ) ) {
            showMessage( 'Please enter a valid email address.', 'error' );
            return;
        }
        if ( ! terms.length ) {
            showMessage( wcsm_params.strings.select_cat || 'Please select at least one category.', 'error' );
            return;
        }

        // ── AJAX submit ──────────────────────────────────────────
        $btn.prop( 'disabled', true ).text( wcsm_params.strings.subscribing );

        $.post( wcsm_params.ajax_url, {
            action: 'wcsm_subscribe',
            nonce:  wcsm_params.nonce,
            email:  email,
            name:   name,
            terms:  terms,
        }, function ( res ) {
            if ( res.success ) {
                $form.find( 'input, button, fieldset' ).prop( 'disabled', true );
                showMessage( res.data.message || wcsm_params.strings.check_email, 'success' );
            } else {
                var message = res.data && res.data.message ? res.data.message : ( wcsm_params.strings.error || 'Something went wrong.' );
                if ( message.indexOf( 'already' ) !== -1 ) {
                    showMessage( message, 'success' ); // Already subscribed is a positive state.
                } else {
                    showMessage( message, 'error' );
                }
                $btn.prop( 'disabled', false ).text( wcsm_params.strings.subscribe || 'Subscribe' );
            }
        } ).fail( function () {
            showMessage( wcsm_params.strings.error || 'Something went wrong. Please try again.', 'error' );
            $btn.prop( 'disabled', false ).text( wcsm_params.strings.subscribe || 'Subscribe' );
        } );
    } );

    function showMessage( text, type ) {
        $msg.text( text )
            .addClass( 'wcsm-' + type )
            .show();
    }

    // Clear message when the user starts typing or changes checkboxes.
    $form.on( 'input change', 'input', function () {
        $msg.hide().removeClass( 'wcsm-success wcsm-error' );
    } );

}( jQuery ) );