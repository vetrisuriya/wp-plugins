<?php
/**
 * Plugin Name:       WP Content Subscription Manager
 * Plugin URI:        https://vetrisuriya.in/wp-content-subscriptions
 * Description:       Let readers subscribe to content categories and receive automatic weekly email digests. Includes WP-Cron scheduling, double opt-in, REST API, and manual campaign tools.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Vetri Suriya
 * License:           GPL v2 or later
 * Text Domain:       wp-content-subscriptions
 * Domain Path:       /languages
 *
 * @package WPContentSubscriptions
 */

defined( 'ABSPATH' ) || exit;

define( 'WCSM_VERSION',          '1.0.0' );
define( 'WCSM_PLUGIN_DIR',       plugin_dir_path( __FILE__ ) );
define( 'WCSM_PLUGIN_URL',       plugin_dir_url( __FILE__ ) );
define( 'WCSM_PLUGIN_BASENAME',  plugin_basename( __FILE__ ) );

/*
 * FATAL ERROR ROOT CAUSE (different from other plugins):
 *
 * The original file called wp_content_subscriptions() at the very bottom,
 * which immediately instantiated the class and called load_dependencies().
 * load_dependencies() uses require_once on all class files.
 * Since NO class files existed as real .php files, PHP threw:
 *   Fatal error: require_once(): Failed to open required file 'class-wcsm-database.php'
 *
 * This happened on EVERY WordPress page load — not just activation.
 *
 * FIX: All class files are now created as real .php files.
 * The bootstrap structure below is preserved as-is (it is correct).
 */

final class WP_Content_Subscriptions {

    private static ?WP_Content_Subscriptions $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_dependencies();
        $this->set_locale();
        $this->define_hooks();
    }

    private function load_dependencies(): void {
        require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-database.php';
        require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-post-type.php';
        require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-settings.php';
        require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-shortcode.php';
        require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-ajax.php';
        require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-rest-api.php';
        require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-cron.php';
        require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-mailer.php';
        require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-tokens.php';
        require_once WCSM_PLUGIN_DIR . 'admin/class-wcsm-admin.php';
    }

    private function set_locale(): void {
        add_action( 'plugins_loaded', function (): void {
            load_plugin_textdomain( 'wp-content-subscriptions', false, dirname( WCSM_PLUGIN_BASENAME ) . '/languages/' );
        } );
    }

    private function define_hooks(): void {
        // Post type.
        $post_type = new WCSM_Post_Type();
        add_action( 'init', array( $post_type, 'register' ) );

        // Settings + admin menu.
        $settings = new WCSM_Settings();
        add_action( 'admin_init', array( $settings, 'register_settings' ) );
        add_action( 'admin_menu', array( $settings, 'add_menu' ) );

        // Admin views / subscriber list.
        $admin = new WCSM_Admin();
        add_action( 'admin_enqueue_scripts', array( $admin, 'enqueue_assets' ) );

        // Shortcode.
        $shortcode = new WCSM_Shortcode();
        add_shortcode( 'subscription_form', array( $shortcode, 'render' ) );

        // AJAX.
        $ajax = new WCSM_Ajax();
        add_action( 'wp_ajax_wcsm_subscribe',           array( $ajax, 'subscribe' ) );
        add_action( 'wp_ajax_nopriv_wcsm_subscribe',    array( $ajax, 'subscribe' ) );
        add_action( 'wp_ajax_wcsm_unsubscribe',         array( $ajax, 'unsubscribe' ) );
        add_action( 'wp_ajax_nopriv_wcsm_unsubscribe',  array( $ajax, 'unsubscribe' ) );

        // REST API.
        $rest = new WCSM_Rest_Api();
        add_action( 'rest_api_init', array( $rest, 'register_routes' ) );

        // WP-Cron.
        add_filter( 'cron_schedules', array( 'WCSM_Cron', 'add_cron_schedules' ) );
        $cron = new WCSM_Cron();
        add_action( 'wcsm_send_digest',       array( $cron, 'send_digest' ) );
        add_action( 'wcsm_cleanup_tokens',    array( $cron, 'cleanup_expired_tokens' ) );

        // Double opt-in confirmation + unsubscribe links.
        add_action( 'init', array( $this, 'handle_confirmation' ) );
        add_action( 'init', array( $this, 'handle_unsubscribe_link' ) );

        // Public assets.
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_public' ) );
    }

    /** Handle ?wcsm_confirm=TOKEN link from confirmation email. */
    public function handle_confirmation(): void {
        if ( ! isset( $_GET['wcsm_confirm'] ) ) return; // phpcs:ignore
        $token  = sanitize_text_field( wp_unslash( $_GET['wcsm_confirm'] ) );
        $result = WCSM_Tokens::confirm( $token );
        $status = $result ? 'confirmed' : 'invalid';
        wp_safe_redirect( add_query_arg( 'wcsm_status', $status, get_home_url() ) );
        exit;
    }

    /** Handle ?wcsm_unsubscribe=TOKEN link from digest emails. */
    public function handle_unsubscribe_link(): void {
        if ( ! isset( $_GET['wcsm_unsubscribe'] ) ) return; // phpcs:ignore
        $token = sanitize_text_field( wp_unslash( $_GET['wcsm_unsubscribe'] ) );
        global $wpdb;
        $table  = $wpdb->prefix . 'wcsm_subscribers';
        $result = $wpdb->update( $table,
            array( 'status' => 'unsubscribed' ),
            array( 'unsubscribe_token' => $token, 'status' => 'active' ),
            array( '%s' ), array( '%s', '%s' )
        );
        $status = $result ? 'unsubscribed' : 'invalid';
        wp_safe_redirect( add_query_arg( 'wcsm_status', $status, get_home_url() ) );
        exit;
    }

    public function enqueue_public(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) || ! has_shortcode( $post->post_content, 'subscription_form' ) ) return;
        wp_enqueue_style(  'wcsm-public', WCSM_PLUGIN_URL . 'public/assets/public.css', array(), WCSM_VERSION );
        wp_enqueue_script( 'wcsm-public', WCSM_PLUGIN_URL . 'public/assets/public.js',  array( 'jquery' ), WCSM_VERSION, true );
        wp_localize_script( 'wcsm-public', 'wcsm_params', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wcsm_nonce' ),
            'strings'  => array(
                'subscribing'  => __( 'Subscribing…',                                           'wp-content-subscriptions' ),
                'check_email'  => __( 'Almost there! Check your email to confirm.',             'wp-content-subscriptions' ),
                'already'      => __( 'You are already subscribed.',                            'wp-content-subscriptions' ),
                'error'        => __( 'Something went wrong. Please try again.',                'wp-content-subscriptions' ),
                'select_cat'   => __( 'Please select at least one category.',                   'wp-content-subscriptions' ),
                'subscribe'    => __( 'Subscribe',                                              'wp-content-subscriptions' ),
            ),
        ) );
    }
}

// Activation — requires files independently (not via constructor).
register_activation_hook( __FILE__, function (): void {
    require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-database.php';
    WCSM_Database::create_tables();

    require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-settings.php';
    require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-cron.php';
    WCSM_Cron::schedule_events();

    flush_rewrite_rules();
    set_transient( 'wcsm_activation_redirect', true, 30 );
} );

// Deactivation.
register_deactivation_hook( __FILE__, function (): void {
    require_once WCSM_PLUGIN_DIR . 'includes/class-wcsm-cron.php';
    WCSM_Cron::unschedule_events();
    flush_rewrite_rules();
} );

// Boot the plugin.
function wp_content_subscriptions(): WP_Content_Subscriptions {
    return WP_Content_Subscriptions::instance();
}
wp_content_subscriptions();