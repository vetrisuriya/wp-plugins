<?php
/**
 * Admin class: assets + menu wiring
 * FILE: wp-content-subscriptions/admin/class-wcsm-admin.php
 *
 * NOTE: This class was listed in the plugin structure but NOT written
 * in the original reference file — created from scratch.
 *
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Admin {

    public function enqueue_assets( string $hook ): void {
        if ( false === strpos( $hook, 'wcsm' ) ) return;
        wp_enqueue_style( 'wcsm-admin', WCSM_PLUGIN_URL . 'admin/assets/admin.css', array(), WCSM_VERSION );
    }

    public static function render_campaign_stats_page(): void {
        require_once WCSM_PLUGIN_DIR . 'admin/views/campaign-stats.php';
        wcsm_render_campaign_stats();
    }
}