<?php
/**
 * Admin view: Subscribers list
 * FILE: wp-content-subscriptions/admin/views/subscribers-list.php
 * Included by WCSM_Settings::render_subscribers_page()
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

function wcsm_render_subscribers_list(): void {
    $status    = sanitize_text_field( $_GET['status'] ?? 'active' );
    $page      = max( 1, absint( $_GET['paged'] ?? 1 ) );
    $per_page  = 25;
    $subs      = WCSM_Database::get_all_paginated( $status, $per_page, ( $page - 1 ) * $per_page );
    $counts    = array(
        'active'       => WCSM_Database::count_by_status( 'active' ),
        'pending'      => WCSM_Database::count_by_status( 'pending' ),
        'unsubscribed' => WCSM_Database::count_by_status( 'unsubscribed' ),
    );
    $next_run  = wp_next_scheduled( 'wcsm_send_digest' );
    $last_sent = (int) get_option( 'wcsm_last_digest_sent', 0 );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Subscribers', 'wp-content-subscriptions' ); ?></h1>

        <!-- Stats cards -->
        <div class="wcsm-stat-cards">
            <div class="wcsm-stat-card">
                <span class="wcsm-stat-num"><?php echo absint( $counts['active'] ); ?></span>
                <span class="wcsm-stat-label"><?php esc_html_e( 'Active', 'wp-content-subscriptions' ); ?></span>
            </div>
            <div class="wcsm-stat-card">
                <span class="wcsm-stat-num"><?php echo absint( $counts['pending'] ); ?></span>
                <span class="wcsm-stat-label"><?php esc_html_e( 'Pending Confirmation', 'wp-content-subscriptions' ); ?></span>
            </div>
            <div class="wcsm-stat-card">
                <span class="wcsm-stat-num"><?php echo absint( $counts['unsubscribed'] ); ?></span>
                <span class="wcsm-stat-label"><?php esc_html_e( 'Unsubscribed', 'wp-content-subscriptions' ); ?></span>
            </div>
            <div class="wcsm-stat-card">
                <span class="wcsm-stat-num"><?php echo $next_run ? esc_html( human_time_diff( $next_run ) ) : esc_html__( 'N/A', 'wp-content-subscriptions' ); ?></span>
                <span class="wcsm-stat-label"><?php esc_html_e( 'Next Digest In', 'wp-content-subscriptions' ); ?></span>
            </div>
        </div>

        <!-- Status filter tabs -->
        <ul class="subsubsub" style="margin-bottom:1rem;">
            <?php
            $tabs = array( 'active' => __( 'Active', 'wp-content-subscriptions' ), 'pending' => __( 'Pending', 'wp-content-subscriptions' ), 'unsubscribed' => __( 'Unsubscribed', 'wp-content-subscriptions' ) );
            $links = array();
            foreach ( $tabs as $slug => $label ) {
                $url     = add_query_arg( array( 'page' => 'wcsm_subscriptions', 'status' => $slug ), admin_url( 'admin.php' ) );
                $current = $status === $slug ? ' class="current"' : '';
                $links[] = '<li><a href="' . esc_url( $url ) . '"' . $current . '>' . esc_html( $label ) . ' <span class="count">(' . absint( $counts[ $slug ] ) . ')</span></a>';
            }
            echo implode( ' | ', $links );
            ?>
        </ul>

        <?php if ( empty( $subs ) ) : ?>
            <p><?php esc_html_e( 'No subscribers found for this status.', 'wp-content-subscriptions' ); ?></p>
        <?php else : ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Email',         'wp-content-subscriptions' ); ?></th>
                    <th><?php esc_html_e( 'Name',          'wp-content-subscriptions' ); ?></th>
                    <th><?php esc_html_e( 'Status',        'wp-content-subscriptions' ); ?></th>
                    <th><?php esc_html_e( 'Subscribed',    'wp-content-subscriptions' ); ?></th>
                    <th><?php esc_html_e( 'Last Emailed',  'wp-content-subscriptions' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $subs as $sub ) : ?>
                <tr>
                    <td><?php echo esc_html( $sub['email'] ); ?></td>
                    <td><?php echo esc_html( $sub['name'] ?: '—' ); ?></td>
                    <td><span class="wcsm-badge wcsm-badge--<?php echo esc_attr( $sub['status'] ); ?>"><?php echo esc_html( ucfirst( $sub['status'] ) ); ?></span></td>
                    <td><?php echo esc_html( $sub['subscribed_at'] ?: '—' ); ?></td>
                    <td><?php echo esc_html( $sub['last_email_at'] ?: '—' ); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php
}