<?php
/**
 * Admin view: Campaign stats
 * FILE: wp-content-subscriptions/admin/views/campaign-stats.php
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

function wcsm_render_campaign_stats(): void {
    $last_run  = get_option( 'wcsm_last_digest_run', null );
    $last_sent = (int) get_option( 'wcsm_last_digest_sent', 0 );
    $next_run  = wp_next_scheduled( 'wcsm_send_digest' );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Digest Campaign Stats', 'wp-content-subscriptions' ); ?></h1>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Last Digest Sent',   'wp-content-subscriptions' ); ?></th>
                <td><?php echo $last_run ? esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $last_run ) ) : esc_html__( 'Never', 'wp-content-subscriptions' ); ?></td></tr>
            <tr><th><?php esc_html_e( 'Emails in Last Run', 'wp-content-subscriptions' ); ?></th>
                <td><?php echo absint( $last_sent ); ?></td></tr>
            <tr><th><?php esc_html_e( 'Next Scheduled Run', 'wp-content-subscriptions' ); ?></th>
                <td><?php echo $next_run ? esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $next_run ) ) : esc_html__( 'Not scheduled', 'wp-content-subscriptions' ); ?></td></tr>
            <tr><th><?php esc_html_e( 'Active Subscribers', 'wp-content-subscriptions' ); ?></th>
                <td><?php echo absint( get_option( 'wcsm_subscriber_count', 0 ) ); ?></td></tr>
        </table>
    </div>
    <?php
}