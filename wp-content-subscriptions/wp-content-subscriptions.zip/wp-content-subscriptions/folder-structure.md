wp-content-subscriptions/
├── wp-content-subscriptions.php   ← Bootstrap
├── readme.txt
├── uninstall.php
├── includes/
│   ├── class-wcsm-post-type.php   ← Email Campaign CPT
│   ├── class-wcsm-database.php    ← DB tables
│   ├── class-wcsm-settings.php    ← Settings API
│   ├── class-wcsm-shortcode.php   ← Shortcodes
│   ├── class-wcsm-ajax.php        ← AJAX handlers
│   ├── class-wcsm-rest-api.php    ← REST endpoints
│   ├── class-wcsm-cron.php        ← WP-Cron scheduler
│   ├── class-wcsm-mailer.php      ← Email builder and sender
│   └── class-wcsm-tokens.php      ← Opt-in token management
├── admin/
│   ├── class-wcsm-admin.php
│   └── views/
│       ├── subscribers-list.php
│       └── campaign-stats.php
├── public/
│   └── assets/
│       ├── public.css
│       └── public.js
└── languages/
    └── wp-content-subscriptions.pot