<?php
/**
 * Settings API: Digest frequency, from email, batch size, external RSS.
 * FILE: wp-content-subscriptions/includes/class-wcsm-settings.php
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Settings {

    const OPTION_GROUP = 'wcsm_settings_group';
    const OPTION_NAME  = 'wcsm_settings';

    public function add_menu(): void {
        add_menu_page( __( 'Subscriptions', 'wp-content-subscriptions' ), __( 'Subscriptions', 'wp-content-subscriptions' ),
            'manage_options', 'wcsm_subscriptions', array( $this, 'render_subscribers_page' ), 'dashicons-email-alt', 25 );
        add_submenu_page( 'wcsm_subscriptions', __( 'Settings', 'wp-content-subscriptions' ), __( 'Settings', 'wp-content-subscriptions' ),
            'manage_options', 'wcsm_settings', array( $this, 'render_settings_page' ) );
    }

    public function register_settings(): void {
        register_setting( self::OPTION_GROUP, self::OPTION_NAME, array( 'sanitize_callback' => array( $this, 'sanitize' ) ) );
        add_settings_section( 'wcsm_email_section', __( 'Email Settings', 'wp-content-subscriptions' ), null, 'wcsm_settings_page' );

        $opts = self::get_options();
        $n    = self::OPTION_NAME;

        add_settings_field( 'from_name',  __( 'From Name',  'wp-content-subscriptions' ), function() use ( $opts, $n ) {
            echo '<input type="text"  name="' . esc_attr( $n ) . '[from_name]"  value="' . esc_attr( $opts['from_name']  ) . '" class="regular-text">';
        }, 'wcsm_settings_page', 'wcsm_email_section' );

        add_settings_field( 'from_email', __( 'From Email', 'wp-content-subscriptions' ), function() use ( $opts, $n ) {
            echo '<input type="email" name="' . esc_attr( $n ) . '[from_email]" value="' . esc_attr( $opts['from_email'] ) . '" class="regular-text">';
        }, 'wcsm_settings_page', 'wcsm_email_section' );

        add_settings_field( 'digest_frequency', __( 'Digest Frequency', 'wp-content-subscriptions' ), function() use ( $opts, $n ) {
            $freq = $opts['digest_frequency'];
            $html = '';
            foreach ( array( 'daily' => 'Daily', 'weekly' => 'Weekly', 'biweekly' => 'Every Two Weeks' ) as $v => $l ) {
                $html .= '<option value="' . esc_attr( $v ) . '"' . selected( $freq, $v, false ) . '>' . esc_html( $l ) . '</option>';
            }
            echo '<select name="' . esc_attr( $n ) . '[digest_frequency]">' . $html . '</select>';
        }, 'wcsm_settings_page', 'wcsm_email_section' );

        add_settings_field( 'batch_size', __( 'Batch Size', 'wp-content-subscriptions' ), function() use ( $opts, $n ) {
            echo '<input type="number" min="10" max="500" name="' . esc_attr( $n ) . '[batch_size]" value="' . esc_attr( $opts['batch_size'] ) . '" class="small-text">';
            echo '<p class="description">' . esc_html__( 'Emails sent per cron run. Keep below 100 to avoid timeouts.', 'wp-content-subscriptions' ) . '</p>';
        }, 'wcsm_settings_page', 'wcsm_email_section' );

        add_settings_field( 'external_rss_url', __( 'External RSS URL', 'wp-content-subscriptions' ), function() use ( $opts, $n ) {
            echo '<input type="url" name="' . esc_attr( $n ) . '[external_rss_url]" value="' . esc_attr( $opts['external_rss_url'] ) . '" class="large-text">';
            echo '<p class="description">' . esc_html__( 'Include up to 5 items from this RSS feed in each digest email.', 'wp-content-subscriptions' ) . '</p>';
        }, 'wcsm_settings_page', 'wcsm_email_section' );
    }

    public function render_settings_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Permission denied.', 'wp-content-subscriptions' ) );
        echo '<div class="wrap"><h1>' . esc_html__( 'Subscription Settings', 'wp-content-subscriptions' ) . '</h1>';
        echo '<form method="post" action="options.php">';
        settings_fields( self::OPTION_GROUP );
        do_settings_sections( 'wcsm_settings_page' );
        submit_button();
        echo '</form></div>';
    }

    public function render_subscribers_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Permission denied.', 'wp-content-subscriptions' ) );
        require_once WCSM_PLUGIN_DIR . 'admin/views/subscribers-list.php';
        wcsm_render_subscribers_list();
    }

    public function sanitize( $input ): array {
        return array(
            'from_name'        => sanitize_text_field( $input['from_name']  ?? '' ),
            'from_email'       => sanitize_email( $input['from_email'] ?? '' ),
            'digest_frequency' => in_array( $input['digest_frequency'] ?? '', array( 'daily', 'weekly', 'biweekly' ), true ) ? $input['digest_frequency'] : 'weekly',
            'batch_size'       => absint( $input['batch_size'] ?? 50 ),
            'external_rss_url' => esc_url_raw( $input['external_rss_url'] ?? '' ),
        );
    }

    public static function get_options(): array {
        return wp_parse_args( get_option( self::OPTION_NAME, array() ), array(
            'from_name'        => get_bloginfo( 'name' ),
            'from_email'       => get_option( 'admin_email' ),
            'digest_frequency' => 'weekly',
            'batch_size'       => 50,
            'external_rss_url' => '',
        ) );
    }
}