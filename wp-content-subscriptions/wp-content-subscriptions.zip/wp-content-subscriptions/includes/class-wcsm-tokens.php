<?php
/**
 * Token Management: Double Opt-In confirmation and unsubscribe tokens
 * FILE: wp-content-subscriptions/includes/class-wcsm-tokens.php
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Tokens {

    public static function send_confirmation( string $email, string $confirm_token ): void {
        $options     = WCSM_Settings::get_options();
        $confirm_url = add_query_arg( 'wcsm_confirm', $confirm_token, get_home_url() );
        $subject     = sprintf( __( 'Please confirm your subscription to %s', 'wp-content-subscriptions' ), get_bloginfo( 'name' ) );
        $message     = sprintf(
            __( "Thank you for subscribing!\n\nPlease confirm your email address by clicking the link below:\n\n%s\n\nThis link will expire in 24 hours.\n\nIf you did not subscribe, please ignore this email.", 'wp-content-subscriptions' ),
            esc_url( $confirm_url )
        );
        $headers = array( sprintf( 'From: %s <%s>', $options['from_name'], $options['from_email'] ) );
        wp_mail( $email, $subject, $message, $headers );
    }

    public static function confirm( string $token ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'wcsm_subscribers';

        $subscriber = $wpdb->get_row( $wpdb->prepare( // phpcs:ignore
            "SELECT id, token_expires FROM {$table} WHERE confirm_token = %s AND status = 'pending' LIMIT 1",
            $token
        ) );

        if ( ! $subscriber ) return false;
        if ( strtotime( $subscriber->token_expires ) < current_time( 'timestamp' ) ) return false;

        $result = $wpdb->update( $table, // phpcs:ignore
            array( 'status' => 'active', 'confirm_token' => '', 'token_expires' => null, 'subscribed_at' => current_time( 'mysql' ) ),
            array( 'id' => $subscriber->id )
        );

        if ( $result ) {
            WCSM_Database::count_active();
            return true;
        }
        return false;
    }
}