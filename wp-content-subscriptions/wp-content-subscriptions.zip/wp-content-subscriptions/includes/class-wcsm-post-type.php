<?php
/**
 * Email Campaign Custom Post Type
 * FILE: wp-content-subscriptions/includes/class-wcsm-post-type.php
 *
 * NOTE: This class was listed in the plugin structure but NOT written
 * in the original reference file — created from scratch.
 *
 * Campaigns are draft email newsletters that the admin creates and
 * can send manually as a one-off digest to all active subscribers.
 *
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Post_Type {

    public function register(): void {
        register_post_type( 'wcsm_campaign', array(
            'labels' => array(
                'name'          => _x( 'Campaigns', 'post type general name', 'wp-content-subscriptions' ),
                'singular_name' => _x( 'Campaign',  'post type singular name', 'wp-content-subscriptions' ),
                'add_new_item'  => __( 'Create Campaign', 'wp-content-subscriptions' ),
                'edit_item'     => __( 'Edit Campaign',   'wp-content-subscriptions' ),
                'not_found'     => __( 'No campaigns found.', 'wp-content-subscriptions' ),
                'menu_name'     => __( 'Campaigns', 'wp-content-subscriptions' ),
            ),
            'public'          => false,
            'show_ui'         => true,
            'show_in_menu'    => 'wcsm_subscriptions',
            'show_in_rest'    => false,
            'capability_type' => 'post',
            'supports'        => array( 'title', 'editor' ),
            'rewrite'         => false,
        ) );

        // Meta box: "Send Campaign" button.
        add_action( 'add_meta_boxes', array( $this, 'add_send_meta_box' ) );
        add_action( 'admin_post_wcsm_send_campaign', array( $this, 'handle_send' ) );
    }

    public function add_send_meta_box(): void {
        add_meta_box( 'wcsm_send_campaign',
            __( 'Send Campaign', 'wp-content-subscriptions' ),
            array( $this, 'render_send_box' ),
            'wcsm_campaign', 'side', 'high'
        );
    }

    public function render_send_box( WP_Post $post ): void {
        $sent       = get_post_meta( $post->ID, '_wcsm_sent_at', true );
        $sent_count = get_post_meta( $post->ID, '_wcsm_sent_count', true );
        ?>
        <?php if ( $sent ) : ?>
            <p><?php printf( esc_html__( '✅ Sent on %s to %d subscribers.', 'wp-content-subscriptions' ), esc_html( $sent ), absint( $sent_count ) ); ?></p>
        <?php else : ?>
            <p><?php esc_html_e( 'Save as Draft first, then click Send to email all active subscribers.', 'wp-content-subscriptions' ); ?></p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="wcsm_send_campaign">
                <input type="hidden" name="campaign_id" value="<?php echo absint( $post->ID ); ?>">
                <?php wp_nonce_field( 'wcsm_send_campaign_' . $post->ID, 'wcsm_send_nonce' ); ?>
                <input type="submit" class="button button-primary" value="<?php esc_attr_e( '📤 Send Now', 'wp-content-subscriptions' ); ?>">
            </form>
        <?php endif; ?>
        <?php
    }

    public function handle_send(): void {
        $campaign_id = absint( $_POST['campaign_id'] ?? 0 );
        if ( ! $campaign_id || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wcsm_send_nonce'] ?? '' ) ), 'wcsm_send_campaign_' . $campaign_id ) ) {
            wp_die( esc_html__( 'Security check failed.', 'wp-content-subscriptions' ) );
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'wp-content-subscriptions' ) );
        }

        $post    = get_post( $campaign_id );
        $html    = apply_filters( 'the_content', $post->post_content );
        $mailer  = new WCSM_Mailer();
        $subs    = WCSM_Database::get_all_active_subscribers();
        $sent    = 0;

        foreach ( $subs as $sub ) {
            $mailer->send_digest_to_subscriber( $sub, $html );
            $sent++;
        }

        update_post_meta( $campaign_id, '_wcsm_sent_at', current_time( 'mysql' ) );
        update_post_meta( $campaign_id, '_wcsm_sent_count', $sent );

        wp_safe_redirect( add_query_arg( array( 'post' => $campaign_id, 'action' => 'edit', 'wcsm_sent' => $sent ), admin_url( 'post.php' ) ) );
        exit;
    }
}