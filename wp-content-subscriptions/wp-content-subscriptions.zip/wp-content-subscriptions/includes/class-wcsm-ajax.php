<?php
/**
 * AJAX: Subscribe and Unsubscribe handlers
 * FILE: wp-content-subscriptions/includes/class-wcsm-ajax.php
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Ajax {

    public function subscribe(): void {
        check_ajax_referer( 'wcsm_nonce', 'nonce' );

        $email    = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
        $name     = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
        $term_ids = isset( $_POST['terms'] ) ? array_map( 'absint', (array) $_POST['terms'] ) : array();

        if ( ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'wp-content-subscriptions' ) ) );
        }
        if ( empty( $term_ids ) ) {
            wp_send_json_error( array( 'message' => __( 'Please select at least one category.', 'wp-content-subscriptions' ) ) );
        }

        // Validate term IDs are real categories.
        $valid_terms = array();
        foreach ( $term_ids as $tid ) {
            $term = get_term( $tid, 'category' );
            if ( $term && ! is_wp_error( $term ) ) $valid_terms[] = $tid;
        }
        if ( empty( $valid_terms ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid categories selected.', 'wp-content-subscriptions' ) ) );
        }

        $result = WCSM_Database::add_subscriber( $email, $name, $valid_terms );

        if ( 'already_subscribed' === $result ) {
            wp_send_json_error( array( 'message' => __( 'You are already subscribed with this email address.', 'wp-content-subscriptions' ) ) );
        }
        if ( ! $result ) {
            wp_send_json_error( array( 'message' => __( 'Subscription failed. Please try again.', 'wp-content-subscriptions' ) ) );
        }

        WCSM_Tokens::send_confirmation( $email, $result );

        wp_send_json_success( array(
            'message' => __( 'Almost there! Check your email to confirm your subscription.', 'wp-content-subscriptions' ),
        ) );
    }

    public function unsubscribe(): void {
        // Token IS the authentication — no nonce needed.
        $token = sanitize_text_field( wp_unslash( $_REQUEST['wcsm_unsubscribe'] ?? '' ) ); // phpcs:ignore
        if ( empty( $token ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid unsubscribe token.', 'wp-content-subscriptions' ) ) );
        }

        global $wpdb;
        $table  = $wpdb->prefix . 'wcsm_subscribers';
        $result = $wpdb->update( $table, // phpcs:ignore
            array( 'status' => 'unsubscribed' ),
            array( 'unsubscribe_token' => $token, 'status' => 'active' )
        );

        if ( $result ) {
            WCSM_Database::count_active();
            wp_send_json_success( array( 'message' => __( 'You have been unsubscribed successfully.', 'wp-content-subscriptions' ) ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Unsubscribe link is invalid or already used.', 'wp-content-subscriptions' ) ) );
        }
    }
}