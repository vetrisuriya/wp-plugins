<?php
/**
 * Database tables: subscribers and their category subscriptions.
 * FILE: wp-content-subscriptions/includes/class-wcsm-database.php
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Database {

    public static function create_tables(): void {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Table 1: Subscribers.
        $t1 = $wpdb->prefix . 'wcsm_subscribers';
        dbDelta( "CREATE TABLE {$t1} (
  id                bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  email             varchar(200) NOT NULL,
  name              varchar(100) DEFAULT '',
  status            varchar(20)  NOT NULL DEFAULT 'pending',
  confirm_token     varchar(64)  DEFAULT '',
  token_expires     datetime     DEFAULT NULL,
  subscribed_at     datetime     DEFAULT NULL,
  last_email_at     datetime     DEFAULT NULL,
  unsubscribe_token varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY  (id),
  UNIQUE KEY email (email),
  KEY status (status),
  KEY confirm_token (confirm_token),
  KEY unsubscribe_token (unsubscribe_token)
) {$charset_collate};" );

        // Table 2: Category subscriptions (subscriber → category mapping).
        $t2 = $wpdb->prefix . 'wcsm_subscriptions';
        dbDelta( "CREATE TABLE {$t2} (
  id            bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  subscriber_id bigint(20) unsigned NOT NULL,
  term_id       bigint(20) unsigned NOT NULL,
  taxonomy      varchar(100) NOT NULL DEFAULT 'category',
  PRIMARY KEY  (id),
  KEY subscriber_id (subscriber_id),
  KEY term_id (term_id),
  UNIQUE KEY subscriber_term (subscriber_id, term_id)
) {$charset_collate};" );

        update_option( 'wcsm_db_version', '1.0.0' );
    }

    public static function add_subscriber( string $email, string $name, array $term_ids ): string|int|false {
        global $wpdb;
        $sub_t   = $wpdb->prefix . 'wcsm_subscribers';
        $pref_t  = $wpdb->prefix . 'wcsm_subscriptions';

        $existing = $wpdb->get_row( $wpdb->prepare( // phpcs:ignore
            "SELECT id, status FROM {$sub_t} WHERE email = %s", $email
        ) );

        if ( $existing && 'active' === $existing->status ) return 'already_subscribed';

        $confirm_token     = wp_generate_uuid4();
        $unsubscribe_token = wp_generate_uuid4();
        $expires           = gmdate( 'Y-m-d H:i:s', strtotime( '+24 hours' ) );

        if ( $existing ) {
            $wpdb->update( $sub_t, array( // phpcs:ignore
                'name' => sanitize_text_field( $name ), 'status' => 'pending',
                'confirm_token' => $confirm_token, 'token_expires' => $expires,
                'unsubscribe_token' => $unsubscribe_token,
            ), array( 'id' => $existing->id ) );
            $subscriber_id = $existing->id;
        } else {
            $wpdb->insert( $sub_t, array( // phpcs:ignore
                'email' => sanitize_email( $email ), 'name' => sanitize_text_field( $name ),
                'status' => 'pending', 'confirm_token' => $confirm_token,
                'token_expires' => $expires, 'unsubscribe_token' => $unsubscribe_token,
            ) );
            $subscriber_id = $wpdb->insert_id;
        }

        if ( ! $subscriber_id ) return false;

        $wpdb->delete( $pref_t, array( 'subscriber_id' => $subscriber_id ), array( '%d' ) ); // phpcs:ignore
        foreach ( $term_ids as $term_id ) {
            $wpdb->insert( $pref_t, array( // phpcs:ignore
                'subscriber_id' => $subscriber_id,
                'term_id'       => absint( $term_id ),
                'taxonomy'      => 'category',
            ) );
        }

        return $confirm_token;
    }

    public static function get_subscribers_by_term( int $term_id ): array {
        global $wpdb;
        $sub_t  = $wpdb->prefix . 'wcsm_subscribers';
        $pref_t = $wpdb->prefix . 'wcsm_subscriptions';
        return $wpdb->get_results( $wpdb->prepare( // phpcs:ignore
            "SELECT s.id, s.email, s.name, s.unsubscribe_token
             FROM {$sub_t} s INNER JOIN {$pref_t} p ON s.id = p.subscriber_id
             WHERE p.term_id = %d AND s.status = 'active'", $term_id
        ) ) ?: array();
    }

    public static function get_all_active_subscribers(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'wcsm_subscribers';
        return $wpdb->get_results( "SELECT * FROM {$table} WHERE status = 'active'" ) ?: array(); // phpcs:ignore
    }

    public static function get_all_paginated( string $status = 'active', int $per_page = 50, int $offset = 0 ): array {
        global $wpdb;
        $table = $wpdb->prefix . 'wcsm_subscribers';
        return $wpdb->get_results( $wpdb->prepare( // phpcs:ignore
            "SELECT id, email, name, status, subscribed_at, last_email_at FROM {$table} WHERE status = %s ORDER BY subscribed_at DESC LIMIT %d OFFSET %d",
            $status, $per_page, $offset
        ), ARRAY_A ) ?: array();
    }

    public static function count_active(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'wcsm_subscribers';
        $count = absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'active'" ) ); // phpcs:ignore
        update_option( 'wcsm_subscriber_count', $count, false );
        return $count;
    }

    public static function count_by_status( string $status ): int {
        global $wpdb;
        $table = $wpdb->prefix . 'wcsm_subscribers';
        return absint( $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", $status ) ) ); // phpcs:ignore
    }
}