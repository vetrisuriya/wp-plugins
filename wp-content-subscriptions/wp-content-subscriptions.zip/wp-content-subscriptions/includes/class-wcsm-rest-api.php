<?php
/**
 * REST API: Subscriber management
 * FILE: wp-content-subscriptions/includes/class-wcsm-rest-api.php
 * Routes: GET /wcsm/v1/subscribers | GET /wcsm/v1/stats | DELETE /wcsm/v1/subscribers/{email}
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Rest_Api {

    const NAMESPACE = 'wcsm/v1';

    public function register_routes(): void {
        register_rest_route( self::NAMESPACE, '/subscribers', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_subscribers' ),
            'permission_callback' => fn() => current_user_can( 'manage_options' ),
            'args'                => array(
                'status'   => array( 'type' => 'string',  'default' => 'active',   'sanitize_callback' => 'sanitize_text_field' ),
                'per_page' => array( 'type' => 'integer', 'default' => 50,         'sanitize_callback' => 'absint' ),
                'page'     => array( 'type' => 'integer', 'default' => 1,          'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/stats', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_stats' ),
            'permission_callback' => fn() => current_user_can( 'manage_options' ),
        ) );

        register_rest_route( self::NAMESPACE, '/subscribers/(?P<email>[^/]+)', array(
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => array( $this, 'delete_subscriber' ),
            'permission_callback' => fn() => current_user_can( 'manage_options' ),
        ) );
    }

    public function get_subscribers( WP_REST_Request $request ): WP_REST_Response {
        $status   = $request->get_param( 'status' );
        $per_page = $request->get_param( 'per_page' );
        $page     = $request->get_param( 'page' );
        $data     = WCSM_Database::get_all_paginated( $status, $per_page, ( $page - 1 ) * $per_page );
        return rest_ensure_response( $data );
    }

    public function get_stats(): WP_REST_Response {
        return rest_ensure_response( array(
            'total_active'     => (int) get_option( 'wcsm_subscriber_count', 0 ),
            'last_digest_run'  => get_option( 'wcsm_last_digest_run', 'Never' ),
            'last_digest_sent' => (int) get_option( 'wcsm_last_digest_sent', 0 ),
            'next_digest_run'  => wp_next_scheduled( 'wcsm_send_digest' ),
        ) );
    }

    public function delete_subscriber( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        global $wpdb;
        $email = sanitize_email( urldecode( $request->get_param( 'email' ) ) );
        if ( ! is_email( $email ) ) return new WP_Error( 'invalid_email', __( 'Invalid email.', 'wp-content-subscriptions' ), array( 'status' => 400 ) );

        $sub_t  = $wpdb->prefix . 'wcsm_subscribers';
        $pref_t = $wpdb->prefix . 'wcsm_subscriptions';
        $sub    = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$sub_t} WHERE email = %s", $email ) ); // phpcs:ignore
        if ( ! $sub ) return new WP_Error( 'not_found', __( 'Subscriber not found.', 'wp-content-subscriptions' ), array( 'status' => 404 ) );

        $wpdb->delete( $pref_t, array( 'subscriber_id' => $sub->id ), array( '%d' ) ); // phpcs:ignore
        $wpdb->delete( $sub_t,  array( 'id' => $sub->id ),             array( '%d' ) ); // phpcs:ignore
        WCSM_Database::count_active();

        return rest_ensure_response( array( 'deleted' => true, 'email' => $email ) );
    }
}