<?php
/**
 * Mailer: Build and send digest emails. Optionally fetch external RSS via HTTP API.
 * FILE: wp-content-subscriptions/includes/class-wcsm-mailer.php
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Mailer {

    public function send_digest_to_subscriber( object $subscriber, string $digest_html ): void {
        $options         = WCSM_Settings::get_options();
        $unsubscribe_url = add_query_arg( 'wcsm_unsubscribe', $subscriber->unsubscribe_token, get_home_url() );
        $external        = $this->fetch_external_rss( $options['external_rss_url'] ?? '' );

        $full_html = $digest_html;
        if ( $external ) {
            $full_html .= '<hr><h2>' . esc_html__( 'Around the Web', 'wp-content-subscriptions' ) . '</h2>' . $external;
        }
        $full_html .= '<p style="margin-top:30px;font-size:11px;color:#999;">'
            . sprintf( '<a href="%s">Unsubscribe</a> from this list.', esc_url( $unsubscribe_url ) )
            . '</p>';

        $subject = sprintf( __( 'Your Weekly Digest from %s', 'wp-content-subscriptions' ), get_bloginfo( 'name' ) );
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            sprintf( 'From: %s <%s>', $options['from_name'], $options['from_email'] ),
        );

        wp_mail( $subscriber->email, $subject, $full_html, $headers );

        // Track last send timestamp.
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'wcsm_subscribers', // phpcs:ignore
            array( 'last_email_at' => current_time( 'mysql' ) ),
            array( 'id' => $subscriber->id )
        );
    }

    public function fetch_external_rss( string $rss_url ): string|false {
        if ( empty( $rss_url ) || ! filter_var( $rss_url, FILTER_VALIDATE_URL ) ) return false;

        $cache_key = 'wcsm_rss_' . md5( $rss_url );
        $cached    = get_transient( $cache_key );
        if ( false !== $cached ) return $cached;

        $response = wp_remote_get( $rss_url, array(
            'timeout'    => 10,
            'user-agent' => 'WordPress/' . get_bloginfo( 'version' ) . '; ' . get_bloginfo( 'url' ),
        ) );

        if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) return false;

        $body = wp_remote_retrieve_body( $response );
        $rss  = simplexml_load_string( $body );
        if ( ! $rss ) return false;

        $html = '<ul>';
        $n    = 0;
        foreach ( $rss->channel->item as $item ) {
            if ( ++$n > 5 ) break;
            $html .= '<li><a href="' . esc_url( (string) $item->link ) . '">' . esc_html( (string) $item->title ) . '</a></li>';
        }
        $html .= '</ul>';

        set_transient( $cache_key, $html, 2 * HOUR_IN_SECONDS );
        return $html;
    }
}