<?php
/**
 * [subscription_form] shortcode
 * FILE: wp-content-subscriptions/includes/class-wcsm-shortcode.php
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Shortcode {

    /**
     * [subscription_form title="…" show_name="yes" categories="1,2,3"]
     */
    public function render( $atts ): string {
        $atts = shortcode_atts( array(
            'title'      => __( 'Subscribe for Updates', 'wp-content-subscriptions' ),
            'show_name'  => 'yes',
            'categories' => '',
        ), $atts, 'subscription_form' );

        $args = array( 'taxonomy' => 'category', 'hide_empty' => true );
        if ( ! empty( $atts['categories'] ) ) {
            $args['include'] = array_map( 'absint', explode( ',', $atts['categories'] ) );
        }
        $categories = get_terms( $args );

        if ( is_wp_error( $categories ) || empty( $categories ) ) {
            return '<p class="wcsm-notice">' . esc_html__( 'No categories available for subscription.', 'wp-content-subscriptions' ) . '</p>';
        }

        // Show status messages from confirmation / unsubscribe redirects.
        $status_msg = '';
        if ( isset( $_GET['wcsm_status'] ) ) { // phpcs:ignore
            $status = sanitize_text_field( wp_unslash( $_GET['wcsm_status'] ) ); // phpcs:ignore
            $messages = array(
                'confirmed'    => __( '✅ Your subscription is confirmed! You will receive the next digest.', 'wp-content-subscriptions' ),
                'unsubscribed' => __( '👋 You have been unsubscribed successfully.', 'wp-content-subscriptions' ),
                'invalid'      => __( '⚠️ That link is invalid or has expired. Please try subscribing again.', 'wp-content-subscriptions' ),
            );
            if ( isset( $messages[ $status ] ) ) {
                $status_msg = '<div class="wcsm-status wcsm-status--' . esc_attr( $status ) . '">' . esc_html( $messages[ $status ] ) . '</div>';
            }
        }

        ob_start();
        ?>
        <?php echo wp_kses_post( $status_msg ); ?>
        <div class="wcsm-form-wrap">
            <h3 class="wcsm-form-title"><?php echo esc_html( $atts['title'] ); ?></h3>
            <form id="wcsm-subscribe-form" class="wcsm-form" novalidate>
                <?php if ( 'yes' === $atts['show_name'] ) : ?>
                <div class="wcsm-form-field">
                    <label for="wcsm-name"><?php esc_html_e( 'Your Name', 'wp-content-subscriptions' ); ?></label>
                    <input type="text" id="wcsm-name" name="name" placeholder="<?php esc_attr_e( 'Jane Doe', 'wp-content-subscriptions' ); ?>" autocomplete="name">
                </div>
                <?php endif; ?>
                <div class="wcsm-form-field">
                    <label for="wcsm-email"><?php esc_html_e( 'Email Address', 'wp-content-subscriptions' ); ?> <span class="wcsm-req">*</span></label>
                    <input type="email" id="wcsm-email" name="email" required placeholder="<?php esc_attr_e( 'you@example.com', 'wp-content-subscriptions' ); ?>" autocomplete="email">
                </div>
                <fieldset class="wcsm-form-field">
                    <legend><?php esc_html_e( 'Subscribe to:', 'wp-content-subscriptions' ); ?></legend>
                    <div class="wcsm-categories">
                        <?php foreach ( $categories as $cat ) : ?>
                        <label class="wcsm-cat-label">
                            <input type="checkbox" name="terms[]" value="<?php echo esc_attr( $cat->term_id ); ?>">
                            <?php echo esc_html( $cat->name ); ?>
                            <span class="wcsm-count">(<?php echo absint( $cat->count ); ?>)</span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </fieldset>
                <div class="wcsm-form-field">
                    <button type="submit" class="wcsm-subscribe-btn">
                        <?php esc_html_e( 'Subscribe', 'wp-content-subscriptions' ); ?>
                    </button>
                </div>
                <div class="wcsm-message" role="alert" aria-live="polite" style="display:none;"></div>
                <p class="wcsm-privacy"><?php esc_html_e( 'We respect your privacy. Unsubscribe anytime.', 'wp-content-subscriptions' ); ?></p>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }
}