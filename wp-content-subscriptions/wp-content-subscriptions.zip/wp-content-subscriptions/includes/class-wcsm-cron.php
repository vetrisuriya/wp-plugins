<?php
/**
 * WP-Cron scheduling and digest sending logic.
 * FILE: wp-content-subscriptions/includes/class-wcsm-cron.php
 * @package WPContentSubscriptions
 */
defined( 'ABSPATH' ) || exit;

class WCSM_Cron {

    public static function schedule_events(): void {
        add_filter( 'cron_schedules', array( __CLASS__, 'add_cron_schedules' ) );
        $options = WCSM_Settings::get_options();
        if ( ! wp_next_scheduled( 'wcsm_send_digest' ) ) {
            wp_schedule_event( self::get_next_run_time( $options['digest_frequency'] ), $options['digest_frequency'], 'wcsm_send_digest' );
        }
        if ( ! wp_next_scheduled( 'wcsm_cleanup_tokens' ) ) {
            wp_schedule_event( time(), 'daily', 'wcsm_cleanup_tokens' );
        }
    }

    public static function unschedule_events(): void {
        foreach ( array( 'wcsm_send_digest', 'wcsm_cleanup_tokens' ) as $hook ) {
            $ts = wp_next_scheduled( $hook );
            if ( $ts ) wp_unschedule_event( $ts, $hook );
        }
    }

    public static function add_cron_schedules( array $schedules ): array {
        $schedules['weekly']   = array( 'interval' => WEEK_IN_SECONDS,     'display' => __( 'Once Weekly',      'wp-content-subscriptions' ) );
        $schedules['biweekly'] = array( 'interval' => 2 * WEEK_IN_SECONDS, 'display' => __( 'Every Two Weeks',  'wp-content-subscriptions' ) );
        return $schedules;
    }

    public function send_digest(): void {
        $options    = WCSM_Settings::get_options();
        $batch_size = absint( $options['batch_size'] ?? 50 );
        $last_run   = (int) get_option( 'wcsm_last_digest_run', strtotime( '-7 days' ) );

        $new_posts = $this->get_new_posts_since( $last_run );
        if ( empty( $new_posts ) ) {
            update_option( 'wcsm_last_digest_run', time() );
            return;
        }

        $digest_html = $this->build_digest_html( $new_posts );
        $subscribers = WCSM_Database::get_all_active_subscribers();
        $mailer      = new WCSM_Mailer();
        $sent        = 0;

        foreach ( $subscribers as $subscriber ) {
            if ( $sent >= $batch_size ) {
                wp_schedule_single_event( time() + 60, 'wcsm_send_digest' );
                break;
            }
            $mailer->send_digest_to_subscriber( $subscriber, $digest_html );
            $sent++;
        }

        update_option( 'wcsm_last_digest_run', time() );
        update_option( 'wcsm_last_digest_sent', $sent );
    }

    private function get_new_posts_since( int $since ): array {
        $cache_key = 'wcsm_digest_posts_' . $since;
        $cached    = get_transient( $cache_key );
        if ( false !== $cached ) return $cached;

        $posts = get_posts( array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 20,
            'date_query'     => array( array( 'after' => gmdate( 'Y-m-d H:i:s', $since ), 'inclusive' => false ) ),
            'meta_query'     => array( 'relation' => 'OR',
                array( 'key' => '_wcsm_notified', 'compare' => 'NOT EXISTS' ),
                array( 'key' => '_wcsm_notified', 'value' => '0' ),
            ),
        ) );

        set_transient( $cache_key, $posts, HOUR_IN_SECONDS );
        return $posts;
    }

    private function build_digest_html( array $posts ): string {
        ob_start();
        ?>
        <div style="max-width:600px;margin:0 auto;font-family:Arial,sans-serif;">
            <h1 style="color:#333;"><?php echo esc_html( get_bloginfo( 'name' ) ); ?> — <?php esc_html_e( 'Latest Content', 'wp-content-subscriptions' ); ?></h1>
            <?php foreach ( $posts as $post ) : ?>
            <div style="border-bottom:1px solid #eee;padding:16px 0;">
                <h2><a href="<?php echo esc_url( get_permalink( $post->ID ) ); ?>" style="color:#0073aa;text-decoration:none;"><?php echo esc_html( $post->post_title ); ?></a></h2>
                <p style="color:#666;font-size:13px;"><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $post->post_date ) ) ); ?></p>
                <p><?php echo esc_html( get_the_excerpt( $post ) ); ?></p>
                <a href="<?php echo esc_url( get_permalink( $post->ID ) ); ?>" style="display:inline-block;background:#0073aa;color:#fff;padding:8px 16px;text-decoration:none;border-radius:4px;"><?php esc_html_e( 'Read More', 'wp-content-subscriptions' ); ?></a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public function cleanup_expired_tokens(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'wcsm_subscribers';
        $wpdb->query( $wpdb->prepare( // phpcs:ignore
            "DELETE FROM {$table} WHERE status = 'pending' AND token_expires < %s",
            current_time( 'mysql' )
        ) );
    }

    private static function get_next_run_time( string $frequency ): int {
        return 'weekly' === $frequency ? strtotime( 'next Monday 08:00:00' ) : strtotime( '+1 day' );
    }
}