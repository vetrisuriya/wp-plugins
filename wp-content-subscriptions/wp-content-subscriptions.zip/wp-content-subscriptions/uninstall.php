<?php
/**
 * Uninstall — removes ALL plugin data permanently.
 * FILE: wp-content-subscriptions/uninstall.php
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;
foreach ( array( 'wcsm_subscribers', 'wcsm_subscriptions' ) as $t ) {
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$t}" );
}

foreach ( array( 'wcsm_settings', 'wcsm_subscriber_count', 'wcsm_last_digest_run', 'wcsm_last_digest_sent', 'wcsm_db_version' ) as $opt ) {
    delete_option( $opt );
}

// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wcsm_%' OR option_name LIKE '_transient_timeout_wcsm_%'" );