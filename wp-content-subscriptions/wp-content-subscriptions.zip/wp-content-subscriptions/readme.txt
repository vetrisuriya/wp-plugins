=== WP Content Subscription Manager ===
Contributors:      vetrisuriya
Tags:              subscription, email digest, newsletter, categories, opt-in
Requires at least: 5.8
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      7.4
License:           GPL v2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Let readers subscribe to content categories and receive automatic email digests. Double opt-in, WP-Cron scheduling, batch sending, external RSS inclusion, and REST API.

== Description ==

**WP Content Subscription Manager** turns your WordPress site into a self-service newsletter platform. Readers subscribe to specific post categories and receive automatic email digests whenever new content is published.

= Core Features =

* **[subscription_form] shortcode** — embeds a subscription form with category checkboxes and double opt-in flow
* **Double opt-in** — every subscriber receives a confirmation email before they are activated
* **Automatic digest emails** — WP-Cron sends digest emails on a daily, weekly, or biweekly schedule
* **Batch sending** — large subscriber lists are split into configurable batches to avoid server timeouts
* **External RSS inclusion** — optionally include up to 5 items from an external RSS feed in every digest
* **Email Campaigns CPT** — create manual one-off email campaigns and send to all active subscribers with one click
* **Subscribers admin page** — view, filter by status, and manage subscribers directly in wp-admin
* **REST API** — GET, filter, and DELETE subscribers via `/wp-json/wcsm/v1/` endpoints
* **Self-service unsubscribe** — unique token-based unsubscribe links in every digest email, no login needed
* **Token cleanup** — expired pending opt-in tokens are automatically deleted by a daily cron job
* **Clean uninstall** — all database tables and options removed on plugin deletion

= Shortcodes =

`[subscription_form]`
`[subscription_form title="Join Our Newsletter" show_name="yes" categories="3,5,12"]`

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload Plugin**
2. Go to **Subscriptions → Settings** and fill in From Name, From Email, and Digest Frequency
3. Add `[subscription_form]` to any page
4. Optionally create an Email Campaign under **Subscriptions → Campaigns**

== Frequently Asked Questions ==

= How does the subscription form work? =

Visitors enter their email and name, tick the categories they want, and click Subscribe. They receive a confirmation email with a verification link. Clicking the link activates their subscription. The digest is sent automatically on the schedule you configure.

= How does double opt-in work? =

Every new subscriber gets a confirmation email with a unique link (`?wcsm_confirm=TOKEN`). Clicking it sets their status from `pending` to `active`. Unconfirmed subscribers are never emailed in digests. Expired tokens (over 24 hours old) are cleaned up daily.

= Why are digests not sending on schedule? =

WP-Cron depends on site traffic — events only fire when a page is visited. On low-traffic sites, add a real server cron to trigger WP-Cron every 5 minutes:

`*/5 * * * * wget -q -O - https://yoursite.com/wp-cron.php?doing_wp_cron > /dev/null 2>&1`

Then add `define('DISABLE_WP_CRON', true)` to `wp-config.php`.

= How do I send a one-off campaign? =

Go to **Subscriptions → Campaigns**, click **Create Campaign**, write your email content in the post editor, and click **Save as Draft**. Then click **📤 Send Now** in the "Send Campaign" meta box. The email is sent to all active subscribers immediately.

= Can I show only specific categories in the subscription form? =

Yes — use the `categories` attribute with a comma-separated list of category IDs:
`[subscription_form categories="3,5,12"]`

= How does unsubscribing work? =

Every digest email contains an unsubscribe link with a unique token (`?wcsm_unsubscribe=TOKEN`). Clicking it immediately sets the subscriber's status to `unsubscribed` without requiring a login.

= What data is stored? =

Two custom database tables: `wp_wcsm_subscribers` (email, name, status, tokens, timestamps) and `wp_wcsm_subscriptions` (subscriber ↔ category relationships). No data is sent to any external service.

== Screenshots ==

1. Subscription form with category checkboxes.
2. Admin subscribers list with status filter tabs and stat cards.
3. Email Campaign post type with "Send Now" button.
4. Settings page — From Name, From Email, Digest Frequency, Batch Size, External RSS URL.
5. Double opt-in confirmation email example.

== Changelog ==

= 1.0.0 =
* Initial release. Subscription form shortcode, double opt-in, WP-Cron digests, batch sending, external RSS, REST API, manual campaign CPT, subscribers admin page.

== Upgrade Notice ==

= 1.0.0 =
Initial release. No upgrade steps required.