# WP Content Subscription Manager — User Guide

## Table of Contents

- [What This Plugin Does](#what-this-plugin-does)
- [After Activation](#after-activation)
- [Step 1: Configure Settings](#step-1-configure-settings)
- [Step 2: Add the Subscription Form](#step-2-add-the-subscription-form)
- [Shortcode Reference](#shortcode-reference)
  - [[subscription_form]](#subscription_form)
- [How Subscription Works (User Journey)](#how-subscription-works-user-journey)
- [Managing Subscribers](#managing-subscribers)
- [Digest Emails](#digest-emails)
- [Email Campaigns (One-Off Sends)](#email-campaigns-one-off-sends)
- [REST API](#rest-api)
- [WP-Cron & Production Setup](#wp-cron--production-setup)
- [FAQ](#faq)

---

## What This Plugin Does

WP Content Subscription Manager lets your readers subscribe to specific post categories and receive automatic email digests when new content is published.

| Feature | Where |
|---|---|
| **Subscription form** | Any page with `[subscription_form]` |
| **Manage subscribers** | **Subscriptions → Subscribers** |
| **Configure digest schedule** | **Subscriptions → Settings** |
| **Send one-off campaigns** | **Subscriptions → Campaigns** |
| **REST API** | `/wp-json/wcsm/v1/` |

---

## After Activation

When you activate the plugin, WordPress creates two database tables:

- `wp_wcsm_subscribers` — stores email, name, status, opt-in token, unsubscribe token
- `wp_wcsm_subscriptions` — stores subscriber ↔ category relationships

The plugin also schedules a WP-Cron job to send digests and a daily job to clean up expired tokens.

---

## Step 1: Configure Settings

Go to **Subscriptions → Settings**.

| Setting | Default | Description |
|---|---|---|
| **From Name** | Site name | The sender name in all digest and confirmation emails |
| **From Email** | Admin email | The From address. Must match your domain to avoid spam filters |
| **Digest Frequency** | Weekly | How often the digest is sent: Daily / Weekly / Every Two Weeks |
| **Batch Size** | 50 | How many emails are sent per cron run. Keep below 100 on shared hosting |
| **External RSS URL** | *(empty)* | Optional. Up to 5 items from this RSS feed are appended to each digest |

Click **Save Changes**.

> **Important:** If you change the Digest Frequency after setup, you need to deactivate and reactivate the plugin (or use WP-CLI) to reschedule the cron event with the new interval.

---

## Step 2: Add the Subscription Form

1. Go to **Pages → Add New**
2. Title it "Subscribe" or "Newsletter"
3. Add the shortcode:

```
[subscription_form]
```

4. Publish the page and add it to your navigation menu

The form will show:
- A name field (optional, shown by default)
- An email field (required)
- Checkboxes for every public category that has at least one published post
- A Subscribe button
- A privacy note

---

## Shortcode Reference

### [subscription_form]

Renders the email subscription form with category checkboxes.

**Basic usage:**

```
[subscription_form]
```

**All attributes:**

```
[subscription_form title="Join Our Newsletter" show_name="yes" categories="3,5,12"]
```

| Attribute | Default | Description |
|---|---|---|
| `title` | `"Subscribe for Updates"` | Heading shown above the form |
| `show_name` | `"yes"` | Show or hide the name field. Use `"no"` to show email + categories only |
| `categories` | *(all non-empty categories)* | Comma-separated list of category IDs to show as options. Leave empty to show all |

**Examples:**

```
[subscription_form]
```
Shows all non-empty categories, with name field, and default heading.

```
[subscription_form title="Get Weekly Updates" show_name="no"]
```
Hides the name field and uses a custom heading.

```
[subscription_form categories="3,5,12"]
```
Shows only the three specified categories.

```
[subscription_form title="Tech News Digest" show_name="no" categories="7"]
```
Single-category form for a focused topic newsletter.

**Finding category IDs:**
Go to **Posts → Categories**. Hover over a category name — the URL in the status bar shows `tag_ID=N`. That number is the category ID.

**Status messages shown on the form page:**
After clicking a confirmation or unsubscribe link in an email, the visitor is redirected back to the page with the form. A status message appears:
- ✅ "Your subscription is confirmed!" — after clicking the opt-in link
- 👋 "You have been unsubscribed successfully." — after clicking an unsubscribe link
- ⚠️ "That link is invalid or has expired." — if the token is wrong or expired

---

## How Subscription Works (User Journey)

```
1. Visitor fills in the form and clicks Subscribe
       ↓
2. AJAX sends email + categories to the server
       ↓
3. Plugin saves subscriber with status = "pending"
   and sends a CONFIRMATION EMAIL
       ↓
4. Visitor clicks the link in the email
       ↓
5. Subscriber status → "active"
   ✅ Visitor sees "Your subscription is confirmed!"
       ↓
6. On the next digest run, active subscriber receives the digest
       ↓
7. Digest contains an UNSUBSCRIBE LINK at the bottom
       ↓
8. Clicking unsubscribe → status = "unsubscribed"
   ✅ No more emails
```

### Subscriber statuses

| Status | Meaning |
|---|---|
| **Pending** | Form submitted but confirmation email not yet clicked. Not emailed in digests. |
| **Active** | Confirmed. Receives all digest emails. |
| **Unsubscribed** | Clicked unsubscribe. Never emailed again. |

---

## Managing Subscribers

Go to **Subscriptions → Subscribers**.

### Stat cards (top of page)

- **Active** — confirmed, receiving digests
- **Pending Confirmation** — submitted form, not yet confirmed
- **Unsubscribed** — opted out
- **Next Digest In** — countdown to the next scheduled send

### Filter tabs

Click **Active**, **Pending**, or **Unsubscribed** to filter the list.

### Table columns

| Column | Description |
|---|---|
| **Email** | Subscriber email address |
| **Name** | Name entered in the form (may be blank if hidden) |
| **Status** | Current status badge |
| **Subscribed** | Date/time the opt-in was confirmed |
| **Last Emailed** | Date/time of the last digest sent to this subscriber |

> **Note:** There is no admin bulk-delete in this version. Use the REST API `DELETE /wp-json/wcsm/v1/subscribers/{email}` to remove individual subscribers programmatically.

---

## Digest Emails

### What triggers a digest

The digest is sent automatically by WP-Cron on your configured schedule. It queries all WordPress posts published since the last digest run (stored in `wcsm_last_digest_run`) that have not yet been marked as notified.

### What the digest contains

- All new posts since the last run (up to 20 per digest)
- Post title (linked), date, excerpt, and "Read More" button
- Optional: up to 5 items from your configured External RSS feed
- An unsubscribe link at the bottom

### Batch sending

The digest is sent in batches. If your subscriber list is larger than the Batch Size setting, the remaining subscribers are scheduled in a follow-up cron event 60 seconds later. This repeats until all subscribers have been emailed.

### Checking digest status

Go to **Subscriptions → Subscribers** and look at the stat cards:
- **Next Digest In** — shows time until the next scheduled send
- **Last Emailed** column — shows when each subscriber last received a digest

---

## Email Campaigns (One-Off Sends)

Campaigns let you send a custom email to all active subscribers at any time, independent of the digest schedule.

### Creating and sending a campaign

1. Go to **Subscriptions → Campaigns** (listed under the Subscriptions menu)
2. Click **Create Campaign**
3. Write your email content in the post editor (use the visual editor for HTML emails)
4. Click **Save as Draft** — do NOT publish
5. In the **Send Campaign** meta box (right sidebar), click **📤 Send Now**
6. WordPress immediately sends the email to all active subscribers
7. After sending, the meta box shows the send date and subscriber count

> **Tip:** The campaign content is sent as raw HTML. Use simple formatting — avoid complex CSS since email clients strip most stylesheets.

---

## REST API

All endpoints require the caller to be logged in as an Administrator.

### GET Subscribers

```
GET /wp-json/wcsm/v1/subscribers
```

**Query parameters:**

| Parameter | Default | Description |
|---|---|---|
| `status` | `active` | Filter: `active`, `pending`, `unsubscribed` |
| `per_page` | `50` | Results per page |
| `page` | `1` | Page number |

**Example:**
```
GET https://yoursite.com/wp-json/wcsm/v1/subscribers?status=active&per_page=100
```

**Response:**
```json
[
  {
    "id": "5",
    "email": "jane@example.com",
    "name": "Jane Smith",
    "status": "active",
    "subscribed_at": "2025-03-01 09:15:00",
    "last_email_at": "2025-03-10 08:00:00"
  }
]
```

### GET Stats

```
GET /wp-json/wcsm/v1/stats
```

**Response:**
```json
{
  "total_active": 248,
  "last_digest_run": 1741600000,
  "last_digest_sent": 248,
  "next_digest_run": 1742200000
}
```

Timestamps are Unix timestamps. Convert with `date -d @1741600000` on Linux.

### DELETE Subscriber

```
DELETE /wp-json/wcsm/v1/subscribers/{email}
```

URL-encode the email address. Example:
```
DELETE /wp-json/wcsm/v1/subscribers/jane%40example.com
```

**Response:**
```json
{ "deleted": true, "email": "jane@example.com" }
```

Returns 404 if the email is not found.

---

## WP-Cron & Production Setup

WP-Cron is WordPress's built-in scheduler. It only runs when someone visits your site — on low-traffic sites this means digests may fire hours or days late.

### Setting up a real server cron (recommended for production)

**Step 1:** Add a real crontab entry to your server (cPanel or SSH):

```bash
*/5 * * * * wget -q -O - https://yoursite.com/wp-cron.php?doing_wp_cron > /dev/null 2>&1
```

This pings WP-Cron every 5 minutes, ensuring scheduled events fire accurately.

**Step 2:** Disable WordPress's own WP-Cron trigger (prevents double-firing):

In `wp-config.php`, add before `/* That's all, stop editing! */`:

```php
define( 'DISABLE_WP_CRON', true );
```

**Verifying the next digest time:**

Check the Subscribers page stat card, or use WP-CLI:
```bash
wp cron event list
```

---

## FAQ

**The subscription form shows "No categories available."**

This appears when no post categories exist OR all existing categories have 0 posts. Create at least one category, publish a post in it, and the form will show it.

**Confirmation emails are not arriving.**

WordPress sends email via the server's default PHP `mail()`. On many shared hosts this goes to spam or doesn't work at all. Install **WP Mail SMTP** and connect to Gmail, SendGrid, or Mailgun. Test with **WP Mail SMTP → Email Test**.

**Can a subscriber change which categories they receive?**

Not in this version via self-service. They would need to unsubscribe and re-subscribe with the new category selection.

**Can I import an existing email list?**

Not through the UI. You can insert rows directly into `wp_wcsm_subscribers` (set `status='active'`) and into `wp_wcsm_subscriptions` for each category relationship. Make sure to generate a unique `unsubscribe_token` for each subscriber.

**The digest is not sending even with WP-Cron set up.**

Check with WP-CLI:
```bash
wp cron event list
```
If `wcsm_send_digest` is not listed, the event was not scheduled. Deactivate and reactivate the plugin to re-schedule it. Also check that the digest has new posts to send — if no new posts exist since the last run, the cron job exits early.

**Can the digest include posts from specific categories only?**

Not in this version — the digest includes all new posts regardless of category. Category filtering is only used for the subscription form (which categories a subscriber picks). The digest always sends all new content.

**How do I export my subscriber list?**

Use the REST API to GET all subscribers and save the JSON response. Or query the database directly:
```sql
SELECT email, name, status, subscribed_at FROM wp_wcsm_subscribers WHERE status = 'active';
```
Export via phpMyAdmin as CSV.

**What happens to subscriber data when I uninstall the plugin?**

Both database tables (`wp_wcsm_subscribers` and `wp_wcsm_subscriptions`) are dropped permanently. All plugin options and transients are deleted. This cannot be undone — export your subscriber list before uninstalling.