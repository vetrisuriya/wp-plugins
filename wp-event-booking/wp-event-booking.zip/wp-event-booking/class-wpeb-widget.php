<?php
/**
 * Upcoming Events Sidebar Widget
 * FILE: wp-event-booking/includes/class-wpeb-widget.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'wpeb_upcoming_events', __( 'Upcoming Events', 'wp-event-booking' ),
            array( 'description' => __( 'Displays upcoming events in the sidebar.', 'wp-event-booking' ) )
        );
        add_action( 'widgets_init', function () { register_widget( 'WPEB_Widget' ); } );
    }

    public function widget( $args, $instance ): void {
        $title = apply_filters( 'widget_title', $instance['title'] ?? '' );
        $limit = absint( $instance['limit'] ?? 3 );

        echo wp_kses_post( $args['before_widget'] );
        if ( $title ) echo wp_kses_post( $args['before_title'] . esc_html( $title ) . $args['after_title'] );

        $cache_key = 'wpeb_widget_events_' . $limit;
        $events    = get_transient( $cache_key );

        if ( false === $events ) {
            $events = ( new WP_Query( array(
                'post_type'      => 'wpeb_event',
                'posts_per_page' => $limit,
                'post_status'    => 'publish',
                'meta_key'       => '_wpeb_event_date',
                'orderby'        => 'meta_value',
                'order'          => 'ASC',
                'meta_query'     => array( array( 'key' => '_wpeb_event_date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=', 'type' => 'DATE' ) ),
            ) ) )->posts;
            set_transient( $cache_key, $events, 30 * MINUTE_IN_SECONDS );
        }

        if ( $events ) {
            echo '<ul class="wpeb-widget-list">';
            foreach ( $events as $event ) {
                $date = get_post_meta( $event->ID, '_wpeb_event_date', true );
                printf( '<li><a href="%s">%s</a><br><small>%s</small></li>',
                    esc_url( get_permalink( $event->ID ) ),
                    esc_html( $event->post_title ),
                    esc_html( $date )
                );
            }
            echo '</ul>';
        } else {
            echo '<p>' . esc_html__( 'No upcoming events.', 'wp-event-booking' ) . '</p>';
        }

        echo wp_kses_post( $args['after_widget'] );
    }

    public function form( $instance ): void {
        $title = $instance['title'] ?? __( 'Upcoming Events', 'wp-event-booking' );
        $limit = $instance['limit'] ?? 3;
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'wp-event-booking' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>"><?php esc_html_e( 'Number of events:', 'wp-event-booking' ); ?></label>
            <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>" type="number" value="<?php echo esc_attr( $limit ); ?>" min="1" max="10">
        </p>
        <?php
    }

    public function update( $new_instance, $old_instance ): array {
        return array( 'title' => sanitize_text_field( $new_instance['title'] ), 'limit' => absint( $new_instance['limit'] ) );
    }
}