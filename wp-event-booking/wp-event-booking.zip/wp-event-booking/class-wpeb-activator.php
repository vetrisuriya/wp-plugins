<?php
/**
 * Activation / Deactivation
 * FILE: wp-event-booking/includes/class-wpeb-activator.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Activator {

    public static function activate(): void {
        self::check_requirements();
        self::create_bookings_table();
        self::add_caps();
        self::set_default_options();
        update_option( 'wpeb_version', WPEB_VERSION, false );
        flush_rewrite_rules();
        set_transient( 'wpeb_activation_redirect', true, 30 );
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }

    public static function maybe_upgrade(): void {
        $installed = get_option( 'wpeb_version', '0.0.0' );
        if ( version_compare( $installed, WPEB_VERSION, '>=' ) ) return;
        self::add_caps();
        update_option( 'wpeb_version', WPEB_VERSION, false );
    }

    private static function check_requirements(): void {
        if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
            wp_die( sprintf( 'WP Event Booking requires PHP 8.0+. Your server runs PHP %s.', PHP_VERSION ), 'PHP Version Error', array( 'back_link' => true ) );
        }
    }

    private static function create_bookings_table(): void {
        global $wpdb;
        $table           = $wpdb->prefix . 'wpeb_bookings';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
  id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  event_id   BIGINT(20) UNSIGNED NOT NULL,
  name       VARCHAR(200) NOT NULL,
  email      VARCHAR(200) NOT NULL,
  seats      TINYINT(3) UNSIGNED NOT NULL DEFAULT 1,
  status     VARCHAR(20) NOT NULL DEFAULT 'pending',
  booked_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY event_id (event_id),
  KEY email (email),
  KEY status (status)
) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    private static function add_caps(): void {
        foreach ( array( 'administrator', 'editor' ) as $role_slug ) {
            $role = get_role( $role_slug );
            if ( $role ) $role->add_cap( 'manage_event_bookings' );
        }
    }

    private static function set_default_options(): void {
        add_option( 'wpeb_options', array(
            'admin_email'            => get_option( 'admin_email', '' ),
            'max_seats_per_booking'  => 5,
        ), '', false );
    }
}