<?php
/**
 * Bookings DB — CRUD for wp_wpeb_bookings table
 * FILE: wp-event-booking/includes/class-wpeb-bookings-db.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Bookings_DB {

    private string $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'wpeb_bookings';
    }

    public function insert( array $data ): int|WP_Error {
        global $wpdb;
        $result = $wpdb->insert( $this->table, array(
            'event_id'  => absint( $data['event_id'] ),
            'name'      => sanitize_text_field( $data['name'] ),
            'email'     => sanitize_email( $data['email'] ),
            'seats'     => absint( $data['seats'] ),
            'status'    => 'pending',
            'booked_at' => current_time( 'mysql' ),
        ), array( '%d', '%s', '%s', '%d', '%s', '%s' ) );

        return false === $result
            ? new WP_Error( 'db_insert_error', __( 'Could not save booking.', 'wp-event-booking' ) )
            : (int) $wpdb->insert_id;
    }

    public function get_booked_seats( int $event_id ): int {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT SUM(seats) FROM {$this->table} WHERE event_id = %d AND status = 'confirmed'",
            $event_id
        ) );
    }

    public function get_by_event( int $event_id ): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE event_id = %d ORDER BY booked_at DESC",
            $event_id
        ), ARRAY_A ) ?: array();
    }

    public function get_all( array $filters = array() ): array {
        global $wpdb;
        $where  = '1=1';
        $values = array();
        if ( ! empty( $filters['event_id'] ) ) { $where .= ' AND event_id = %d'; $values[] = absint( $filters['event_id'] ); }
        if ( ! empty( $filters['status'] )   ) { $where .= ' AND status = %s';   $values[]  = sanitize_text_field( $filters['status'] ); }
        $limit = absint( $filters['limit'] ?? 50 );
        $sql   = "SELECT * FROM {$this->table} WHERE {$where} ORDER BY booked_at DESC LIMIT %d";
        $values[] = $limit;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return $wpdb->get_results( $wpdb->prepare( $sql, ...$values ), ARRAY_A ) ?: array();
    }

    public function update_status( int $booking_id, string $status ): bool {
        global $wpdb;
        $allowed = array( 'pending', 'confirmed', 'cancelled' );
        if ( ! in_array( $status, $allowed, true ) ) return false;
        return false !== $wpdb->update( $this->table,
            array( 'status' => $status ),
            array( 'id' => $booking_id ),
            array( '%s' ),
            array( '%d' )
        );
    }

    public function count_by_status( string $status = '' ): int {
        global $wpdb;
        if ( ! $status ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table}" );
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->table} WHERE status = %s", $status ) );
    }
}