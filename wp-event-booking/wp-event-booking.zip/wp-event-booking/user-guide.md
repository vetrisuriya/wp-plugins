# WP Event Booking System — User Guide

## Table of Contents

- [Why the Fatal Error Happened](#why-the-fatal-error-happened)
- [Correct Plugin Folder Structure](#correct-plugin-folder-structure)
- [After Activation](#after-activation)
- [Step 1: Configure Settings](#step-1-configure-settings)
- [Step 2: Create Event Categories](#step-2-create-event-categories)
- [Step 3: Create an Event](#step-3-create-an-event)
- [Step 4: Add Shortcodes to Pages](#step-4-add-shortcodes-to-pages)
- [Shortcode Reference](#shortcode-reference)
  - [[event_list]](#event_list)
  - [[event_booking event_id="42"]](#event_booking-event_id42)
- [Managing Bookings](#managing-bookings)
- [REST API](#rest-api)
- [FAQ](#faq)

---

## Why the Fatal Error Happened

The plugin had **three bugs** that prevented activation:

### Bug 1 — Autoloader path mismatch (the fatal error itself)

```
Fatal error: Class "WPEB_Admin" not found in wp-event-booking.php on line 57
```

The original `wp-event-booking.php` used `spl_autoload_register()` which built file paths as:

```
wp-event-booking/includes/class-wpeb-admin.php   ← looked HERE
wp-event-booking/class-wpeb-admin.php            ← file was HERE
```

The autoloader silently found nothing. When WordPress called `new WPEB_Admin()`, PHP threw the fatal error.

**Fix:** Replaced `spl_autoload_register` with explicit `require_once` calls pointing to the plugin root.

### Bug 2 — Admin CSS/JS wrong paths

`class-wpeb-admin.php` enqueued:
```
WPEB_PLUGIN_URL . 'admin/css/wpeb-admin.css'   ← folder doesn't exist
WPEB_PLUGIN_URL . 'admin/js/wpeb-admin.js'     ← folder doesn't exist
```
Should be:
```
WPEB_PLUGIN_URL . 'wpeb-admin.css'    ← file is in plugin root
WPEB_PLUGIN_URL . 'wpeb-admin.js'     ← file is in plugin root
```

### Bug 3 — Public CSS/JS wrong paths

`class-wpeb-shortcodes.php` enqueued:
```
WPEB_PLUGIN_URL . 'public/css/wpeb-public.css'  ← folder doesn't exist
WPEB_PLUGIN_URL . 'public/js/wpeb-public.js'    ← folder doesn't exist
```
Should be:
```
WPEB_PLUGIN_URL . 'wpeb-public.css'  ← file is in plugin root
WPEB_PLUGIN_URL . 'wpeb-public.js'   ← file is in plugin root
```

All three bugs are now fixed.

---

## Correct Plugin Folder Structure

Put ALL files flat inside one folder named `wp-event-booking`. Do NOT create any subfolders.

```
wp-event-booking/
├── wp-event-booking.php          ← FIXED: explicit require_once, no autoloader
├── class-wpeb-activator.php
├── class-wpeb-cpt.php
├── class-wpeb-meta.php
├── class-wpeb-bookings-db.php
├── class-wpeb-settings.php
├── class-wpeb-shortcodes.php     ← FIXED: asset paths
├── class-wpeb-ajax.php
├── class-wpeb-rest-api.php
├── class-wpeb-widget.php
├── class-wpeb-email.php
├── class-wpeb-capabilities.php
├── class-wpeb-admin.php          ← FIXED: asset paths + full render
├── wpeb-public.css
├── wpeb-public.js
├── wpeb-admin.css
├── wpeb-admin.js
├── uninstall.php                 ← rename wpeb-uninstall.php → uninstall.php
└── readme.txt                    ← rename wpeb-readme.txt → readme.txt
```

**Important renames before uploading:**
- `wpeb-uninstall.php` → rename to `uninstall.php`
- `wpeb-readme.txt` → rename to `readme.txt`

---

## After Activation

When you activate the plugin it automatically:

1. Creates the `wp_wpeb_bookings` database table
2. Adds the `manage_event_bookings` capability to Administrator and Editor roles
3. Registers the `wpeb_event` Custom Post Type and `wpeb_event_category` taxonomy
4. Registers the `Upcoming Events` sidebar widget

Activate from **Plugins → Installed Plugins → WP Event Booking System → Activate**.

---

## Step 1: Configure Settings

Go to **Events → Settings**.

| Setting | Default | Description |
|---|---|---|
| **Organiser Email** | Admin email | Booking notification emails are sent to this address |
| **Max Seats Per Booking** | `5` | Maximum seats one visitor can book at a time |

Click **Save Settings**.

---

## Step 2: Create Event Categories

1. Go to **Events → Event Categories**
2. Click **Add New Event Category**
3. Enter a **Name** (e.g. "Workshop") — the Slug is auto-generated
4. Click **Add New Event Category**

Category slugs (e.g. `workshop`, `conference`) are used in the `[event_list]` shortcode to filter by category.

---

## Step 3: Create an Event

1. Go to **Events → Add New Event**
2. Enter the **event name** as the post title
3. Write the **full event description** in the main editor
4. Optionally add a **Featured Image** (shown as a thumbnail on the event card)
5. Fill in the **Event Details** meta box on the right:

| Field | Required | Description |
|---|---|---|
| **Event Date** | Yes | Date of the event. Events with a past date are not shown in `[event_list]`. |
| **Event Time** | No | Start time shown on the card (e.g. "10:00 AM") |
| **Venue / Location** | No | Shown on the card with a 📍 icon |
| **Total Seats** | Yes | Maximum bookings allowed. Seat count tracks confirmed bookings. |
| **Ticket Price** | No | Free text (e.g. "$25", "€50", "Free"). Shown on the card. |

6. Assign the event to one or more **Event Categories** using the checkbox panel
7. Click **Publish**

> **Finding the Event ID:** After publishing, look at the URL in the browser address bar: `post.php?post=42`. The number after `post=` is the Event ID. You need this for the `[event_booking]` shortcode.

---

## Step 4: Add Shortcodes to Pages

### Events Listing Page

1. Go to **Pages → Add New**
2. Title it "Events" or "Upcoming Events"
3. In the content editor, add the shortcode:

```
[event_list]
```

4. Publish and add to your navigation menu

### Individual Event / Booking Page

You have two options:

**Option A** — Use the single event post itself.  
Add the booking shortcode at the top of the event's post content:

```
[event_booking event_id="42"]
```

Replace `42` with the actual post ID.

**Option B** — Dedicated booking page.  
Create a separate page titled "Book Event", add the shortcode, and link to it from each event card.

---

## Shortcode Reference

### [event_list]

Renders a responsive grid of upcoming events. Only events with a date ≥ today are shown, sorted by date ascending.

**Basic usage:**

```
[event_list]
```

**Filtered usage:**

```
[event_list category="workshop" limit="6"]
```

| Attribute | Default | Description |
|---|---|---|
| `category` | all | Event Category **slug** to filter by. Slug shown in Events → Event Categories → Slug column. |
| `limit` | `10` | Maximum events to display. |

**What each event card shows:**

- Featured image (if set)
- Event title (linked to the single event page)
- Event date and time
- Venue/location
- Ticket price (or "Free")
- Available seats remaining
- Book Now button (or "Sold Out" when no seats remain)

**Caching:** Event list results are cached using WordPress transients for 1 hour. Cache clears automatically when a booking is confirmed.

---

### [event_booking event_id="42"]

Renders the AJAX booking form for a specific event.

**Usage:**

```
[event_booking event_id="42"]
```

| Attribute | Required | Description |
|---|---|---|
| `event_id` | **Yes** | WordPress post ID of the event. Found in the URL: `post=42`. |

**What it shows:**

- When seats are available: Name, Email, Number of Seats (capped at Max Per Booking from settings), and a Book My Seat button
- When sold out: a Sold Out message — no form shown

**What happens on submission:**

1. AJAX sends the form data with a WordPress nonce for security
2. Seat availability is re-checked on the server (prevents overbooking)
3. Booking is saved to `wp_wpeb_bookings` as `pending`
4. A confirmation email is sent to the attendee
5. A notification email is sent to the organiser email from settings
6. The form shows a success message

**Seat calculation:**

```
Available seats = Total Seats − COUNT(confirmed bookings for this event)
```

Pending bookings do not count toward the seat limit. Only Confirmed bookings reduce seat availability.

---

## Managing Bookings

Go to **Events → Bookings** to see all bookings in a table.

### Status Filter Tabs

| Status | Meaning |
|---|---|
| **Pending** | New booking submitted, not yet reviewed |
| **Confirmed** | Admin clicked ✓ Confirm — seat is reserved |
| **Cancelled** | Admin clicked ✕ Cancel — seat is released back |

### Actions

- **✓ Confirm** — Marks the booking Confirmed. The seat is now taken from the available count.
- **✕ Cancel** — Marks the booking Cancelled. The seat is released back into the available pool.

Both actions update via AJAX — no page reload required.

### Stat Cards

At the top of the page: Pending, Confirmed, Cancelled, and Total counts shown as cards.

---

## REST API

All event endpoints are **public** — no authentication required for reading.

### GET — List Upcoming Events

```
GET /wp-json/wpeb/v1/events
```

**Query parameters:**

| Parameter | Default | Description |
|---|---|---|
| `category` | all | Event Category slug |
| `limit` | `10` | Number of results |
| `page` | `1` | Page number |

**Response:**

```json
[
  {
    "id": 42,
    "title": "Yoga Workshop",
    "date": "2025-08-15",
    "time": "10:00 AM",
    "venue": "Downtown Studio",
    "price": "$25",
    "total_seats": 20,
    "booked_seats": 8,
    "available_seats": 12,
    "url": "https://yoursite.com/events/yoga-workshop/",
    "thumbnail": "https://yoursite.com/uploads/..."
  }
]
```

### GET — Single Event

```
GET /wp-json/wpeb/v1/events/{id}
```

Returns the same fields as the list endpoint plus the full event `content` (HTML).

Returns `404` if the event is not found or not published.

---

## FAQ

**The booking form shows but submitting does nothing.**  
Open the browser console (F12). If you see a 400 error, the nonce may have expired — refresh the page. If the AJAX request fails entirely, confirm that `wpeb-public.js` is in the plugin root folder (not in `public/js/`).

**The event doesn't appear in [event_list] after publishing.**  
The shortcode only shows events with a date ≥ today. Check the Event Date in the Event Details meta box — it must be set to a future date.

**Available seats not updating after confirming a booking.**  
Seat counts use transient caching (1 hour). After confirming a booking, click the Confirm button — the cache busts on confirmed booking writes. Hard-refresh the front-end page.

**How do I prevent double-bookings?**  
The AJAX handler re-checks seat availability server-side on every submission using `SELECT FOR UPDATE`-equivalent logic. Even if two visitors submit simultaneously, only the first succeeds if it takes the last seat.

**Can I send booking confirmation emails automatically?**  
Yes — `class-wpeb-email.php` sends a confirmation email to the attendee and a notification to the organiser email on every new booking submission. Check your WordPress `wp_mail()` delivery (install WP Mail SMTP if emails go to spam).

**How do I delete all plugin data?**  
Go to **Plugins → Delete** WP Event Booking System. The `uninstall.php` file drops the `wpeb_bookings` table, removes all `wpeb_event` posts, deletes plugin options, and removes capabilities from all roles.