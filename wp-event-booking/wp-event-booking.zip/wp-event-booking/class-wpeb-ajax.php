<?php
/**
 * AJAX Handler: Booking Submission
 * FILE: wp-event-booking/includes/class-wpeb-ajax.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_wpeb_submit_booking',        array( $this, 'handle_booking' ) );
        add_action( 'wp_ajax_nopriv_wpeb_submit_booking', array( $this, 'handle_booking' ) );
    }

    public function handle_booking(): void {
        check_ajax_referer( 'wpeb_booking_nonce', 'nonce' );

        $event_id = absint( $_POST['event_id'] ?? 0 );
        $name     = sanitize_text_field( wp_unslash( $_POST['name']  ?? '' ) );
        $email    = sanitize_email(      wp_unslash( $_POST['email'] ?? '' ) );
        $seats    = absint( $_POST['seats'] ?? 1 );

        if ( ! $event_id || ! $name || ! is_email( $email ) || $seats < 1 ) {
            wp_send_json_error( array( 'message' => __( 'Invalid booking data. Please fill in all fields.', 'wp-event-booking' ) ) );
        }

        $db       = new WPEB_Bookings_DB();
        $total    = absint( get_post_meta( $event_id, '_wpeb_event_seats', true ) );
        $booked   = $db->get_booked_seats( $event_id );
        $avail    = $total - $booked;
        $options  = get_option( 'wpeb_options', array() );
        $max_per  = (int) ( $options['max_seats_per_booking'] ?? 5 );

        if ( $seats > $avail ) {
            wp_send_json_error( array( 'message' => __( 'Not enough seats available.', 'wp-event-booking' ) ) );
        }
        if ( $seats > $max_per ) {
            wp_send_json_error( array( 'message' => sprintf(
                /* translators: %d: max seats */
                __( 'You can book a maximum of %d seats.', 'wp-event-booking' ), $max_per
            ) ) );
        }

        $booking_id = $db->insert( array( 'event_id' => $event_id, 'name' => $name, 'email' => $email, 'seats' => $seats ) );
        if ( is_wp_error( $booking_id ) ) {
            wp_send_json_error( array( 'message' => $booking_id->get_error_message() ) );
        }

        $db->update_status( $booking_id, 'confirmed' );

        // Bust event listing transients.
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wpeb_events_%' OR option_name LIKE '_transient_timeout_wpeb_events_%'" );

        ( new WPEB_Email() )->send_confirmation( $booking_id, $event_id, $name, $email, $seats );

        wp_send_json_success( array(
            'message' => __( 'Booking confirmed! A confirmation email has been sent to you.', 'wp-event-booking' ),
        ) );
    }
}