wp-event-booking/
│
├── wp-event-booking.php          ← Main plugin file (header + bootstrap)
├── uninstall.php                 ← Cleanup on plugin delete
├── readme.txt                    ← WordPress.org readme
│
├── includes/
│   ├── class-wpeb-activator.php  ← Activation: DB table, flush rewrite rules
│   ├── class-wpeb-cpt.php        ← Register Events CPT + taxonomies
│   ├── class-wpeb-meta.php       ← Custom fields (meta boxes) for events
│   ├── class-wpeb-bookings-db.php← CRUD for wp_wpeb_bookings table
│   ├── class-wpeb-shortcodes.php ← [event_list], [event_booking]
│   ├── class-wpeb-widget.php     ← Upcoming Events widget
│   ├── class-wpeb-ajax.php       ← AJAX handlers for booking submission
│   ├── class-wpeb-rest-api.php   ← REST API endpoints
│   ├── class-wpeb-settings.php   ← Settings API (admin options page)
│   ├── class-wpeb-admin.php      ← Admin bookings list table
│   ├── class-wpeb-email.php      ← Booking confirmation email sender
│   └── class-wpeb-capabilities.php ← Custom capabilities
│
├── admin/
│   ├── css/wpeb-admin.css
│   └── js/wpeb-admin.js
│
├── public/
│   ├── css/wpeb-public.css
│   └── js/wpeb-public.js
│
└── languages/
    └── wp-event-booking.pot