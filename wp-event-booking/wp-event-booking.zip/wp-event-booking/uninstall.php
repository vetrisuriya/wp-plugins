<?php
/**
 * Uninstall Handler
 * FILE: wp-event-booking/uninstall.php
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpeb_bookings" );

delete_option( 'wpeb_options' );
delete_option( 'wpeb_version' );

foreach ( array( '_wpeb_event_date', '_wpeb_event_time', '_wpeb_event_venue', '_wpeb_event_seats', '_wpeb_event_price' ) as $key ) {
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $key ) );
}

foreach ( array( 'administrator', 'editor' ) as $slug ) {
    $role = get_role( $slug );
    if ( $role ) $role->remove_cap( 'manage_event_bookings' );
}

// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wpeb_%' OR option_name LIKE '_transient_timeout_wpeb_%'" );