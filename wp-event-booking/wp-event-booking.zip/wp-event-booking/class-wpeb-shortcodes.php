<?php
/**
 * Shortcodes: [event_list] and [event_booking]
 * FILE: wp-event-booking/includes/class-wpeb-shortcodes.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Shortcodes {

    public function __construct() {
        add_shortcode( 'event_list',    array( $this, 'render_event_list' ) );
        add_shortcode( 'event_booking', array( $this, 'render_booking_form' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_public_assets' ) );
    }

    public function enqueue_public_assets(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) ) return;
        if (
            ! has_shortcode( $post->post_content, 'event_list' ) &&
            ! has_shortcode( $post->post_content, 'event_booking' )
        ) return;

        wp_enqueue_style(  'wpeb-public', WPEB_PLUGIN_URL . 'wpeb-public.css', array(), WPEB_VERSION );
        wp_enqueue_script( 'wpeb-public', WPEB_PLUGIN_URL . 'wpeb-public.js',  array( 'jquery' ), WPEB_VERSION, true );
        wp_localize_script( 'wpeb-public', 'WPEBData', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wpeb_booking_nonce' ),
            'strings'  => array(
                'booking_success' => __( 'Booking confirmed! Check your email.', 'wp-event-booking' ),
                'booking_error'   => __( 'Booking failed. Please try again.',    'wp-event-booking' ),
                'booking'         => __( 'Booking…',                             'wp-event-booking' ),
                'book_seat'       => __( 'Book My Seat',                         'wp-event-booking' ),
            ),
        ) );
    }

    /**
     * [event_list category="yoga" limit="6"]
     */
    public function render_event_list( array $atts ): string {
        $atts = shortcode_atts( array( 'category' => '', 'limit' => 10 ), $atts, 'event_list' );

        $cache_key = 'wpeb_events_' . md5( serialize( $atts ) );
        $events    = get_transient( $cache_key );

        if ( false === $events ) {
            $args = array(
                'post_type'      => 'wpeb_event',
                'posts_per_page' => absint( $atts['limit'] ),
                'post_status'    => 'publish',
                'orderby'        => 'meta_value',
                'meta_key'       => '_wpeb_event_date',
                'order'          => 'ASC',
                'meta_query'     => array( array(
                    'key'     => '_wpeb_event_date',
                    'value'   => current_time( 'Y-m-d' ),
                    'compare' => '>=',
                    'type'    => 'DATE',
                ) ),
            );
            if ( $atts['category'] ) {
                $args['tax_query'] = array( array(
                    'taxonomy' => 'wpeb_event_category',
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field( $atts['category'] ),
                ) );
            }
            $events = ( new WP_Query( $args ) )->posts;
            set_transient( $cache_key, $events, HOUR_IN_SECONDS );
        }

        if ( empty( $events ) ) {
            return '<p class="wpeb-no-events">' . esc_html__( 'No upcoming events found.', 'wp-event-booking' ) . '</p>';
        }

        ob_start();
        echo '<div class="wpeb-event-list">';
        foreach ( $events as $event ) {
            $date  = get_post_meta( $event->ID, '_wpeb_event_date',  true );
            $time  = get_post_meta( $event->ID, '_wpeb_event_time',  true );
            $venue = get_post_meta( $event->ID, '_wpeb_event_venue', true );
            $price = get_post_meta( $event->ID, '_wpeb_event_price', true );
            $db    = new WPEB_Bookings_DB();
            $total = absint( get_post_meta( $event->ID, '_wpeb_event_seats', true ) );
            $avail = max( 0, $total - $db->get_booked_seats( $event->ID ) );
            ?>
            <div class="wpeb-event-card <?php echo $avail <= 0 ? 'wpeb-sold-out' : ''; ?>">
                <?php if ( has_post_thumbnail( $event->ID ) ) : ?>
                    <div class="wpeb-event-thumb">
                        <?php echo get_the_post_thumbnail( $event->ID, 'medium' ); ?>
                    </div>
                <?php endif; ?>
                <div class="wpeb-event-body">
                    <h3 class="wpeb-event-title">
                        <a href="<?php echo esc_url( get_permalink( $event->ID ) ); ?>">
                            <?php echo esc_html( $event->post_title ); ?>
                        </a>
                    </h3>
                    <div class="wpeb-event-meta">
                        <span class="wpeb-meta-date">📅 <?php echo esc_html( $date ); ?><?php if ( $time ) echo ' ' . esc_html( $time ); ?></span>
                        <?php if ( $venue ) : ?><span class="wpeb-meta-venue">📍 <?php echo esc_html( $venue ); ?></span><?php endif; ?>
                        <span class="wpeb-meta-price"><?php echo $price ? esc_html( $price ) : esc_html__( 'Free', 'wp-event-booking' ); ?></span>
                        <span class="wpeb-meta-seats">
                            <?php if ( $avail > 0 ) : ?>
                                <?php printf( esc_html__( '%d seats left', 'wp-event-booking' ), $avail ); ?>
                            <?php else : ?>
                                <strong><?php esc_html_e( 'Sold Out', 'wp-event-booking' ); ?></strong>
                            <?php endif; ?>
                        </span>
                    </div>
                    <a class="wpeb-book-btn <?php echo $avail <= 0 ? 'wpeb-btn-disabled' : ''; ?>"
                       href="<?php echo esc_url( get_permalink( $event->ID ) ); ?>">
                        <?php echo $avail > 0 ? esc_html__( 'Book Now', 'wp-event-booking' ) : esc_html__( 'Sold Out', 'wp-event-booking' ); ?>
                    </a>
                </div>
            </div>
            <?php
        }
        echo '</div>';
        return ob_get_clean();
    }

    /**
     * [event_booking event_id="42"]
     */
    public function render_booking_form( array $atts ): string {
        $atts     = shortcode_atts( array( 'event_id' => 0 ), $atts, 'event_booking' );
        $event_id = absint( $atts['event_id'] );
        if ( ! $event_id ) return '<p class="wpeb-error">' . esc_html__( 'No event specified.', 'wp-event-booking' ) . '</p>';

        $db        = new WPEB_Bookings_DB();
        $total     = absint( get_post_meta( $event_id, '_wpeb_event_seats', true ) );
        $booked    = $db->get_booked_seats( $event_id );
        $available = max( 0, $total - $booked );
        $options   = get_option( 'wpeb_options', array() );
        $max_per   = (int) ( $options['max_seats_per_booking'] ?? 5 );

        ob_start();
        if ( $available <= 0 ) {
            echo '<p class="wpeb-sold-out">' . esc_html__( 'This event is sold out.', 'wp-event-booking' ) . '</p>';
        } else {
            ?>
            <div class="wpeb-booking-form-wrap">
                <p class="wpeb-seats-info">
                    <?php printf( esc_html__( '%d seats remaining', 'wp-event-booking' ), $available ); ?>
                </p>
                <div id="wpeb-booking-message" role="alert" aria-live="polite" style="display:none;"></div>
                <div id="wpeb-booking-form">
                    <input type="hidden" id="wpeb-event-id" value="<?php echo esc_attr( $event_id ); ?>">
                    <p>
                        <label for="wpeb-name"><?php  esc_html_e( 'Your Name',        'wp-event-booking' ); ?> <span class="wpeb-req">*</span></label>
                        <input type="text"   id="wpeb-name"  class="wpeb-input" required autocomplete="name">
                    </p>
                    <p>
                        <label for="wpeb-email"><?php esc_html_e( 'Email Address',     'wp-event-booking' ); ?> <span class="wpeb-req">*</span></label>
                        <input type="email"  id="wpeb-email" class="wpeb-input" required autocomplete="email">
                    </p>
                    <p>
                        <label for="wpeb-seats"><?php esc_html_e( 'Number of Seats', 'wp-event-booking' ); ?></label>
                        <input type="number" id="wpeb-seats" class="wpeb-input" value="1" min="1" max="<?php echo esc_attr( min( $available, $max_per ) ); ?>">
                    </p>
                    <button type="button" id="wpeb-submit-booking" class="wpeb-btn">
                        <?php esc_html_e( 'Book My Seat', 'wp-event-booking' ); ?>
                    </button>
                </div>
            </div>
            <?php
        }
        return ob_get_clean();
    }
}