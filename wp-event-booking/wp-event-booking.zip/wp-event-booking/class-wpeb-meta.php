<?php
/**
 * Event Meta Boxes — Date, Time, Venue, Seats, Price
 * FILE: wp-event-booking/includes/class-wpeb-meta.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Meta {

    public function __construct() {
        add_action( 'add_meta_boxes',          array( $this, 'add_event_meta_box' ) );
        add_action( 'save_post_wpeb_event',    array( $this, 'save_event_meta' ) );
        add_filter( 'manage_wpeb_event_posts_columns',       array( $this, 'columns' ) );
        add_action( 'manage_wpeb_event_posts_custom_column', array( $this, 'column_content' ), 10, 2 );
    }

    public function add_event_meta_box(): void {
        add_meta_box( 'wpeb_event_details', __( 'Event Details', 'wp-event-booking' ),
            array( $this, 'render_meta_box' ), 'wpeb_event', 'normal', 'high' );
    }

    public function render_meta_box( WP_Post $post ): void {
        wp_nonce_field( 'wpeb_save_event_meta', 'wpeb_event_nonce' );
        $date  = get_post_meta( $post->ID, '_wpeb_event_date',  true );
        $time  = get_post_meta( $post->ID, '_wpeb_event_time',  true );
        $venue = get_post_meta( $post->ID, '_wpeb_event_venue', true );
        $seats = get_post_meta( $post->ID, '_wpeb_event_seats', true );
        $price = get_post_meta( $post->ID, '_wpeb_event_price', true );
        $db    = new WPEB_Bookings_DB();
        $booked = $db->get_booked_seats( $post->ID );
        ?>
        <table class="form-table">
            <tr><th><label for="wpeb_event_date"><?php  esc_html_e( 'Event Date',     'wp-event-booking' ); ?></label></th>
                <td><input type="date"   id="wpeb_event_date"  name="wpeb_event_date"  value="<?php echo esc_attr( $date  ); ?>"></td></tr>
            <tr><th><label for="wpeb_event_time"><?php  esc_html_e( 'Event Time',     'wp-event-booking' ); ?></label></th>
                <td><input type="time"   id="wpeb_event_time"  name="wpeb_event_time"  value="<?php echo esc_attr( $time  ); ?>"></td></tr>
            <tr><th><label for="wpeb_event_venue"><?php esc_html_e( 'Venue',          'wp-event-booking' ); ?></label></th>
                <td><input type="text"   id="wpeb_event_venue" name="wpeb_event_venue" value="<?php echo esc_attr( $venue ); ?>" class="regular-text"></td></tr>
            <tr><th><label for="wpeb_event_seats"><?php esc_html_e( 'Total Seats',    'wp-event-booking' ); ?></label></th>
                <td>
                    <input type="number" id="wpeb_event_seats" name="wpeb_event_seats" value="<?php echo esc_attr( $seats ); ?>" min="1">
                    <?php if ( $booked > 0 ) : ?>
                    <p class="description"><?php printf( esc_html__( '%d seats already booked.', 'wp-event-booking' ), $booked ); ?></p>
                    <?php endif; ?>
                </td></tr>
            <tr><th><label for="wpeb_event_price"><?php esc_html_e( 'Ticket Price',   'wp-event-booking' ); ?></label></th>
                <td><input type="text"   id="wpeb_event_price" name="wpeb_event_price" value="<?php echo esc_attr( $price ); ?>" placeholder="e.g. $25 or Free"></td></tr>
        </table>
        <?php
    }

    public function save_event_meta( int $post_id ): void {
        if ( ! isset( $_POST['wpeb_event_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wpeb_event_nonce'] ) ), 'wpeb_save_event_meta' ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        $fields = array(
            '_wpeb_event_date'  => 'sanitize_text_field',
            '_wpeb_event_time'  => 'sanitize_text_field',
            '_wpeb_event_venue' => 'sanitize_text_field',
            '_wpeb_event_seats' => 'absint',
            '_wpeb_event_price' => 'sanitize_text_field',
        );
        foreach ( $fields as $meta_key => $fn ) {
            $post_key = str_replace( '_wpeb_event_', 'wpeb_event_', $meta_key );
            if ( isset( $_POST[ $post_key ] ) ) {
                update_post_meta( $post_id, $meta_key, call_user_func( $fn, wp_unslash( $_POST[ $post_key ] ) ) );
            }
        }
        // Bust event list transients.
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wpeb_events_%' OR option_name LIKE '_transient_timeout_wpeb_events_%'" );
    }

    public function columns( array $cols ): array {
        return array(
            'cb'              => $cols['cb'],
            'title'           => __( 'Event',     'wp-event-booking' ),
            'wpeb_date'       => __( 'Date',      'wp-event-booking' ),
            'wpeb_venue'      => __( 'Venue',     'wp-event-booking' ),
            'wpeb_seats'      => __( 'Seats',     'wp-event-booking' ),
            'wpeb_price'      => __( 'Price',     'wp-event-booking' ),
            'taxonomy-wpeb_event_category' => __( 'Category', 'wp-event-booking' ),
            'date'            => __( 'Published', 'wp-event-booking' ),
        );
    }

    public function column_content( string $col, int $post_id ): void {
        switch ( $col ) {
            case 'wpeb_date':  echo esc_html( get_post_meta( $post_id, '_wpeb_event_date',  true ) ?: '—' ); break;
            case 'wpeb_venue': echo esc_html( get_post_meta( $post_id, '_wpeb_event_venue', true ) ?: '—' ); break;
            case 'wpeb_price': echo esc_html( get_post_meta( $post_id, '_wpeb_event_price', true ) ?: 'Free' ); break;
            case 'wpeb_seats':
                $total  = absint( get_post_meta( $post_id, '_wpeb_event_seats', true ) );
                $booked = ( new WPEB_Bookings_DB() )->get_booked_seats( $post_id );
                $avail  = max( 0, $total - $booked );
                printf( '%d / %d %s', $avail, $total, esc_html__( 'avail.', 'wp-event-booking' ) );
                break;
        }
    }
}