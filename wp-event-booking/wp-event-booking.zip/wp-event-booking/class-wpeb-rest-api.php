<?php
/**
 * REST API: Events Endpoints
 * FILE: wp-event-booking/includes/class-wpeb-rest-api.php
 * Routes: GET /wpeb/v1/events  |  GET /wpeb/v1/events/{id}
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Rest_Api {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes(): void {
        register_rest_route( 'wpeb/v1', '/events', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_events' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'category' => array( 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'limit'    => array( 'type' => 'integer', 'default' => 10, 'sanitize_callback' => 'absint' ),
                'page'     => array( 'type' => 'integer', 'default' => 1,  'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'wpeb/v1', '/events/(?P<id>\d+)', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_event' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function get_events( WP_REST_Request $request ): WP_REST_Response {
        $limit = $request->get_param( 'limit' );
        $page  = $request->get_param( 'page' );
        $args  = array(
            'post_type'      => 'wpeb_event',
            'posts_per_page' => $limit,
            'paged'          => $page,
            'post_status'    => 'publish',
            'meta_key'       => '_wpeb_event_date',
            'orderby'        => 'meta_value',
            'order'          => 'ASC',
            'meta_query'     => array( array( 'key' => '_wpeb_event_date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=', 'type' => 'DATE' ) ),
        );
        if ( $c = $request->get_param( 'category' ) ) {
            $args['tax_query'] = array( array( 'taxonomy' => 'wpeb_event_category', 'field' => 'slug', 'terms' => $c ) );
        }
        $query    = new WP_Query( $args );
        $data     = array_map( array( $this, 'prepare' ), $query->posts );
        $response = new WP_REST_Response( $data, 200 );
        $response->header( 'X-WP-Total',      $query->found_posts );
        $response->header( 'X-WP-TotalPages', $query->max_num_pages );
        return $response;
    }

    public function get_event( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $post = get_post( absint( $request->get_param( 'id' ) ) );
        if ( ! $post || 'wpeb_event' !== $post->post_type ) {
            return new WP_Error( 'not_found', __( 'Event not found.', 'wp-event-booking' ), array( 'status' => 404 ) );
        }
        return new WP_REST_Response( $this->prepare( $post ), 200 );
    }

    private function prepare( WP_Post $post ): array {
        $db = new WPEB_Bookings_DB();
        $total = absint( get_post_meta( $post->ID, '_wpeb_event_seats', true ) );
        return array(
            'id'             => $post->ID,
            'title'          => $post->post_title,
            'excerpt'        => get_the_excerpt( $post ),
            'url'            => get_permalink( $post->ID ),
            'thumbnail'      => get_the_post_thumbnail_url( $post->ID, 'medium' ) ?: '',
            'date'           => get_post_meta( $post->ID, '_wpeb_event_date',  true ),
            'time'           => get_post_meta( $post->ID, '_wpeb_event_time',  true ),
            'venue'          => get_post_meta( $post->ID, '_wpeb_event_venue', true ),
            'price'          => get_post_meta( $post->ID, '_wpeb_event_price', true ),
            'total_seats'    => $total,
            'booked_seats'   => $db->get_booked_seats( $post->ID ),
            'available_seats'=> max( 0, $total - $db->get_booked_seats( $post->ID ) ),
        );
    }
}