=== WP Event Booking System ===
Contributors:      vetrisuriya
Tags:              events, booking, tickets, event calendar, seat management
Requires at least: 6.0
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      8.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A complete event listing and seat booking system. List events, manage seat limits, and accept bookings directly on your site with AJAX booking forms — no external service needed.

== Description ==

**WP Event Booking System** gives you everything you need to run events on WordPress. Create events with dates, venues, ticket prices, and seat limits. Display them in a card grid. Let visitors book seats without leaving your site.

= Core Features =

* **Events CPT** — dedicated admin area with date, time, venue, seats, and price fields
* **Event Categories** — organise events into topics (Yoga, Music, Workshop, etc.)
* **`[event_list]` shortcode** — responsive card grid of upcoming events with seat availability
* **`[event_booking]` shortcode** — AJAX booking form with seat-limit enforcement and sold-out display
* **Bookings admin page** — view all bookings, filter by status, confirm or cancel with one click
* **Confirmation emails** — automatic email to the attendee and the organiser on every booking
* **Seat tracking** — custom `wpeb_bookings` database table tracks seats per event
* **Upcoming Events widget** — sidebar widget showing next N events by date
* **Settings page** — configure organiser email and max seats per booking
* **REST API** — `GET /wp-json/wpeb/v1/events` and `/events/{id}` for headless use
* **Transient caching** — event list queries cached for 1 hour, busted on new bookings
* **Clean uninstall** — drops DB table, removes all options and meta on deletion

= Shortcodes =

**Event listing grid:**
`[event_list]`
`[event_list category="workshop" limit="6"]`

**Booking form:**
`[event_booking event_id="42"]`

See the full shortcode reference in the user guide.

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload Plugin**
2. Go to **Events → Settings** and set your organiser email and max seats per booking
3. Go to **Events → Add New Event** to create your first event
4. Add `[event_list]` to your Events page
5. Add `[event_booking event_id="YOUR_EVENT_ID"]` to each individual event page

== Frequently Asked Questions ==

= How do I find the event ID for the booking shortcode? =

Open the event in the admin editor. The ID is in the URL: `edit.php?post=42&action=edit` — the number after `post=` is the event ID. Use it as: `[event_booking event_id="42"]`.

= How do I display an event list by category? =

First create a category under **Events → Event Categories** and assign events to it. Then use the `category` attribute with the category slug: `[event_list category="yoga"]`.

= How are seats tracked? =

Each confirmed booking stores the number of seats in the `wpeb_bookings` database table. The booking form checks available seats server-side before accepting a booking. The front end shows a live "N seats remaining" count.

= What happens when an event is sold out? =

The `[event_booking]` shortcode replaces the form with "This event is sold out." The `[event_list]` card shows "Sold Out" and the Book Now button is greyed out.

= Can I limit how many seats one person can book? =

Yes — go to **Events → Settings → Max Seats Per Booking**. Default is 5.

= How do I confirm or cancel a booking? =

Go to **Events → Bookings**. Each row has ✓ Confirm and ✕ Cancel buttons. Clicking either updates the status via AJAX and refreshes the available seat count for that event.

= Does the plugin send emails? =

Yes — when a booking is confirmed, it sends:
1. A confirmation email to the attendee with event details and booking ID
2. A notification email to the organiser with the attendee's name and email

= How does the REST API work? =

Use `GET /wp-json/wpeb/v1/events` to list upcoming events. Optional params: `category`, `limit`, `page`. Use `GET /wp-json/wpeb/v1/events/{id}` for a single event including available seat count.

== Screenshots ==

1. Event card grid — [event_list] shortcode output with date, venue, price, and seats remaining.
2. Booking form — [event_booking] shortcode with name, email, seat fields and "Book My Seat" button.
3. Sold out state — form replaced with sold-out message when all seats are taken.
4. Event edit screen — Event Details meta box with date, time, venue, seats, and price.
5. Bookings admin page — list of all bookings with status badges and Confirm/Cancel buttons.
6. Upcoming Events widget — sidebar widget showing the next 3 events by date.
7. Settings page — organiser email and max seats per booking.

== Changelog ==

= 1.0.0 =
* Initial release
* Events CPT (wpeb_event) with Event Categories taxonomy
* Event Details meta box: date, time, venue, total seats, ticket price
* Custom DB table: wp_wpeb_bookings (event_id, name, email, seats, status, booked_at)
* [event_list] shortcode — grid of upcoming events with category filter and limit
* [event_booking event_id="N"] shortcode — AJAX booking form with seat-limit enforcement
* Bookings admin page — filter by status, confirm/cancel via AJAX
* Automatic confirmation email to attendee and organiser
* Upcoming Events sidebar widget
* Settings API: organiser email, max seats per booking
* REST API: GET /wpeb/v1/events + GET /wpeb/v1/events/{id}
* Transient caching (1-hour TTL) with automatic cache-busting on new bookings
* manage_event_bookings capability on Administrator and Editor

== Upgrade Notice ==

= 1.0.0 =
Initial release. No upgrade steps required.