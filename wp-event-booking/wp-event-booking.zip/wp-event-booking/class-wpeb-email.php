<?php
/**
 * Booking Confirmation Email
 * FILE: wp-event-booking/includes/class-wpeb-email.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Email {

    public function send_confirmation( int $booking_id, int $event_id, string $name, string $email, int $seats ): bool {
        $event   = get_post( $event_id );
        $title   = $event ? $event->post_title : '';
        $date    = get_post_meta( $event_id, '_wpeb_event_date',  true );
        $time    = get_post_meta( $event_id, '_wpeb_event_time',  true );
        $venue   = get_post_meta( $event_id, '_wpeb_event_venue', true );
        $options = get_option( 'wpeb_options', array() );
        $admin   = $options['admin_email'] ?? get_option( 'admin_email' );
        $site    = get_bloginfo( 'name' );
        $headers = array( 'Content-Type: text/plain; charset=UTF-8' );

        // ── To attendee ──────────────────────────────────────────
        $subject = sprintf( __( 'Booking Confirmed – %s', 'wp-event-booking' ), $title );
        $message = sprintf(
            __( "Hi %1\$s,\n\nYour booking is confirmed!\n\nEvent: %2\$s\nDate: %3\$s %4\$s\nVenue: %5\$s\nSeats: %6\$d\nBooking ID: #%7\$d\n\nSee you there!\n\n%8\$s", 'wp-event-booking' ),
            $name, $title, $date, $time, $venue, $seats, $booking_id, $site
        );
        $attendee_sent = wp_mail( $email, $subject, $message, $headers );

        // ── To organizer ─────────────────────────────────────────
        wp_mail( $admin,
            sprintf( __( 'New Booking: %1$s registered for %2$s', 'wp-event-booking' ), $name, $title ),
            sprintf( __( "New booking received.\n\nName: %1\$s\nEmail: %2\$s\nSeats: %3\$d\nEvent: %4\$s\nDate: %5\$s", 'wp-event-booking' ), $name, $email, $seats, $title, $date ),
            $headers
        );

        return $attendee_sent;
    }
}