<?php
/**
 * Settings API
 * FILE: wp-event-booking/includes/class-wpeb-settings.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Settings {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
    }

    public function add_settings_page(): void {
        add_submenu_page( 'edit.php?post_type=wpeb_event',
            __( 'Event Booking Settings', 'wp-event-booking' ),
            __( 'Settings', 'wp-event-booking' ),
            'manage_options', 'wpeb-settings', array( $this, 'render_settings_page' )
        );
    }

    public function register_settings(): void {
        register_setting( 'wpeb_settings_group', 'wpeb_options', array( 'sanitize_callback' => array( $this, 'sanitize_options' ) ) );

        add_settings_section( 'wpeb_email_section',   __( 'Email Settings',   'wp-event-booking' ), '__return_false', 'wpeb-settings' );
        add_settings_field( 'admin_email', __( 'Organizer Email', 'wp-event-booking' ),
            array( $this, 'render_email_field' ), 'wpeb-settings', 'wpeb_email_section' );

        add_settings_section( 'wpeb_booking_section', __( 'Booking Settings', 'wp-event-booking' ), '__return_false', 'wpeb-settings' );
        add_settings_field( 'max_seats_per_booking', __( 'Max Seats Per Booking', 'wp-event-booking' ),
            array( $this, 'render_seats_field' ), 'wpeb-settings', 'wpeb_booking_section' );
    }

    public function render_email_field(): void {
        $email = get_option( 'wpeb_options', array() )['admin_email'] ?? get_option( 'admin_email' );
        echo '<input type="email" name="wpeb_options[admin_email]" value="' . esc_attr( $email ) . '" class="regular-text">';
        echo '<p class="description">' . esc_html__( 'Booking notification emails are sent to this address.', 'wp-event-booking' ) . '</p>';
    }

    public function render_seats_field(): void {
        $seats = (int) ( get_option( 'wpeb_options', array() )['max_seats_per_booking'] ?? 5 );
        echo '<input type="number" name="wpeb_options[max_seats_per_booking]" value="' . esc_attr( $seats ) . '" min="1" max="20">';
        echo '<p class="description">' . esc_html__( 'Maximum seats a single person can book per event.', 'wp-event-booking' ) . '</p>';
    }

    public function sanitize_options( array $input ): array {
        return array(
            'admin_email'           => sanitize_email( $input['admin_email'] ?? '' ),
            'max_seats_per_booking' => absint( $input['max_seats_per_booking'] ?? 5 ),
        );
    }

    public function render_settings_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Event Booking Settings', 'wp-event-booking' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'wpeb_settings_group' ); do_settings_sections( 'wpeb-settings' ); submit_button(); ?>
            </form>
        </div>
        <?php
    }
}