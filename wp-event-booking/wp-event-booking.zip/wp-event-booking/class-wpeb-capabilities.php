<?php
/**
 * Capabilities
 * FILE: wp-event-booking/includes/class-wpeb-capabilities.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Capabilities {

    public function __construct() {
        // Future: can add capability-based UI restrictions here.
    }

    public static function add_to_role( string $role_name ): void {
        $role = get_role( $role_name );
        if ( $role ) $role->add_cap( 'manage_event_bookings' );
    }

    public static function remove_from_all(): void {
        global $wp_roles;
        if ( ! isset( $wp_roles ) ) $wp_roles = new WP_Roles();
        foreach ( array_keys( $wp_roles->roles ) as $slug ) {
            $role = get_role( $slug );
            if ( $role ) $role->remove_cap( 'manage_event_bookings' );
        }
    }

    public static function can_manage(): bool {
        return current_user_can( 'manage_event_bookings' );
    }
}