/* global WPEBAdmin, jQuery */
/**
 * WP Event Booking System — Admin JavaScript
 * FILE: wp-event-booking/admin/js/wpeb-admin.js
 *
 * Handles:
 *  - Confirm booking button (bookings list page)
 *  - Cancel booking button (bookings list page)
 */
( function ( $ ) {
    'use strict';

    /* ── Confirm / Cancel booking ───────────────────────────────── */
    $( document ).on( 'click', '.wpeb-confirm-btn, .wpeb-cancel-btn', function () {
        var $btn       = $( this );
        var bookingId  = $btn.data( 'id' );
        var newStatus  = $btn.data( 'status' );
        var $row       = $btn.closest( 'tr' );
        var $badge     = $row.find( '.wpeb-status-badge' );

        if ( ! window.confirm( WPEBAdmin.strings.confirm_action ) ) return;

        $btn.prop( 'disabled', true ).text( WPEBAdmin.strings.updating );

        $.post( WPEBAdmin.ajax_url, {
            action:     'wpeb_update_booking_status',
            nonce:      WPEBAdmin.nonce,
            booking_id: bookingId,
            status:     newStatus,
        }, function ( res ) {
            if ( res.success ) {
                // Update badge class and text.
                $badge
                    .removeClass( 'wpeb-status-pending wpeb-status-confirmed wpeb-status-cancelled' )
                    .addClass( 'wpeb-status-' + newStatus )
                    .text( newStatus.charAt(0).toUpperCase() + newStatus.slice(1) );

                // Remove the button that was just used.
                $btn.remove();

                // Update remaining button state.
                if ( newStatus === 'confirmed' ) {
                    $row.find( '.wpeb-confirm-btn' ).remove();
                } else if ( newStatus === 'cancelled' ) {
                    $row.find( '.wpeb-cancel-btn' ).remove();
                }
            } else {
                alert( WPEBAdmin.strings.error );
                $btn.prop( 'disabled', false ).text( newStatus === 'confirmed' ? '✓ Confirm' : '✕ Cancel' );
            }
        } ).fail( function () {
            alert( WPEBAdmin.strings.error );
            $btn.prop( 'disabled', false ).text( newStatus === 'confirmed' ? '✓ Confirm' : '✕ Cancel' );
        } );
    } );

}( jQuery ) );