<?php
/**
 * Events Custom Post Type + Event Category Taxonomy
 * FILE: wp-event-booking/includes/class-wpeb-cpt.php
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_CPT {

    public function __construct() {
        add_action( 'init',       array( $this, 'register_event_post_type' ) );
        add_action( 'init',       array( $this, 'register_event_category_taxonomy' ) );
        add_action( 'admin_init', array( $this, 'maybe_redirect' ) );
    }

    public function register_event_post_type(): void {
        register_post_type( 'wpeb_event', array(
            'labels' => array(
                'name'          => _x( 'Events',        'post type general name', 'wp-event-booking' ),
                'singular_name' => _x( 'Event',         'post type singular name', 'wp-event-booking' ),
                'add_new_item'  => __( 'Add New Event',  'wp-event-booking' ),
                'edit_item'     => __( 'Edit Event',     'wp-event-booking' ),
                'view_item'     => __( 'View Event',     'wp-event-booking' ),
                'not_found'     => __( 'No events found.', 'wp-event-booking' ),
                'menu_name'     => __( 'Events',         'wp-event-booking' ),
            ),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'events' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 5,
            'menu_icon'          => 'dashicons-calendar-alt',
            'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
            'show_in_rest'       => true,
        ) );
    }

    public function register_event_category_taxonomy(): void {
        register_taxonomy( 'wpeb_event_category', 'wpeb_event', array(
            'labels' => array(
                'name'          => _x( 'Event Categories', 'taxonomy general name', 'wp-event-booking' ),
                'singular_name' => _x( 'Event Category',  'taxonomy singular name', 'wp-event-booking' ),
                'add_new_item'  => __( 'Add New Category', 'wp-event-booking' ),
                'menu_name'     => __( 'Event Categories', 'wp-event-booking' ),
            ),
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'event-category' ),
        ) );
    }

    public function maybe_redirect(): void {
        if ( ! get_transient( 'wpeb_activation_redirect' ) ) return;
        delete_transient( 'wpeb_activation_redirect' );
        if ( isset( $_GET['activate-multi'] ) ) return;
        wp_safe_redirect( admin_url( 'edit.php?post_type=wpeb_event&welcome=1' ) );
        exit;
    }
}