<?php
/**
 * Plugin Name:       WP Event Booking System
 * Plugin URI:        https://vetrisuriya.in/wp-event-booking
 * Description:       A complete event listing and seat booking system. List events, manage seat limits, and accept bookings directly on your site with a front-end booking form.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Vetri Suriya
 * License:           GPL v2 or later
 * Text Domain:       wp-event-booking
 * Domain Path:       /languages
 * @package WP_Event_Booking
 */

defined( 'ABSPATH' ) || exit;

define( 'WPEB_VERSION',         '1.0.0' );
define( 'WPEB_PLUGIN_DIR',      plugin_dir_path( __FILE__ ) );
define( 'WPEB_PLUGIN_URL',      plugin_dir_url( __FILE__ ) );
define( 'WPEB_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/*
 * ═══════════════════════════════════════════════════════════════════
 *  FATAL ERROR ROOT CAUSE — WHY IT BROKE
 * ═══════════════════════════════════════════════════════════════════
 *
 *  The original file used spl_autoload_register() which built paths as:
 *
 *    WPEB_PLUGIN_DIR . 'includes/class-wpeb-admin.php'
 *
 *  Problem 1 — Wrong directory:
 *    All class files are flat in the plugin root, NOT inside an
 *    'includes/' subfolder. The autoloader silently found nothing.
 *    When WordPress called new WPEB_Admin() on line 57, PHP threw:
 *      Fatal error: Class "WPEB_Admin" not found
 *
 *  Problem 2 — Asset paths also wrong:
 *    class-wpeb-admin.php enqueued from 'admin/css/' and 'admin/js/'
 *    class-wpeb-shortcodes.php enqueued from 'public/css/' and 'public/js/'
 *    These subdirectories never existed — all CSS/JS files are in the root.
 *
 *  FIX:
 *    Replace spl_autoload_register with explicit require_once calls
 *    pointing to the plugin root where the files actually live.
 *    Asset paths in admin and shortcodes classes are also corrected.
 * ═══════════════════════════════════════════════════════════════════
 */

// ── Load all class files explicitly (no autoloader magic) ─────────
require_once WPEB_PLUGIN_DIR . 'class-wpeb-activator.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-cpt.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-meta.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-bookings-db.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-settings.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-shortcodes.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-ajax.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-rest-api.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-widget.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-email.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-capabilities.php';
require_once WPEB_PLUGIN_DIR . 'class-wpeb-admin.php';

// ── Activation / Deactivation ──────────────────────────────────────
register_activation_hook( __FILE__, array( 'WPEB_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WPEB_Activator', 'deactivate' ) );

// ── Boot on plugins_loaded ─────────────────────────────────────────
add_action( 'plugins_loaded', function (): void {

    load_plugin_textdomain(
        'wp-event-booking',
        false,
        dirname( WPEB_PLUGIN_BASENAME ) . '/languages'
    );

    // Instantiate all feature classes.
    // Each class registers its own hooks inside __construct().
    new WPEB_CPT();
    new WPEB_Meta();
    new WPEB_Shortcodes();
    new WPEB_Widget();
    new WPEB_Ajax();
    new WPEB_Rest_Api();
    new WPEB_Settings();
    new WPEB_Admin();
    new WPEB_Capabilities();

    // Run DB upgrade check on every load (cheap — compares version strings).
    WPEB_Activator::maybe_upgrade();
} );