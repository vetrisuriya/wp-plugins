<?php
/**
 * Admin: Bookings list page + admin asset enqueue.
 * FILE: wp-event-booking/class-wpeb-admin.php
 *
 * BUGS FIXED IN THIS VERSION
 * ──────────────────────────────────────────────────────────────────
 * Bug 1 (fatal): WPEB_Bookings_DB::count_by_status() called statically
 *                but the method is a regular instance method.
 *                Fix: instantiate → $db = new WPEB_Bookings_DB()
 *                     then call   → $db->count_by_status()
 *
 * Bug 2 (fatal): WPEB_Bookings_DB::get_all( $status, $event_id )
 *                called with 2 positional args but real signature is
 *                get_all( array $filters = array() ) — one array arg.
 *                Fix: $db->get_all( array( 'status' => ..., 'event_id' => ... ) )
 *
 * Bug 3 (fatal): WPEB_Bookings_DB::update_status() called statically.
 *                Fix: $db->update_status()
 *
 * Bug 4 (notice): render loop used 'attendee_name' / 'attendee_email'
 *                 but the DB table columns are 'name' and 'email'.
 *                 Fix: use correct column keys from the DB class.
 *
 * Bug 5 (wrong paths from previous session):
 *                 'admin/css/wpeb-admin.css' → 'wpeb-admin.css' (root)
 *                 'admin/js/wpeb-admin.js'   → 'wpeb-admin.js'  (root)
 * ──────────────────────────────────────────────────────────────────
 * @package WP_Event_Booking
 */
defined( 'ABSPATH' ) || exit;

class WPEB_Admin {

    public function __construct() {
        add_action( 'admin_menu',            array( $this, 'add_bookings_page' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
        add_action( 'wp_ajax_wpeb_update_booking_status', array( $this, 'update_booking_status' ) );
    }

    /* ── Admin submenu ──────────────────────────────────────────── */

    public function add_bookings_page(): void {
        add_submenu_page(
            'edit.php?post_type=wpeb_event',
            __( 'All Bookings', 'wp-event-booking' ),
            __( 'Bookings',     'wp-event-booking' ),
            'manage_event_bookings',
            'wpeb-bookings',
            array( $this, 'render_bookings_page' )
        );
    }

    /* ── Admin assets ───────────────────────────────────────────── */

    public function enqueue_admin_assets( string $hook ): void {
        $screen = get_current_screen();

        $is_event_screen    = $screen && 'wpeb_event' === $screen->post_type
                              && in_array( $hook, array( 'post.php', 'post-new.php', 'edit.php' ), true );
        $is_bookings_screen = false !== strpos( $hook, 'wpeb-bookings' );

        if ( ! $is_event_screen && ! $is_bookings_screen ) return;

        wp_enqueue_style(
            'wpeb-admin',
            WPEB_PLUGIN_URL . 'wpeb-admin.css',   // ← plugin root (fixed in prev. session)
            array(),
            WPEB_VERSION
        );
        wp_enqueue_script(
            'wpeb-admin',
            WPEB_PLUGIN_URL . 'wpeb-admin.js',    // ← plugin root (fixed in prev. session)
            array( 'jquery' ),
            WPEB_VERSION,
            true
        );
        wp_localize_script( 'wpeb-admin', 'WPEBAdmin', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wpeb_admin_nonce' ),
            'strings'  => array(
                'confirm_action' => __( 'Are you sure?', 'wp-event-booking' ),
                'updating'       => __( 'Updating…',     'wp-event-booking' ),
                'confirmed'      => __( 'Confirmed',     'wp-event-booking' ),
                'cancelled'      => __( 'Cancelled',     'wp-event-booking' ),
            ),
        ) );
    }

    /* ── Bookings page render ────────────────────────────────────── */

    public function render_bookings_page(): void {
        if ( ! current_user_can( 'manage_event_bookings' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'wp-event-booking' ) );
        }

        $status_filter = sanitize_text_field( $_GET['status']   ?? '' );
        $event_filter  = absint( $_GET['event_id'] ?? 0 );

        // ── FIX 1: instantiate, then call as instance methods ────
        $db = new WPEB_Bookings_DB();

        $counts = array(
            'all'       => $db->count_by_status(),
            'pending'   => $db->count_by_status( 'pending' ),
            'confirmed' => $db->count_by_status( 'confirmed' ),
            'cancelled' => $db->count_by_status( 'cancelled' ),
        );

        // ── FIX 2: correct param — one array, not two positional args ──
        $filters = array();
        if ( $status_filter ) $filters['status']   = $status_filter;
        if ( $event_filter )  $filters['event_id'] = $event_filter;
        $bookings = $db->get_all( $filters );

        $status_colors = array(
            'pending'   => '#d97706',
            'confirmed' => '#059669',
            'cancelled' => '#dc2626',
        );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'All Bookings', 'wp-event-booking' ); ?></h1>

            <!-- Stat cards -->
            <div style="display:flex;gap:1rem;flex-wrap:wrap;margin:1rem 0 1.5rem;">
                <?php foreach ( array( 'pending' => '#d97706', 'confirmed' => '#059669', 'cancelled' => '#dc2626' ) as $s => $c ) : ?>
                <div style="background:#fff;border:1px solid #ddd;border-top:4px solid <?php echo esc_attr( $c ); ?>;padding:1rem 1.5rem;min-width:100px;text-align:center;border-radius:4px;">
                    <div style="font-size:1.75rem;font-weight:800;"><?php echo absint( $counts[ $s ] ); ?></div>
                    <div style="font-size:.8125rem;color:#64748b;text-transform:capitalize;"><?php echo esc_html( $s ); ?></div>
                </div>
                <?php endforeach; ?>
                <div style="background:#fff;border:1px solid #ddd;border-top:4px solid #475569;padding:1rem 1.5rem;min-width:100px;text-align:center;border-radius:4px;">
                    <div style="font-size:1.75rem;font-weight:800;"><?php echo absint( $counts['all'] ); ?></div>
                    <div style="font-size:.8125rem;color:#64748b;"><?php esc_html_e( 'Total', 'wp-event-booking' ); ?></div>
                </div>
            </div>

            <!-- Status filter tabs -->
            <ul class="subsubsub">
                <?php
                $tabs      = array(
                    ''          => __( 'All',       'wp-event-booking' ),
                    'pending'   => __( 'Pending',   'wp-event-booking' ),
                    'confirmed' => __( 'Confirmed', 'wp-event-booking' ),
                    'cancelled' => __( 'Cancelled', 'wp-event-booking' ),
                );
                $count_map = array( '' => 'all', 'pending' => 'pending', 'confirmed' => 'confirmed', 'cancelled' => 'cancelled' );
                $links     = array();
                foreach ( $tabs as $slug => $label ) {
                    $url     = add_query_arg( array( 'post_type' => 'wpeb_event', 'page' => 'wpeb-bookings', 'status' => $slug ), admin_url( 'edit.php' ) );
                    $class   = $status_filter === $slug ? ' class="current"' : '';
                    $links[] = '<li><a href="' . esc_url( $url ) . '"' . $class . '>'
                             . esc_html( $label )
                             . ' <span class="count">(' . absint( $counts[ $count_map[ $slug ] ] ) . ')</span></a>';
                }
                echo implode( ' | ', $links );
                ?>
            </ul>

            <!-- Event filter -->
            <form method="get" style="margin-top:1rem;">
                <input type="hidden" name="post_type" value="wpeb_event">
                <input type="hidden" name="page"      value="wpeb-bookings">
                <?php if ( $status_filter ) : ?>
                    <input type="hidden" name="status" value="<?php echo esc_attr( $status_filter ); ?>">
                <?php endif; ?>
                <select name="event_id">
                    <option value=""><?php esc_html_e( '— All Events —', 'wp-event-booking' ); ?></option>
                    <?php
                    $events = get_posts( array( 'post_type' => 'wpeb_event', 'posts_per_page' => -1, 'post_status' => array( 'publish', 'draft' ) ) );
                    foreach ( $events as $ev ) {
                        printf( '<option value="%d"%s>%s</option>', $ev->ID, selected( $event_filter, $ev->ID, false ), esc_html( $ev->post_title ) );
                    }
                    ?>
                </select>
                <button type="submit" class="button"><?php esc_html_e( 'Filter', 'wp-event-booking' ); ?></button>
                <?php if ( $event_filter ) : ?>
                    <a href="<?php echo esc_url( add_query_arg( array( 'post_type' => 'wpeb_event', 'page' => 'wpeb-bookings' ), admin_url( 'edit.php' ) ) ); ?>" class="button">
                        <?php esc_html_e( 'Clear', 'wp-event-booking' ); ?>
                    </a>
                <?php endif; ?>
            </form>

            <?php if ( empty( $bookings ) ) : ?>
                <p style="margin-top:1rem;"><?php esc_html_e( 'No bookings found.', 'wp-event-booking' ); ?></p>
            <?php else : ?>
            <table class="wp-list-table widefat fixed striped" style="margin-top:1rem;">
                <thead>
                    <tr>
                        <th style="width:50px;"><?php esc_html_e( 'ID',       'wp-event-booking' ); ?></th>
                        <th><?php esc_html_e( 'Event',    'wp-event-booking' ); ?></th>
                        <th><?php esc_html_e( 'Name',     'wp-event-booking' ); ?></th>
                        <th><?php esc_html_e( 'Email',    'wp-event-booking' ); ?></th>
                        <th style="width:60px;"><?php esc_html_e( 'Seats',  'wp-event-booking' ); ?></th>
                        <th style="width:100px;"><?php esc_html_e( 'Status', 'wp-event-booking' ); ?></th>
                        <th><?php esc_html_e( 'Booked On', 'wp-event-booking' ); ?></th>
                        <th><?php esc_html_e( 'Actions',   'wp-event-booking' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $bookings as $b ) :
                        $event = get_post( absint( $b['event_id'] ) );
                        $color = $status_colors[ $b['status'] ] ?? '#64748b';
                    ?>
                    <tr data-booking-id="<?php echo absint( $b['id'] ); ?>">
                        <td><?php echo absint( $b['id'] ); ?></td>

                        <td><?php echo $event
                            ? '<a href="' . esc_url( get_edit_post_link( $event->ID ) ) . '">' . esc_html( $event->post_title ) . '</a>'
                            : '—'; ?>
                        </td>

                        <!-- FIX 4: correct column keys are 'name' and 'email', not 'attendee_name' / 'attendee_email' -->
                        <td><?php echo esc_html( $b['name'] ); ?></td>
                        <td><a href="mailto:<?php echo esc_attr( $b['email'] ); ?>"><?php echo esc_html( $b['email'] ); ?></a></td>
                        <td><?php echo absint( $b['seats'] ); ?></td>

                        <td>
                            <span style="background:<?php echo esc_attr( $color ); ?>20;color:<?php echo esc_attr( $color ); ?>;
                                         padding:2px 8px;border-radius:4px;font-size:.8125rem;
                                         font-weight:700;text-transform:capitalize;">
                                <?php echo esc_html( $b['status'] ); ?>
                            </span>
                        </td>

                        <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $b['booked_at'] ) ) ); ?></td>

                        <td>
                            <?php if ( 'pending' === $b['status'] ) : ?>
                                <button class="button button-small wpeb-confirm-btn"
                                        data-id="<?php echo absint( $b['id'] ); ?>">
                                    <?php esc_html_e( '✓ Confirm', 'wp-event-booking' ); ?>
                                </button>
                            <?php endif; ?>
                            <?php if ( in_array( $b['status'], array( 'pending', 'confirmed' ), true ) ) : ?>
                                <button class="button button-small wpeb-cancel-btn"
                                        data-id="<?php echo absint( $b['id'] ); ?>"
                                        style="color:#dc2626;">
                                    <?php esc_html_e( '✕ Cancel', 'wp-event-booking' ); ?>
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php
    }

    /* ── AJAX: update booking status ────────────────────────────── */

    public function update_booking_status(): void {
        check_ajax_referer( 'wpeb_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_event_bookings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-event-booking' ) ) );
        }

        $id     = absint( sanitize_text_field( $_POST['booking_id'] ?? '0' ) );
        $status = sanitize_text_field( $_POST['status'] ?? '' );

        if ( ! $id || ! in_array( $status, array( 'confirmed', 'cancelled' ), true ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid data.', 'wp-event-booking' ) ) );
        }

        // ── FIX 3: instance method call, not static ───────────────
        $db      = new WPEB_Bookings_DB();
        $updated = $db->update_status( $id, $status );

        if ( $updated ) {
            wp_send_json_success( array(
                'message' => ucfirst( $status ),
                'status'  => $status,
            ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Update failed. Please try again.', 'wp-event-booking' ) ) );
        }
    }
}