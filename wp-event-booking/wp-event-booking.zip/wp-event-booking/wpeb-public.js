/* global WPEBData, jQuery */
/**
 * WP Event Booking System — Public JavaScript
 * FILE: wp-event-booking/public/js/wpeb-public.js
 */
( function ( $ ) {
    'use strict';

    /* ── Booking form submit ────────────────────────────────────── */
    $( document ).on( 'click', '#wpeb-submit-booking', function () {
        var $btn     = $( this );
        var $form    = $( '#wpeb-booking-form' );
        var $msg     = $( '#wpeb-booking-message' );
        var eventId  = $( '#wpeb-event-id' ).val();
        var name     = $( '#wpeb-name'  ).val().trim();
        var email    = $( '#wpeb-email' ).val().trim();
        var seats    = parseInt( $( '#wpeb-seats' ).val(), 10 ) || 1;

        // ── Front-end validation ─────────────────────────────────
        $msg.removeClass( 'wpeb-success wpeb-error' ).hide();

        if ( ! name || ! email || ! seats ) {
            $msg.addClass( 'wpeb-error' )
                .text( 'Please fill in your name, email, and seat count.' )
                .show();
            return;
        }
        if ( ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( email ) ) {
            $msg.addClass( 'wpeb-error' ).text( 'Please enter a valid email address.' ).show();
            return;
        }

        // ── Submit via AJAX ──────────────────────────────────────
        $btn.prop( 'disabled', true ).text( WPEBData.strings.booking );

        $.ajax( {
            url:    WPEBData.ajax_url,
            method: 'POST',
            data: {
                action:   'wpeb_submit_booking',
                nonce:    WPEBData.nonce,
                event_id: eventId,
                name:     name,
                email:    email,
                seats:    seats,
            },
            success: function ( res ) {
                if ( res.success ) {
                    $form.fadeOut( 300 );
                    $msg.removeClass( 'wpeb-error' )
                        .addClass( 'wpeb-success' )
                        .text( res.data.message )
                        .show();
                    // Update seats remaining display.
                    var $seatsInfo = $( '.wpeb-seats-info' );
                    if ( $seatsInfo.length ) {
                        $seatsInfo.fadeOut( 300 );
                    }
                } else {
                    $msg.addClass( 'wpeb-error' ).text( res.data.message ).show();
                    $btn.prop( 'disabled', false ).text( WPEBData.strings.book_seat );
                }
            },
            error: function () {
                $msg.addClass( 'wpeb-error' ).text( WPEBData.strings.booking_error ).show();
                $btn.prop( 'disabled', false ).text( WPEBData.strings.book_seat );
            },
        } );
    } );

    /* ── Clear message on input ─────────────────────────────────── */
    $( document ).on( 'input', '.wpeb-input', function () {
        $( '#wpeb-booking-message' ).hide().removeClass( 'wpeb-success wpeb-error' );
    } );

}( jQuery ) );