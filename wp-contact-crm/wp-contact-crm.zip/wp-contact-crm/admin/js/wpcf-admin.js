/**
 * WP Advanced Contact Form & CRM — Admin JavaScript
 * FILE: wp-contact-crm/admin/js/wpcf-admin.js
 *
 * Depends on: jQuery, wp_localize_script 'WPCFAdmin'
 *
 * WPCFAdmin = {
 *   ajax_url, nonce, statuses, chart_data, strings: { ... }
 * }
 *
 * Sections:
 *  1. Row Actions — View (👁), Reply (✉), Delete (🗑)
 *  2. Detail Panel — open / render / close
 *  3. Reply Modal  — open / send / close
 *  4. Status Dropdown — inline AJAX update
 *  5. Bulk Actions
 *  6. Select All checkbox
 *  7. Column sort (client-side)
 *  8. Stat card click → filter rows
 *  9. Add note (inside detail panel)
 * 10. Dismiss instructions panel
 * 11. Toast notifications
 * 12. Charts (Chart.js)
 */

jQuery( function ( $ ) {
    'use strict';

    var ADMIN = window.WPCFAdmin || {};
    var S     = ADMIN.strings || {};

    /* ── Cached elements ──────────────────────────────────────── */
    var $overlay = $( '#wpcf-detail-overlay' );
    var $panel   = $( '#wpcf-detail-panel' );
    var $body    = $( '#wpcf-detail-body' );
    var $modal   = $( '#wpcf-reply-modal' );

    /* ══════════════════════════════════════════════════════════════
       1.  ROW ACTIONS  —  View · Reply · Delete
       The three buttons in the col-actions column.
       data-id is on the button itself (set in PHP render_dashboard).
    ══════════════════════════════════════════════════════════════ */

    /* ── 1a. VIEW ────────────────────────────────────────────── */
    $( document ).on( 'click', '.wpcf-row-btn--view', function () {
        var id = $( this ).data( 'id' );
        if ( ! id ) return;
        openDetailPanel( id );
    } );

    /* ── 1b. REPLY ───────────────────────────────────────────── */
    $( document ).on( 'click', '.wpcf-row-btn--reply', function () {
        var $btn = $( this );
        openReplyModal(
            $btn.data( 'id' ),
            $btn.data( 'name' ),
            $btn.data( 'email' ),
            $btn.data( 'subject' )
        );
    } );

    /* ── 1c. DELETE ──────────────────────────────────────────── */
    $( document ).on( 'click', '.wpcf-row-btn--delete', function () {
        var $btn = $( this );
        var id   = $btn.data( 'id' );
        if ( ! id ) return;

        if ( ! window.confirm( S.confirm_delete || 'Delete this submission permanently? This cannot be undone.' ) ) {
            return;
        }

        var $row = $btn.closest( 'tr' );
        $btn.prop( 'disabled', true ).text( '…' );

        $.post( ADMIN.ajax_url, {
            action: 'wpcf_delete_submission',
            nonce:  ADMIN.nonce,
            id:     id,
        } )
        .done( function ( res ) {
            if ( res.success ) {
                $row.fadeOut( 300, function () {
                    $( this ).remove();
                    refreshStatCounts();
                } );
                toast( S.deleted || 'Deleted', 'success' );
            } else {
                $btn.prop( 'disabled', false ).text( '🗑' );
                toast( ( res.data && res.data.message ) || S.error || 'Delete failed.', 'error' );
            }
        } )
        .fail( function () {
            $btn.prop( 'disabled', false ).text( '🗑' );
            toast( S.error || 'Network error.', 'error' );
        } );
    } );

    /* ══════════════════════════════════════════════════════════════
       2.  DETAIL PANEL  —  slide-in side panel showing full message
    ══════════════════════════════════════════════════════════════ */

    function openDetailPanel( id ) {
        /* Show panel with loading state */
        $body.html(
            '<p style="padding:1rem;color:#646970;">' +
            ( S.loading || 'Loading…' ) + '</p>'
        );
        showOverlay();

        $.post( ADMIN.ajax_url, {
            action: 'wpcf_get_submission',
            nonce:  ADMIN.nonce,
            id:     id,
        } )
        .done( function ( res ) {
            if ( res.success && res.data ) {
                renderDetailPanel( res.data );
                /* Auto-updates table row status to 'read' */
                $( 'tr[data-id="' + id + '"]' )
                    .removeClass( 'is-new' )
                    .find( '.wpcf-status-select' )
                    .val( 'read' );
            } else {
                $body.html( '<p style="padding:1rem;color:#cc1818;">' +
                    ( ( res.data && res.data.message ) || 'Could not load submission.' ) +
                    '</p>' );
            }
        } )
        .fail( function () {
            $body.html( '<p style="padding:1rem;color:#cc1818;">' +
                ( S.error || 'Network error.' ) + '</p>' );
        } );
    }

    function renderDetailPanel( d ) {
        var statuses = ADMIN.statuses || {};
        var html     = '';

        /* ── Meta table ── */
        html += '<dl class="wpcf-detail-meta">';

        function metaRow( label, value ) {
            if ( ! value ) return;
            html += '<dt>' + esc( label ) + '</dt><dd>' + value + '</dd>';
        }

        metaRow( 'From',    esc( d.name ) );
        metaRow( 'Email',   '<a href="mailto:' + esc( d.email ) + '">' + esc( d.email ) + '</a>' );
        metaRow( 'Phone',   d.phone   ? esc( d.phone )   : '' );
        metaRow( 'Subject', d.subject ? esc( d.subject ) : '' );
        metaRow( 'Date',    esc( d.submitted_at || '' ) );     /* submitted_at is the DB field */
        metaRow( 'Source',  d.source_url ? '<a href="' + esc( d.source_url ) + '" target="_blank" rel="noopener">' + esc( d.source_url ) + '</a>' : '' );

        html += '</dl>';

        /* ── Status badge + quick change ── */
        html += '<div class="wpcf-detail-status-row">';
        html += '<label style="font-size:.8125rem;font-weight:700;color:#1d2327;">Status:</label>';
        html += '<select class="wpcf-status-select" data-id="' + esc( String( d.id ) ) + '">';
        Object.keys( statuses ).forEach( function ( k ) {
            html += '<option value="' + esc( k ) + '"' + ( k === d.status ? ' selected' : '' ) + '>' +
                    esc( statuses[ k ] ) + '</option>';
        } );
        html += '</select>';
        html += '<button type="button" class="wpcf-toolbar-btn wpcf-panel-reply-btn" ' +
                'data-id="' + esc( String( d.id ) ) + '" ' +
                'data-name="' + esc( d.name ) + '" ' +
                'data-email="' + esc( d.email ) + '" ' +
                'data-subject="' + esc( d.subject ) + '">✉ Reply</button>';
        html += '</div>';

        /* ── Message body ── */
        html += '<div class="wpcf-detail-section">';
        html += '<strong class="wpcf-detail-section-label">Message</strong>';
        html += '<div class="wpcf-detail-message">' + esc( d.message || '' ) + '</div>';
        html += '</div>';

        /* ── Activity / notes ── */
        if ( d.notes && d.notes.length ) {
            html += '<div class="wpcf-detail-section">';
            html += '<strong class="wpcf-detail-section-label">Activity</strong>';
            html += '<div class="wpcf-timeline">';
            d.notes.forEach( function ( note ) {
                html += '<div class="wpcf-timeline-item">';
                html +=   '<div class="wpcf-tl-dot wpcf-tl-dot--' + esc( note.type || 'note' ) + '">📌</div>';
                html +=   '<div class="wpcf-tl-content">';
                html +=     '<div class="wpcf-tl-meta"><strong>' + esc( note.author || 'Admin' ) +
                             '</strong> &middot; ' + esc( note.date ) + '</div>';
                html +=     '<div class="wpcf-tl-body">' + esc( note.content ) + '</div>';
                html +=   '</div>';
                html += '</div>';
            } );
            html += '</div></div>';
        }

        /* ── Add note ── */
        html += '<div class="wpcf-add-note">';
        html += '<strong class="wpcf-detail-section-label">Add Note</strong>';
        html += '<textarea class="wpcf-note-textarea" data-id="' + esc( String( d.id ) ) + '" ' +
                'placeholder="Internal note — not visible to the submitter…"></textarea>';
        html += '<div style="text-align:right;margin-top:.375rem">';
        html += '<button type="button" class="button button-secondary wpcf-save-note-btn" ' +
                'data-id="' + esc( String( d.id ) ) + '">' +
                ( S.save_note || 'Save Note' ) + '</button>';
        html += '</div>';
        html += '</div>';

        $body.html( html );

        /* Wire the Reply button inside the panel */
        $body.find( '.wpcf-panel-reply-btn' ).on( 'click', function () {
            openReplyModal(
                $( this ).data( 'id' ),
                $( this ).data( 'name' ),
                $( this ).data( 'email' ),
                $( this ).data( 'subject' )
            );
        } );
    }

    function showOverlay() {
        $overlay.show().css( 'opacity', 0 );
        /* Trigger CSS transition */
        requestAnimationFrame( function () {
            $overlay.addClass( 'is-open' );
        } );
        document.body.style.overflow = 'hidden';
    }

    function closeDetailPanel() {
        $overlay.removeClass( 'is-open' );
        /* Hide after CSS transition ends */
        setTimeout( function () {
            $overlay.hide();
        }, 300 );
        document.body.style.overflow = '';
    }

    /* Close panel clicks */
    $( document ).on( 'click', '#wpcf-close-detail', closeDetailPanel );
    $overlay.on( 'click', function ( e ) {
        if ( $( e.target ).is( $overlay ) ) closeDetailPanel();
    } );

    /* ══════════════════════════════════════════════════════════════
       3.  REPLY MODAL  —  compose and send a reply email
    ══════════════════════════════════════════════════════════════ */

    function openReplyModal( id, name, email, subject ) {
        $( '#wpcf-reply-id' ).val( id );
        $( '#wpcf-reply-to' ).text( 'To: ' + name + ' <' + email + '>' );
        $( '#wpcf-reply-subject' ).val( subject ? 'Re: ' + subject : '' );
        $( '#wpcf-reply-body' ).val( '' );
        $( '#wpcf-reply-error' ).hide().text( '' );

        $modal.show().css( 'opacity', 0 );
        requestAnimationFrame( function () {
            $modal.addClass( 'is-open' );
        } );
        document.body.style.overflow = 'hidden';
        $( '#wpcf-reply-subject' ).focus();
    }

    function closeReplyModal() {
        $modal.removeClass( 'is-open' );
        setTimeout( function () { $modal.hide(); }, 250 );
        document.body.style.overflow = '';
    }

    /* Close modal */
    $( document ).on( 'click', '#wpcf-close-modal, #wpcf-close-modal-2', closeReplyModal );
    $modal.on( 'click', function ( e ) {
        if ( $( e.target ).is( $modal ) ) closeReplyModal();
    } );

    /* Send reply */
    $( document ).on( 'click', '#wpcf-send-reply-btn', function () {
        var $btn     = $( this );
        var id       = $( '#wpcf-reply-id' ).val();
        var subject  = $( '#wpcf-reply-subject' ).val().trim();
        var body     = $( '#wpcf-reply-body' ).val().trim();
        var $errBox  = $( '#wpcf-reply-error' );

        $errBox.hide().text( '' );

        if ( ! subject || ! body ) {
            $errBox.text( 'Subject and message are both required.' ).show();
            return;
        }

        $btn.prop( 'disabled', true ).text( S.sending || 'Sending…' );

        $.post( ADMIN.ajax_url, {
            action:  'wpcf_send_reply',
            nonce:   ADMIN.nonce,
            id:      id,
            subject: subject,
            body:    body,
        } )
        .done( function ( res ) {
            $btn.prop( 'disabled', false ).text( S.send_reply || 'Send Reply' );
            if ( res.success ) {
                closeReplyModal();
                /* Update the table row status to replied */
                $( 'tr[data-id="' + id + '"]' )
                    .find( '.wpcf-status-select' )
                    .val( 'replied' );
                toast( S.reply_sent || 'Reply sent!', 'success' );
            } else {
                var msg = ( res.data && res.data.message ) || S.error || 'Send failed.';
                $errBox.text( msg ).show();
            }
        } )
        .fail( function () {
            $btn.prop( 'disabled', false ).text( S.send_reply || 'Send Reply' );
            $errBox.text( S.error || 'Network error.' ).show();
        } );
    } );

    /* Esc key closes both panel and modal */
    $( document ).on( 'keydown', function ( e ) {
        if ( e.key !== 'Escape' ) return;
        if ( $modal.hasClass( 'is-open' ) )   closeReplyModal();
        if ( $overlay.hasClass( 'is-open' ) ) closeDetailPanel();
    } );

    /* ══════════════════════════════════════════════════════════════
       4.  STATUS DROPDOWN  —  inline change triggers AJAX
    ══════════════════════════════════════════════════════════════ */

    $( document ).on( 'change', '.wpcf-status-select', function () {
        var $sel   = $( this );
        /* data-id is on the select element itself (set in PHP) */
        var id     = parseInt( $sel.data( 'id' ), 10 ) || 0;
        var status = $sel.val();
        if ( ! id ) return;

        $sel.prop( 'disabled', true );

        $.post( ADMIN.ajax_url, {
            action: 'wpcf_update_status',
            nonce:  ADMIN.nonce,
            id:     id,
            status: status,
        } )
        .done( function ( res ) {
            $sel.prop( 'disabled', false );
            if ( res.success ) {
                $( 'tr[data-id="' + id + '"]' )
                    .removeClass( 'is-new is-read is-replied is-closed is-spam' )
                    .addClass( 'is-' + status );
                refreshStatCounts();
                toast( 'Status updated', 'success' );
            } else {
                toast( ( res.data && res.data.message ) || S.error || 'Update failed.', 'error' );
            }
        } )
        .fail( function () {
            $sel.prop( 'disabled', false );
            toast( S.error || 'Network error.', 'error' );
        } );
    } );

    /* ══════════════════════════════════════════════════════════════
       5.  BULK ACTIONS
    ══════════════════════════════════════════════════════════════ */

    $( document ).on( 'click', '#wpcf-bulk-apply', function () {
        var action = $( '#wpcf-bulk-action' ).val();
        var ids    = getCheckedIds();

        if ( ! action )    { toast( 'Please select an action.', 'error' ); return; }
        if ( ! ids.length ){ toast( S.no_items || 'No items selected.', 'error' ); return; }

        if ( action === 'delete' &&
             ! window.confirm( S.confirm_bulk || 'Apply this action to all selected items?' ) ) {
            return;
        }

        $.post( ADMIN.ajax_url, {
            action:      'wpcf_bulk_action',
            nonce:       ADMIN.nonce,
            bulk_action: action,
            ids:         ids,
        } )
        .done( function ( res ) {
            if ( res.success ) {
                if ( action === 'delete' ) {
                    ids.forEach( function ( id ) {
                        $( 'tr[data-id="' + id + '"]' ).fadeOut( 250, function () {
                            $( this ).remove();
                        } );
                    } );
                } else {
                    ids.forEach( function ( id ) {
                        $( 'tr[data-id="' + id + '"]' )
                            .find( '.wpcf-status-select' ).val( action );
                    } );
                }
                $( '.wpcf-row-check, #wpcf-select-all' ).prop( 'checked', false );
                refreshStatCounts();
                toast( ( res.data && res.data.message ) || 'Done!', 'success' );
            } else {
                toast( ( res.data && res.data.message ) || S.error || 'Action failed.', 'error' );
            }
        } );
    } );

    function getCheckedIds() {
        return $( '.wpcf-row-check:checked' ).map( function () {
            return $( this ).closest( 'tr' ).data( 'id' );
        } ).get();
    }

    /* ══════════════════════════════════════════════════════════════
       6.  SELECT ALL
    ══════════════════════════════════════════════════════════════ */

    $( document ).on( 'change', '#wpcf-select-all', function () {
        $( '.wpcf-row-check' ).prop( 'checked', $( this ).prop( 'checked' ) );
    } );

    $( document ).on( 'change', '.wpcf-row-check', function () {
        var total   = $( '.wpcf-row-check' ).length;
        var checked = $( '.wpcf-row-check:checked' ).length;
        $( '#wpcf-select-all' )
            .prop( 'checked',       total > 0 && checked === total )
            .prop( 'indeterminate', checked > 0 && checked < total );
    } );

    /* ══════════════════════════════════════════════════════════════
       7.  COLUMN SORT (client-side for current page)
    ══════════════════════════════════════════════════════════════ */

    $( document ).on( 'click', '.wpcf-table th.is-sortable', function () {
        var $th  = $( this );
        var col  = $th.data( 'col' );
        var asc  = ! $th.hasClass( 'sort-asc' );

        $( '.wpcf-table th' ).removeClass( 'sort-asc sort-desc' );
        $th.addClass( asc ? 'sort-asc' : 'sort-desc' );

        var $tbody = $( '.wpcf-table tbody' );
        $tbody.find( 'tr' ).sort( function ( a, b ) {
            var av = $( a ).find( '.col-' + col ).text().trim();
            var bv = $( b ).find( '.col-' + col ).text().trim();
            if ( col === 'id' ) return asc ? +av - +bv : +bv - +av;
            return asc ? av.localeCompare( bv ) : bv.localeCompare( av );
        } ).appendTo( $tbody );
    } );

    /* ══════════════════════════════════════════════════════════════
       8.  STAT CARD CLICK → filter table rows
    ══════════════════════════════════════════════════════════════ */

    $( document ).on( 'click', '.wpcf-stat-card[data-status]', function () {
        var status = $( this ).data( 'status' );
        $( '.wpcf-status-tab' ).removeClass( 'current' );
        $( '.wpcf-status-tab[data-status="' + status + '"]' ).addClass( 'current' );

        $( '.wpcf-table tbody tr' ).each( function () {
            if ( status === 'total' ) {
                $( this ).show();
            } else {
                $( this ).toggle( $( this ).find( '.wpcf-status-select' ).val() === status );
            }
        } );
    } );

    /* ══════════════════════════════════════════════════════════════
       9.  ADD NOTE (inside detail panel)
    ══════════════════════════════════════════════════════════════ */

    $( document ).on( 'click', '.wpcf-save-note-btn', function () {
        var $btn  = $( this );
        var id    = $btn.data( 'id' );
        var $ta   = $body.find( '.wpcf-note-textarea[data-id="' + id + '"]' );
        var note  = $ta.val().trim();
        if ( ! note ) return;

        $btn.prop( 'disabled', true ).text( 'Saving…' );

        $.post( ADMIN.ajax_url, {
            action: 'wpcf_add_note',
            nonce:  ADMIN.nonce,
            id:     id,
            note:   note,
        } )
        .done( function ( res ) {
            $btn.prop( 'disabled', false ).text( S.save_note || 'Save Note' );
            if ( res.success ) {
                $ta.val( '' );
                /* Prepend the new note to the timeline */
                var noteHtml =
                    '<div class="wpcf-timeline-item">' +
                    '<div class="wpcf-tl-dot wpcf-tl-dot--note">📌</div>' +
                    '<div class="wpcf-tl-content">' +
                    '<div class="wpcf-tl-meta"><strong>You</strong> &middot; just now</div>' +
                    '<div class="wpcf-tl-body">' + esc( note ) + '</div>' +
                    '</div></div>';

                var $tl = $body.find( '.wpcf-timeline' );
                if ( $tl.length ) {
                    $tl.prepend( noteHtml );
                } else {
                    /* No timeline section yet — create it above the note form */
                    $body.find( '.wpcf-add-note' ).before(
                        '<div class="wpcf-detail-section">' +
                        '<strong class="wpcf-detail-section-label">Activity</strong>' +
                        '<div class="wpcf-timeline">' + noteHtml + '</div>' +
                        '</div>'
                    );
                }
                toast( S.saved || 'Note saved', 'success' );
            } else {
                toast( ( res.data && res.data.message ) || S.error || 'Save failed.', 'error' );
            }
        } );
    } );

    /* ══════════════════════════════════════════════════════════════
       10.  DISMISS INSTRUCTIONS PANEL
    ══════════════════════════════════════════════════════════════ */

    $( document ).on( 'click', '#wpcf-dismiss-instructions', function () {
        $( '#wpcm-instructions, #wpcf-instructions' ).slideUp( 250 );
        $.post( ADMIN.ajax_url, {
            action: 'wpcf_dismiss_instructions',
            nonce:  ADMIN.nonce,
        } );
    } );

    /* ══════════════════════════════════════════════════════════════
       11.  TOAST NOTIFICATIONS
    ══════════════════════════════════════════════════════════════ */

    function toast( message, type ) {
        var $c = $( '#wpcf-toasts' );
        if ( ! $c.length ) {
            $c = $( '<div id="wpcf-toasts" class="wpcf-toast-container"></div>' ).appendTo( 'body' );
        }
        var $t = $(
            '<div class="wpcf-toast wpcf-toast--' + ( type || 'success' ) + '">' +
            '<span>' + esc( message ) + '</span>' +
            '<button class="wpcf-toast__close" aria-label="Close">×</button>' +
            '</div>'
        ).appendTo( $c );

        $t.find( '.wpcf-toast__close' ).on( 'click', function () { removeToast( $t ); } );
        setTimeout( function () { removeToast( $t ); }, 4500 );
    }

    function removeToast( $t ) {
        $t.addClass( 'is-removing' );
        setTimeout( function () { $t.remove(); }, 220 );
    }

    /* ══════════════════════════════════════════════════════════════
       12.  CHARTS (Chart.js)
    ══════════════════════════════════════════════════════════════ */

    if ( typeof Chart !== 'undefined' && ADMIN.chart_data ) {
        var cd = ADMIN.chart_data;

        var $vol = $( '#wpcf-volume-chart' );
        if ( $vol.length ) {
            new Chart( $vol[0].getContext( '2d' ), {
                type: 'line',
                data: {
                    labels:   cd.labels   || [],
                    datasets: [ {
                        label:           'Submissions',
                        data:            cd.volumes  || [],
                        borderColor:     '#2271b1',
                        backgroundColor: 'rgba(34,113,177,.09)',
                        borderWidth:     2,
                        pointRadius:     3,
                        fill:            true,
                        tension:         0.35,
                    } ],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { beginAtZero: true, ticks: { stepSize: 1 } },
                        x: { grid: { display: false } },
                    },
                },
            } );
        }

        var $pie = $( '#wpcf-status-chart' );
        if ( $pie.length ) {
            new Chart( $pie[0].getContext( '2d' ), {
                type: 'doughnut',
                data: {
                    labels:   [ 'New', 'Read', 'Replied', 'Closed', 'Spam' ],
                    datasets: [ {
                        data: [ cd.new || 0, cd.read || 0, cd.replied || 0, cd.closed || 0, cd.spam || 0 ],
                        backgroundColor: [ '#2271b1', '#7c3aed', '#00a32a', '#646970', '#cc1818' ],
                        borderWidth: 0,
                    } ],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom' } },
                    cutout: '65%',
                },
            } );
        }
    }

    /* ══════════════════════════════════════════════════════════════
       HELPERS
    ══════════════════════════════════════════════════════════════ */

    /* Refresh the stat-card numbers by counting visible rows */
    function refreshStatCounts() {
        var counts = { new: 0, read: 0, replied: 0, closed: 0, spam: 0, total: 0 };
        $( '.wpcf-table tbody tr' ).each( function () {
            var s = $( this ).find( '.wpcf-status-select' ).val() || '';
            if ( counts.hasOwnProperty( s ) ) counts[ s ]++;
            counts.total++;
        } );
        Object.keys( counts ).forEach( function ( k ) {
            $( '.wpcf-stat-card[data-status="' + k + '"] .wpcf-stat-card__num' ).text( counts[ k ] );
            $( '.wpcf-status-tab[data-status="' + k + '"] .wpcf-tab-count' ).text( counts[ k ] );
        } );
    }

    /* HTML-escape a string for safe insertion into innerHTML */
    function esc( s ) {
        return String( s || '' )
            .replace( /&/g, '&amp;'  )
            .replace( /</g, '&lt;'   )
            .replace( />/g, '&gt;'   )
            .replace( /"/g, '&quot;' );
    }

} );