wp-contact-crm/
│
├── wp-contact-crm.php             ← Bootstrap + plugin header
├── uninstall.php
├── readme.txt
│
├── includes/
│   ├── class-wpcf-activator.php   ← DB table + caps
│   ├── class-wpcf-submissions-db.php ← CRUD for submissions table
│   ├── class-wpcf-settings.php    ← Settings API
│   ├── class-wpcf-shortcodes.php  ← [contact_form]
│   ├── class-wpcf-ajax.php        ← Submit + status update handlers
│   ├── class-wpcf-email.php       ← Auto-reply + admin notification
│   ├── class-wpcf-rate-limiter.php← Transient-based rate limiting
│   ├── class-wpcf-rest-api.php    ← REST endpoint
│   └── class-wpcf-admin.php       ← CRM dashboard list table
│
├── admin/
│   ├── css/wpcf-admin.css
│   └── js/wpcf-admin.js
│
├── public/
│   ├── css/wpcf-public.css
│   └── js/wpcf-public.js
│
└── languages/
    └── wp-contact-crm.pot