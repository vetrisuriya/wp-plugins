# WP Advanced Contact Form & CRM - User Guide

## Overview

WP Advanced Contact Form & CRM is a powerful WordPress plugin that provides:
- A fully customizable contact form
- Built-in CRM dashboard to manage all submissions
- Automatic email notifications and auto-reply messages
- Spam protection with rate limiting
- REST API for programmatic access
- CSV export functionality

**Requires:** WordPress 6.0+, PHP 8.0+

---

## Table of Contents

1. [Installation & Activation](#installation--activation)
2. [Initial Setup](#initial-setup)
3. [Adding the Contact Form](#adding-the-contact-form)
4. [Contact Form Shortcodes](#contact-form-shortcodes)
5. [Managing Submissions](#managing-submissions)
6. [Settings & Configuration](#settings--configuration)
7. [REST API](#rest-api)
8. [Security Features](#security-features)

---

## Installation & Activation

### Step 1: Upload Plugin
1. Go to **WordPress Admin Dashboard**
2. Navigate to **Plugins → Add New**
3. Click **Upload Plugin**
4. Select the `wp-contact-crm` plugin folder and upload
5. Click **Install Now**

### Step 2: Activate Plugin
1. After installation, click **Activate Plugin**
2. You will be automatically redirected to the Contact CRM dashboard
3. The plugin creates a custom database table for storing submissions

### First Access
- A new menu item **"Contact CRM"** will appear in the WordPress admin sidebar
- Two submenu pages are available:
  - **Contact CRM** - Dashboard with all submissions
  - **Settings** - Configuration options

---

## Initial Setup

### Configure Email Settings

1. Go to **Contact CRM → Settings**
2. Configure the following options:

#### Email Settings Section

**Notification Email**
- The email address where submissions will be sent
- Default: Your WordPress admin email
- Change this to receive notifications at a different email

**Auto-Reply Message**
- Message sent automatically to users who submit the form
- Default: "Thank you for contacting us. We will reply within 1-2 business days."
- Customize with your own message
- This email is sent immediately after form submission

#### Security Settings Section

**Max Submissions per IP per Hour**
- Controls spam rate limiting
- Default: 3 submissions per IP per hour
- Increase for high-traffic forms, decrease for stricter spam control
- Prevents abuse by limiting submissions from the same IP address

3. Click **Save Changes** to apply settings

---

## Adding the Contact Form

### Basic Usage

Add the contact form to any page or post using the shortcode:

```
[contact_form]
```

### Shortcode Parameters

#### Shortcode: `[contact_form]`

The `[contact_form]` shortcode displays a professional contact form with built-in validation and spam protection.

**Available Attributes:**

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `title` | string | (empty) | Heading text displayed above the form |
| `subtitle` | string | (empty) | Subheading text displayed above the form |
| `show_phone` | boolean | `false` | Show/hide the phone number field |
| `show_subject` | boolean | `true` | Show/hide the subject field |
| `class` | string | (empty) | Additional CSS class(es) for styling |
| `form_id` | string | `default` | Unique form identifier (useful for tracking multiple forms) |

**Basic Examples:**

```
[contact_form]
```
Displays the basic contact form with name, email, subject, and message fields.

```
[contact_form title="Get In Touch" subtitle="We reply within 24 hours"]
```
Adds a title and subtitle above the form.

```
[contact_form show_phone="true"]
```
Shows the phone number field.

```
[contact_form title="Contact Us" show_phone="true" show_subject="false" class="contact-dark"]
```
Shows a customized form with:
- Title "Contact Us"
- Phone field visible
- Subject field hidden
- Custom CSS class "contact-dark" for styling

**Form Validation:**

The form includes client-side and server-side validation:

- **Name**: Required, minimum 2 characters
- **Email**: Required, must be valid email format
- **Phone**: Optional, validates phone format if provided
- **Subject**: Optional
- **Message**: Required, maximum 1000 characters
- **File upload**: Not included in basic form

**Form Fields:**

All forms include:
- **Name** (required)
- **Email** (required)
- **Subject** (optional, unless `show_subject="false"`)
- **Phone** (optional, unless `show_phone="true"`)
- **Message** (required, max 1000 characters)
- **Character counter** for message field
- **Send Message button**
- **Success message** after submission

**Security Features Built-In:**

- Honeypot field to catch spam bots
- AJAX submission with nonce verification
- Rate limiting by IP address
- Server-side sanitization and validation

---

## Managing Submissions

### Accessing the Dashboard

1. Go to **Contact CRM** in the WordPress admin sidebar
2. The dashboard displays all form submissions with:
   - Submission count by status
   - Submission volume chart (last 30 days)
   - List of all submissions
   - Filtering and search options

### Submission Statuses

Each submission has a status that tracks its lifecycle:

| Status | Description |
|--------|-------------|
| **New** | Unread submission (highlighted for attention) |
| **Read** | Admin has read the submission |
| **Replied** | Admin has sent a reply email to the user |
| **Closed** | Submission resolved and archived |
| **Spam** | Marked as spam and hidden from main list |

### Managing Individual Submissions

1. Click on any submission in the list to open the detail panel
2. Available actions:

**Update Status**
- Click the status dropdown to change: New → Read → Replied → Closed → Spam
- Status automatically updates across all views

**Send Reply Email**
- Click "Send Reply" button
- Compose your response email
- Email sent to the original user with your reply

**Add Internal Note**
- Add private notes for team members
- Notes appear only in the admin dashboard
- Useful for tracking conversation history

**Copy Email/Details**
- Quick copy contact information for follow-up outside the system

**Delete Submission**
- Permanently remove a submission from the database
- Warning: This action cannot be undone

### Filtering & Searching

**By Status**
- Click status tabs to filter submissions:
  - All, New, Read, Replied, Closed, Spam

**Search**
- Use the search box to find submissions by:
  - Submitter name
  - Email address
  - Subject line
  - Message content

**Pagination**
- 25 submissions per page
- Navigate through pages using pagination controls

### Bulk Actions

Select multiple submissions and perform actions on all of them:
- Change status for multiple submissions
- Delete multiple submissions at once
- Useful for managing large volumes of submissions

### Export to CSV

1. Click the **"Export CSV"** button
2. All visible submissions are exported based on current filters/search
3. Exported file includes:
   - Name, Email, Phone, Subject, Message
   - Submission date and time
   - Current status
   - Source page URL
   - Assigned admin user

Use CSV for:
- Backup purposes
- Analysis in spreadsheet software
- Integration with other systems
- Reporting to team members

---

## Settings & Configuration

### How to Access Settings

1. Go to **Contact CRM → Settings**
2. Two main sections available:

### Email Settings

#### Notification Email Address
- **Field:** "Notification Email"
- **Purpose:** Receives admin notifications when new submissions arrive
- **Default:** Your WordPress admin email
- **How to Change:** Enter a different email address and click Save
- **Note:** This should be an email you actively monitor

**Example:** 
If you set this to `sales@example.com`, every new form submission will be emailed to that address with the submitted information.

#### Auto-Reply Message
- **Field:** "Auto-Reply Message"
- **Purpose:** Automatic response sent to users immediately after form submission
- **Default:** "Thank you for contacting us. We will reply within 1-2 business days."
- **How to Customize:** Replace the text with your custom message
- **Best Practices:**
  - Keep the message concise (1-3 sentences)
  - Set expectations for response time
  - Include additional contact information if needed
  - Add a link to your website or FAQ

**Example Auto-Reply Message:**
```
Thank you for contacting us! Your message has been received.
Our team will review your inquiry and respond within 24 hours.
For urgent matters, please call us at (555) 123-4567.
```

### Security Settings

#### Rate Limiting

- **Field:** "Max Submissions per IP per Hour"
- **Purpose:** Prevents spam and abuse by limiting form submissions
- **Default:** 3 submissions per IP per hour
- **Allowed Range:** 1-20 submissions

**How Rate Limiting Works:**
1. Plugin records IP address of form submitters
2. Tracks number of submissions from each IP per hour
3. Blocks further submissions if limit exceeded
4. Shows user an error message asking to wait
5. Limit resets after 1 hour

**Recommendations:**
- **For low-traffic sites:** Keep at 3 (default)
- **For normal websites:** 5-10 submissions per hour
- **For high-traffic sites:** 15-20 submissions per hour
- **For internal-only forms:** 20 (no restriction)

**Example:**
If set to 5, a visitor can submit the form 5 times within any 1-hour window. The 6th attempt will be blocked until an hour has passed since their first submission.

### Other Built-In Security Features (Non-Configurable)

These features work automatically and cannot be changed:

1. **Honeypot Field**
   - Hidden field that only bots would fill
   - Any submission with this field filled is silently rejected

2. **AJAX Submission**
   - Form submits in background without page reload
   - Uses WordPress nonce verification

3. **Sanitization & Validation**
   - All input sanitized before saving
   - Email format validated
   - XSS protection applied
   - Database injection prevented

4. **CORS Protection**
   - Form can only be submitted from your website
   - Prevents submissions from external sites

---

## REST API

### Overview

The plugin provides REST API endpoints for programmatic access to submissions. All endpoints require authentication and the `manage_crm` capability (admin level).

### Base URL
```
https://yourdomain.com/wp-json/wpcf/v1/
```

### Authentication

All requests must include:
1. Basic Auth (username:password) or
2. Application Passwords (WordPress 5.6+)
3. Or use nonce in header

### Endpoints

#### GET /submissions
**Retrieve a list of submissions with optional filters**

**URL:**
```
GET /wp-json/wpcf/v1/submissions
```

**Parameters:**
- `status` (string): Filter by status - `new`, `read`, `replied`, `closed`, `spam`
- `search` (string): Search in name, email, subject, message
- `per_page` (integer): Results per page (default: 20, max: 100)
- `page` (integer): Page number (default: 1)

**Example Request:**
```bash
curl -u username:password \
  "https://yourdomain.com/wp-json/wpcf/v1/submissions?status=new&per_page=10"
```

**Example Response:**
```json
[
  {
    "id": 42,
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "555-1234",
    "subject": "Website Inquiry",
    "message": "I'm interested in your services...",
    "source_url": "https://yourdomain.com/contact",
    "status": "new",
    "assigned_to": null,
    "submitted_at": "2025-05-28 10:30:00",
    "replied_at": null
  }
]
```

**Use Cases:**
- Display submissions in external dashboard
- Sync submissions to CRM system
- Generate custom reports

---

#### PATCH /submissions/{id}
**Update a submission's status**

**URL:**
```
PATCH /wp-json/wpcf/v1/submissions/42
```

**Body (JSON):**
```json
{
  "status": "replied"
}
```

**Allowed Status Values:**
- `new`
- `read`
- `replied`
- `closed`
- `spam`

**Example Request:**
```bash
curl -X PATCH -u username:password \
  -H "Content-Type: application/json" \
  -d '{"status":"closed"}' \
  "https://yourdomain.com/wp-json/wpcf/v1/submissions/42"
```

**Example Response:**
```json
{
  "success": true,
  "id": 42,
  "status": "closed"
}
```

**Use Cases:**
- Update submission status from external system
- Mark submissions as replied/closed programmatically
- Integrate with workflows

---

### IP Address Privacy

**Important:** 
- IP addresses are **included** in database storage (for spam tracking)
- IP addresses are **stripped** from all REST API responses for privacy
- IP addresses are **not exported** in CSV files
- Only available in admin dashboard

---

## Security Features

### How Your Data Is Protected

1. **Honeypot Field**
   - Hidden form field that catches automated bots
   - Looks legitimate but filled only by scripts
   - Submissions with honeypot filled are rejected silently

2. **Rate Limiting**
   - Prevents spam by limiting submissions per IP address
   - Configurable limit (default: 3 per hour)
   - Uses WordPress transients for tracking

3. **AJAX Nonce Verification**
   - Form submission includes security token
   - Verified on server before processing
   - Prevents CSRF (Cross-Site Request Forgery) attacks

4. **Input Sanitization**
   - All form inputs sanitized before saving
   - Special characters escaped
   - HTML/JavaScript stripped from message field

5. **Email Validation**
   - Email format verified on client and server
   - Invalid emails rejected

6. **Message Length Limits**
   - Maximum 1000 characters enforced
   - Prevents database abuse

7. **IP Address Tracking**
   - Submitted IP address recorded for spam prevention
   - Used for rate limiting and spam detection

### User Privacy

**Data Collected:**
- Name, Email, Phone (if enabled)
- Message content
- Submission date/time
- Source page URL
- IP address (for spam tracking only)

**Data Not Collected:**
- User ID (not required to be logged in)
- Cookies or tracking data
- Location data beyond IP address

**Data Retention:**
- All submissions stored indefinitely until manually deleted
- Admins can delete submissions at any time
- CSV export available for backup/archival

---

## Troubleshooting

### Form Not Showing

**Problem:** Shortcode `[contact_form]` not displaying

**Solutions:**
1. Check that plugin is activated (Contact CRM menu visible)
2. Verify PHP version is 8.0 or higher
3. Check WordPress version is 6.0 or higher
4. Clear any page caching plugins
5. Verify shortcode is spelled correctly: `[contact_form]`

### Form Submissions Not Received

**Problem:** Form appears to submit but no confirmation or email

**Solutions:**
1. Check email settings in **Contact CRM → Settings**
2. Verify "Notification Email" is set correctly
3. Check WordPress admin email is working
4. Check spam folder for auto-reply email
5. Look for submissions in **Contact CRM dashboard**
   - Click on "New" tab to see recent submissions

### "Too Many Submissions" Error

**Problem:** User gets error "Too many submissions from your IP"

**Solutions:**
1. This is rate limiting in action
2. Check setting in **Contact CRM → Settings → Max Submissions per IP per Hour**
3. Increase the limit if needed
4. Wait for the hourly window to pass before trying again
5. Submitter should wait 1 hour before resubmitting

### Rate Limiting Too Strict

**Problem:** Legitimate users can't submit multiple times

**Solutions:**
1. Go to **Contact CRM → Settings**
2. Increase "Max Submissions per IP per Hour" value
3. Click "Save Changes"
4. Example: Change from 3 to 10 for more generous limits

### Emails Not Sending

**Problem:** Auto-reply or admin notifications not arriving

**Solutions:**
1. Verify email settings in **Contact CRM → Settings**
2. Test your WordPress email setup:
   - Install "WP Mail Logging" plugin to debug
3. Check your hosting provider's mail relay settings
4. Verify sender email isn't flagged as spam
5. Check WordPress wp-config.php mail settings
6. Contact your hosting provider for email relay issues

### Dashboard Not Loading

**Problem:** Contact CRM admin page shows blank or error

**Solutions:**
1. Verify PHP version 8.0+ in hosting control panel
2. Check WordPress error log for PHP errors
3. Disable other plugins temporarily to check for conflicts
4. Clear WordPress transients:
   - Go to **Tools → Site Health** (if available)
5. Reinstall the plugin

---

## Advanced Features

### Multiple Contact Forms

You can use the `form_id` attribute to track different forms separately:

```
[contact_form form_id="footer"]
[contact_form form_id="sidebar" show_phone="true"]
```

This helps identify which form each submission came from in the CRM dashboard.

### Custom Styling

Add custom CSS class for styling:

```
[contact_form class="contact-compact" title="Quick Contact"]
```

Then add CSS in your theme:
```css
.contact-compact .wpcf-form-card {
  max-width: 400px;
}
```

### Bulk Exporting Data

Export all submissions as CSV:
1. Go to **Contact CRM** dashboard
2. Apply any filters you want (by status, search, etc.)
3. Click **Export CSV** button
4. File downloads with all visible submissions

---

## Support & Documentation

For additional help:
1. Check this guide's Troubleshooting section
2. Review plugin code comments in `/includes/` folder
3. Contact your hosting provider for server-level issues
4. Check WordPress.org plugin forum for community support

---

## Version Information

- **Plugin Name:** WP Advanced Contact Form & CRM
- **Current Version:** 1.0.0
- **Requires WordPress:** 6.0 or higher
- **Requires PHP:** 8.0 or higher
- **License:** GPL 2.0 or later

---

## Summary Table

| Feature | Details |
|---------|---------|
| **Main Shortcode** | `[contact_form]` |
| **Database Table** | wp_wpcf_submissions |
| **Admin Menu** | Contact CRM |
| **Capabilities Required** | manage_crm (admin) |
| **Email Notifications** | Auto-reply + Admin notification |
| **Rate Limiting** | Configurable per IP per hour |
| **Data Export** | CSV format |
| **REST API** | Yes, /wp-json/wpcf/v1/ |
| **Spam Protection** | Honeypot, nonce, rate limiting |
| **Character Limit** | Message: 1000 characters max |

---

**Last Updated:** May 28, 2025
**Plugin Version:** 1.0.0
