<?php
/**
 * REST API — Submissions Endpoint
 *
 * FILE: wp-contact-crm/includes/class-wpcf-rest-api.php
 *
 * @package WP_Contact_CRM
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPCF_Rest_Api {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes(): void {
        register_rest_route( 'wpcf/v1', '/submissions', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_submissions' ),
            'permission_callback' => array( $this, 'admin_permission' ),
            'args'                => array(
                'status'   => array( 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'search'   => array( 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'per_page' => array( 'type' => 'integer', 'default' => 20, 'minimum' => 1, 'maximum' => 100 ),
                'page'     => array( 'type' => 'integer', 'default' => 1,  'minimum' => 1 ),
            ),
        ) );

        register_rest_route( 'wpcf/v1', '/submissions/(?P<id>\d+)', array(
            'methods'             => 'PATCH',
            'callback'            => array( $this, 'patch_submission' ),
            'permission_callback' => array( $this, 'admin_permission' ),
        ) );
    }

    public function get_submissions( WP_REST_Request $request ): WP_REST_Response {
        $db       = new WPCF_Submissions_DB();
        $per_page = (int) $request->get_param( 'per_page' );
        $page     = (int) $request->get_param( 'page' );

        $rows = $db->get_all( array_filter( array(
            'status'  => $request->get_param( 'status' ),
            'search'  => $request->get_param( 'search' ),
            'limit'   => $per_page,
            'offset'  => ( $page - 1 ) * $per_page,
        ) ) );

        $rows = array_map( function ( array $row ) {
            unset( $row['ip_address'] );
            return $row;
        }, $rows );

        $response = new WP_REST_Response( $rows, 200 );
        $response->header( 'X-WP-Total', count( $rows ) );
        return $response;
    }

    public function patch_submission( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $id     = absint( $request->get_param( 'id' ) );
        $body   = $request->get_json_params();
        $status = sanitize_text_field( $body['status'] ?? '' );
        $db     = new WPCF_Submissions_DB();

        if ( ! $db->update_status( $id, $status ) ) {
            return new WP_Error( 'invalid_submission', __( 'Invalid submission ID or status.', 'wp-contact-crm' ), array( 'status' => 400 ) );
        }

        return new WP_REST_Response( array( 'success' => true, 'id' => $id, 'status' => $status ), 200 );
    }

    public function admin_permission(): bool {
        return current_user_can( 'manage_crm' );
    }
}