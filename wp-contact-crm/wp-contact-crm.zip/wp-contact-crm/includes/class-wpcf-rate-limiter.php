<?php
/**
 * Transient-based Rate Limiter
 *
 * FILE: wp-contact-crm/includes/class-wpcf-rate-limiter.php
 *
 * @package WP_Contact_CRM
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPCF_Rate_Limiter {

    private string $key;
    private int    $limit;

    public function __construct() {
        $ip          = $this->get_ip();
        $this->key   = 'wpcf_rate_' . md5( $ip );
        $this->limit = (int) WPCF_Settings::get( 'rate_limit', 3 );
    }

    public function allow(): bool {
        return (int) get_transient( $this->key ) < $this->limit;
    }

    public function record(): void {
        $count = (int) get_transient( $this->key );
        if ( 0 === $count ) {
            set_transient( $this->key, 1, HOUR_IN_SECONDS );
        } else {
            $timeout_key = '_transient_timeout_' . $this->key;
            $expiry      = (int) get_option( $timeout_key, 0 );
            $remaining   = max( 1, $expiry - time() );
            set_transient( $this->key, $count + 1, $remaining );
        }
    }

    public function get_count(): int {
        return (int) get_transient( $this->key );
    }

    private function get_ip(): string {
        $candidates = array(
            $_SERVER['HTTP_CLIENT_IP']       ?? '',
            $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '',
            $_SERVER['REMOTE_ADDR']          ?? '',
        );
        foreach ( $candidates as $raw ) {
            if ( ! $raw ) continue;
            $ip = trim( explode( ',', sanitize_text_field( wp_unslash( $raw ) ) )[0] );
            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
        }
        return '0.0.0.0';
    }
}