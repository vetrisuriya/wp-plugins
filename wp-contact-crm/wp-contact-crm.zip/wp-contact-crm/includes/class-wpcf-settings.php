<?php
/**
 * Settings API — admin menu registration and settings page.
 *
 * FILE: wp-contact-crm/includes/class-wpcf-settings.php
 *
 * FIX APPLIED:
 *   Constructor now accepts a WPCF_Admin $admin parameter.
 *   add_page() uses $this->admin (the injected instance) as the menu
 *   page callback instead of creating `new WPCF_Admin()` inline.
 *
 *   BEFORE (broken):
 *     public function add_page() {
 *         add_menu_page( ..., array( new WPCF_Admin(), 'render_dashboard' ), ... );
 *         //                        ^^^^^^^^^^^^^^^^
 *         //                        Creates a SECOND WPCF_Admin instance.
 *         //                        Its constructor re-hooks admin_enqueue_scripts,
 *         //                        causing duplicate script/style registration.
 *     }
 *
 *   AFTER (fixed):
 *     private WPCF_Admin $admin;
 *     public function __construct( WPCF_Admin $admin ) {
 *         $this->admin = $admin;   // store the one instance created in main file
 *         ...
 *     }
 *     public function add_page() {
 *         add_menu_page( ..., array( $this->admin, 'render_dashboard' ), ... );
 *         //                        ^^^^^^^^^^^
 *         //                        Reuses the existing object — no second construction.
 *     }
 *
 * @package WP_Contact_CRM
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPCF_Settings {

    /**
     * The single WPCF_Admin instance, injected from the main plugin file.
     * Stored so add_page() can use it as the menu page callback without
     * creating a new instance.
     *
     * @var WPCF_Admin
     */
    private WPCF_Admin $admin;

    /**
     * Constructor.
     *
     * @param WPCF_Admin $admin The WPCF_Admin instance created in wp-contact-crm.php.
     */
    public function __construct( WPCF_Admin $admin ) {
        $this->admin = $admin;

        add_action( 'admin_menu', array( $this, 'add_page' ) );
        add_action( 'admin_init', array( $this, 'register' ) );
    }

    /**
     * Register admin menu pages.
     *
     * Uses $this->admin — the already-constructed instance — as the callback
     * for the main CRM dashboard page.  No second WPCF_Admin object is created.
     *
     * @return void
     */
    public function add_page(): void {
        add_menu_page(
            __( 'Contact CRM',  'wp-contact-crm' ),
            __( 'Contact CRM',  'wp-contact-crm' ),
            'manage_crm',
            'wpcf-crm',
            array( $this->admin, 'render_dashboard' ),  // ← reuse existing instance
            'dashicons-email-alt',
            30
        );

        add_submenu_page(
            'wpcf-crm',
            __( 'Form Settings', 'wp-contact-crm' ),
            __( 'Settings',      'wp-contact-crm' ),
            'manage_options',
            'wpcf-settings',
            array( $this, 'render' )
        );
    }

    /**
     * Register settings, sections, and fields.
     *
     * @return void
     */
    public function register(): void {
        register_setting(
            'wpcf_group',
            'wpcf_options',
            array( 'sanitize_callback' => array( $this, 'sanitize' ) )
        );

        add_settings_section(
            'wpcf_email',
            __( 'Email Settings', 'wp-contact-crm' ),
            '__return_false',
            'wpcf-settings'
        );
        add_settings_field(
            'recipient_email',
            __( 'Notification Email', 'wp-contact-crm' ),
            array( $this, 'field_recipient' ),
            'wpcf-settings',
            'wpcf_email'
        );
        add_settings_field(
            'auto_reply_message',
            __( 'Auto-Reply Message', 'wp-contact-crm' ),
            array( $this, 'field_auto_reply' ),
            'wpcf-settings',
            'wpcf_email'
        );

        add_settings_section(
            'wpcf_security',
            __( 'Security Settings', 'wp-contact-crm' ),
            '__return_false',
            'wpcf-settings'
        );
        add_settings_field(
            'rate_limit',
            __( 'Max Submissions per IP per Hour', 'wp-contact-crm' ),
            array( $this, 'field_rate_limit' ),
            'wpcf-settings',
            'wpcf_security'
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Field renderers
    // ─────────────────────────────────────────────────────────────────────────

    public function field_recipient(): void {
        $val = $this->val( 'recipient_email', get_option( 'admin_email', '' ) );
        printf(
            '<input type="email" name="wpcf_options[recipient_email]" value="%s" class="regular-text">',
            esc_attr( $val )
        );
    }

    public function field_auto_reply(): void {
        $default = __( 'Thank you for contacting us. We will reply within 1-2 business days.', 'wp-contact-crm' );
        $val     = $this->val( 'auto_reply_message', $default );
        printf(
            '<textarea name="wpcf_options[auto_reply_message]" rows="4" class="large-text">%s</textarea>',
            esc_textarea( $val )
        );
    }

    public function field_rate_limit(): void {
        $val = $this->val( 'rate_limit', 3 );
        printf(
            '<input type="number" name="wpcf_options[rate_limit]" value="%d" min="1" max="20">
             <p class="description">%s</p>',
            absint( $val ),
            esc_html__( 'Number of form submissions allowed per IP address per hour before the rate limiter blocks further attempts.', 'wp-contact-crm' )
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Sanitize + read helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Sanitize settings before saving to wp_options.
     *
     * @param  mixed $input Raw $_POST data from the settings form.
     * @return array        Sanitized key → value pairs.
     */
    public function sanitize( $input ): array {
        if ( ! is_array( $input ) ) {
            return array();
        }
        return array(
            'recipient_email'    => sanitize_email( $input['recipient_email'] ?? '' ),
            'auto_reply_message' => sanitize_textarea_field( $input['auto_reply_message'] ?? '' ),
            'rate_limit'         => absint( $input['rate_limit'] ?? 3 ),
        );
    }

    /**
     * Read a single key from the wpcf_options option array.
     *
     * @param  string $key     Option key.
     * @param  mixed  $default Fallback value.
     * @return mixed
     */
    private function val( string $key, $default = '' ): mixed {
        $opts = get_option( 'wpcf_options', array() );
        return $opts[ $key ] ?? $default;
    }

    /**
     * Render the settings page.
     *
     * @return void
     */
    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-contact-crm' ) );
        }
        ?>
        <div class="wrap wpcf-settings-wrap">
            <h1><?php esc_html_e( 'Contact Form Settings', 'wp-contact-crm' ); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'wpcf_group' );
                do_settings_sections( 'wpcf-settings' );
                submit_button( __( 'Save Settings', 'wp-contact-crm' ) );
                ?>
            </form>
        </div>
        <?php
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Static accessor — used by classes that need a settings value without
    // holding a reference to this object (e.g. WPCF_Email, WPCF_Rate_Limiter).
    //
    //   Usage:  $recipient = WPCF_Settings::get( 'recipient_email', get_option('admin_email') );
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Read a single option value statically.
     *
     * @param  string $key
     * @param  mixed  $default
     * @return mixed
     */
    public static function get( string $key, $default = '' ): mixed {
        $opts = get_option( 'wpcf_options', array() );
        return $opts[ $key ] ?? $default;
    }
}