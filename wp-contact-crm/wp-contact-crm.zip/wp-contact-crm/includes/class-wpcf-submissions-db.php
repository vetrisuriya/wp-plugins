<?php
/**
 * Custom Database Table — CRUD Layer
 *
 * FILE: wp-contact-crm/includes/class-wpcf-submissions-db.php
 *
 * Handles all read/write operations on the wpcf_submissions table.
 * Never writes raw SQL inline in other classes — all DB access goes here.
 *
 * Table schema (created by class-wpcf-activator.php):
 *   id, name, email, phone, subject, message,
 *   source_url, ip_address, status, assigned_to,
 *   submitted_at, replied_at
 *
 * @package WP_Contact_CRM
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPCF_Submissions_DB {

    /** @var string Full table name including $wpdb->prefix */
    private string $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'wpcf_submissions';
    }

    /**
     * Insert a new submission row.
     *
     * @param  array $data  Keys: name, email, phone, subject, message, source_url, ip_address.
     * @return int|WP_Error Inserted row ID on success, WP_Error on DB failure.
     */
    public function insert( array $data ): int|WP_Error {
        global $wpdb;

        $result = $wpdb->insert(
            $this->table,
            array(
                'name'         => sanitize_text_field( $data['name']       ?? '' ),
                'email'        => sanitize_email(      $data['email']      ?? '' ),
                'phone'        => sanitize_text_field( $data['phone']      ?? '' ),
                'subject'      => sanitize_text_field( $data['subject']    ?? '' ),
                'message'      => sanitize_textarea_field( $data['message'] ?? '' ),
                'source_url'   => esc_url_raw(         $data['source_url']  ?? '' ),
                'ip_address'   => sanitize_text_field( $data['ip_address']  ?? '' ),
                'status'       => 'new',
                'submitted_at' => current_time( 'mysql' ),
            ),
            array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
        );

        if ( false === $result ) {
            return new WP_Error(
                'db_insert_error',
                __( 'Could not save submission to database.', 'wp-contact-crm' ),
                array( 'db_error' => $wpdb->last_error )
            );
        }

        return (int) $wpdb->insert_id;
    }

    /**
     * Retrieve submissions with optional filters.
     *
     * @param  array $filters  Optional keys: status (string), search (string),
     *                         limit (int), offset (int), orderby (string), order (string).
     * @return array[]         Array of associative row arrays.
     */
    public function get_all( array $filters = array() ): array {
        global $wpdb;

        $where  = '1=1';
        $values = array();

        if ( ! empty( $filters['status'] ) ) {
            $where   .= ' AND status = %s';
            $values[] = sanitize_text_field( $filters['status'] );
        }

        if ( ! empty( $filters['search'] ) ) {
            $like     = '%' . $wpdb->esc_like( sanitize_text_field( $filters['search'] ) ) . '%';
            $where   .= ' AND (name LIKE %s OR email LIKE %s OR subject LIKE %s OR message LIKE %s)';
            $values[] = $like;
            $values[] = $like;
            $values[] = $like;
            $values[] = $like;
        }

        // Whitelist orderby to prevent SQL injection.
        $allowed_orderby = array( 'submitted_at', 'name', 'email', 'status', 'id' );
        $orderby = in_array( $filters['orderby'] ?? '', $allowed_orderby, true )
            ? $filters['orderby']
            : 'submitted_at';

        $order  = strtoupper( $filters['order'] ?? 'DESC' ) === 'ASC' ? 'ASC' : 'DESC';
        $limit  = absint( $filters['limit']  ?? 50 );
        $offset = absint( $filters['offset'] ?? 0 );

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $sql = "SELECT * FROM {$this->table} WHERE {$where}
                ORDER BY {$orderby} {$order}
                LIMIT %d OFFSET %d";

        $values[] = $limit;
        $values[] = $offset;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
        return $wpdb->get_results(
            $wpdb->prepare( $sql, ...$values ),
            ARRAY_A
        ) ?: array();
    }

    /**
     * Get a single submission by ID.
     *
     * @param  int        $id  Submission row ID.
     * @return array|null      Row as associative array, or null if not found.
     */
    public function get_by_id( int $id ): array|null {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d LIMIT 1", $id ),
            ARRAY_A
        );

        return $row ?: null;
    }

    /**
     * Update the status column of a submission.
     *
     * Allowed statuses: new, read, replied, closed, spam.
     * Sets replied_at timestamp automatically when status = 'replied'.
     *
     * @param  int    $id      Submission ID.
     * @param  string $status  New status string.
     * @return bool            True on success, false on failure or invalid status.
     */
    public function update_status( int $id, string $status ): bool {
        global $wpdb;

        $allowed = array( 'new', 'read', 'replied', 'closed', 'spam' );
        if ( ! in_array( $status, $allowed, true ) ) {
            return false;
        }

        $data   = array( 'status' => $status );
        $format = array( '%s' );

        // Automatically stamp replied_at when status is set to 'replied'.
        if ( 'replied' === $status ) {
            $data['replied_at'] = current_time( 'mysql' );
            $format[]           = '%s';
        }

        $result = $wpdb->update(
            $this->table,
            $data,
            array( 'id' => $id ),
            $format,
            array( '%d' )
        );

        return false !== $result;
    }

    /**
     * Delete a submission permanently.
     *
     * @param  int  $id  Submission ID.
     * @return bool      True on success.
     */
    public function delete( int $id ): bool {
        global $wpdb;

        return false !== $wpdb->delete(
            $this->table,
            array( 'id' => $id ),
            array( '%d' )
        );
    }

    /**
     * Count submissions by status.
     *
     * @param  string $status  Status string, or empty string for total.
     * @return int
     */
    public function count_by_status( string $status = '' ): int {
        global $wpdb;

        if ( ! $status ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            return (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$this->table}"
            );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table} WHERE status = %s",
                $status
            )
        );
    }

    /**
     * Get submission counts grouped by status — one DB query for the stat cards.
     *
     * @return array  Keys: new, read, replied, closed, spam, total.
     */
    public function get_status_counts(): array {
        global $wpdb;

        $defaults = array(
            'new'     => 0,
            'read'    => 0,
            'replied' => 0,
            'closed'  => 0,
            'spam'    => 0,
            'total'   => 0,
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $rows = $wpdb->get_results(
            "SELECT status, COUNT(*) AS cnt FROM {$this->table} GROUP BY status",
            ARRAY_A
        );

        $counts = $defaults;
        foreach ( (array) $rows as $row ) {
            $s = $row['status'] ?? '';
            if ( isset( $counts[ $s ] ) ) {
                $counts[ $s ] = (int) $row['cnt'];
            }
            $counts['total'] += (int) $row['cnt'];
        }

        return $counts;
    }

    /**
     * Get daily submission counts for the volume chart (last N days).
     *
     * @param  int   $days  Number of days to look back (default 30).
     * @return array        Associative array: 'labels' => [], 'volumes' => [].
     */
    public function get_volume_by_day( int $days = 30 ): array {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(submitted_at) AS day, COUNT(*) AS cnt
                 FROM {$this->table}
                 WHERE submitted_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
                 GROUP BY DATE(submitted_at)
                 ORDER BY day ASC",
                $days
            ),
            ARRAY_A
        );

        $map = array();
        foreach ( (array) $rows as $row ) {
            $map[ $row['day'] ] = (int) $row['cnt'];
        }

        $labels  = array();
        $volumes = array();
        for ( $i = $days - 1; $i >= 0; $i-- ) {
            $date      = gmdate( 'Y-m-d', strtotime( "-{$i} days" ) );
            $labels[]  = gmdate( 'M j', strtotime( $date ) );
            $volumes[] = $map[ $date ] ?? 0;
        }

        return compact( 'labels', 'volumes' );
    }

    /**
     * Export all submissions as an array for CSV download.
     *
     * Strips ip_address for privacy before export.
     *
     * @param  string $status  Optional status filter.
     * @return array[]
     */
    public function export( string $status = '' ): array {
        $rows = $this->get_all( array_filter( array(
            'status' => $status,
            'limit'  => 5000,
        ) ) );

        return array_map( function ( array $row ) {
            unset( $row['ip_address'] );
            return $row;
        }, $rows );
    }
}