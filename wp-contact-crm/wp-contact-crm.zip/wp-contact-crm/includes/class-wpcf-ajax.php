<?php
/**
 * AJAX Handlers
 *
 * FILE: wp-contact-crm/includes/class-wpcf-ajax.php
 *
 * All wp_ajax_* hooks live here.
 * Admin actions: view, reply, delete, status-update, bulk, note, export.
 * Public action: form submission.
 *
 * @package WP_Contact_CRM
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPCF_Ajax {

    public function __construct() {
        // ── Public (logged-in + guests) ──────────────────────────
        add_action( 'wp_ajax_wpcf_submit',        array( $this, 'submit' ) );
        add_action( 'wp_ajax_nopriv_wpcf_submit', array( $this, 'submit' ) );

        // ── Admin only ────────────────────────────────────────────
        add_action( 'wp_ajax_wpcf_get_submission',    array( $this, 'get_submission' ) );
        add_action( 'wp_ajax_wpcf_delete_submission', array( $this, 'delete_submission' ) );
        add_action( 'wp_ajax_wpcf_send_reply',        array( $this, 'send_reply' ) );
        add_action( 'wp_ajax_wpcf_update_status',     array( $this, 'update_status' ) );
        add_action( 'wp_ajax_wpcf_bulk_action',       array( $this, 'bulk_action' ) );
        add_action( 'wp_ajax_wpcf_add_note',          array( $this, 'add_note' ) );
        add_action( 'wp_ajax_wpcf_export_csv',        array( $this, 'export_csv' ) );
        add_action( 'wp_ajax_wpcf_dismiss_instructions', array( $this, 'dismiss_instructions' ) );
    }

    /* ════════════════════════════════════════════════════════════
       PUBLIC: Front-end form submission
    ════════════════════════════════════════════════════════════ */

    public function submit(): void {
        check_ajax_referer( 'wpcf_submit_nonce', 'nonce' );

        // Honeypot — silently appear to succeed but discard.
        if ( ! empty( $_POST['wpcf_website'] ) ) {
            wp_send_json_success( array( 'message' => __( 'Message sent!', 'wp-contact-crm' ) ) );
        }

        // Rate limit.
        $limiter = new WPCF_Rate_Limiter();
        if ( ! $limiter->allow() ) {
            wp_send_json_error( array( 'message' => __( 'Too many submissions. Please wait and try again.', 'wp-contact-crm' ) ) );
        }

        $name    = sanitize_text_field( wp_unslash( $_POST['name']    ?? '' ) );
        $email   = sanitize_email(      wp_unslash( $_POST['email']   ?? '' ) );
        $phone   = sanitize_text_field( wp_unslash( $_POST['phone']   ?? '' ) );
        $subject = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );
        $message = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );

        if ( ! $name || ! $email || ! $message ) {
            wp_send_json_error( array( 'message' => __( 'Name, email, and message are required.', 'wp-contact-crm' ) ) );
        }
        if ( ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'wp-contact-crm' ) ) );
        }

        $db = new WPCF_Submissions_DB();
        $id = $db->insert( array(
            'name'       => $name,
            'email'      => $email,
            'phone'      => $phone,
            'subject'    => $subject,
            'message'    => $message,
            'source_url' => wp_get_referer() ?: get_site_url(),
            'ip_address' => $this->get_client_ip(),
        ) );

        if ( is_wp_error( $id ) ) {
            wp_send_json_error( array( 'message' => $id->get_error_message() ) );
        }

        $count = (int) get_option( 'wpcf_total_submissions', 0 );
        update_option( 'wpcf_total_submissions', $count + 1, false );

        $mailer = new WPCF_Email();
        $mailer->send_auto_reply( $name, $email );
        $mailer->send_admin_notification( $id, $name, $email, $subject, $message );

        $limiter->record();

        wp_send_json_success( array( 'message' => __( "Message sent! We'll be in touch soon.", 'wp-contact-crm' ) ) );
    }

    /* ════════════════════════════════════════════════════════════
       ADMIN: VIEW — load full submission for the detail panel
       Called by: View button (👁) → openDetailPanel() in wpcf-admin.js
    ════════════════════════════════════════════════════════════ */

    public function get_submission(): void {
        check_ajax_referer( 'wpcf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_crm' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-contact-crm' ) ) );
        }

        $id  = absint( $_POST['id'] ?? 0 );
        $db  = new WPCF_Submissions_DB();
        $row = $db->get_by_id( $id );

        if ( ! $row ) {
            wp_send_json_error( array( 'message' => __( 'Submission not found.', 'wp-contact-crm' ) ) );
        }

        // Auto-mark as read when viewed.
        if ( 'new' === $row['status'] ) {
            $db->update_status( $id, 'read' );
            $row['status'] = 'read';
        }

        // Strip IP — not shown in the panel.
        unset( $row['ip_address'] );

        // Attach notes stored in wp_options.
        $row['notes'] = get_option( 'wpcf_notes_' . $id, array() );

        wp_send_json_success( $row );
    }

    /* ════════════════════════════════════════════════════════════
       ADMIN: DELETE — permanently remove a submission
       Called by: Delete button (🗑) → deleteSubmission() in wpcf-admin.js
    ════════════════════════════════════════════════════════════ */

    public function delete_submission(): void {
        check_ajax_referer( 'wpcf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_crm' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-contact-crm' ) ) );
        }

        $id = absint( $_POST['id'] ?? 0 );
        if ( ! $id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid submission ID.', 'wp-contact-crm' ) ) );
        }

        $db = new WPCF_Submissions_DB();
        if ( ! $db->delete( $id ) ) {
            wp_send_json_error( array( 'message' => __( 'Submission not found or already deleted.', 'wp-contact-crm' ) ) );
        }

        // Also clean up notes for this submission.
        delete_option( 'wpcf_notes_' . $id );

        wp_send_json_success( array( 'message' => __( 'Submission deleted.', 'wp-contact-crm' ) ) );
    }

    /* ════════════════════════════════════════════════════════════
       ADMIN: REPLY — send a reply email to the submitter
       Called by: Reply button (✉) → sendReply() in wpcf-admin.js
    ════════════════════════════════════════════════════════════ */

    public function send_reply(): void {
        check_ajax_referer( 'wpcf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_crm' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-contact-crm' ) ) );
        }

        $id      = absint( $_POST['id']            ?? 0 );
        $subject = sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) );
        $body    = sanitize_textarea_field( wp_unslash( $_POST['body'] ?? '' ) );

        if ( ! $id || ! $subject || ! $body ) {
            wp_send_json_error( array( 'message' => __( 'ID, subject, and body are all required.', 'wp-contact-crm' ) ) );
        }

        $db  = new WPCF_Submissions_DB();
        $row = $db->get_by_id( $id );
        if ( ! $row ) {
            wp_send_json_error( array( 'message' => __( 'Submission not found.', 'wp-contact-crm' ) ) );
        }

        $mailer = new WPCF_Email();
        $sent   = $mailer->send_manual_reply( $row['email'], $row['name'], $subject, $body );

        if ( ! $sent ) {
            wp_send_json_error( array( 'message' => __( 'Email could not be sent. Check your mail configuration.', 'wp-contact-crm' ) ) );
        }

        // Update status → replied.
        $db->update_status( $id, 'replied' );

        // Log the reply in notes.
        $notes   = get_option( 'wpcf_notes_' . $id, array() );
        $notes[] = array(
            'type'    => 'reply',
            'author'  => wp_get_current_user()->display_name,
            'date'    => current_time( 'mysql' ),
            'content' => 'Reply sent. Subject: ' . $subject,
        );
        update_option( 'wpcf_notes_' . $id, $notes, false );

        wp_send_json_success( array( 'message' => __( 'Reply sent!', 'wp-contact-crm' ) ) );
    }

    /* ════════════════════════════════════════════════════════════
       ADMIN: STATUS UPDATE — inline dropdown in table or detail panel
    ════════════════════════════════════════════════════════════ */

    public function update_status(): void {
        check_ajax_referer( 'wpcf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_crm' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-contact-crm' ) ) );
        }

        $id     = absint( $_POST['id']     ?? 0 );
        $status = sanitize_text_field( wp_unslash( $_POST['status'] ?? '' ) );
        $db     = new WPCF_Submissions_DB();

        if ( ! $id || ! $db->update_status( $id, $status ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid submission or status value.', 'wp-contact-crm' ) ) );
        }

        wp_send_json_success( array( 'status' => $status ) );
    }

    /* ════════════════════════════════════════════════════════════
       ADMIN: BULK ACTION
    ════════════════════════════════════════════════════════════ */

    public function bulk_action(): void {
        check_ajax_referer( 'wpcf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_crm' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-contact-crm' ) ) );
        }

        $action  = sanitize_text_field( wp_unslash( $_POST['bulk_action'] ?? '' ) );
        $ids     = array_filter( array_map( 'absint', (array) ( $_POST['ids'] ?? array() ) ) );
        $allowed = array( 'new', 'read', 'replied', 'closed', 'spam', 'delete' );

        if ( ! $ids )                                     wp_send_json_error( array( 'message' => __( 'No items selected.',  'wp-contact-crm' ) ) );
        if ( ! in_array( $action, $allowed, true ) )      wp_send_json_error( array( 'message' => __( 'Invalid action.',     'wp-contact-crm' ) ) );

        $db        = new WPCF_Submissions_DB();
        $processed = 0;

        foreach ( $ids as $id ) {
            if ( 'delete' === $action ) {
                if ( $db->delete( $id ) ) {
                    delete_option( 'wpcf_notes_' . $id );
                    $processed++;
                }
            } else {
                if ( $db->update_status( $id, $action ) ) $processed++;
            }
        }

        wp_send_json_success( array(
            'message'   => sprintf( __( '%d item(s) updated.', 'wp-contact-crm' ), $processed ),
            'processed' => $processed,
        ) );
    }

    /* ════════════════════════════════════════════════════════════
       ADMIN: ADD NOTE
    ════════════════════════════════════════════════════════════ */

    public function add_note(): void {
        check_ajax_referer( 'wpcf_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_crm' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-contact-crm' ) ) );
        }

        $id   = absint( $_POST['id'] ?? 0 );
        $note = sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) );

        if ( ! $id || ! $note ) {
            wp_send_json_error( array( 'message' => __( 'Invalid request.', 'wp-contact-crm' ) ) );
        }

        $notes   = get_option( 'wpcf_notes_' . $id, array() );
        $notes[] = array(
            'type'    => 'note',
            'author'  => wp_get_current_user()->display_name,
            'date'    => current_time( 'mysql' ),
            'content' => $note,
        );
        update_option( 'wpcf_notes_' . $id, $notes, false );

        wp_send_json_success( array( 'message' => __( 'Note saved.', 'wp-contact-crm' ) ) );
    }

    /* ════════════════════════════════════════════════════════════
       ADMIN: EXPORT CSV
    ════════════════════════════════════════════════════════════ */

    public function export_csv(): void {
        if ( ! current_user_can( 'manage_crm' ) ) wp_die( 403 );
        check_ajax_referer( 'wpcf_admin_nonce', 'nonce' );

        $status = sanitize_text_field( $_GET['status'] ?? '' );
        $db     = new WPCF_Submissions_DB();
        $rows   = $db->export( $status );

        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="wpcf-' . gmdate( 'Y-m-d' ) . '.csv"' );
        header( 'Pragma: no-cache' );

        $out = fopen( 'php://output', 'w' );
        if ( ! empty( $rows ) ) fputcsv( $out, array_keys( $rows[0] ) );
        foreach ( $rows as $row ) fputcsv( $out, $row );
        fclose( $out );
        exit;
    }

    /* ════════════════════════════════════════════════════════════
       ADMIN: DISMISS INSTRUCTIONS PANEL
    ════════════════════════════════════════════════════════════ */

    public function dismiss_instructions(): void {
        check_ajax_referer( 'wpcf_admin_nonce', 'nonce' );
        update_user_meta( get_current_user_id(), 'wpcf_hide_instructions', '1' );
        wp_send_json_success();
    }

    /* ── Utility ─────────────────────────────────────────────── */

    private function get_client_ip(): string {
        foreach ( array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $key ) {
            if ( empty( $_SERVER[ $key ] ) ) continue;
            $ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) )[0] );
            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
        }
        return '0.0.0.0';
    }
}