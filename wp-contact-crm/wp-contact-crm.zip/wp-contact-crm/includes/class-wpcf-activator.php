<?php
/**
 * Activation / Deactivation Handler
 *
 * FILE: wp-contact-crm/includes/class-wpcf-activator.php
 *
 * LOAD ORDER (CRITICAL — this is why this file exists separately):
 *   This file is require_once'd at the ROOT LEVEL of wp-contact-crm.php,
 *   BEFORE register_activation_hook() is called.
 *
 *   All other plugin classes are loaded inside add_action('plugins_loaded').
 *   plugins_loaded does NOT fire during the activation request, so if this
 *   class were inside that callback, WordPress would throw:
 *     Fatal error: Class "WPCF_Activator" not found
 *
 *   By loading this file at the root level, it is available on every
 *   WordPress request — including the activation request — at zero meaningful
 *   performance cost (the class has no constructor side-effects).
 *
 * @package WP_Contact_CRM
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPCF_Activator {

    // ─────────────────────────────────────────────────────────────────────────
    // Activation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Run on plugin activation (register_activation_hook).
     *
     * WordPress wraps this in a try/catch. If we wp_die() or throw here,
     * WordPress deactivates the plugin and shows the error to the admin —
     * which is the correct fail-fast behaviour for activation problems.
     *
     * @return void
     */
    public static function activate(): void {
        // 1. Check minimum requirements.
        self::check_requirements();

        // 2. Create / upgrade the custom submissions table.
        self::create_table();

        // 3. Grant the manage_crm capability to the Administrator role.
        //    add_cap() is idempotent: safe to call on every re-activation.
        self::add_capabilities();

        // 4. Store plugin version for upgrade routines.
        //    update_option autoload=false: this value is only needed in
        //    the admin context for upgrade checks, not on every page load.
        update_option( 'wpcf_version', WPCF_VERSION, false );

        // 5. Set default options (only if not already set).
        self::set_defaults();

        // 6. Flush rewrite rules.
        //    The plugin does not register a CPT, but this is good practice
        //    and costs nothing — rules are rebuilt on the NEXT request, not now.
        flush_rewrite_rules();

        // 7. Activation redirect flag.
        //    WPCF_Admin checks for this transient on admin_init and redirects
        //    the admin to the Settings page on first activation.
        set_transient( 'wpcf_activation_redirect', true, 30 );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Deactivation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Run on plugin deactivation (register_deactivation_hook).
     *
     * Lighter than uninstall — we keep all data but remove scheduled events
     * and flush rewrite rules. The admin may simply be deactivating temporarily.
     *
     * @return void
     */
    public static function deactivate(): void {
        // Flush rewrite rules so any plugin-registered rules are removed.
        flush_rewrite_rules();

        // Remove any scheduled cron events (none registered in this plugin yet,
        // but included as a pattern for future use).
        // wp_clear_scheduled_hook( 'wpcf_daily_cleanup' );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Minimum requirements check.
     * wp_die() with a helpful message rather than letting a cryptic PHP error appear.
     */
    private static function check_requirements(): void {
        // PHP version (union types in DB + REST classes require 8.0).
        if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
            wp_die(
                esc_html(
                    sprintf(
                        /* translators: %s PHP version */
                        __( 'WP Contact CRM requires PHP 8.0 or higher. Your server runs PHP %s. Please upgrade PHP or contact your host.', 'wp-contact-crm' ),
                        PHP_VERSION
                    )
                ),
                esc_html__( 'PHP Version Error', 'wp-contact-crm' ),
                array( 'back_link' => true )
            );
        }

        // WordPress version.
        global $wp_version;
        if ( version_compare( $wp_version, '6.0', '<' ) ) {
            wp_die(
                esc_html(
                    sprintf(
                        /* translators: %s WordPress version */
                        __( 'WP Contact CRM requires WordPress 6.0 or higher. You are running %s.', 'wp-contact-crm' ),
                        $wp_version
                    )
                ),
                esc_html__( 'WordPress Version Error', 'wp-contact-crm' ),
                array( 'back_link' => true )
            );
        }
    }

    /**
     * Create (or upgrade) the wpcf_submissions database table.
     *
     * dbDelta() is the correct WordPress way to create/modify tables.
     * It compares the $sql schema against the existing table and applies
     * only the necessary changes — safe to call on every activation.
     *
     * IMPORTANT DBDELTA FORMATTING RULES (these cause silent failures if wrong):
     *   1. Two spaces between the column name and its definition.
     *   2. PRIMARY KEY must be on its own line.
     *   3. Each KEY definition must include the word KEY.
     *   4. Only one SQL statement per dbDelta() call (no semicolons mid-string).
     *   5. The closing parenthesis and charset must be on the same line.
     */
    private static function create_table(): void {
        global $wpdb;

        $table           = $wpdb->prefix . 'wpcf_submissions';
        $charset_collate = $wpdb->get_charset_collate();

        // Note the two spaces after each column name — required by dbDelta.
        $sql = "CREATE TABLE {$table} (
  id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  name         VARCHAR(200) NOT NULL DEFAULT '',
  email        VARCHAR(200) NOT NULL DEFAULT '',
  phone        VARCHAR(50)  NOT NULL DEFAULT '',
  subject      VARCHAR(500) NOT NULL DEFAULT '',
  message      TEXT NOT NULL,
  source_url   VARCHAR(500) NOT NULL DEFAULT '',
  ip_address   VARCHAR(45)  NOT NULL DEFAULT '',
  status       VARCHAR(20)  NOT NULL DEFAULT 'new',
  assigned_to  BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  replied_at   DATETIME DEFAULT NULL,
  PRIMARY KEY  (id),
  KEY email (email(100)),
  KEY status (status),
  KEY submitted_at (submitted_at)
) {$charset_collate};";

        // upgrade.php is only available in admin context, never on the frontend.
        // Activation hooks always run in admin context — this require is safe here.
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Add the manage_crm capability to the Administrator role.
     *
     * This capability gates:
     *   - Access to the CRM dashboard menu page.
     *   - All AJAX status-update and delete actions.
     *   - The REST API submissions endpoint.
     *
     * The capability is stored in the wp_user_roles option row for 'administrator'.
     * It persists across requests and is removed in uninstall.php.
     */
    private static function add_capabilities(): void {
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin->add_cap( 'manage_crm' );
        }
    }

    /**
     * Set default plugin options using add_option().
     *
     * add_option() does NOTHING if the option already exists — it will never
     * overwrite settings the admin has already configured.
     * This is safer than update_option() on activation.
     */
    private static function set_defaults(): void {
        add_option(
            'wpcf_options',
            array(
                'recipient_email'    => get_option( 'admin_email', '' ),
                'auto_reply_message' => __( 'Thank you for contacting us. We will reply within 1-2 business days.', 'wp-contact-crm' ),
                'rate_limit'         => 3,
            ),
            '',  // deprecated $deprecated parameter — pass empty string.
            false // autoload = false: settings only needed in admin, not every page.
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Version upgrade routine
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Run upgrade routines when the plugin is updated.
     * Called from add_action('plugins_loaded') in the main file.
     *
     * Pattern: compare stored version to WPCF_VERSION constant.
     * Add version-specific migration blocks as the plugin grows.
     *
     * @return void
     */
    public static function maybe_upgrade(): void {
        $installed = get_option( 'wpcf_version', '0.0.0' );

        if ( version_compare( $installed, WPCF_VERSION, '>=' ) ) {
            return; // Already up-to-date — early exit (the common path).
        }

        // ── Future migration example ─────────────────────────────────────────
        // if ( version_compare( $installed, '1.1.0', '<' ) ) {
        //     self::upgrade_to_1_1_0(); // e.g. add a new column via dbDelta
        // }
        // ────────────────────────────────────────────────────────────────────

        // Always re-apply capabilities after an upgrade — in case a new role
        // needs access or the option was somehow cleared.
        self::add_capabilities();

        update_option( 'wpcf_version', WPCF_VERSION, false );
    }
}