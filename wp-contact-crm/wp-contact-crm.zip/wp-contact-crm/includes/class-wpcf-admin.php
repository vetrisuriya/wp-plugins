<?php
/**
 * Admin CRM Dashboard
 *
 * FILE: wp-contact-crm/includes/class-wpcf-admin.php
 *
 * Responsibilities:
 *  - Register admin menu page under "Contact CRM"
 *  - Enqueue admin CSS + JS + Chart.js + wp_localize_script data
 *  - Render the submissions table (render_dashboard)
 *  - Render the detail side-panel overlay HTML
 *  - Render the reply modal HTML
 *  - Handle first-activation redirect
 *
 * Instantiated ONCE in wp-contact-crm.php:
 *   $admin = new WPCF_Admin();
 *   new WPCF_Settings( $admin );   ← settings receives the instance
 *
 * @package WP_Contact_CRM
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPCF_Admin {

    public function __construct() {
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin' ) );
        add_action( 'admin_init',            array( $this, 'maybe_redirect' ) );
        add_action( 'current_screen',        array( $this, 'add_help_tabs' ) );
    }

    /* ════════════════════════════════════════════════════════════
       ENQUEUE — CSS, JS, Chart.js, localised data
    ════════════════════════════════════════════════════════════ */

    public function enqueue_admin( string $hook ): void {
        if ( false === strpos( $hook, 'wpcf-crm' ) ) {
            return;
        }

        wp_enqueue_script(
            'chartjs',
            'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js',
            array(), '4.4.1', true
        );

        wp_enqueue_style(
            'wpcf-admin',
            WPCF_URL . 'admin/css/wpcf-admin.css',
            array(), WPCF_VERSION
        );

        wp_enqueue_script(
            'wpcf-admin',
            WPCF_URL . 'admin/js/wpcf-admin.js',
            array( 'jquery', 'chartjs' ),
            WPCF_VERSION,
            true
        );

        $db     = new WPCF_Submissions_DB();
        $counts = $db->get_status_counts();
        $volume = $db->get_volume_by_day( 30 );

        wp_localize_script( 'wpcf-admin', 'WPCFAdmin', array(
            'ajax_url'   => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'wpcf_admin_nonce' ),
            'statuses'   => array(
                'new'     => __( 'New',     'wp-contact-crm' ),
                'read'    => __( 'Read',    'wp-contact-crm' ),
                'replied' => __( 'Replied', 'wp-contact-crm' ),
                'closed'  => __( 'Closed',  'wp-contact-crm' ),
                'spam'    => __( 'Spam',    'wp-contact-crm' ),
            ),
            'chart_data' => array_merge( $counts, $volume ),
            'strings'    => array(
                'confirm_delete' => __( 'Delete this submission permanently? This cannot be undone.', 'wp-contact-crm' ),
                'confirm_bulk'   => __( 'Apply this action to all selected items?',                  'wp-contact-crm' ),
                'deleting'       => __( 'Deleting…',    'wp-contact-crm' ),
                'sending'        => __( 'Sending…',     'wp-contact-crm' ),
                'loading'        => __( 'Loading…',     'wp-contact-crm' ),
                'saved'          => __( 'Saved',        'wp-contact-crm' ),
                'deleted'        => __( 'Deleted',      'wp-contact-crm' ),
                'reply_sent'     => __( 'Reply sent!',  'wp-contact-crm' ),
                'no_items'       => __( 'No items selected.', 'wp-contact-crm' ),
                'error'          => __( 'Something went wrong. Please try again.', 'wp-contact-crm' ),
                'send_reply'     => __( 'Send Reply',   'wp-contact-crm' ),
                'save_note'      => __( 'Save Note',    'wp-contact-crm' ),
            ),
        ) );
    }

    /* ════════════════════════════════════════════════════════════
       ACTIVATION REDIRECT
    ════════════════════════════════════════════════════════════ */

    public function maybe_redirect(): void {
        if ( ! get_transient( 'wpcf_activation_redirect' ) ) return;
        delete_transient( 'wpcf_activation_redirect' );
        if ( isset( $_GET['activate-multi'] ) ) return;
        wp_safe_redirect( admin_url( 'admin.php?page=wpcf-crm&welcome=1' ) );
        exit;
    }

    /* ════════════════════════════════════════════════════════════
       HELP TABS
    ════════════════════════════════════════════════════════════ */

    public function add_help_tabs(): void {
        $screen = get_current_screen();
        if ( ! $screen || false === strpos( $screen->id, 'wpcf-crm' ) ) return;

        $screen->add_help_tab( array(
            'id'      => 'wpcf-help-start',
            'title'   => __( 'Getting Started', 'wp-contact-crm' ),
            'content' =>
                '<h2>' . __( 'Getting Started', 'wp-contact-crm' ) . '</h2>' .
                '<p>' . __( 'Add <code>[contact_form]</code> to any page. Submissions appear here instantly.', 'wp-contact-crm' ) . '</p>' .
                '<ul>' .
                    '<li>' . __( 'Add phone field: <code>[contact_form show_phone="true"]</code>', 'wp-contact-crm' ) . '</li>' .
                    '<li>' . __( 'Custom title: <code>[contact_form title="Get In Touch"]</code>', 'wp-contact-crm' ) . '</li>' .
                '</ul>',
        ) );

        $screen->add_help_tab( array(
            'id'      => 'wpcf-help-crm',
            'title'   => __( 'Row Actions', 'wp-contact-crm' ),
            'content' =>
                '<h2>' . __( 'Row Actions', 'wp-contact-crm' ) . '</h2>' .
                '<ul>' .
                    '<li><strong>👁 View</strong> — ' . __( 'Opens the full message in the side panel. Auto-marks as Read.', 'wp-contact-crm' ) . '</li>' .
                    '<li><strong>✉ Reply</strong> — ' . __( 'Opens a modal to compose and send an email reply. Auto-marks as Replied.', 'wp-contact-crm' ) . '</li>' .
                    '<li><strong>🗑 Delete</strong> — ' . __( 'Permanently removes the submission after confirmation.', 'wp-contact-crm' ) . '</li>' .
                '</ul>',
        ) );

        $screen->set_help_sidebar(
            '<p><strong>' . __( 'Links', 'wp-contact-crm' ) . '</strong></p>' .
            '<p><a href="' . esc_url( admin_url( 'admin.php?page=wpcf-settings' ) ) . '">' . __( '⚙ Settings', 'wp-contact-crm' ) . '</a></p>'
        );
    }

    /* ════════════════════════════════════════════════════════════
       RENDER DASHBOARD — main CRM page
    ════════════════════════════════════════════════════════════ */

    public function render_dashboard(): void {
        if ( ! current_user_can( 'manage_crm' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'wp-contact-crm' ) );
        }

        $db            = new WPCF_Submissions_DB();
        $status_filter = sanitize_text_field( $_GET['status'] ?? '' );
        $search        = sanitize_text_field( $_GET['s']      ?? '' );
        $paged         = max( 1, absint( $_GET['paged'] ?? 1 ) );
        $per_page      = 25;

        $submissions = $db->get_all( array_filter( array(
            'status'  => $status_filter,
            'search'  => $search,
            'limit'   => $per_page,
            'offset'  => ( $paged - 1 ) * $per_page,
        ) ) );

        $counts       = $db->get_status_counts();
        $all_statuses = array( 'new', 'read', 'replied', 'closed', 'spam' );
        $hide_panel   = get_user_meta( get_current_user_id(), 'wpcf_hide_instructions', true );
        ?>
        <div class="wrap wpcf-crm-wrap">

            <?php /* ── Quick-start panel (dismissible per user) ── */ ?>
            <?php if ( ! $hide_panel ) : ?>
            <div class="wpcf-instructions-panel" id="wpcm-instructions" role="note">
                <div class="wpcf-instructions-panel__inner">
                    <span class="wpcf-instructions-panel__icon" aria-hidden="true">💡</span>
                    <div class="wpcf-instructions-panel__content">
                        <strong><?php esc_html_e( 'Quick Start:', 'wp-contact-crm' ); ?></strong>
                        <?php esc_html_e( 'Add', 'wp-contact-crm' ); ?>
                        <code>[contact_form]</code>
                        <?php esc_html_e( 'to any page. Click', 'wp-contact-crm' ); ?>
                        👁 <?php esc_html_e( 'to view a message,', 'wp-contact-crm' ); ?>
                        ✉ <?php esc_html_e( 'to reply,', 'wp-contact-crm' ); ?>
                        🗑 <?php esc_html_e( 'to delete.', 'wp-contact-crm' ); ?>
                        &nbsp;
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpcf-settings' ) ); ?>">
                            <?php esc_html_e( 'Configure settings →', 'wp-contact-crm' ); ?>
                        </a>
                    </div>
                    <button type="button"
                            id="wpcf-dismiss-instructions"
                            class="wpcf-instructions-panel__close"
                            aria-label="<?php esc_attr_e( 'Dismiss', 'wp-contact-crm' ); ?>">×</button>
                </div>
            </div>
            <?php endif; ?>

            <!-- Page header -->
            <div class="wpcf-page-header">
                <div class="wpcf-page-header__left">
                    <div class="wpcf-page-header__icon">📬</div>
                    <h1>
                        <?php esc_html_e( 'Contact CRM', 'wp-contact-crm' ); ?>
                        <?php if ( $counts['new'] > 0 ) : ?>
                            <span class="wpcf-leads-count"><?php echo absint( $counts['new'] ); ?></span>
                        <?php endif; ?>
                    </h1>
                </div>
                <div class="wpcf-page-header__actions">
                    <a id="wpcf-export-btn"
                       href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=wpcf_export_csv&nonce=' . wp_create_nonce( 'wpcf_admin_nonce' ) ) ); ?>"
                       class="wpcf-toolbar-btn wpcf-toolbar-btn--export">
                        ⬇ <?php esc_html_e( 'Export CSV', 'wp-contact-crm' ); ?>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpcf-settings' ) ); ?>"
                       class="wpcf-toolbar-btn">
                        ⚙ <?php esc_html_e( 'Settings', 'wp-contact-crm' ); ?>
                    </a>
                </div>
            </div>

            <!-- Stat cards -->
            <div class="wpcf-stats-row">
                <?php
                $cards = array(
                    array( 'status' => 'total',   'label' => __( 'Total',   'wp-contact-crm' ), 'class' => 'total'   ),
                    array( 'status' => 'new',      'label' => __( 'New',     'wp-contact-crm' ), 'class' => 'new'     ),
                    array( 'status' => 'read',     'label' => __( 'Read',    'wp-contact-crm' ), 'class' => 'read'    ),
                    array( 'status' => 'replied',  'label' => __( 'Replied', 'wp-contact-crm' ), 'class' => 'replied' ),
                    array( 'status' => 'closed',   'label' => __( 'Closed',  'wp-contact-crm' ), 'class' => 'closed'  ),
                );
                foreach ( $cards as $card ) : ?>
                <div class="wpcf-stat-card wpcf-stat-card--<?php echo esc_attr( $card['class'] ); ?>"
                     data-status="<?php echo esc_attr( $card['status'] ); ?>"
                     role="button" tabindex="0">
                    <div class="wpcf-stat-card__num"><?php echo absint( $counts[ $card['status'] ] ?? 0 ); ?></div>
                    <div class="wpcf-stat-card__label"><?php echo esc_html( $card['label'] ); ?></div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Toolbar -->
            <div class="wpcf-toolbar">
                <form method="get" action="" style="display:contents">
                    <input type="hidden" name="page" value="wpcf-crm">
                    <div class="wpcf-search-wrap">
                        <input type="search"
                               name="s"
                               class="wpcf-search-input"
                               value="<?php echo esc_attr( $search ); ?>"
                               placeholder="<?php esc_attr_e( 'Search name, email, subject…', 'wp-contact-crm' ); ?>"
                               aria-label="<?php esc_attr_e( 'Search submissions', 'wp-contact-crm' ); ?>">
                        <button type="submit" class="wpcf-search-btn" aria-label="<?php esc_attr_e( 'Search', 'wp-contact-crm' ); ?>">🔍</button>
                    </div>
                </form>

                <select id="wpcf-bulk-action" class="wpcf-bulk-select">
                    <option value=""><?php esc_html_e( '— Bulk Action —', 'wp-contact-crm' ); ?></option>
                    <option value="read"><?php    esc_html_e( 'Mark as Read',    'wp-contact-crm' ); ?></option>
                    <option value="replied"><?php esc_html_e( 'Mark as Replied', 'wp-contact-crm' ); ?></option>
                    <option value="closed"><?php  esc_html_e( 'Mark as Closed',  'wp-contact-crm' ); ?></option>
                    <option value="spam"><?php    esc_html_e( 'Mark as Spam',    'wp-contact-crm' ); ?></option>
                    <option value="delete"><?php  esc_html_e( 'Delete',          'wp-contact-crm' ); ?></option>
                </select>
                <button type="button" id="wpcf-bulk-apply" class="wpcf-toolbar-btn">
                    <?php esc_html_e( 'Apply', 'wp-contact-crm' ); ?>
                </button>
                <span class="wpcf-item-count">
                    <?php printf( esc_html__( '%d submission(s)', 'wp-contact-crm' ), absint( $counts['total'] ) ); ?>
                </span>
            </div>

            <!-- Status tabs -->
            <div class="wpcf-status-tabs" role="tablist">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpcf-crm' ) ); ?>"
                   class="wpcf-status-tab <?php echo ! $status_filter ? 'current' : ''; ?>"
                   data-status="total">
                    <?php esc_html_e( 'All', 'wp-contact-crm' ); ?>
                    <span class="wpcf-tab-count"><?php echo absint( $counts['total'] ); ?></span>
                </a>
                <?php foreach ( $all_statuses as $s ) : ?>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpcf-crm&status=' . $s ) ); ?>"
                   class="wpcf-status-tab <?php echo $status_filter === $s ? 'current' : ''; ?>"
                   data-status="<?php echo esc_attr( $s ); ?>">
                    <?php echo esc_html( ucfirst( $s ) ); ?>
                    <span class="wpcf-tab-count"><?php echo absint( $counts[ $s ] ?? 0 ); ?></span>
                </a>
                <?php endforeach; ?>
            </div>

            <!-- Submissions table -->
            <div class="wpcf-table-wrap">
                <table class="wpcf-table">
                    <thead>
                        <tr>
                            <th class="col-cb">
                                <input type="checkbox" id="wpcf-select-all"
                                       aria-label="<?php esc_attr_e( 'Select all', 'wp-contact-crm' ); ?>">
                            </th>
                            <th class="col-id    is-sortable" data-col="id">     #</th>
                            <th class="col-name  is-sortable" data-col="name">   <?php esc_html_e( 'Name',    'wp-contact-crm' ); ?></th>
                            <th class="col-email">                                <?php esc_html_e( 'Email',   'wp-contact-crm' ); ?></th>
                            <th class="col-subject">                              <?php esc_html_e( 'Subject', 'wp-contact-crm' ); ?></th>
                            <th class="col-message">                              <?php esc_html_e( 'Message', 'wp-contact-crm' ); ?></th>
                            <th class="col-date  is-sortable" data-col="date">   <?php esc_html_e( 'Date',    'wp-contact-crm' ); ?></th>
                            <th class="col-status">                               <?php esc_html_e( 'Status',  'wp-contact-crm' ); ?></th>
                            <th class="col-actions">                              <?php esc_html_e( 'Actions', 'wp-contact-crm' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ( empty( $submissions ) ) : ?>
                        <tr>
                            <td colspan="9">
                                <div class="wpcf-empty">
                                    <div class="wpcf-empty__icon" aria-hidden="true">📭</div>
                                    <div class="wpcf-empty__title">
                                        <?php esc_html_e( 'No submissions found', 'wp-contact-crm' ); ?>
                                    </div>
                                    <div class="wpcf-empty__desc">
                                        <?php esc_html_e( 'Add [contact_form] to a page to start collecting messages.', 'wp-contact-crm' ); ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ( $submissions as $row ) : ?>
                        <tr data-id="<?php echo absint( $row['id'] ); ?>"
                            class="<?php echo 'new' === $row['status'] ? 'is-new' : ''; ?>">
                            <td class="col-cb">
                                <input type="checkbox" class="wpcf-row-check"
                                       aria-label="<?php esc_attr_e( 'Select row', 'wp-contact-crm' ); ?>">
                            </td>
                            <td class="col-id"><?php echo absint( $row['id'] ); ?></td>
                            <td class="col-name"><?php echo esc_html( $row['name'] ); ?></td>
                            <td class="col-email">
                                <a href="mailto:<?php echo esc_attr( $row['email'] ); ?>"
                                   class="wpcf-cell-email"><?php echo esc_html( $row['email'] ); ?></a>
                            </td>
                            <td class="col-subject">
                                <span class="wpcf-cell-subject"><?php echo esc_html( $row['subject'] ?: '—' ); ?></span>
                            </td>
                            <td class="col-message">
                                <span class="wpcf-cell-message"
                                      title="<?php echo esc_attr( $row['message'] ); ?>">
                                    <?php echo esc_html( mb_strlen( $row['message'] ) > 80
                                        ? mb_substr( $row['message'], 0, 80 ) . '…'
                                        : $row['message']
                                    ); ?>
                                </span>
                            </td>
                            <td class="col-date">
                                <?php echo esc_html( wp_date(
                                    get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
                                    strtotime( $row['submitted_at'] )
                                ) ); ?>
                            </td>
                            <td class="col-status">
                                <?php /* Inline status dropdown — wired by initStatusDropdowns() in JS */ ?>
                                <select class="wpcf-status-select"
                                        data-id="<?php echo absint( $row['id'] ); ?>"
                                        aria-label="<?php esc_attr_e( 'Change status', 'wp-contact-crm' ); ?>">
                                    <?php foreach ( $all_statuses as $s ) : ?>
                                    <option value="<?php echo esc_attr( $s ); ?>"
                                            <?php selected( $row['status'], $s ); ?>>
                                        <?php echo esc_html( ucfirst( $s ) ); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="col-actions">
                                <?php /* Three action buttons — wired by initRowActions() in wpcf-admin.js */ ?>
                                <div class="wpcf-row-actions" role="group"
                                     aria-label="<?php esc_attr_e( 'Actions', 'wp-contact-crm' ); ?>">

                                    <button type="button"
                                            class="wpcf-row-btn wpcf-row-btn--view"
                                            data-id="<?php echo absint( $row['id'] ); ?>"
                                            title="<?php esc_attr_e( 'View message', 'wp-contact-crm' ); ?>"
                                            aria-label="<?php esc_attr_e( 'View message', 'wp-contact-crm' ); ?>">👁</button>

                                    <button type="button"
                                            class="wpcf-row-btn wpcf-row-btn--reply"
                                            data-id="<?php echo absint( $row['id'] ); ?>"
                                            data-name="<?php echo esc_attr( $row['name'] ); ?>"
                                            data-email="<?php echo esc_attr( $row['email'] ); ?>"
                                            data-subject="<?php echo esc_attr( $row['subject'] ); ?>"
                                            title="<?php esc_attr_e( 'Reply', 'wp-contact-crm' ); ?>"
                                            aria-label="<?php esc_attr_e( 'Reply to this submission', 'wp-contact-crm' ); ?>">✉</button>

                                    <button type="button"
                                            class="wpcf-row-btn wpcf-row-btn--delete"
                                            data-id="<?php echo absint( $row['id'] ); ?>"
                                            title="<?php esc_attr_e( 'Delete', 'wp-contact-crm' ); ?>"
                                            aria-label="<?php esc_attr_e( 'Delete this submission', 'wp-contact-crm' ); ?>">🗑</button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>

                <div class="wpcf-pagination">
                    <span class="wpcf-pagination__info">
                        <?php printf(
                            esc_html__( 'Showing %d of %d submissions', 'wp-contact-crm' ),
                            count( $submissions ),
                            absint( $counts['total'] )
                        ); ?>
                    </span>
                </div>
            </div><!-- /.wpcf-table-wrap -->

            <?php /* ── DETAIL PANEL — populated by openDetailPanel() in JS ── */ ?>
            <div class="wpcf-detail-overlay"
                 id="wpcf-detail-overlay"
                 role="dialog"
                 aria-modal="true"
                 aria-label="<?php esc_attr_e( 'Submission detail', 'wp-contact-crm' ); ?>"
                 style="display:none">
                <div class="wpcf-detail-panel" id="wpcf-detail-panel">
                    <div class="wpcf-detail-head">
                        <h2><?php esc_html_e( 'Submission Detail', 'wp-contact-crm' ); ?></h2>
                        <button type="button"
                                id="wpcf-close-detail"
                                class="wpcf-detail-close"
                                aria-label="<?php esc_attr_e( 'Close panel', 'wp-contact-crm' ); ?>">×</button>
                    </div>
                    <div class="wpcf-detail-body" id="wpcf-detail-body">
                        <?php esc_html_e( 'Loading…', 'wp-contact-crm' ); ?>
                    </div>
                </div>
            </div>

            <?php /* ── REPLY MODAL — populated by openReplyModal() in JS ── */ ?>
            <div class="wpcf-modal-overlay"
                 id="wpcf-reply-modal"
                 role="dialog"
                 aria-modal="true"
                 aria-label="<?php esc_attr_e( 'Send Reply', 'wp-contact-crm' ); ?>"
                 style="display:none">
                <div class="wpcf-modal">
                    <div class="wpcf-modal__head">
                        <span><?php esc_html_e( 'Send Reply', 'wp-contact-crm' ); ?></span>
                        <button type="button"
                                class="wpcf-modal__close"
                                id="wpcf-close-modal"
                                aria-label="<?php esc_attr_e( 'Close', 'wp-contact-crm' ); ?>">×</button>
                    </div>
                    <div class="wpcf-modal__body">
                        <input type="hidden" id="wpcf-reply-id" value="">
                        <p class="wpcf-reply-to" id="wpcf-reply-to"></p>
                        <label for="wpcf-reply-subject" class="screen-reader-text">
                            <?php esc_html_e( 'Subject', 'wp-contact-crm' ); ?>
                        </label>
                        <input type="text"
                               id="wpcf-reply-subject"
                               class="wpcf-reply-subject"
                               placeholder="<?php esc_attr_e( 'Subject', 'wp-contact-crm' ); ?>">
                        <label for="wpcf-reply-body" class="screen-reader-text">
                            <?php esc_html_e( 'Message', 'wp-contact-crm' ); ?>
                        </label>
                        <textarea id="wpcf-reply-body"
                                  class="wpcf-reply-body"
                                  placeholder="<?php esc_attr_e( 'Write your reply…', 'wp-contact-crm' ); ?>"></textarea>
                        <p id="wpcf-reply-error" class="wpcf-notice wpcf-notice--error" style="display:none"></p>
                    </div>
                    <div class="wpcf-modal__foot">
                        <button type="button" id="wpcf-close-modal-2" class="button">
                            <?php esc_html_e( 'Cancel', 'wp-contact-crm' ); ?>
                        </button>
                        <button type="button" id="wpcf-send-reply-btn" class="button button-primary">
                            <?php esc_html_e( 'Send Reply', 'wp-contact-crm' ); ?>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Toast container -->
            <div id="wpcf-toasts" class="wpcf-toast-container" aria-live="polite"></div>

        </div><!-- /.wrap -->
        <?php
    }
}