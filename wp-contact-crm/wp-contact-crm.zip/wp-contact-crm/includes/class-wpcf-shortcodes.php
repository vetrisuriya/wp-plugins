<?php
/**
 * Shortcode: [contact_form]
 *
 * FILE: wp-contact-crm/includes/class-wpcf-shortcodes.php
 *
 * Renders the contact form HTML and conditionally enqueues
 * public CSS + JS only on pages that contain the shortcode.
 *
 * Usage:
 *   [contact_form]
 *   [contact_form title="Get In Touch" subtitle="We reply within 24 hours"]
 *   [contact_form show_phone="true" show_subject="false" class="wpcf-theme-minimal"]
 *
 * @package WP_Contact_CRM
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPCF_Shortcodes {

    public function __construct() {
        add_shortcode( 'contact_form', array( $this, 'render' ) );
        // Enqueue on the page — not globally.
        add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue' ) );
    }

    /**
     * Enqueue assets only when the shortcode is present in the current post.
     * Avoids loading CSS/JS on every page of the site.
     *
     * @return void
     */
    public function maybe_enqueue(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) ) return;
        if ( ! has_shortcode( $post->post_content, 'contact_form' ) ) return;

        wp_enqueue_style(
            'wpcf-public',
            WPCF_URL . 'public/css/wpcf-public.css',
            array(),
            WPCF_VERSION
        );

        wp_enqueue_script(
            'wpcf-public',
            WPCF_URL . 'public/js/wpcf-public.js',
            array(),          // vanilla JS — no jQuery dependency
            WPCF_VERSION,
            true
        );

        wp_localize_script( 'wpcf-public', 'WPCFData', array(
            'ajax_url'     => admin_url( 'admin-ajax.php' ),
            'nonce'        => wp_create_nonce( 'wpcf_submit_nonce' ),
            'max_chars'    => 1000,
            'max_file_size'=> 5 * 1024 * 1024, // 5 MB in bytes
            'allowed_types'=> array( 'pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png' ),
            'success_mode' => 'replace',
            'redirect_url' => '',
            'strings'      => array(
                'sending'          => __( 'Sending…',                         'wp-contact-crm' ),
                'submit_label'     => __( 'Send Message',                     'wp-contact-crm' ),
                'required'         => __( 'This field is required.',          'wp-contact-crm' ),
                'invalid_email'    => __( 'Please enter a valid email.',      'wp-contact-crm' ),
                'invalid_phone'    => __( 'Please enter a valid phone number.','wp-contact-crm' ),
                'too_short'        => __( 'Please enter at least {n} characters.','wp-contact-crm' ),
                'too_long'         => __( 'Maximum {n} characters allowed.',  'wp-contact-crm' ),
                'consent_required' => __( 'Please accept the privacy policy.','wp-contact-crm' ),
                'file_too_large'   => __( 'File is too large: {name}.',       'wp-contact-crm' ),
                'file_type_invalid'=> __( 'File type not allowed: {ext}.',    'wp-contact-crm' ),
                'chars_remaining'  => __( 'characters remaining',             'wp-contact-crm' ),
                'success'          => __( 'Message sent! We\'ll be in touch soon.', 'wp-contact-crm' ),
                'error'            => __( 'Something went wrong. Please try again.','wp-contact-crm' ),
                'btn_label'        => __( 'Send Message',                     'wp-contact-crm' ),
            ),
        ) );
    }

    /**
     * Render the contact form HTML.
     *
     * @param  array  $atts    Shortcode attributes.
     * @param  string $content Inner content (unused).
     * @return string          HTML output.
     */
    public function render( array $atts, string $content = '' ): string {
        $a = shortcode_atts( array(
            'title'        => '',
            'subtitle'     => '',
            'show_phone'   => 'false',
            'show_subject' => 'true',
            'class'        => '',
            'form_id'      => 'default',
        ), $atts, 'contact_form' );

        $extra_class = sanitize_html_class( $a['class'] );
        $show_phone  = filter_var( $a['show_phone'],   FILTER_VALIDATE_BOOLEAN );
        $show_subject = filter_var( $a['show_subject'], FILTER_VALIDATE_BOOLEAN );

        ob_start();
        ?>
        <div class="wpcf-wrap <?php echo esc_attr( $extra_class ); ?>" role="region" aria-label="<?php esc_attr_e( 'Contact Form', 'wp-contact-crm' ); ?>">
            <div class="wpcf-form-card">

                <?php if ( $a['title'] || $a['subtitle'] ) : ?>
                <div class="wpcf-form-header">
                    <?php if ( $a['title'] ) : ?>
                        <h2 class="wpcf-form-title"><?php echo esc_html( $a['title'] ); ?></h2>
                    <?php endif; ?>
                    <?php if ( $a['subtitle'] ) : ?>
                        <p class="wpcf-form-desc"><?php echo esc_html( $a['subtitle'] ); ?></p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Response message (success/error) -->
                <div id="wpcf-response" role="alert" aria-live="polite"></div>

                <!-- Success state (replaces form on submission) -->
                <div class="wpcf-success-state" aria-hidden="true">
                    <div class="wpcf-check-circle" aria-hidden="true">
                        <svg class="wpcf-check-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                    </div>
                    <h3 class="wpcf-success-title"><?php esc_html_e( 'Message Sent!', 'wp-contact-crm' ); ?></h3>
                    <p class="wpcf-success-message"><?php esc_html_e( 'Thank you for reaching out. We\'ll be in touch soon.', 'wp-contact-crm' ); ?></p>
                    <button type="button" class="wpcf-success-again"><?php esc_html_e( 'Send another message', 'wp-contact-crm' ); ?></button>
                </div>

                <!-- The form -->
                <form id="wpcf-form"
                      class="wpcf-form"
                      novalidate
                      data-form-id="<?php echo esc_attr( $a['form_id'] ); ?>">

                    <!-- Honeypot (hidden from real users, filled by bots) -->
                    <div class="wpcf-hp" aria-hidden="true">
                        <label for="wpcf-website"><?php esc_html_e( 'Leave this field blank', 'wp-contact-crm' ); ?></label>
                        <input type="text" id="wpcf-website" name="wpcf_website" tabindex="-1" autocomplete="off">
                    </div>

                    <!-- Name + Email — two-column row -->
                    <div class="wpcf-row-2col">
                        <div class="wpcf-field" id="wpcf-field-name">
                            <label class="wpcf-label" for="wpcf-name">
                                <?php esc_html_e( 'Your Name', 'wp-contact-crm' ); ?>
                                <span class="wpcf-req" aria-hidden="true">*</span>
                            </label>
                            <input class="wpcf-input"
                                   type="text"
                                   id="wpcf-name"
                                   name="name"
                                   required
                                   data-min="2"
                                   autocomplete="name"
                                   aria-required="true">
                        </div>
                        <div class="wpcf-field" id="wpcf-field-email">
                            <label class="wpcf-label" for="wpcf-email">
                                <?php esc_html_e( 'Email Address', 'wp-contact-crm' ); ?>
                                <span class="wpcf-req" aria-hidden="true">*</span>
                            </label>
                            <input class="wpcf-input"
                                   type="email"
                                   id="wpcf-email"
                                   name="email"
                                   required
                                   data-type="email"
                                   autocomplete="email"
                                   aria-required="true">
                        </div>
                    </div>

                    <?php if ( $show_phone ) : ?>
                    <div class="wpcf-field" id="wpcf-field-phone">
                        <label class="wpcf-label" for="wpcf-phone">
                            <?php esc_html_e( 'Phone Number', 'wp-contact-crm' ); ?>
                        </label>
                        <input class="wpcf-input"
                               type="tel"
                               id="wpcf-phone"
                               name="phone"
                               data-type="tel"
                               autocomplete="tel">
                    </div>
                    <?php endif; ?>

                    <?php if ( $show_subject ) : ?>
                    <div class="wpcf-field" id="wpcf-field-subject">
                        <label class="wpcf-label" for="wpcf-subject">
                            <?php esc_html_e( 'Subject', 'wp-contact-crm' ); ?>
                        </label>
                        <input class="wpcf-input"
                               type="text"
                               id="wpcf-subject"
                               name="subject">
                    </div>
                    <?php endif; ?>

                    <!-- Message -->
                    <div class="wpcf-field wpcf-field--textarea wpcf-field--message" id="wpcf-field-message">
                        <label class="wpcf-label" for="wpcf-message">
                            <?php esc_html_e( 'Message', 'wp-contact-crm' ); ?>
                            <span class="wpcf-req" aria-hidden="true">*</span>
                        </label>
                        <textarea class="wpcf-textarea"
                                  id="wpcf-message"
                                  name="message"
                                  required
                                  maxlength="1000"
                                  aria-required="true"
                                  data-max="1000"></textarea>
                        <div class="wpcf-char-row">
                            <span class="wpcf-char-count" aria-live="polite">1000 <?php esc_html_e( 'characters remaining', 'wp-contact-crm' ); ?></span>
                        </div>
                    </div>

                    <!-- Submit -->
                    <div class="wpcf-submit-row">
                        <button type="submit" id="wpcf-submit" class="wpcf-submit-btn" aria-label="<?php esc_attr_e( 'Send message', 'wp-contact-crm' ); ?>">
                            <?php esc_html_e( 'Send Message', 'wp-contact-crm' ); ?>
                        </button>
                        <span class="wpcf-submit-note">
                            <?php esc_html_e( 'We\'ll reply within 1-2 business days.', 'wp-contact-crm' ); ?>
                        </span>
                    </div>

                </form><!-- /#wpcf-form -->
            </div><!-- /.wpcf-form-card -->
        </div><!-- /.wpcf-wrap -->
        <?php
        return ob_get_clean();
    }
}