<?php
/**
 * Email — Auto-Reply + Admin Notification + Manual Reply
 *
 * FILE: wp-contact-crm/includes/class-wpcf-email.php
 *
 * All wp_mail() calls go through this class.
 * Uses WPCF_Settings::get() to read per-installation configuration.
 *
 * @package WP_Contact_CRM
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPCF_Email {

    /**
     * Send an auto-reply to the person who submitted the form.
     *
     * @param  string $name  Submitter's name.
     * @param  string $email Submitter's email address.
     * @return bool          Whether wp_mail succeeded.
     */
    public function send_auto_reply( string $name, string $email ): bool {
        if ( ! WPCF_Settings::get( 'auto_reply', true ) ) {
            return false; // Auto-reply disabled in Settings.
        }

        $site_name = get_bloginfo( 'name' );
        $subject   = sprintf(
            /* translators: %s: site name */
            __( 'We received your message — %s', 'wp-contact-crm' ),
            $site_name
        );

        $body = WPCF_Settings::get(
            'auto_reply_message',
            __( 'Thank you for contacting us. We will reply within 1-2 business days.', 'wp-contact-crm' )
        );

        $message = sprintf(
            "Hi %s,\n\n%s\n\n%s",
            sanitize_text_field( $name ),
            wp_strip_all_tags( $body ),
            $site_name
        );

        return wp_mail(
            $email,
            $subject,
            $message,
            $this->get_headers()
        );
    }

    /**
     * Send a notification email to the site admin about a new submission.
     *
     * @param  int    $id      Submission database ID.
     * @param  string $name    Submitter name.
     * @param  string $email   Submitter email.
     * @param  string $subject Form subject field.
     * @param  string $message Form message.
     * @return bool
     */
    public function send_admin_notification( int $id, string $name, string $email, string $subject, string $message ): bool {
        $recipient = WPCF_Settings::get( 'recipient_email', get_option( 'admin_email' ) );
        $site_name = get_bloginfo( 'name' );
        $admin_url = admin_url( 'admin.php?page=wpcf-crm' );

        $mail_subject = sprintf(
            /* translators: 1: site name 2: submitter name */
            __( '[%1$s] New contact from %2$s', 'wp-contact-crm' ),
            $site_name,
            $name
        );

        $mail_body = sprintf(
            /* translators: 1:name 2:email 3:subject 4:message 5:admin_url */
            __(
                "You have a new contact form submission.\n\n" .
                "Name:    %1\$s\n"  .
                "Email:   %2\$s\n"  .
                "Subject: %3\$s\n\n".
                "Message:\n%4\$s\n\n" .
                "View in CRM: %5\$s",
                'wp-contact-crm'
            ),
            $name,
            $email,
            $subject ?: '—',
            $message,
            $admin_url
        );

        return wp_mail(
            $recipient,
            $mail_subject,
            $mail_body,
            $this->get_headers( $email, $name ) // Reply-To: submitter's email
        );
    }

    /**
     * Send a manual reply email from the admin CRM interface.
     *
     * @param  string $to_email    Recipient email.
     * @param  string $to_name     Recipient name.
     * @param  string $subject     Email subject.
     * @param  string $body        Email body (plain text or HTML).
     * @return bool
     */
    public function send_manual_reply( string $to_email, string $to_name, string $subject, string $body ): bool {
        $headers = $this->get_headers();

        return wp_mail(
            sprintf( '"%s" <%s>', $to_name, $to_email ),
            $subject,
            $body,
            $headers
        );
    }

    /**
     * Build wp_mail headers array.
     *
     * @param  string $reply_to_email  Optional Reply-To email address.
     * @param  string $reply_to_name   Optional Reply-To name.
     * @return string[]
     */
    private function get_headers( string $reply_to_email = '', string $reply_to_name = '' ): array {
        $headers   = array( 'Content-Type: text/plain; charset=UTF-8' );
        $from_name = get_bloginfo( 'name' );
        $from_mail = get_option( 'admin_email' );

        $headers[] = sprintf( 'From: %s <%s>', $from_name, $from_mail );

        if ( $reply_to_email && is_email( $reply_to_email ) ) {
            if ( $reply_to_name ) {
                $headers[] = sprintf( 'Reply-To: %s <%s>', $reply_to_name, $reply_to_email );
            } else {
                $headers[] = 'Reply-To: ' . $reply_to_email;
            }
        }

        return $headers;
    }
}