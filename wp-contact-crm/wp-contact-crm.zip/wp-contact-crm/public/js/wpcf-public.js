/**
 * WP Advanced Contact Form & CRM
 * FILE: wp-contact-crm/public/js/wpcf-public.js
 *
 * Enqueued by: class-wpcf-shortcodes.php → enqueue()
 * Depends on:  wp_localize_script( 'wpcf-public', 'WPCFData', [...] )
 *
 * WPCFData = {
 *   ajax_url, nonce,
 *   strings: { required, sending, success, error, invalid_email,
 *              too_short, too_long, consent_required,
 *              file_too_large, file_type_invalid,
 *              chars_remaining, submit_another },
 *   max_chars,       // int — message field max chars (0 = none)
 *   max_file_size,   // int — bytes
 *   allowed_types,   // ['pdf','doc','jpg',...]
 *   redirect_url,    // string — redirect after success (empty = none)
 *   success_mode,    // 'message' | 'hide' | 'redirect'
 *   show_steps,      // bool — multi-step form
 *   recaptcha_site,  // string — v3 site key (empty = disabled)
 * }
 *
 * Features:
 *  01. Floating label management
 *  02. Real-time inline field validation
 *  03. Character counter on message field
 *  04. Honeypot guard
 *  05. AJAX form submission (fetch, no jQuery .ajax())
 *  06. reCAPTCHA v3 token fetch before submit
 *  07. File upload drag-and-drop + file list
 *  08. Multi-step navigation
 *  09. Success state (animated check / redirect / form hide)
 *  10. Error shake + scroll to error
 *  11. Form reset / "Send another" button
 *  12. Keyboard accessibility (Enter on inputs advances to next field)
 *  13. Analytics event dispatch
 */

/* global WPCFData, jQuery */
( function () {
    'use strict';

    var D = ( typeof WPCFData !== 'undefined' ) ? WPCFData : {};

    /* ── DOM ready ─────────────────────────────────────────────── */
    document.addEventListener( 'DOMContentLoaded', function () {
        document.querySelectorAll( '.wpcf-form' ).forEach( initForm );
    } );

    /* ════════════════════════════════════════════════════════════
       MAIN INIT — one call per [contact_form] on the page
    ════════════════════════════════════════════════════════════ */
    function initForm( form ) {
        var wrap   = form.closest( '.wpcf-wrap' );
        if ( ! wrap ) return;

        var btn       = form.querySelector( '#wpcf-submit, .wpcf-submit-btn' );
        var resp      = wrap.querySelector( '#wpcf-response' );
        var succState = wrap.querySelector( '.wpcf-success-state' );
        var card      = wrap.querySelector( '.wpcf-form-card' );
        var fields    = Array.from( form.querySelectorAll( '.wpcf-input, .wpcf-textarea, .wpcf-select' ) );

        if ( ! btn ) return;

        /* ── 01  Floating labels ─────────────────────────────── */
        fields.forEach( function ( el ) {
            var fieldWrap = el.closest( '.wpcf-field' );
            if ( ! fieldWrap ) return;

            function refresh() {
                fieldWrap.classList.toggle( 'has-value', el.value.trim().length > 0 );
            }

            el.addEventListener( 'focus', function () {
                fieldWrap.classList.add( 'is-active' );
            } );
            el.addEventListener( 'blur', function () {
                fieldWrap.classList.remove( 'is-active' );
                refresh();
                validateField( el ); // validate on blur
            } );
            el.addEventListener( 'input', function () {
                refresh();
                // Clear error once user starts fixing it
                clearFieldError( el );
            } );

            refresh(); // set on page load if pre-filled
        } );

        /* ── 02  Inline field validation ─────────────────────── */
        function validateField( el ) {
            var val   = el.value.trim();
            var type  = el.dataset.type || el.type || 'text';
            var min   = parseInt( el.dataset.min, 10 ) || 0;
            var max   = parseInt( el.dataset.max, 10 ) || 0;
            var req   = el.hasAttribute( 'required' );

            clearFieldError( el );

            if ( req && ! val ) {
                return setFieldError( el, D.strings.required || 'This field is required.' );
            }
            if ( type === 'email' && val && ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( val ) ) {
                return setFieldError( el, D.strings.invalid_email || 'Please enter a valid email address.' );
            }
            if ( type === 'tel' && val && ! /^[\d\s\+\-\(\)]{6,20}$/.test( val ) ) {
                return setFieldError( el, D.strings.invalid_phone || 'Please enter a valid phone number.' );
            }
            if ( min && val.length < min ) {
                return setFieldError( el, ( D.strings.too_short || 'Please enter at least {n} characters.' ).replace( '{n}', min ) );
            }
            if ( max && val.length > max ) {
                return setFieldError( el, ( D.strings.too_long || 'Maximum {n} characters allowed.' ).replace( '{n}', max ) );
            }

            // Mark valid
            el.classList.remove( 'has-error' );
            el.classList.add( 'is-valid' );
            return true;
        }

        function validateAll() {
            var valid = true;
            var firstInvalid = null;

            fields.forEach( function ( el ) {
                if ( el.closest( '.wpcf-step-panel:not(.is-active)' ) ) return;
                if ( ! validateField( el ) ) {
                    valid = false;
                    if ( ! firstInvalid ) firstInvalid = el;
                }
            } );

            // Consent checkbox
            var consent = form.querySelector( '.wpcf-consent__checkbox' );
            if ( consent && consent.hasAttribute( 'required' ) && ! consent.checked ) {
                var consWrap = consent.closest( '.wpcf-consent' );
                if ( consWrap ) consWrap.classList.add( 'has-error' );
                if ( ! firstInvalid ) firstInvalid = consent;
                valid = false;
            }

            if ( firstInvalid ) {
                firstInvalid.focus();
                firstInvalid.closest( '.wpcf-field, .wpcf-consent' )?.scrollIntoView( { behavior: 'smooth', block: 'center' } );
            }
            return valid;
        }

        function setFieldError( el, msg ) {
            el.classList.add( 'has-error' );
            el.classList.remove( 'is-valid' );
            var fieldWrap = el.closest( '.wpcf-field' );
            if ( fieldWrap ) {
                var existing = fieldWrap.querySelector( '.wpcf-field-error' );
                if ( ! existing ) {
                    var err = document.createElement( 'span' );
                    err.className    = 'wpcf-field-error';
                    err.textContent  = msg;
                    err.setAttribute( 'role', 'alert' );
                    fieldWrap.appendChild( err );
                }
            }
            return false;
        }

        function clearFieldError( el ) {
            el.classList.remove( 'has-error' );
            var fieldWrap = el.closest( '.wpcf-field' );
            if ( fieldWrap ) {
                var err = fieldWrap.querySelector( '.wpcf-field-error' );
                if ( err ) err.remove();
            }
        }

        /* Consent checkbox clear on change */
        var consentEl = form.querySelector( '.wpcf-consent__checkbox' );
        if ( consentEl ) {
            consentEl.addEventListener( 'change', function () {
                var w = this.closest( '.wpcf-consent' );
                if ( w ) w.classList.toggle( 'has-error', ! this.checked );
            } );
        }

        /* ── 03  Character counter ───────────────────────────── */
        var msgEl   = form.querySelector( '#wpcf-message, .wpcf-field--message .wpcf-textarea' );
        var counter = form.querySelector( '.wpcf-char-count' );
        var maxC    = parseInt( D.max_chars, 10 ) || 0;

        if ( msgEl && counter && maxC ) {
            function updateCounter() {
                var len = msgEl.value.length;
                var rem = maxC - len;
                counter.textContent = rem + ' ' + ( D.strings.chars_remaining || 'characters remaining' );
                counter.classList.toggle( 'is-warning', rem < maxC * 0.15 && rem > 0 );
                counter.classList.toggle( 'is-limit',   rem <= 0 );
            }
            msgEl.addEventListener( 'input', updateCounter );
            updateCounter();
        }

        /* ── 04  Honeypot ────────────────────────────────────── */
        // Server also checks; client-side we just prevent obvious submissions
        var hp = form.querySelector( '.wpcf-hp input, #wpcf-website' );

        /* ── 05  File upload ─────────────────────────────────── */
        var uploadArea = form.querySelector( '.wpcf-upload-area' );
        var fileInput  = uploadArea ? uploadArea.querySelector( 'input[type="file"]' ) : null;
        var fileList   = form.querySelector( '.wpcf-file-list' );
        var selectedFiles = [];

        if ( uploadArea && fileInput ) {
            uploadArea.addEventListener( 'dragover', function ( e ) {
                e.preventDefault();
                uploadArea.classList.add( 'is-over' );
            } );
            uploadArea.addEventListener( 'dragleave', function () {
                uploadArea.classList.remove( 'is-over' );
            } );
            uploadArea.addEventListener( 'drop', function ( e ) {
                e.preventDefault();
                uploadArea.classList.remove( 'is-over' );
                handleFiles( Array.from( e.dataTransfer.files ) );
            } );
            fileInput.addEventListener( 'change', function () {
                handleFiles( Array.from( this.files ) );
            } );

            function handleFiles( files ) {
                var maxBytes  = parseInt( D.max_file_size, 10 ) || 5 * 1024 * 1024;
                var allowed   = Array.isArray( D.allowed_types ) ? D.allowed_types : [];

                files.forEach( function ( file ) {
                    var ext = file.name.split( '.' ).pop().toLowerCase();
                    if ( allowed.length && ! allowed.includes( ext ) ) {
                        showResp( D.strings.file_type_invalid || 'File type not allowed: ' + ext, 'error' );
                        return;
                    }
                    if ( file.size > maxBytes ) {
                        showResp( D.strings.file_too_large || 'File too large: ' + file.name, 'error' );
                        return;
                    }
                    selectedFiles.push( file );
                    renderFileItem( file );
                } );
            }

            function renderFileItem( file ) {
                if ( ! fileList ) return;
                var item = document.createElement( 'div' );
                item.className = 'wpcf-file-item';
                item.innerHTML =
                    '<span>📎</span>' +
                    '<span>' + escHtml( file.name ) + ' (' + formatBytes( file.size ) + ')</span>' +
                    '<button type="button" class="wpcf-file-remove" aria-label="Remove file">✕</button>';
                item.querySelector( '.wpcf-file-remove' ).addEventListener( 'click', function () {
                    selectedFiles = selectedFiles.filter( function ( f ) { return f !== file; } );
                    item.remove();
                } );
                fileList.appendChild( item );
            }
        }

        /* ── 06  Submit handler ──────────────────────────────── */
        btn.addEventListener( 'click', handleSubmit );
        form.addEventListener( 'submit', function ( e ) {
            e.preventDefault();
            handleSubmit();
        } );

        /* Enter on inputs submits if on last field */
        form.addEventListener( 'keydown', function ( e ) {
            if ( e.key === 'Enter' && e.target.tagName !== 'TEXTAREA' && e.target.tagName !== 'BUTTON' ) {
                e.preventDefault();
                handleSubmit();
            }
        } );

        async function handleSubmit() {
            // Check honeypot
            if ( hp && hp.value ) return;

            if ( ! validateAll() ) return;

            setLoading( true );

            // reCAPTCHA v3
            var captchaToken = '';
            if ( D.recaptcha_site && window.grecaptcha ) {
                try {
                    captchaToken = await window.grecaptcha.execute( D.recaptcha_site, { action: 'wpcf_submit' } );
                } catch ( ex ) {
                    captchaToken = '';
                }
            }

            // Build FormData (handles files)
            var fd = new FormData();
            fd.append( 'action',         'wpcf_submit' );
            fd.append( 'nonce',          D.nonce || '' );
            fd.append( 'name',           ( form.querySelector( '#wpcf-name' )    || {} ).value || '' );
            fd.append( 'email',          ( form.querySelector( '#wpcf-email' )   || {} ).value || '' );
            fd.append( 'phone',          ( form.querySelector( '#wpcf-phone' )   || {} ).value || '' );
            fd.append( 'subject',        ( form.querySelector( '#wpcf-subject' ) || {} ).value || '' );
            fd.append( 'message',        ( form.querySelector( '#wpcf-message' ) || {} ).value || '' );
            fd.append( 'wpcf_website',   hp ? hp.value : '' );
            fd.append( 'captcha_token',  captchaToken );
            fd.append( 'form_id',        form.dataset.formId || '' );

            // Append selected files
            selectedFiles.forEach( function ( file, i ) {
                fd.append( 'attachment_' + i, file );
            } );

            // Append any extra custom fields
            form.querySelectorAll( '[data-custom-field]' ).forEach( function ( el ) {
                fd.append( 'custom[' + el.name + ']', el.value );
            } );

            try {
                var res  = await fetch( D.ajax_url || '/wp-admin/admin-ajax.php', {
                    method:      'POST',
                    credentials: 'same-origin',
                    body:        fd,
                } );
                var data = await res.json();

                setLoading( false );

                if ( data.success ) {
                    handleSuccess( data.data );
                    fireEvent( 'wpcf_submitted', { form_id: form.dataset.formId } );
                } else {
                    var msg = ( data.data && data.data.message ) || D.strings.error || 'Something went wrong.';
                    showResp( msg, 'error' );
                }
            } catch ( err ) {
                setLoading( false );
                showResp( D.strings.error || 'Network error. Please try again.', 'error' );
            }
        }

        /* ── 07  Success handling ────────────────────────────── */
        function handleSuccess( data ) {
            var mode = D.success_mode || 'message';

            if ( mode === 'redirect' && D.redirect_url ) {
                window.location.href = D.redirect_url;
                return;
            }

            if ( mode === 'hide' || mode === 'replace' ) {
                form.style.display = 'none';
            }

            if ( succState ) {
                var titleEl = succState.querySelector( '.wpcf-success-title' );
                var msgEl2  = succState.querySelector( '.wpcf-success-message' );
                if ( titleEl && data && data.title )   titleEl.textContent = data.title;
                if ( msgEl2  && data && data.message ) msgEl2.textContent  = data.message;
                succState.classList.add( 'is-visible' );
            } else {
                showResp( ( data && data.message ) || D.strings.success || 'Message sent!', 'success' );
                if ( mode === 'hide' ) {
                    form.style.display = 'none';
                }
            }

            // "Send another message" button
            var againBtn = wrap.querySelector( '.wpcf-success-again' );
            if ( againBtn ) {
                againBtn.addEventListener( 'click', resetForm );
            }
        }

        /* ── 08  UI helpers ──────────────────────────────────── */
        function setLoading( loading ) {
            if ( loading ) {
                btn.disabled = true;
                btn.innerHTML = '<span class="wpcf-spinner" aria-hidden="true"></span>' +
                    escHtml( D.strings.sending || 'Sending…' );
                if ( card ) card.classList.add( 'is-loading' );
            } else {
                btn.disabled = false;
                btn.textContent = D.strings.btn_label || 'Send Message';
                if ( card ) card.classList.remove( 'is-loading' );
            }
        }

        function showResp( msg, type ) {
            if ( ! resp ) return;
            resp.className   = 'wpcf-' + type;
            resp.textContent = msg;
            resp.style.display = 'block';
            resp.setAttribute( 'role', 'alert' );
            resp.scrollIntoView( { behavior: 'smooth', block: 'nearest' } );
        }

        function resetForm() {
            form.reset();
            form.style.display = '';
            if ( succState ) succState.classList.remove( 'is-visible' );
            if ( resp )      resp.style.display = 'none';
            selectedFiles = [];
            if ( fileList ) fileList.innerHTML = '';
            fields.forEach( function ( el ) {
                el.classList.remove( 'has-error', 'is-valid' );
                var fw = el.closest( '.wpcf-field' );
                if ( fw ) {
                    fw.classList.remove( 'is-active', 'has-value' );
                    var e = fw.querySelector( '.wpcf-field-error' );
                    if ( e ) e.remove();
                }
            } );
            if ( counter ) counter.textContent = maxC + ' ' + ( D.strings.chars_remaining || 'characters remaining' );
        }

        /* ── 09  Multi-step form ─────────────────────────────── */
        var stepPanels = Array.from( form.querySelectorAll( '.wpcf-step-panel' ) );
        var stepDots   = Array.from( wrap.querySelectorAll( '.wpcf-step' ) );
        var currentStep = 0;

        if ( stepPanels.length > 1 ) {
            showStep( 0 );

            form.querySelectorAll( '.wpcf-btn-next' ).forEach( function ( nextBtn ) {
                nextBtn.addEventListener( 'click', function () {
                    // Validate current step fields
                    var panel  = stepPanels[ currentStep ];
                    var panelFields = Array.from( panel.querySelectorAll( '.wpcf-input, .wpcf-textarea' ) );
                    var valid  = panelFields.every( function ( el ) { return validateField( el ) !== false; } );
                    if ( ! valid ) return;
                    if ( currentStep < stepPanels.length - 1 ) showStep( currentStep + 1 );
                } );
            } );

            form.querySelectorAll( '.wpcf-btn-prev' ).forEach( function ( prevBtn ) {
                prevBtn.addEventListener( 'click', function () {
                    if ( currentStep > 0 ) showStep( currentStep - 1 );
                } );
            } );

            function showStep( idx ) {
                stepPanels.forEach( function ( p, i ) { p.classList.toggle( 'is-active', i === idx ); } );
                stepDots.forEach( function ( d, i ) {
                    d.classList.toggle( 'is-active', i === idx );
                    d.classList.toggle( 'is-done',   i <  idx );
                } );
                currentStep = idx;
            }
        }

        /* ── 10  Response close button ───────────────────────── */
        if ( resp ) {
            var closeBtn = document.createElement( 'button' );
            closeBtn.type        = 'button';
            closeBtn.className   = 'wpcf-response-close';
            closeBtn.textContent = '×';
            closeBtn.setAttribute( 'aria-label', 'Close message' );
            closeBtn.addEventListener( 'click', function () {
                resp.style.display = 'none';
            } );
            resp.appendChild( closeBtn );
        }
    }

    /* ── Utilities ──────────────────────────────────────────── */
    function escHtml( str ) {
        return String( str )
            .replace( /&/g, '&amp;' ).replace( /</g, '&lt;' )
            .replace( />/g, '&gt;' ).replace( /"/g, '&quot;' );
    }

    function formatBytes( bytes ) {
        if ( bytes < 1024 )       return bytes + ' B';
        if ( bytes < 1024 * 1024 ) return ( bytes / 1024 ).toFixed( 1 ) + ' KB';
        return ( bytes / ( 1024 * 1024 ) ).toFixed( 1 ) + ' MB';
    }

    function fireEvent( name, detail ) {
        document.dispatchEvent( new CustomEvent( name, { bubbles: true, detail: detail } ) );
        if ( window.dataLayer ) window.dataLayer.push( Object.assign( { event: name }, detail ) );
    }

} )();