# WP Advanced Contact Form & CRM

A powerful WordPress plugin that provides a professional contact form with an integrated CRM dashboard for managing submissions, auto-replies, and team collaboration.

## 📋 Quick Links to Documentation

- **[USER_GUIDE.md](USER_GUIDE.md)** - Complete feature documentation and user guide
- **[SHORTCODE_REFERENCE.md](SHORTCODE_REFERENCE.md)** - Quick reference for contact form shortcodes
- **[SETUP_GUIDE.md](SETUP_GUIDE.md)** - Step-by-step setup and configuration instructions

## ✨ Features

### Contact Form
- Professional, mobile-responsive contact form
- Client-side and server-side validation
- Configurable fields (name, email, phone, subject, message)
- Character counter for message field
- Success/error messages with real-time feedback
- AJAX submission (no page reload)

### CRM Dashboard
- View all form submissions in one place
- Status tracking: New, Read, Replied, Closed, Spam
- Search and filter submissions
- Bulk actions (status change, delete)
- Detail panel for each submission
- Internal notes for team collaboration
- Reply email functionality
- CSV export for reporting

### Email Management
- Auto-reply emails to form submitters
- Admin notifications for new submissions
- Configurable auto-reply message
- Custom notification email address
- Immediate delivery on submission

### Security & Spam Protection
- Rate limiting by IP address (configurable)
- Honeypot field for bot detection
- AJAX nonce verification (CSRF protection)
- Input sanitization and validation
- Email format validation
- Message character limits

### REST API
- Programmatic access to submissions
- List submissions with filters
- Update submission status
- Search and pagination support
- Restricted to admin users only

### Additional Features
- Multiple forms on different pages
- Custom CSS styling options
- Chart.js integration for analytics
- 30-day submission volume tracking
- Status breakdown charts
- Translation-ready (WordPress i18n)

## 🚀 Quick Start

### 1. Installation
1. Upload the `wp-contact-crm` folder to `/wp-content/plugins/`
2. Go to WordPress admin and activate the plugin
3. You'll see "Contact CRM" in the sidebar menu

### 2. Initial Setup (3 minutes)
1. Go to **Contact CRM → Settings**
2. Enter your notification email address
3. Customize the auto-reply message
4. Adjust rate limiting if needed
5. Click Save

### 3. Add Form to Website
Add this shortcode to any page or post:
```
[contact_form title="Contact Us"]
```

### 4. Test It
- Visit the page with your form
- Submit a test message
- Verify you receive emails

For detailed setup instructions, see [SETUP_GUIDE.md](SETUP_GUIDE.md)

## 🎯 Use Cases

- **Service Business:** Collect leads and manage inquiries
- **E-commerce:** Handle customer support requests
- **Portfolio:** Showcase contact form for potential clients
- **Agency:** Manage multiple client inquiry forms
- **Non-profit:** Accept donations and volunteer inquiries
- **SaaS:** Sales inquiry and support requests

## 📝 Basic Shortcode Usage

### Simplest Form
```
[contact_form]
```

### With Customization
```
[contact_form 
  title="Get In Touch" 
  subtitle="We reply within 24 hours"
  show_phone="true"]
```

### Multiple Forms on One Site
```
[contact_form form_id="general" title="General Contact"]
[contact_form form_id="support" title="Support Request" show_phone="true"]
[contact_form form_id="sales" title="Sales" show_subject="true"]
```

For complete shortcode reference, see [SHORTCODE_REFERENCE.md](SHORTCODE_REFERENCE.md)

## ⚙️ Settings

### Email Settings
- **Notification Email:** Where admin notifications are sent
- **Auto-Reply Message:** Message sent to form submitters

### Security Settings
- **Rate Limiting:** Max submissions per IP per hour (default: 3)

For detailed configuration guide, see [SETUP_GUIDE.md](SETUP_GUIDE.md)

## 📊 CRM Dashboard

### Features
- View all form submissions
- Filter by status (New, Read, Replied, Closed, Spam)
- Search submissions by name, email, subject, or message
- Update submission status with one click
- Send reply emails directly from dashboard
- Add internal notes for team collaboration
- View submission details
- Delete submissions
- Export to CSV

### Navigation
**Contact CRM → [Main Dashboard]** - View submissions
**Contact CRM → Settings** - Configure plugin

## 🔐 Security Features

The plugin includes:
- **Rate Limiting:** Prevents spam by limiting submissions per IP per hour
- **Honeypot Field:** Catches automated bot submissions
- **AJAX Nonce Verification:** Prevents CSRF attacks
- **Input Sanitization:** All inputs cleaned before saving
- **Email Validation:** Verified on client and server
- **Character Limits:** Message limited to 1000 characters
- **IP Tracking:** Records submitter IP for spam prevention

## 🔌 REST API

### Available Endpoints

**List Submissions**
```
GET /wp-json/wpcf/v1/submissions
```

**Update Submission**
```
PATCH /wp-json/wpcf/v1/submissions/{id}
```

All endpoints require admin authentication.

For complete API documentation, see [USER_GUIDE.md#rest-api](USER_GUIDE.md#rest-api)

## 📱 Form Fields

### Always Included
- **Name** (Required, min 2 characters)
- **Email** (Required, valid email format)
- **Message** (Required, max 1000 characters)

### Optional (Configurable)
- **Phone** (Optional, shown with `show_phone="true"`)
- **Subject** (Optional, shown with `show_subject="true"`)

### Hidden (Always Present)
- **Honeypot Field** (Spam protection)
- **Security Nonce** (CSRF protection)

## 📧 Email Notifications

### Auto-Reply Email
- **Sent to:** Form submitter
- **Sent when:** Form submitted successfully
- **Message:** Customizable via Settings
- **Timing:** Immediate

### Admin Notification Email
- **Sent to:** Configured notification email address
- **Sent when:** Form submitted successfully (after auto-reply)
- **Includes:** All submission details
- **Timing:** Immediately after auto-reply

## 🎨 Customization

### Add Custom Title and Subtitle
```
[contact_form title="Contact Our Sales Team" subtitle="Available Monday-Friday, 9am-5pm EST"]
```

### Apply Custom CSS Class
```
[contact_form class="contact-form-compact"]
```

Then add to your theme's custom CSS:
```css
.contact-form-compact .wpcf-submit-btn {
  background-color: #007cba;
  padding: 15px 30px;
}
```

### Show/Hide Optional Fields
```
[contact_form show_phone="true" show_subject="false"]
```

For more customization examples, see [SHORTCODE_REFERENCE.md](SHORTCODE_REFERENCE.md)

## 🔍 Data Collected

When a form is submitted, the following is stored:
- Name, Email, Phone (if shown)
- Subject, Message
- Submission date and time
- Page URL where form was submitted
- Visitor IP address (for spam tracking)
- Status (default: "New")

**Privacy Note:** All data is stored securely in your database. IP addresses are stripped from REST API responses for privacy.

## ⚡ Performance

- **Lightweight:** Only ~2MB plugin size
- **Minimal DB Impact:** Less than 1KB per submission
- **Optimized Loading:** CSS/JS only loaded on pages with form
- **Fast Queries:** Database optimized for quick submission retrieval
- **Scalable:** Handles thousands of submissions efficiently

## 🛠️ Requirements

- **WordPress:** 6.0 or higher
- **PHP:** 8.0 or higher
- **MySQL:** 5.7 or higher (standard on all modern hosts)

## 📦 What's Included

```
wp-contact-crm/
├── wp-contact-crm.php              # Main plugin file
├── readme.txt                       # Plugin readme
├── uninstall.php                    # Cleanup on uninstall
├── USER_GUIDE.md                    # Complete user guide
├── SHORTCODE_REFERENCE.md           # Shortcode documentation
├── SETUP_GUIDE.md                   # Setup instructions
├── folder-structure.md              # Project structure
│
├── includes/
│   ├── class-wpcf-activator.php     # Activation/deactivation
│   ├── class-wpcf-admin.php         # Admin dashboard
│   ├── class-wpcf-submissions-db.php # Database layer
│   ├── class-wpcf-shortcodes.php    # Contact form shortcode
│   ├── class-wpcf-ajax.php          # AJAX handlers
│   ├── class-wpcf-email.php         # Email handling
│   ├── class-wpcf-rate-limiter.php  # Rate limiting
│   ├── class-wpcf-rest-api.php      # REST endpoints
│   └── class-wpcf-settings.php      # Settings page
│
├── admin/
│   ├── css/wpcf-admin.css           # Admin styles
│   └── js/wpcf-admin.js             # Admin JavaScript
│
├── public/
│   ├── css/wpcf-public.css          # Form styles
│   └── js/wpcf-public.js            # Form JavaScript
│
└── languages/
    └── wp-contact-crm.pot           # Translation file
```

## 🐛 Troubleshooting

### Form Not Showing
- Verify plugin is activated
- Check WordPress is 6.0+, PHP is 8.0+
- Clear page cache
- Verify shortcode spelling: `[contact_form]`

### Emails Not Sending
- Check notification email in Settings
- Verify email isn't going to spam
- Check WordPress email setup
- Contact hosting provider about email relay

### Rate Limiting Too Strict
- Go to Settings
- Increase "Max Submissions per IP per Hour"
- Save changes

For more troubleshooting help, see [SETUP_GUIDE.md#troubleshooting](SETUP_GUIDE.md#troubleshooting)

## 📚 Documentation

This plugin includes comprehensive documentation:

1. **USER_GUIDE.md** - Everything you need to know about using the plugin
2. **SHORTCODE_REFERENCE.md** - Quick reference for shortcode attributes
3. **SETUP_GUIDE.md** - Step-by-step setup and configuration

Start with the documentation that matches your needs:
- **Just installed?** → Read [SETUP_GUIDE.md](SETUP_GUIDE.md)
- **Want to add a form?** → Read [SHORTCODE_REFERENCE.md](SHORTCODE_REFERENCE.md)
- **Need detailed info?** → Read [USER_GUIDE.md](USER_GUIDE.md)

## 👥 Team Collaboration

- Invite team members as WordPress administrators
- All admins can access the CRM dashboard
- Add internal notes on submissions for team discussion
- Reply to submissions directly from the dashboard
- Bulk manage multiple submissions

## 📈 Analytics

The CRM dashboard includes:
- **Submission Volume Chart:** 30-day trend
- **Status Breakdown Chart:** Distribution of submission statuses
- **Total Submissions Counter:** Site-wide metric

## 🔄 Updates

The plugin checks for updates automatically. When a new version is available:
1. Go to **Plugins** page
2. Click **Update Now** when available
3. Plugin updates seamlessly without losing data

## 📄 License

This plugin is licensed under the **GNU General Public License v2.0 or later**

For license details, see the plugin header comments.

## 🤝 Support

For help:
1. Check the documentation files included with the plugin
2. Review the troubleshooting section in [SETUP_GUIDE.md](SETUP_GUIDE.md)
3. Check [USER_GUIDE.md](USER_GUIDE.md) for detailed feature information
4. Contact your WordPress hosting provider for server-level issues

## 💡 Tips & Best Practices

### For Best Results
1. ✅ Test the form after setup
2. ✅ Monitor the CRM dashboard regularly
3. ✅ Adjust rate limiting based on spam received
4. ✅ Keep auto-reply message friendly and professional
5. ✅ Reply to submissions promptly
6. ✅ Archive old submissions periodically
7. ✅ Export submissions for backup/reporting
8. ✅ Mark spam submissions to improve filtering

### Security Best Practices
1. ✅ Keep WordPress updated
2. ✅ Keep plugins updated
3. ✅ Use strong admin passwords
4. ✅ Limit admin access to necessary users
5. ✅ Enable HTTPS on your site
6. ✅ Regular database backups
7. ✅ Monitor submissions for unusual activity

## 📊 Common Use Cases

- **Lead Generation:** Collect sales inquiries
- **Customer Support:** Manage support requests
- **Event Registration:** Accept event signups
- **Feedback Collection:** Gather customer feedback
- **Job Applications:** Collect applications
- **Quote Requests:** Accept pricing inquiries
- **Newsletter Signup:** Build email list
- **Appointment Booking:** Schedule appointments
- **Portfolio Contact:** Showcase contact form
- **Directory Listings:** Accept business information

## 🎓 Getting Started Video

Setup should take about 5-10 minutes:

1. Activate plugin (1 min)
2. Configure settings (2 min)
3. Add form to page (1 min)
4. Test submission (1 min)
5. Review CRM dashboard (1 min)

See [SETUP_GUIDE.md](SETUP_GUIDE.md) for step-by-step instructions.

## 🚀 What's Next

After installation:
1. Read [SETUP_GUIDE.md](SETUP_GUIDE.md) for setup instructions
2. Configure settings in Contact CRM → Settings
3. Add `[contact_form]` to a page
4. Test the form
5. Monitor submissions in the CRM dashboard
6. Adjust settings based on your needs
7. Invite team members if needed

---

## Quick Reference

| Feature | Details |
|---------|---------|
| **Main Shortcode** | `[contact_form]` |
| **Admin Menu** | Contact CRM |
| **Settings Page** | Contact CRM → Settings |
| **Database Table** | wp_wpcf_submissions |
| **Min Requirements** | WordPress 6.0+, PHP 8.0+ |
| **Plugin Size** | ~2MB |
| **Supported Languages** | English (translatable) |

---

**Version:** 1.0.0  
**Last Updated:** May 28, 2025  
**License:** GPL 2.0+  
**Author:** Vetri Suriya  

For comprehensive guides and documentation, see the included markdown files:
- [USER_GUIDE.md](USER_GUIDE.md)
- [SHORTCODE_REFERENCE.md](SHORTCODE_REFERENCE.md)
- [SETUP_GUIDE.md](SETUP_GUIDE.md)
