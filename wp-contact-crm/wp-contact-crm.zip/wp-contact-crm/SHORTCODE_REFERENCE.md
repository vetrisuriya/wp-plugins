# Quick Reference: Contact Form Shortcodes

## Main Shortcode: `[contact_form]`

### Simplest Usage
```
[contact_form]
```
Displays a basic contact form with Name, Email, Subject, and Message fields.

---

## All Available Attributes

| Attribute | Type | Default | Options |
|-----------|------|---------|---------|
| `title` | text | (empty) | Any text, e.g., "Contact Us" |
| `subtitle` | text | (empty) | Any text, e.g., "We reply within 24 hours" |
| `show_phone` | true/false | false | true or false |
| `show_subject` | true/false | true | true or false |
| `class` | text | (empty) | CSS class name(s) |
| `form_id` | text | default | Any unique identifier |

---

## Common Examples

### Example 1: Basic Form with Title
```
[contact_form title="Get In Touch"]
```

### Example 2: Form with Title and Subtitle
```
[contact_form title="Contact Our Team" subtitle="We respond within 24 hours"]
```

### Example 3: Include Phone Field
```
[contact_form show_phone="true"]
```

### Example 4: Hide Subject Field
```
[contact_form show_subject="false"]
```

### Example 5: Complete Customization
```
[contact_form 
  title="Sales Inquiry" 
  subtitle="Let's talk about your project" 
  show_phone="true" 
  show_subject="true" 
  class="contact-sales"]
```

### Example 6: Multiple Forms on One Page
```
[contact_form form_id="footer" title="Footer Contact"]
[contact_form form_id="sidebar" title="Sidebar Contact" show_phone="true"]
```

---

## Form Fields Included

### Always Included:
- ✅ Name (Required, min 2 characters)
- ✅ Email (Required, valid format)
- ✅ Message (Required, max 1000 characters)

### Optional (Configurable):
- 📞 Phone (Show with `show_phone="true"`)
- 📋 Subject (Hide with `show_subject="false"`)

### Always Hidden:
- 🔒 Honeypot (spam protection)
- 🔐 Security nonce (verification token)

---

## Form Validation

The form validates:

| Field | Requirements |
|-------|--------------|
| Name | At least 2 characters |
| Email | Valid email format |
| Phone | Valid phone format (if shown) |
| Message | 1-1000 characters required |

---

## Response Messages

### Success Message
*"Message sent! We'll be in touch soon."*

### Error Messages (User-Facing)
- "This field is required."
- "Please enter a valid email."
- "Please enter a valid phone number."
- "Please enter at least 2 characters."
- "Maximum 1000 characters allowed."
- "Too many submissions from your IP. Please wait before trying again."

---

## Styling Tips

### Apply Custom CSS Class
```
[contact_form class="my-custom-form"]
```

Then add to your theme CSS:
```css
.my-custom-form .wpcf-form-card {
  background-color: #f5f5f5;
  padding: 30px;
  border-radius: 10px;
}

.my-custom-form .wpcf-submit-btn {
  background-color: #007cba;
  color: white;
}
```

### Available CSS Classes for Styling

```
.wpcf-wrap                  /* Main form container */
.wpcf-form-card             /* Form card wrapper */
.wpcf-form-header           /* Title/subtitle area */
.wpcf-form-title            /* Title element */
.wpcf-form-desc             /* Subtitle element */
.wpcf-field                 /* Individual field wrapper */
.wpcf-label                 /* Label element */
.wpcf-input                 /* Text/email/tel input */
.wpcf-textarea              /* Message textarea */
.wpcf-submit-btn            /* Submit button */
.wpcf-row-2col              /* Two-column row (name+email) */
.wpcf-response              /* Response message area */
.wpcf-success-state         /* Success confirmation */
.wpcf-character-count       /* Character counter display */
```

---

## JavaScript Customization

### Available Global Object
```javascript
// Data available to custom scripts
WPCFData = {
  ajax_url: "...",           // AJAX endpoint
  nonce: "...",              // Security token
  max_chars: 1000,           // Max message length
  max_file_size: 5242880,    // 5MB in bytes
  allowed_types: [...],      // Allowed file types
  success_mode: "replace",   // Form replaced on success
  redirect_url: "",          // Redirect URL (if set)
  strings: {
    // Translatable strings
    sending: "Sending…",
    success: "Message sent!",
    error: "Something went wrong..."
  }
}
```

### Hook Into Form Submission
```javascript
document.addEventListener('wpcfAfterSubmit', function(e) {
  // e.detail contains submission response
  console.log('Form submitted!', e.detail);
});
```

---

## Admin Dashboard Access

### Navigate to Submissions
1. WordPress Admin → **Contact CRM**
2. View all submissions by status: New, Read, Replied, Closed, Spam
3. Search by name, email, subject, or message
4. Filter by status or date range
5. Export to CSV

---

## Settings Available

Access via: **Contact CRM → Settings**

### Email Settings
- **Notification Email:** Where to send admin alerts
- **Auto-Reply Message:** Message sent to submitter immediately

### Security Settings
- **Rate Limit:** Max submissions per IP per hour (default: 3)

---

## Usage on Different Page Types

### On a Regular Page
```
[contact_form title="Contact Us"]
```

### In a Page Template
```php
<?php
// Inside your page template
echo do_shortcode('[contact_form title="Get In Touch"]');
?>
```

### In a Widget
1. Add **Custom HTML** widget
2. Paste: `[contact_form]`
3. Click Save

### Multiple Forms
```
[contact_form form_id="contact" title="General Contact"]
[contact_form form_id="support" title="Support Request" show_phone="true"]
```

---

## Troubleshooting Shortcodes

### Problem: Shortcode showing as text `[contact_form]`
- **Solution:** Plugin may not be activated. Check Contact CRM menu in admin.

### Problem: Form not displaying
- **Solution:** Check PHP version is 8.0+
- **Solution:** Check WordPress version is 6.0+
- **Solution:** Clear any caching plugins

### Problem: Attribute not working
- **Solution:** Check spelling: use `show_phone="true"` not `show_phone=true`
- **Solution:** Remember boolean values must be in quotes: `"true"` or `"false"`

---

## Admin Capabilities

Required capability to manage submissions: **manage_crm**

Automatically assigned to:
- Site Administrators
- Users with custom "Manage CRM" role

---

## Data Stored in Database

When a form is submitted, the following is saved:

- Name, Email, Phone (if submitted)
- Subject, Message
- Submission timestamp
- Page URL where form was submitted
- Visitor IP address (for spam tracking)
- Status (default: "New")
- Assigned admin user (initially null)

---

## Email Notifications

### Auto-Reply Email
- **Sent to:** Form submitter's email
- **Sent when:** Form submitted successfully
- **Message:** Configured in Settings
- **Default:** "Thank you for contacting us. We will reply within 1-2 business days."

### Admin Notification
- **Sent to:** Email configured in Settings
- **Sent when:** Form submitted successfully (after auto-reply)
- **Includes:** All submission details
- **Subject:** "New Contact Form Submission"

---

## REST API Quick Reference

### List Submissions
```
GET /wp-json/wpcf/v1/submissions
```

### Update Submission Status
```
PATCH /wp-json/wpcf/v1/submissions/42
Body: {"status":"replied"}
```

### Parameters for GET
- `status`: new, read, replied, closed, spam
- `search`: text to search
- `per_page`: 1-100 (default: 20)
- `page`: page number (default: 1)

---

## Performance Notes

- CSS/JS only loaded on pages with shortcode
- Honeypot field transparent to users
- AJAX form prevents page reload
- Database optimized for fast queries
- Character counter real-time validation

---

## Supported Languages

Default: English

Can be translated via:
- WordPress WPML plugin
- Loco Translate plugin
- Manual translation files in `/languages/` folder

---

## Version & Requirements

- **Plugin Version:** 1.0.0
- **WordPress:** 6.0+
- **PHP:** 8.0+
- **License:** GPL 2.0+

---

## Common Use Cases

| Need | Shortcode |
|------|-----------|
| Basic contact form | `[contact_form]` |
| Sales inquiry | `[contact_form form_id="sales" show_phone="true" title="Sales Contact"]` |
| Support request | `[contact_form form_id="support" title="Technical Support"]` |
| Newsletter signup | `[contact_form title="Subscribe" show_subject="false" class="newsletter"]` |
| Quote request | `[contact_form form_id="quote" show_subject="true" show_phone="true" title="Request a Quote"]` |

---

## Quick Attribute Combinations

### Simple & Clean
```
[contact_form]
```

### Professional Sales Form
```
[contact_form 
  title="Request a Demo" 
  subtitle="Our team will contact you within 24 hours"
  show_phone="true"
  class="demo-form"]
```

### Customer Support
```
[contact_form 
  form_id="support"
  title="Contact Support" 
  show_subject="true"
  show_phone="true"]
```

### Footer Contact
```
[contact_form 
  form_id="footer"
  title="Quick Contact"
  subtitle="Get in touch"
  class="footer-contact"]
```

---

**Last Updated:** May 28, 2025  
**For detailed instructions, see USER_GUIDE.md**
