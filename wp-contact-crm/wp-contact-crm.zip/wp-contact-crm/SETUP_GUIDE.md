# WP Advanced Contact Form & CRM - Setup & Configuration Guide

## Post-Installation Setup Checklist

After activating the plugin, follow this checklist to get started:

- [ ] Configure Email Settings
- [ ] Set Auto-Reply Message
- [ ] Adjust Rate Limiting Settings
- [ ] Add Contact Form to a Page
- [ ] Test Form Submission
- [ ] Test Email Notifications
- [ ] Invite Team Members (optional)
- [ ] Review CRM Dashboard
- [ ] Customize Form Appearance (optional)
- [ ] Configure REST API Access (if needed)

---

## Step-by-Step Setup Guide

### Step 1: Access the Admin Dashboard

1. Log in to WordPress Admin
2. Look for **"Contact CRM"** in the left sidebar menu
3. Click to see two options:
   - Contact CRM (main dashboard)
   - Settings (configuration)

### Step 2: Configure Email Settings

**Location:** Contact CRM → Settings

#### Set Notification Email

1. Scroll to **"Email Settings"** section
2. Find **"Notification Email"** field
3. Enter the email address where you want to receive form submissions
   - Default: Your WordPress admin email
   - **Recommended:** Use an email account you check regularly
   - **Example:** sales@yourdomain.com, contact@yourdomain.com
4. Click **"Save Changes"**

**Why:** Every form submission will be emailed to this address. Make sure it's monitored.

#### Create Auto-Reply Message

1. In the same **"Email Settings"** section
2. Find **"Auto-Reply Message"** text area
3. Replace the default message with your own
4. Keep it professional but friendly
5. Mention expected response time
6. Optionally add contact information for urgent matters
7. Click **"Save Changes"**

**Example Auto-Reply Message:**
```
Hi [Name],

Thank you for contacting us! We've received your message and appreciate you reaching out.

Our team will review your inquiry and get back to you within 1 business day. For urgent matters, you can also call us at (555) 123-4567.

Best regards,
The [Company Name] Team
```

**Note:** The auto-reply sends to the user who submitted the form, while admin notifications go to the email you configured above.

### Step 3: Configure Security Settings

**Location:** Contact CRM → Settings

#### Set Rate Limiting

1. Scroll to **"Security Settings"** section
2. Find **"Max Submissions per IP per Hour"** field
3. Decide appropriate limit:
   - **Default: 3** - Good for most websites
   - **Lower (1-2)** - If you have spam issues
   - **Higher (10-20)** - If you have legitimate high-volume users
4. Click **"Save Changes"**

**How It Works:**
- Visitors can submit the form up to your set limit per hour
- If they exceed it, they see: "Too many submissions. Please wait."
- Limit resets after 1 hour from their first submission
- Tracked by IP address (works for most cases but not perfect for corporate networks)

**When to Adjust:**
- **Too strict?** People complain they can't submit twice = increase limit
- **Too lenient?** Getting spam submissions = decrease limit

### Step 4: Add Contact Form to a Page

You need at least one page with the contact form visible to users.

#### Option A: Add to Existing Page

1. Go to **Pages → All Pages**
2. Click on the page where you want the form
3. Edit the content
4. Add this shortcode where you want the form to appear:
   ```
   [contact_form]
   ```
5. Or customize it:
   ```
   [contact_form title="Contact Us" subtitle="We'd love to hear from you"]
   ```
6. Click **Publish** or **Update**

#### Option B: Create New Contact Page

1. Go to **Pages → Add New**
2. Title: "Contact Us" (or your preferred title)
3. Add content above the form:
   ```
   This is our contact page. Fill out the form below and we'll get back to you soon.

   [contact_form title="Send us a Message"]
   ```
4. Click **Publish**
5. Copy the page URL for testing

### Step 5: Test the Form

Now test that everything works:

1. Go to the front-end page with your contact form
2. **Fill out the form with test data:**
   - Name: "Test User"
   - Email: Your test email address
   - Subject: "Test submission"
   - Message: "This is a test"
3. **Click Send Message**
4. You should see a success message: "Message sent! We'll be in touch soon."

**Verify three things:**

✅ **Success message appears** on the front-end
✅ **Auto-reply email** arrives at the test email address
✅ **Admin notification** arrives at your configured notification email

### Step 6: Verify Email Delivery

**Check Your Inboxes:**

1. **Admin Inbox** (notification email)
   - Should have: "New Contact Form Submission"
   - Contains all submitted data

2. **Test Email Inbox** (user email)
   - Should have: Auto-reply message you configured
   - May be in spam folder initially

**If emails aren't arriving:**

**Problem:** No email notifications received
- Check your configured email in Settings is correct
- Verify with your hosting provider email isn't blocked
- Check spam/junk folders
- Install "WP Mail Logging" plugin to debug

**Problem:** Emails going to spam
- Add your domain to email whitelist
- Contact hosting provider about email relay
- Check sender address isn't blocked

### Step 7: Review CRM Dashboard

1. Go to **Contact CRM** (main menu)
2. You should see your test submission
3. Explore the dashboard:
   - **Status tabs:** New, Read, Replied, Closed, Spam
   - **Search bar:** Find submissions by name/email/subject/message
   - **Charts:** Volume over last 30 days and status breakdown
   - **List table:** All submissions with quick actions

**Test Dashboard Actions:**

1. Click your test submission in the list
2. A detail panel should open showing:
   - All submitted information
   - Buttons to reply, mark spam, delete, etc.
3. Try changing the status: New → Read → Replied → Closed
4. Try adding an internal note
5. Click "Send Reply" to test the reply functionality

### Step 8: Invite Team Members (Optional)

If you want other admins to access the CRM:

1. Go to **Users → Add New**
2. Create a new user account
3. Set Role to: **Administrator**
4. New user can now access Contact CRM

**Alternative - Limited Access:**
- Create role with only `manage_crm` capability (requires custom code or plugin)
- Prevents them from seeing other WordPress admin areas

### Step 9: Customize Form Appearance (Optional)

By default, the form has professional styling. To customize:

#### Option A: Change Form Title/Subtitle

Use shortcode attributes:
```
[contact_form 
  title="Get In Touch" 
  subtitle="Our team responds within 24 hours"]
```

#### Option B: Show/Hide Phone and Subject

```
[contact_form 
  show_phone="true" 
  show_subject="false"]
```

#### Option C: Add Custom CSS Class

```
[contact_form class="contact-compact"]
```

Then add CSS in your theme:
```css
.contact-compact .wpcf-submit-btn {
  background-color: #007cba;
  padding: 12px 30px;
  font-size: 16px;
}

.contact-compact .wpcf-form-card {
  max-width: 500px;
  margin: 0 auto;
}
```

Add this to your theme's custom CSS:
1. Go to **Customize** or **Appearance → Custom CSS**
2. Paste the CSS code
3. Click Publish

#### Option D: Multiple Forms on Different Pages

Each page can have a different form configuration:

**Page 1 - General Contact:**
```
[contact_form 
  form_id="general" 
  title="General Inquiry"]
```

**Page 2 - Support:**
```
[contact_form 
  form_id="support" 
  title="Technical Support"
  show_phone="true"]
```

**Page 3 - Sales:**
```
[contact_form 
  form_id="sales" 
  title="Sales Request"
  show_subject="false"
  show_phone="true"]
```

### Step 10: REST API Configuration (Advanced)

If you want to integrate with external systems:

**Enable for Your Application:**

1. Generate WordPress Application Password:
   - Go to **Users → [Your User] → Edit**
   - Scroll to "Application Passwords"
   - Enter app name: "CRM Integration"
   - Click "Create Application Password"
   - Copy the generated password

2. Use in your external app:
```bash
curl -u username:application_password \
  "https://yourdomain.com/wp-json/wpcf/v1/submissions?status=new"
```

3. Update submission status programmatically:
```bash
curl -X PATCH -u username:application_password \
  -H "Content-Type: application/json" \
  -d '{"status":"replied"}' \
  "https://yourdomain.com/wp-json/wpcf/v1/submissions/42"
```

---

## Daily Operations Guide

### Checking New Submissions

**Morning Routine:**
1. Go to **Contact CRM** dashboard
2. Click **"New"** tab to see unread submissions
3. Review each submission
4. Change status to "Read"
5. Reply to important ones
6. Mark resolved ones as "Closed"

### Replying to Submissions

**To send a reply email:**
1. Open submission detail panel
2. Click **"Send Reply"** button
3. Compose your email response
4. Click Send
5. Status automatically changes to "Replied"

### Adding Internal Notes

**For team coordination:**
1. Open submission detail panel
2. Click **"Add Note"**
3. Type internal notes (only visible to admins)
4. Save note
5. Useful for: "John will follow up", "Waiting for more info", etc.

### Bulk Management

**To manage multiple submissions at once:**
1. Check boxes next to submissions
2. Select bulk action from dropdown:
   - Mark as Read/Replied/Closed
   - Mark as Spam
   - Delete
3. Click Apply
4. Confirm action

### Weekly Reporting

**Export submissions for reporting:**
1. Apply any filters (date range, status, etc.)
2. Click **"Export CSV"** button
3. Open in Excel/Google Sheets
4. Analyze submission trends
5. Share with team

---

## Backup & Maintenance

### Regular Backups

**The plugin creates a database table.** Ensure your hosting does regular backups:

**Verify backups:**
1. Go to **Tools → Site Health**
2. Check if backups are configured
3. Ensure plugin table is included in backups

**If not:**
1. Contact hosting support
2. Ensure they backup WordPress database
3. Ask specifically about wp_wpcf_submissions table

### Database Table Info

- **Table Name:** wp_wpcf_submissions
- **Created:** During plugin activation
- **Tracks:** All contact form submissions
- **Size:** Grows with each submission (minimal per submission)

### Cleaning Up Old Submissions

**To delete old submissions:**
1. Go to **Contact CRM** dashboard
2. Filter by status if needed
3. Search for old submissions
4. Select them
5. Use bulk action: "Delete"
6. Confirm deletion

**Note:** Deletion is permanent. Consider exporting to CSV first for records.

---

## Troubleshooting Setup Issues

### Issue: Plugin Not Activated

**Symptoms:** No "Contact CRM" menu in admin

**Solutions:**
1. Go to **Plugins** → Find "WP Contact CRM"
2. Click **Activate**
3. Verify PHP is 8.0+ (hosting control panel)
4. Check WordPress is 6.0+ (About WordPress page)

### Issue: Forms Not Showing

**Symptoms:** Shortcode appears as text `[contact_form]`

**Solutions:**
1. Ensure plugin is activated (see above)
2. Verify shortcode spelling is exactly: `[contact_form]`
3. Clear page cache if using caching plugin
4. Refresh browser hard cache: Ctrl+Shift+R (Windows) / Cmd+Shift+R (Mac)

### Issue: Emails Not Sending

**Symptoms:** No emails received at configured email address

**Solutions:**
1. Verify Settings → Notification Email is correct
2. Check spam/junk folder
3. Test WordPress email:
   - Install "WP Mail Logging" plugin
   - Submit test form
   - Check logs for errors
4. Contact hosting provider about:
   - Email relay enabled
   - Sender domain whitelisted
   - SMTP settings correct

### Issue: Form Not Submitting

**Symptoms:** "Something went wrong" error when submitting

**Solutions:**
1. Check browser console for JavaScript errors (F12)
2. Verify AJAX URL is correct:
   - Open page → Right-click → Inspect
   - Look for wpcf_submit in Network tab
3. Ensure form isn't rate-limited:
   - Try again after 1 hour
   - Or increase rate limit in Settings
4. Check form validation:
   - Ensure all required fields filled
   - Email format is valid

### Issue: Rate Limiting Too Strict

**Symptoms:** Users get "Too many submissions" error

**Solutions:**
1. Go to **Contact CRM → Settings**
2. Find **"Max Submissions per IP per Hour"**
3. Increase the number (try 10 instead of 3)
4. Click **Save Changes**
5. Users can submit again after 1 hour passes

---

## Performance Considerations

### For High-Traffic Sites

**Optimize plugin performance:**

1. **Increase rate limit** if not concerned about spam:
   - Settings → Set to 15-20

2. **Archive old submissions:**
   - Export to CSV for backup
   - Delete old submissions (Contact CRM dashboard)
   - Keeps database small and fast

3. **Use caching:**
   - Plugin itself is lightweight
   - Cache won't affect form functionality
   - Recommend W3 Total Cache or WP Super Cache

4. **Monitor database:**
   - Regularly check submissions count
   - If 10,000+, consider archival process

### Plugin Size

- **Footprint:** ~2MB
- **Database Impact:** <1KB per submission
- **Caching:** CSS/JS only loaded on pages with form
- **Performance:** Minimal impact on site speed

---

## Security Best Practices

### Configured Protections

The plugin provides:
- ✅ Rate limiting (prevents spam)
- ✅ Honeypot field (catches bots)
- ✅ AJAX nonce verification (prevents CSRF)
- ✅ Input sanitization (prevents injection)
- ✅ Email validation (prevents typos)

### Additional Steps You Should Take

1. **Keep WordPress updated:**
   - Security patches released regularly
   - Go to **Dashboard → Updates**

2. **Keep plugins updated:**
   - Always update when new versions available
   - This plugin auto-checks for updates

3. **Use strong passwords:**
   - For WordPress admin accounts
   - At least 12 characters recommended

4. **Limit admin access:**
   - Only necessary users should have admin role
   - Remove unused admin accounts

5. **Use HTTPS:**
   - Encrypts form data in transit
   - Most hosting providers include SSL
   - Verify your site URL is https://

6. **Monitor submissions:**
   - Regularly check CRM dashboard
   - Look for spam patterns
   - Mark suspicious submissions as spam

---

## FAQ

**Q: Can I delete all submissions at once?**
A: Select submissions in bulk and use Delete action, or use WP CLI for large deletions.

**Q: Can I export submissions older than today?**
A: Yes, no date filter in plugin. Manually search/filter, then export visible results.

**Q: Can I schedule auto-delete of old submissions?**
A: Not built-in. Use WP CLI or hire developer for custom solution.

**Q: What if the table doesn't get created?**
A: Manually run activation: Go to Plugins → WP Contact CRM → Deactivate → Activate.

**Q: Can I use HTML in auto-reply message?**
A: No, plain text only for safety. But email clients render line breaks.

**Q: Can I track which form each submission came from?**
A: Yes, use `form_id` attribute to distinguish: `[contact_form form_id="footer"]`

**Q: Is the form compatible with page builders?**
A: Yes, add shortcode to any text/HTML block in Elementor, Divi, Beaver Builder, etc.

---

## Next Steps

After completing setup:

1. ✅ Create a "Contact" page with form
2. ✅ Add link to contact page in navigation menu
3. ✅ Review form on mobile devices
4. ✅ Test full submission flow
5. ✅ Set up team member access if needed
6. ✅ Document your response process
7. ✅ Monitor spam submissions and adjust rate limiting
8. ✅ Create backup of database
9. ✅ Schedule weekly review of submissions

---

**Version:** 1.0.0  
**Last Updated:** May 28, 2025  
**Requires:** WordPress 6.0+, PHP 8.0+
