<?php
/**
 * Uninstall Handler
 * FILE: wp-contact-crm/uninstall.php
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

$table = $wpdb->prefix . 'wpcf_submissions';
// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$table}" );

delete_option( 'wpcf_options' );
delete_option( 'wpcf_version' );
delete_option( 'wpcf_total_submissions' );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'wpcf\_notes\_%'" );
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_wpcf\_rate\_%' OR option_name LIKE '\_transient\_timeout\_wpcf\_rate\_%'" );

global $wp_roles;
if ( ! isset( $wp_roles ) ) $wp_roles = new WP_Roles();
foreach ( array_keys( $wp_roles->roles ) as $role_slug ) {
    $role = get_role( $role_slug );
    if ( $role ) $role->remove_cap( 'manage_crm' );
}