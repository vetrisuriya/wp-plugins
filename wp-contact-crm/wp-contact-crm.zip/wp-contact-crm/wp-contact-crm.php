<?php
/**
 * Plugin Name:       WP Advanced Contact Form & CRM
 * Plugin URI:        https://vetrisuriya.in/wp-contact-crm
 * Description:       A contact form plugin with a built-in CRM. All submissions are stored
 *                    in a custom database table, with status tracking (new/read/replied/closed),
 *                    auto-reply emails, spam rate limiting, and a REST API.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Vetri Suriya
 * Author URI:        https://vetrisuriya.in/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-contact-crm
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

// ─────────────────────────────────────────────────────────────────────────────
// FIX 1 ─ PHP version guard BEFORE any require_once or register_*_hook call.
//
// WHY here, not in the activator?
// If PHP < 8.0, every file that contains a union-type return hint (int|WP_Error,
// array|null, WP_REST_Response|WP_Error) throws a PARSE error the moment PHP
// tries to compile it — before a single line of code inside the file runs.
// Putting the guard here means we never even attempt to load those files.
// ─────────────────────────────────────────────────────────────────────────────
if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
    add_action( 'admin_notices', function () {
        printf(
            '<div class="notice notice-error"><p>%s</p></div>',
            esc_html(
                sprintf(
                    /* translators: %s = PHP version string */
                    __( 'WP Contact CRM requires PHP 8.0 or higher. Your server is running PHP %s. Please upgrade PHP or contact your host.', 'wp-contact-crm' ),
                    PHP_VERSION
                )
            )
        );
    } );
    return; // Stop loading the plugin entirely on this request.
}

// ─────────────────────────────────────────────────────────────────────────────
// Constants — defined at the file root so they are available immediately,
// before plugins_loaded, including during the activation hook callback.
// ─────────────────────────────────────────────────────────────────────────────
define( 'WPCF_VERSION',  '1.0.0' );
define( 'WPCF_DIR',      plugin_dir_path( __FILE__ ) );
define( 'WPCF_URL',      plugin_dir_url( __FILE__ ) );
define( 'WPCF_BASENAME', plugin_basename( __FILE__ ) );

// ─────────────────────────────────────────────────────────────────────────────
// FIX 2 ─ Require the activator class HERE, at the file root level,
//          BEFORE calling register_activation_hook().
//
// ORIGINAL BUG:
//   register_activation_hook( __FILE__, [ 'WPCF_Activator', 'activate' ] );
//   add_action( 'plugins_loaded', function() {
//       require_once WPCF_DIR . 'includes/class-wpcf-activator.php'; // ← too late
//   });
//
// HOW ACTIVATION HOOKS WORK:
//   When a user clicks "Activate" in wp-admin/plugins.php, WordPress sends a
//   request to that same URL with ?action=activate. WordPress:
//     1. Loads wp-settings.php (fires muplugins_loaded, plugins_loaded, etc.)
//     2. But the activating plugin is NOT in the active plugins list yet, so
//        its plugins_loaded callback never runs on this request.
//     3. Then WordPress calls do_action( 'activate_' . plugin_basename ) —
//        which is what register_activation_hook wraps.
//
//   Result: class-wpcf-activator.php was never require_once'd before step 3,
//   so PHP throws: Fatal error: Class "WPCF_Activator" not found.
//
//   THE FIX: require_once the activator at the file root (top-level code),
//   so it is loaded on EVERY request — including the activation request —
//   before register_activation_hook is processed.
//
//   PERFORMANCE NOTE: This adds one require_once on every page load.
//   The activator class is lightweight (no actions hooked in constructor),
//   so the cost is negligible. Only the static activate() method is ever
//   called — and only once, during activation.
// ─────────────────────────────────────────────────────────────────────────────
require_once WPCF_DIR . 'includes/class-wpcf-activator.php';

register_activation_hook( __FILE__, array( 'WPCF_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WPCF_Activator', 'deactivate' ) );

// ─────────────────────────────────────────────────────────────────────────────
// plugins_loaded — load the rest of the plugin.
//
// All other classes load here (NOT at the file root) so they are only loaded
// when WordPress is fully bootstrapped and the active plugins list is final.
//
// FIX 3 ─ WPCF_Admin is instantiated ONCE here, then its instance is injected
// into WPCF_Settings via the constructor.
//
// ORIGINAL BUG:
//   new WPCF_Settings();  // ← WPCF_Settings::add_page() creates new WPCF_Admin()
//   new WPCF_Admin();     // ← main file creates a SECOND WPCF_Admin()
//
// WHAT WENT WRONG:
//   WPCF_Admin::__construct() calls add_action('admin_enqueue_scripts', ...).
//   With two instances, that hook fires TWICE on every admin page.
//   wp_enqueue_script() is idempotent for the handle, but wp_localize_script()
//   appends a new inline <script> block each time it is called — so the page
//   ends up with two WPCFAdmin objects, the second overwriting the first.
//   This causes JS errors when admin.js tries to read stale nonce values.
//
// THE FIX:
//   Create one WPCF_Admin instance, pass it into WPCF_Settings so the settings
//   class uses the same object as the page callback — no second construction.
// ─────────────────────────────────────────────────────────────────────────────
add_action( 'plugins_loaded', function () {

    load_plugin_textdomain(
        'wp-contact-crm',
        false,
        dirname( WPCF_BASENAME ) . '/languages'
    );

    // Load all remaining classes.
    // class-wpcf-activator.php is already loaded above — do NOT add it here.
    $classes = array(
        'WPCF_Submissions_DB',
        'WPCF_Settings',
        'WPCF_Shortcodes',
        'WPCF_Ajax',
        'WPCF_Email',
        'WPCF_Rate_Limiter',
        'WPCF_Rest_Api',
        'WPCF_Admin',
    );

    foreach ( $classes as $class ) {
        require_once WPCF_DIR . 'includes/class-'
            . strtolower( str_replace( '_', '-', $class ) )
            . '.php';
    }

    // FIX 3 — create WPCF_Admin once, inject into WPCF_Settings.
    $admin = new WPCF_Admin();
    new WPCF_Settings( $admin );  // settings receives the instance, not creates a new one
    new WPCF_Shortcodes();
    new WPCF_Ajax();
    new WPCF_Rest_Api();
    // Note: $admin hooks itself in its own constructor; no separate call needed.
} );