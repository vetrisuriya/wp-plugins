<?php
/**
 * Admin Dashboard Widget + Revenue Totals
 * FILE: wp-invoice-manager/includes/class-wpim-admin.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Admin {

    public function __construct() {
        add_action( 'wp_dashboard_setup', array( $this, 'add_dashboard_widget' ) );
    }

    public function add_dashboard_widget(): void {
        wp_add_dashboard_widget(
            'wpim_revenue_widget',
            __( 'Invoice Manager', 'wp-invoice-manager' ),
            array( $this, 'render_dashboard_widget' )
        );
    }

    public function render_dashboard_widget(): void {
        $totals = get_transient( 'wpim_dashboard_totals' );

        if ( false === $totals ) {
            $db       = new WPIM_Line_Items_DB();
            $opts     = get_option( 'wpim_options', array() );
            $tax_rate = floatval( $opts['tax_rate'] ?? 0 );

            $paid_ids = get_posts( array(
                'post_type'   => 'wpim_invoice',
                'numberposts' => -1,
                'post_status' => 'publish',
                'fields'      => 'ids',
                'meta_query'  => array( array( 'key' => '_wpim_status', 'value' => 'paid' ) ),
            ) );

            $revenue = 0.0;
            foreach ( $paid_ids as $id ) {
                $sub     = $db->get_invoice_total( (int) $id );
                $revenue += $sub + ( $sub * $tax_rate / 100 );
            }

            $unpaid_q = new WP_Query( array(
                'post_type'   => 'wpim_invoice',
                'post_status' => 'publish',
                'fields'      => 'ids',
                'meta_query'  => array( array( 'key' => '_wpim_status', 'value' => array( 'sent', 'overdue' ), 'compare' => 'IN' ) ),
            ) );

            $totals = array(
                'revenue'      => round( $revenue, 2 ),
                'unpaid_count' => $unpaid_q->found_posts,
            );
            set_transient( 'wpim_dashboard_totals', $totals, DAY_IN_SECONDS );
        }

        $currency = get_option( 'wpim_options', array() )['currency_symbol'] ?? '$';
        ?>
        <p>
            <strong><?php esc_html_e( 'Total Revenue (Paid):', 'wp-invoice-manager' ); ?></strong>
            <?php echo esc_html( $currency . number_format( $totals['revenue'], 2 ) ); ?>
        </p>
        <p>
            <strong><?php esc_html_e( 'Outstanding Invoices:', 'wp-invoice-manager' ); ?></strong>
            <?php echo absint( $totals['unpaid_count'] ); ?>
        </p>
        <p>
            <a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=wpim_invoice' ) ); ?>">
                <?php esc_html_e( 'View All Invoices →', 'wp-invoice-manager' ); ?>
            </a>
        </p>
        <?php
    }
}