<?php
/**
 * REST API: Invoice Endpoints
 * FILE: wp-invoice-manager/includes/class-wpim-rest-api.php
 * Routes:
 *   GET  /wpim/v1/invoices            — list invoices (manage_invoices required)
 *   POST /wpim/v1/invoices/{id}/pay   — mark paid (webhook secret header required)
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Rest_Api {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes(): void {
        register_rest_route( 'wpim/v1', '/invoices', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_invoices' ),
            'permission_callback' => fn() => current_user_can( 'manage_invoices' ),
            'args'                => array(
                'status'   => array( 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'per_page' => array( 'type' => 'integer', 'default' => 50, 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'wpim/v1', '/invoices/(?P<id>\d+)/pay', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'mark_paid' ),
            'permission_callback' => array( $this, 'verify_webhook_secret' ),
            'args'                => array( 'id' => array( 'type' => 'integer', 'required' => true ) ),
        ) );
    }

    public function verify_webhook_secret( WP_REST_Request $request ): bool {
        $secret   = get_option( 'wpim_options', array() )['webhook_secret'] ?? '';
        $provided = $request->get_header( 'X-WPIM-Secret' );
        return $secret && hash_equals( $secret, (string) $provided );
    }

    public function get_invoices( WP_REST_Request $request ): WP_REST_Response {
        $db     = new WPIM_Line_Items_DB();
        $args   = array( 'post_type' => 'wpim_invoice', 'posts_per_page' => $request->get_param( 'per_page' ), 'post_status' => 'publish' );
        $status = $request->get_param( 'status' );
        if ( $status ) $args['meta_query'] = array( array( 'key' => '_wpim_status', 'value' => $status ) );

        $data = array();
        foreach ( ( new WP_Query( $args ) )->posts as $post ) {
            $data[] = array(
                'id'             => $post->ID,
                'title'          => $post->post_title,
                'invoice_number' => get_post_meta( $post->ID, '_wpim_invoice_number', true ),
                'client_name'    => get_post_meta( $post->ID, '_wpim_client_name',    true ),
                'client_email'   => get_post_meta( $post->ID, '_wpim_client_email',   true ),
                'due_date'       => get_post_meta( $post->ID, '_wpim_due_date',       true ),
                'status'         => get_post_meta( $post->ID, '_wpim_status',         true ),
                'total'          => $db->get_invoice_total( $post->ID ),
            );
        }
        return new WP_REST_Response( $data, 200 );
    }

    public function mark_paid( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $id = absint( $request->get_param( 'id' ) );
        if ( ! $id || 'wpim_invoice' !== get_post_type( $id ) ) {
            return new WP_Error( 'not_found', __( 'Invoice not found.', 'wp-invoice-manager' ), array( 'status' => 404 ) );
        }
        update_post_meta( $id, '_wpim_status', 'paid' );
        update_post_meta( $id, '_wpim_paid_date', current_time( 'Y-m-d' ) );
        delete_transient( 'wpim_dashboard_totals' );
        return new WP_REST_Response( array( 'success' => true, 'invoice_id' => $id ), 200 );
    }
}