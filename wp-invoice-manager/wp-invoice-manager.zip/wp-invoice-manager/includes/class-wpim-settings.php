<?php
/**
 * Settings API — Currency, Tax, Company Details
 * FILE: wp-invoice-manager/includes/class-wpim-settings.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Settings {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_page' ) );
        add_action( 'admin_init', array( $this, 'register' ) );
    }

    public function add_page(): void {
        add_submenu_page(
            'edit.php?post_type=wpim_invoice',
            __( 'Invoice Settings', 'wp-invoice-manager' ),
            __( 'Settings',         'wp-invoice-manager' ),
            'manage_options',
            'wpim-settings',
            array( $this, 'render' )
        );
    }

    public function register(): void {
        register_setting( 'wpim_group', 'wpim_options', array( 'sanitize_callback' => array( $this, 'sanitize' ) ) );

        add_settings_section( 'wpim_company', __( 'Company Details',  'wp-invoice-manager' ), '__return_false', 'wpim-settings' );
        add_settings_field( 'company_name',   __( 'Company Name',     'wp-invoice-manager' ), array( $this, 'field_company_name'  ), 'wpim-settings', 'wpim_company' );
        add_settings_field( 'company_email',  __( 'Company Email',    'wp-invoice-manager' ), array( $this, 'field_company_email' ), 'wpim-settings', 'wpim_company' );

        add_settings_section( 'wpim_invoice_s', __( 'Invoice Settings', 'wp-invoice-manager' ), '__return_false', 'wpim-settings' );
        add_settings_field( 'currency_symbol', __( 'Currency Symbol',  'wp-invoice-manager' ), array( $this, 'field_currency' ), 'wpim-settings', 'wpim_invoice_s' );
        add_settings_field( 'tax_rate',        __( 'Tax Rate (%)',     'wp-invoice-manager' ), array( $this, 'field_tax'      ), 'wpim-settings', 'wpim_invoice_s' );
        add_settings_field( 'invoice_prefix',  __( 'Invoice Prefix',  'wp-invoice-manager' ), array( $this, 'field_prefix'   ), 'wpim-settings', 'wpim_invoice_s' );
    }

    private function get( string $key, $default = '' ) {
        return get_option( 'wpim_options', array() )[ $key ] ?? $default;
    }

    public function field_company_name():  void { echo '<input type="text"  name="wpim_options[company_name]"    value="' . esc_attr( $this->get( 'company_name' ) ) . '" class="regular-text">'; }
    public function field_company_email(): void { echo '<input type="email" name="wpim_options[company_email]"   value="' . esc_attr( $this->get( 'company_email', get_option( 'admin_email' ) ) ) . '" class="regular-text">'; }
    public function field_currency():      void { echo '<input type="text"  name="wpim_options[currency_symbol]" value="' . esc_attr( $this->get( 'currency_symbol', '$' ) ) . '" size="5"> <p class="description">' . esc_html__( 'E.g. $, £, €, ₹', 'wp-invoice-manager' ) . '</p>'; }
    public function field_tax():           void { echo '<input type="number" name="wpim_options[tax_rate]" value="' . esc_attr( $this->get( 'tax_rate', 0 ) ) . '" step="0.01" min="0" max="100"> %'; }
    public function field_prefix():        void { echo '<input type="text"  name="wpim_options[invoice_prefix]"  value="' . esc_attr( $this->get( 'invoice_prefix', 'INV' ) ) . '" size="10"> <p class="description">' . esc_html__( 'Prefix for invoice numbers, e.g. INV → INV-1001', 'wp-invoice-manager' ) . '</p>'; }

    public function sanitize( $input ): array {
        return array(
            'company_name'    => sanitize_text_field( $input['company_name']    ?? '' ),
            'company_email'   => sanitize_email(      $input['company_email']   ?? '' ),
            'currency_symbol' => sanitize_text_field( $input['currency_symbol'] ?? '$' ),
            'tax_rate'        => round( floatval( $input['tax_rate'] ?? 0 ), 2 ),
            'invoice_prefix'  => sanitize_text_field( $input['invoice_prefix']  ?? 'INV' ),
        );
    }

    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Invoice Settings', 'wp-invoice-manager' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'wpim_group' ); do_settings_sections( 'wpim-settings' ); submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public static function get_opt( string $key, $default = '' ) {
        return get_option( 'wpim_options', array() )[ $key ] ?? $default;
    }
}