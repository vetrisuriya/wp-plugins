<?php
/**
 * Shortcode: [my_invoices] — Client Portal
 * FILE: wp-invoice-manager/includes/class-wpim-shortcodes.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Shortcodes {

    public function __construct() {
        add_shortcode( 'my_invoices', array( $this, 'render' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
    }

    public function enqueue(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) || ! has_shortcode( $post->post_content, 'my_invoices' ) ) return;
        wp_enqueue_style(  'wpim-public', WPIM_URL . 'public/css/wpim-public.css', array(), WPIM_VERSION );
        wp_enqueue_script( 'wpim-public', WPIM_URL . 'public/js/wpim-public.js',  array( 'jquery' ), WPIM_VERSION, true );
        wp_localize_script( 'wpim-public', 'WPIMData', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wpim_public_nonce' ),
        ) );
    }

    /**
     * [my_invoices] — Shows a table of invoices for the logged-in user.
     * Matches the user's WordPress email against the _wpim_client_email meta.
     */
    public function render( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<p class="wpim-login-required">' .
                esc_html__( 'Please log in to view your invoices.', 'wp-invoice-manager' ) .
                ' <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">' .
                esc_html__( 'Log in', 'wp-invoice-manager' ) . '</a></p>';
        }

        $atts     = shortcode_atts( array( 'limit' => 20 ), $atts, 'my_invoices' );
        $email    = wp_get_current_user()->user_email;
        $opts     = get_option( 'wpim_options', array() );
        $currency = $opts['currency_symbol'] ?? '$';
        $tax_rate = floatval( $opts['tax_rate'] ?? 0 );
        $db       = new WPIM_Line_Items_DB();

        $query = new WP_Query( array(
            'post_type'      => 'wpim_invoice',
            'posts_per_page' => absint( $atts['limit'] ),
            'post_status'    => 'publish',
            'meta_query'     => array( array( 'key' => '_wpim_client_email', 'value' => $email ) ),
        ) );

        if ( ! $query->have_posts() ) {
            return '<p class="wpim-no-invoices">' . esc_html__( 'You have no invoices yet.', 'wp-invoice-manager' ) . '</p>';
        }

        ob_start();
        ?>
        <div class="wpim-portal">
            <h2><?php esc_html_e( 'My Invoices', 'wp-invoice-manager' ); ?></h2>
            <div class="wpim-table-wrap">
                <table class="wpim-invoice-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Invoice #',   'wp-invoice-manager' ); ?></th>
                            <th><?php esc_html_e( 'Description', 'wp-invoice-manager' ); ?></th>
                            <th><?php esc_html_e( 'Due Date',    'wp-invoice-manager' ); ?></th>
                            <th><?php esc_html_e( 'Amount',      'wp-invoice-manager' ); ?></th>
                            <th><?php esc_html_e( 'Status',      'wp-invoice-manager' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ( $query->have_posts() ) : $query->the_post();
                        $id      = get_the_ID();
                        $inv_num = get_post_meta( $id, '_wpim_invoice_number', true );
                        $due     = get_post_meta( $id, '_wpim_due_date', true );
                        $status  = get_post_meta( $id, '_wpim_status', true ) ?: 'draft';
                        $sub     = $db->get_invoice_total( $id );
                        $grand   = $sub + ( $sub * $tax_rate / 100 );
                    ?>
                    <tr class="wpim-status-<?php echo esc_attr( $status ); ?>">
                        <td><?php echo esc_html( $inv_num ?: '—' ); ?></td>
                        <td><?php the_title(); ?></td>
                        <td><?php echo esc_html( $due ?: '—' ); ?></td>
                        <td><?php echo esc_html( $currency . number_format( $grand, 2 ) ); ?></td>
                        <td><span class="wpim-badge wpim-badge-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( ucfirst( $status ) ); ?></span></td>
                    </tr>
                    <?php endwhile; wp_reset_postdata(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}