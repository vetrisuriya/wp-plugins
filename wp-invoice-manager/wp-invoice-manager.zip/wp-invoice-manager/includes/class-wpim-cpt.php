<?php
/**
 * Invoices Custom Post Type
 * FILE: wp-invoice-manager/includes/class-wpim-cpt.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_CPT {

    public function __construct() {
        add_action( 'init',       array( $this, 'register' ) );
        add_action( 'admin_init', array( $this, 'maybe_redirect' ) );
        add_filter( 'manage_wpim_invoice_posts_columns',       array( $this, 'columns' ) );
        add_action( 'manage_wpim_invoice_posts_custom_column', array( $this, 'column_content' ), 10, 2 );
    }

    public function register(): void {
        register_post_type( 'wpim_invoice', array(
            'labels' => array(
                'name'          => _x( 'Invoices', 'post type general name', 'wp-invoice-manager' ),
                'singular_name' => _x( 'Invoice',  'post type singular name', 'wp-invoice-manager' ),
                'add_new_item'  => __( 'Create Invoice', 'wp-invoice-manager' ),
                'edit_item'     => __( 'Edit Invoice',   'wp-invoice-manager' ),
                'not_found'     => __( 'No invoices found.', 'wp-invoice-manager' ),
                'menu_name'     => __( 'Invoices', 'wp-invoice-manager' ),
            ),
            'public'            => false,
            'show_ui'           => true,
            'show_in_menu'      => true,
            'show_in_rest'      => false,
            'capability_type'   => 'post',
            'capabilities'      => array( 'create_posts' => 'manage_invoices' ),
            'map_meta_cap'      => true,
            'supports'          => array( 'title' ),
            'menu_icon'         => 'dashicons-media-spreadsheet',
            'menu_position'     => 26,
            'rewrite'           => false,
        ) );
    }

    public function columns( array $cols ): array {
        return array(
            'cb'                  => $cols['cb'],
            'title'               => __( 'Description',    'wp-invoice-manager' ),
            'wpim_invoice_number' => __( 'Invoice #',      'wp-invoice-manager' ),
            'wpim_client'         => __( 'Client',         'wp-invoice-manager' ),
            'wpim_amount'         => __( 'Amount',         'wp-invoice-manager' ),
            'wpim_due_date'       => __( 'Due Date',       'wp-invoice-manager' ),
            'wpim_status'         => __( 'Status',         'wp-invoice-manager' ),
            'wpim_actions'        => __( 'Actions',        'wp-invoice-manager' ),
            'date'                => __( 'Created',        'wp-invoice-manager' ),
        );
    }

    public function column_content( string $col, int $post_id ): void {
        $opts     = get_option( 'wpim_options', array() );
        $currency = $opts['currency_symbol'] ?? '$';
        $tax_rate = floatval( $opts['tax_rate'] ?? 0 );
        $db       = new WPIM_Line_Items_DB();

        switch ( $col ) {
            case 'wpim_invoice_number':
                echo esc_html( get_post_meta( $post_id, '_wpim_invoice_number', true ) ?: '—' );
                break;
            case 'wpim_client':
                echo esc_html( get_post_meta( $post_id, '_wpim_client_name', true ) ?: '—' );
                echo '<br><small>' . esc_html( get_post_meta( $post_id, '_wpim_client_email', true ) ) . '</small>';
                break;
            case 'wpim_amount':
                $sub   = $db->get_invoice_total( $post_id );
                $grand = $sub + ( $sub * $tax_rate / 100 );
                echo esc_html( $currency . number_format( $grand, 2 ) );
                break;
            case 'wpim_due_date':
                echo esc_html( get_post_meta( $post_id, '_wpim_due_date', true ) ?: '—' );
                break;
            case 'wpim_status':
                $status = get_post_meta( $post_id, '_wpim_status', true ) ?: 'draft';
                echo '<span class="wpim-badge wpim-badge-' . esc_attr( $status ) . '">' . esc_html( ucfirst( $status ) ) . '</span>';
                break;
            case 'wpim_actions':
                $status = get_post_meta( $post_id, '_wpim_status', true );
                if ( 'paid' !== $status ) {
                    printf(
                        '<button class="button button-small wpim-mark-paid" data-invoice-id="%d">%s</button> ',
                        $post_id,
                        esc_html__( '✓ Mark Paid', 'wp-invoice-manager' )
                    );
                    printf(
                        '<button class="button button-small wpim-send-reminder" data-invoice-id="%d">%s</button>',
                        $post_id,
                        esc_html__( '✉ Remind', 'wp-invoice-manager' )
                    );
                }
                break;
        }
    }

    public function maybe_redirect(): void {
        if ( ! get_transient( 'wpim_activation_redirect' ) ) return;
        delete_transient( 'wpim_activation_redirect' );
        if ( isset( $_GET['activate-multi'] ) ) return;
        wp_safe_redirect( admin_url( 'edit.php?post_type=wpim_invoice&welcome=1' ) );
        exit;
    }
}