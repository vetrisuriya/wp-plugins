<?php
/**
 * Email Wrappers — Send Invoice + Payment Reminder
 * FILE: wp-invoice-manager/includes/class-wpim-email.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Email {

    private function opts(): array { return get_option( 'wpim_options', array() ); }

    public function send_invoice( int $invoice_id ): bool {
        $opts     = $this->opts();
        $to       = get_post_meta( $invoice_id, '_wpim_client_email', true );
        $name     = get_post_meta( $invoice_id, '_wpim_client_name',  true );
        $inv_num  = get_post_meta( $invoice_id, '_wpim_invoice_number', true );
        $due      = get_post_meta( $invoice_id, '_wpim_due_date', true );
        $db       = new WPIM_Line_Items_DB();
        $sub      = $db->get_invoice_total( $invoice_id );
        $grand    = $sub + ( $sub * floatval( $opts['tax_rate'] ?? 0 ) / 100 );
        $currency = $opts['currency_symbol'] ?? '$';
        $company  = $opts['company_name']  ?? get_bloginfo( 'name' );
        $from     = $opts['company_email'] ?? get_option( 'admin_email' );

        $subject = sprintf( __( 'Invoice %s from %s', 'wp-invoice-manager' ), $inv_num, $company );
        $message = sprintf(
            __( "Dear %1\$s,\n\nPlease find your invoice %2\$s for %3\$s due on %4\$s.\n\nThank you for your business.\n\n%5\$s", 'wp-invoice-manager' ),
            $name, $inv_num, $currency . number_format( $grand, 2 ), $due, $company
        );

        return wp_mail( $to, $subject, $message, array(
            'Content-Type: text/plain; charset=UTF-8',
            'From: ' . $company . ' <' . $from . '>',
        ) );
    }

    public function send_reminder( int $invoice_id ): bool {
        $opts    = $this->opts();
        $to      = get_post_meta( $invoice_id, '_wpim_client_email', true );
        $inv_num = get_post_meta( $invoice_id, '_wpim_invoice_number', true );
        $due     = get_post_meta( $invoice_id, '_wpim_due_date', true );
        $company = $opts['company_name'] ?? get_bloginfo( 'name' );

        return wp_mail(
            $to,
            sprintf( __( 'Payment Reminder: Invoice %s', 'wp-invoice-manager' ), $inv_num ),
            sprintf(
                __( "This is a friendly reminder that invoice %1\$s was due on %2\$s.\n\nPlease arrange payment at your earliest convenience.\n\n%3\$s", 'wp-invoice-manager' ),
                $inv_num, $due, $company
            )
        );
    }
}