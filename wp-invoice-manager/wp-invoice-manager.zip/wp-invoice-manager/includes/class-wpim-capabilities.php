<?php
/**
 * Capabilities
 * FILE: wp-invoice-manager/includes/class-wpim-capabilities.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Capabilities {

    public static function add(): void {
        $admin = get_role( 'administrator' );
        if ( $admin ) $admin->add_cap( 'manage_invoices' );
    }

    public static function remove(): void {
        global $wp_roles;
        if ( ! isset( $wp_roles ) ) $wp_roles = new WP_Roles();
        foreach ( array_keys( $wp_roles->roles ) as $slug ) {
            $role = get_role( $slug );
            if ( $role ) $role->remove_cap( 'manage_invoices' );
        }
    }
}