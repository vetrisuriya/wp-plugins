<?php
/**
 * Auto-incrementing Invoice Number Counter
 * FILE: wp-invoice-manager/includes/class-wpim-invoice-number.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Invoice_Number {

    private static string $option_key = 'wpim_invoice_counter';

    public static function next(): string {
        $current = (int) get_option( self::$option_key, 1000 );
        $next    = $current + 1;
        update_option( self::$option_key, $next, false );
        $prefix  = get_option( 'wpim_options', array() )['invoice_prefix'] ?? 'INV';
        return sanitize_text_field( $prefix ) . '-' . $next;
    }

    public static function current(): int {
        return (int) get_option( self::$option_key, 1000 );
    }

    public static function reset( int $value = 1000 ): void {
        if ( current_user_can( 'manage_options' ) ) {
            update_option( self::$option_key, absint( $value ), false );
        }
    }
}