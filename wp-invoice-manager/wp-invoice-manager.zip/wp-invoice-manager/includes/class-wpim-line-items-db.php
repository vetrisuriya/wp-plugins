<?php
/**
 * Line Items DB — CRUD for wp_wpim_line_items
 * FILE: wp-invoice-manager/includes/class-wpim-line-items-db.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Line_Items_DB {

    private string $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'wpim_line_items';
    }

    public function get_by_invoice( int $invoice_id ): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return $wpdb->get_results(
            $wpdb->prepare( "SELECT * FROM {$this->table} WHERE invoice_id = %d ORDER BY sort_order ASC", $invoice_id ),
            ARRAY_A
        ) ?: array();
    }

    public function save_items( int $invoice_id, array $items ): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->delete( $this->table, array( 'invoice_id' => $invoice_id ), array( '%d' ) );

        foreach ( $items as $order => $item ) {
            $desc     = sanitize_text_field( $item['description'] ?? '' );
            $qty      = round( floatval( $item['quantity']   ?? 1 ), 2 );
            $price    = round( floatval( $item['unit_price'] ?? 0 ), 2 );
            $subtotal = round( $qty * $price, 2 );
            if ( ! $desc && ! $qty && ! $price ) continue; // skip blank rows

            $wpdb->insert( $this->table, array(
                'invoice_id'  => $invoice_id,
                'description' => $desc,
                'quantity'    => $qty,
                'unit_price'  => $price,
                'subtotal'    => $subtotal,
                'sort_order'  => absint( $order ),
            ), array( '%d', '%s', '%f', '%f', '%f', '%d' ) );
        }
    }

    public function get_invoice_total( int $invoice_id ): float {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (float) $wpdb->get_var(
            $wpdb->prepare( "SELECT SUM(subtotal) FROM {$this->table} WHERE invoice_id = %d", $invoice_id )
        );
    }
}