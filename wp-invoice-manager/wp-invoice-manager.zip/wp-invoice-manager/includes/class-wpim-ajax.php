<?php
/**
 * AJAX Handlers: mark paid + send reminder
 * FILE: wp-invoice-manager/includes/class-wpim-ajax.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_wpim_mark_paid',     array( $this, 'mark_paid'     ) );
        add_action( 'wp_ajax_wpim_send_reminder', array( $this, 'send_reminder' ) );
    }

    public function mark_paid(): void {
        check_ajax_referer( 'wpim_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_invoices' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-invoice-manager' ) ) );
        }

        $id = absint( $_POST['invoice_id'] ?? 0 );
        if ( ! $id || 'wpim_invoice' !== get_post_type( $id ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid invoice.', 'wp-invoice-manager' ) ) );
        }

        update_post_meta( $id, '_wpim_status',    'paid' );
        update_post_meta( $id, '_wpim_paid_date', current_time( 'Y-m-d' ) );
        delete_transient( 'wpim_dashboard_totals' );

        wp_send_json_success( array(
            'message' => __( 'Invoice marked as paid.', 'wp-invoice-manager' ),
            'status'  => 'paid',
        ) );
    }

    public function send_reminder(): void {
        check_ajax_referer( 'wpim_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_invoices' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wp-invoice-manager' ) ) );
        }

        $id   = absint( $_POST['invoice_id'] ?? 0 );
        $sent = ( new WPIM_Email() )->send_reminder( $id );

        if ( $sent ) {
            wp_send_json_success( array( 'message' => __( 'Reminder email sent.', 'wp-invoice-manager' ) ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Failed to send reminder.', 'wp-invoice-manager' ) ) );
        }
    }
}