<?php
/**
 * Invoice Meta Boxes — Client Details + Invoice Details + Line Items
 * FILE: wp-invoice-manager/includes/class-wpim-meta.php
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Meta {

    public function __construct() {
        add_action( 'add_meta_boxes',          array( $this, 'add_meta_boxes' ) );
        add_action( 'save_post_wpim_invoice',  array( $this, 'save' ) );
        add_action( 'admin_enqueue_scripts',   array( $this, 'enqueue_admin' ) );
    }

    public function enqueue_admin( string $hook ): void {
        if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) return;
        $screen = get_current_screen();
        if ( ! $screen || 'wpim_invoice' !== $screen->post_type ) return;

        wp_enqueue_style(  'wpim-admin', WPIM_URL . 'admin/css/wpim-admin.css', array(), WPIM_VERSION );
        wp_enqueue_script( 'wpim-admin', WPIM_URL . 'admin/js/wpim-admin.js',  array( 'jquery' ), WPIM_VERSION, true );
        wp_localize_script( 'wpim-admin', 'WPIMAdmin', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wpim_admin_nonce' ),
            'currency' => get_option( 'wpim_options', array() )['currency_symbol'] ?? '$',
            'strings'  => array(
                'confirm_paid' => __( 'Mark this invoice as paid?',           'wp-invoice-manager' ),
                'sending'      => __( 'Sending…',                             'wp-invoice-manager' ),
                'sent'         => __( 'Reminder sent!',                       'wp-invoice-manager' ),
                'failed'       => __( 'Failed to send. Please try again.',    'wp-invoice-manager' ),
                'remind'       => __( '✉ Remind',                             'wp-invoice-manager' ),
            ),
        ) );
    }

    public function add_meta_boxes(): void {
        add_meta_box( 'wpim_client',       __( 'Client Details',  'wp-invoice-manager' ), array( $this, 'client_box'       ), 'wpim_invoice', 'normal', 'high' );
        add_meta_box( 'wpim_invoice_meta', __( 'Invoice Details', 'wp-invoice-manager' ), array( $this, 'invoice_meta_box' ), 'wpim_invoice', 'normal', 'high' );
        add_meta_box( 'wpim_line_items',   __( 'Line Items',      'wp-invoice-manager' ), array( $this, 'line_items_box'   ), 'wpim_invoice', 'normal', 'default' );
    }

    public function client_box( WP_Post $post ): void {
        wp_nonce_field( 'wpim_save_meta', 'wpim_nonce' );
        $name  = get_post_meta( $post->ID, '_wpim_client_name',    true );
        $email = get_post_meta( $post->ID, '_wpim_client_email',   true );
        $addr  = get_post_meta( $post->ID, '_wpim_client_address', true );
        ?>
        <table class="form-table">
            <tr><th><label for="wpim_client_name"><?php  esc_html_e( 'Client Name',    'wp-invoice-manager' ); ?></label></th>
                <td><input type="text"  id="wpim_client_name"    name="wpim_client_name"    value="<?php echo esc_attr( $name  ); ?>" class="large-text"></td></tr>
            <tr><th><label for="wpim_client_email"><?php esc_html_e( 'Client Email',   'wp-invoice-manager' ); ?></label></th>
                <td><input type="email" id="wpim_client_email"   name="wpim_client_email"   value="<?php echo esc_attr( $email ); ?>" class="large-text"></td></tr>
            <tr><th><label for="wpim_client_address"><?php esc_html_e( 'Address', 'wp-invoice-manager' ); ?></label></th>
                <td><textarea id="wpim_client_address" name="wpim_client_address" class="large-text" rows="3"><?php echo esc_textarea( $addr ); ?></textarea></td></tr>
        </table>
        <?php
    }

    public function invoice_meta_box( WP_Post $post ): void {
        $due_date = get_post_meta( $post->ID, '_wpim_due_date',       true );
        $status   = get_post_meta( $post->ID, '_wpim_status',         true ) ?: 'draft';
        $inv_num  = get_post_meta( $post->ID, '_wpim_invoice_number', true );
        $statuses = array(
            'draft'   => __( 'Draft',   'wp-invoice-manager' ),
            'sent'    => __( 'Sent',    'wp-invoice-manager' ),
            'paid'    => __( 'Paid',    'wp-invoice-manager' ),
            'overdue' => __( 'Overdue', 'wp-invoice-manager' ),
        );
        ?>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Invoice Number', 'wp-invoice-manager' ); ?></th>
                <td><input type="text" name="wpim_invoice_number" value="<?php echo esc_attr( $inv_num ); ?>" class="regular-text" readonly>
                    <p class="description"><?php esc_html_e( 'Auto-assigned on first save.', 'wp-invoice-manager' ); ?></p></td></tr>
            <tr><th><label for="wpim_due_date"><?php esc_html_e( 'Due Date', 'wp-invoice-manager' ); ?></label></th>
                <td><input type="date" id="wpim_due_date" name="wpim_due_date" value="<?php echo esc_attr( $due_date ); ?>"></td></tr>
            <tr><th><label for="wpim_status"><?php esc_html_e( 'Status', 'wp-invoice-manager' ); ?></label></th>
                <td><select id="wpim_status" name="wpim_status">
                    <?php foreach ( $statuses as $val => $label ) : ?>
                        <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $status, $val ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                </select></td></tr>
        </table>
        <?php
    }

    public function line_items_box( WP_Post $post ): void {
        $db    = new WPIM_Line_Items_DB();
        $items = $db->get_by_invoice( $post->ID );
        $opts  = get_option( 'wpim_options', array() );
        $curr  = $opts['currency_symbol'] ?? '$';
        ?>
        <table id="wpim-line-items-table" class="wpim-line-items" width="100%">
            <thead>
                <tr>
                    <th style="width:50%"><?php esc_html_e( 'Description', 'wp-invoice-manager' ); ?></th>
                    <th style="width:12%"><?php esc_html_e( 'Qty',         'wp-invoice-manager' ); ?></th>
                    <th style="width:15%"><?php esc_html_e( 'Unit Price',  'wp-invoice-manager' ); ?></th>
                    <th style="width:15%"><?php esc_html_e( 'Subtotal',    'wp-invoice-manager' ); ?></th>
                    <th style="width:8%"></th>
                </tr>
            </thead>
            <tbody>
                <?php if ( $items ) : ?>
                    <?php foreach ( $items as $i => $item ) : ?>
                    <tr class="wpim-line-row">
                        <td><input type="text"   name="wpim_items[<?php echo $i; ?>][description]" value="<?php echo esc_attr( $item['description'] ); ?>" class="large-text"></td>
                        <td><input type="number" name="wpim_items[<?php echo $i; ?>][quantity]"    value="<?php echo esc_attr( $item['quantity'] );    ?>" step="0.01" min="0" class="small-text wpim-qty"></td>
                        <td><input type="number" name="wpim_items[<?php echo $i; ?>][unit_price]"  value="<?php echo esc_attr( $item['unit_price'] );  ?>" step="0.01" min="0" class="small-text wpim-price"></td>
                        <td class="wpim-subtotal"><?php echo esc_html( $curr . number_format( (float) $item['subtotal'], 2 ) ); ?></td>
                        <td><button type="button" class="button button-small wpim-remove-row">✕</button></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr class="wpim-line-row">
                        <td><input type="text"   name="wpim_items[0][description]" value="" class="large-text" placeholder="<?php esc_attr_e( 'Service description…', 'wp-invoice-manager' ); ?>"></td>
                        <td><input type="number" name="wpim_items[0][quantity]"    value="1" step="0.01" min="0" class="small-text wpim-qty"></td>
                        <td><input type="number" name="wpim_items[0][unit_price]"  value="0" step="0.01" min="0" class="small-text wpim-price"></td>
                        <td class="wpim-subtotal"><?php echo esc_html( $curr . '0.00' ); ?></td>
                        <td><button type="button" class="button button-small wpim-remove-row">✕</button></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <p>
            <button type="button" class="button wpim-add-row">+ <?php esc_html_e( 'Add Line Item', 'wp-invoice-manager' ); ?></button>
        </p>
        <table class="wpim-totals">
            <tr><td><?php esc_html_e( 'Subtotal:', 'wp-invoice-manager' ); ?></td><td id="wpim-total-subtotal"><?php echo esc_html( $curr . '0.00' ); ?></td></tr>
            <tr><td><?php printf( esc_html__( 'Tax (%s%%):',    'wp-invoice-manager' ), esc_html( $opts['tax_rate'] ?? 0 ) ); ?></td><td id="wpim-total-tax"><?php echo esc_html( $curr . '0.00' ); ?></td></tr>
            <tr class="wpim-grand-total"><td><?php esc_html_e( 'Total:', 'wp-invoice-manager' ); ?></td><td id="wpim-total-grand"><?php echo esc_html( $curr . '0.00' ); ?></td></tr>
        </table>
        <?php
    }

    public function save( int $post_id ): void {
        if ( ! isset( $_POST['wpim_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wpim_nonce'] ) ), 'wpim_save_meta' ) ) return;
        if ( ! current_user_can( 'manage_invoices' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        $fields = array(
            '_wpim_client_name'    => 'sanitize_text_field',
            '_wpim_client_email'   => 'sanitize_email',
            '_wpim_client_address' => 'sanitize_textarea_field',
            '_wpim_due_date'       => 'sanitize_text_field',
            '_wpim_status'         => 'sanitize_text_field',
        );

        foreach ( $fields as $meta_key => $sanitizer ) {
            $post_key = str_replace( '_wpim_', 'wpim_', $meta_key );
            if ( isset( $_POST[ $post_key ] ) ) {
                update_post_meta( $post_id, $meta_key, call_user_func( $sanitizer, wp_unslash( $_POST[ $post_key ] ) ) );
            }
        }

        // Assign invoice number on first save.
        if ( empty( get_post_meta( $post_id, '_wpim_invoice_number', true ) ) ) {
            update_post_meta( $post_id, '_wpim_invoice_number', WPIM_Invoice_Number::next() );
        }

        // Save line items.
        if ( isset( $_POST['wpim_items'] ) && is_array( $_POST['wpim_items'] ) ) {
            $db = new WPIM_Line_Items_DB();
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $db->save_items( $post_id, wp_unslash( $_POST['wpim_items'] ) );
        }

        delete_transient( 'wpim_dashboard_totals' );
    }
}