<?php
/**
 * Activation / Deactivation Handler
 * FILE: wp-invoice-manager/includes/class-wpim-activator.php
 *
 * Loaded at the ROOT LEVEL of wp-invoice-manager.php before register_activation_hook.
 * Must NOT be inside plugins_loaded.
 *
 * @package WP_Invoice_Manager
 */
defined( 'ABSPATH' ) || exit;

class WPIM_Activator {

    public static function activate(): void {
        self::check_requirements();
        self::create_line_items_table();
        self::add_capabilities();
        self::set_default_options();
        update_option( 'wpim_version', WPIM_VERSION, false );
        flush_rewrite_rules();
        set_transient( 'wpim_activation_redirect', true, 30 );
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }

    public static function maybe_upgrade(): void {
        $installed = get_option( 'wpim_version', '0.0.0' );
        if ( version_compare( $installed, WPIM_VERSION, '>=' ) ) return;
        self::add_capabilities();
        update_option( 'wpim_version', WPIM_VERSION, false );
    }

    private static function check_requirements(): void {
        if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
            wp_die(
                sprintf( 'WP Invoice Manager requires PHP 8.0+. Your server runs PHP %s.', PHP_VERSION ),
                'PHP Version Error',
                array( 'back_link' => true )
            );
        }
    }

    private static function create_line_items_table(): void {
        global $wpdb;
        $table           = $wpdb->prefix . 'wpim_line_items';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
  id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  invoice_id  BIGINT(20) UNSIGNED NOT NULL,
  description VARCHAR(500) NOT NULL,
  quantity    DECIMAL(10,2) NOT NULL DEFAULT 1.00,
  unit_price  DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  subtotal    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  sort_order  TINYINT(3) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  KEY invoice_id (invoice_id)
) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    private static function add_capabilities(): void {
        $admin = get_role( 'administrator' );
        if ( $admin ) $admin->add_cap( 'manage_invoices' );
    }

    private static function set_default_options(): void {
        add_option( 'wpim_options', array(
            'company_name'    => get_bloginfo( 'name' ),
            'company_email'   => get_option( 'admin_email', '' ),
            'currency_symbol' => '$',
            'tax_rate'        => 0,
            'invoice_prefix'  => 'INV',
        ), '', false );

        if ( ! get_option( 'wpim_invoice_counter' ) ) {
            update_option( 'wpim_invoice_counter', 1000, false );
        }
    }
}