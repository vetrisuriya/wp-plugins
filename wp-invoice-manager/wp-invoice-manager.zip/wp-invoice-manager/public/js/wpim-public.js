/* WP Invoice Manager — Public JS (placeholder)
 * FILE: wp-invoice-manager/public/js/wpim-public.js
 * Currently the client portal is read-only. This file is reserved
 * for future features such as online payment button integration.
 */
( function ( $ ) {
    'use strict';
    // Future: download invoice as PDF, pay online via Stripe, etc.
}( jQuery ) );