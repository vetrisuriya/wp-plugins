<?php
/**
 * Uninstall — removes ALL plugin data permanently.
 * FILE: wp-invoice-manager/uninstall.php
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpim_line_items" );

delete_option( 'wpim_options' );
delete_option( 'wpim_version' );
delete_option( 'wpim_invoice_counter' );

$admin = get_role( 'administrator' );
if ( $admin ) $admin->remove_cap( 'manage_invoices' );