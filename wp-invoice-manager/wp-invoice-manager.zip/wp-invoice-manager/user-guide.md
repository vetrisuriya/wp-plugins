# WP Invoice & Billing Manager — User Guide

## Table of Contents

- [What This Plugin Does](#what-this-plugin-does)
- [After Activation](#after-activation)
- [Step 1: Configure Settings](#step-1-configure-settings)
- [Step 2: Create an Invoice](#step-2-create-an-invoice)
- [Step 3: Send the Invoice to the Client](#step-3-send-the-invoice-to-the-client)
- [Step 4: Track & Update Status](#step-4-track--update-status)
- [Step 5: Client Portal](#step-5-client-portal)
- [Shortcode Reference](#shortcode-reference)
- [Invoice Status Workflow](#invoice-status-workflow)
- [Dashboard Widget](#dashboard-widget)
- [REST API](#rest-api)
- [FAQ](#faq)

---

## What This Plugin Does

WP Invoice & Billing Manager lets you create professional invoices directly inside WordPress and share them with clients — no external billing software needed.

| Feature | Where |
|---|---|
| Create invoices with line items | **Invoices → Create Invoice** |
| Send invoice to client by email | Invoice list → **✉ Send Invoice** button |
| Send payment reminder | Invoice list → **✉ Remind** button |
| Mark invoice as paid | Invoice list → **✓ Mark Paid** button |
| Client views their invoices | Any page with `[my_invoices]` |
| Revenue summary | WordPress dashboard widget |

---

## After Activation

On first activation the plugin:
- Creates the `wp_wpim_line_items` database table
- Adds the `manage_invoices` capability to the Administrator role
- Sets the invoice counter to 1000 (first invoice = INV-1001)
- Redirects you to **Invoices → All Invoices**

---

## Step 1: Configure Settings

Go to **Invoices → Settings** before creating your first invoice.

| Setting | Default | Description |
|---|---|---|
| **Company Name** | Site name | Your business name — used in email signatures |
| **Company Email** | Admin email | The From address on all invoice emails |
| **Currency Symbol** | `$` | Shown before all amounts (e.g. `£`, `€`, `₹`, `$`) |
| **Tax Rate (%)** | `0` | Applied automatically to invoice totals (e.g. 20 for 20% VAT) |
| **Invoice Prefix** | `INV` | Prefix for invoice numbers — `INV` → INV-1001, `INV-2024` → INV-2024-1001 |

Click **Save Changes** when done.

---

## Step 2: Create an Invoice

1. Go to **Invoices → Create Invoice**
2. Enter the **invoice title** (this is the description shown to the client, e.g. "Web Design — March 2025")

### Client Details box

| Field | Description |
|---|---|
| **Client Name** | Full name of the client |
| **Client Email** | Must match the client's WordPress user email for the portal to work |
| **Address** | Client's billing address (optional, shown on the invoice email) |

### Invoice Details box

| Field | Description |
|---|---|
| **Invoice Number** | Auto-assigned on first save — shown as read-only |
| **Due Date** | Payment due date — used in reminder emails |
| **Status** | Start as **Draft**, change to **Sent** after emailing |

### Line Items box

Click **+ Add Line Item** for each service or product.

| Column | What to enter |
|---|---|
| **Description** | Service name (e.g. "Logo Design", "Hosting — Annual") |
| **Qty** | Quantity (e.g. 1, 5, 0.5 for half a day) |
| **Unit Price** | Price per unit in your set currency |
| **Subtotal** | Calculated automatically (Qty × Unit Price) |

The Total, Tax, and Grand Total update live as you type.

Click **Publish** (top right) to save the invoice.

> **Important:** Invoice number is assigned on the **first save/publish**. Once assigned it never changes — even if you update the invoice later.

---

## Step 3: Send the Invoice to the Client

### Send the initial invoice email

From the **Invoices list** (Invoices → All Invoices), find your invoice and click **✉ Send Invoice** in the Actions column. This sends an email to the client with:
- Invoice number
- Amount due (subtotal + tax)
- Due date
- Your company name and email as the sender

After sending, manually change the invoice **Status** to **Sent** in the edit screen.

### Send a payment reminder

If a due date has passed and the invoice is not yet paid, click **✉ Remind** in the Actions column. This sends a polite reminder email referencing the invoice number and due date.

---

## Step 4: Track & Update Status

### Invoice list table columns

| Column | What it shows |
|---|---|
| **Invoice #** | Auto-generated number (e.g. INV-1001) |
| **Client** | Client name and email |
| **Amount** | Grand total including tax |
| **Due Date** | Payment deadline |
| **Status** | Current badge: Draft / Sent / Paid / Overdue |
| **Actions** | ✓ Mark Paid · ✉ Remind buttons |

### Marking an invoice as paid

Click **✓ Mark Paid** in the Actions column. This:
1. Changes the status to **Paid** via AJAX (no page reload)
2. Records the payment date in post meta
3. Clears the dashboard revenue cache so totals refresh immediately
4. Removes the action buttons from that row

### Changing status manually

Open the invoice (click the title to edit it), change the **Status** dropdown in the Invoice Details box, and click **Update**.

---

## Step 5: Client Portal

### Add the shortcode to a page

1. Go to **Pages → Add New**
2. Title it "My Invoices" or "Client Portal"
3. Add `[my_invoices]` to the page content
4. Publish the page
5. Share the page URL with your clients

### What clients see

When a client **logs into WordPress** and visits the page, they see a table of all invoices where the **Client Email field matches their WordPress account email address**.

> The client must have a WordPress user account and be logged in. Their user email must exactly match the email entered in the invoice's Client Email field.

**If not logged in:** The page shows: "Please log in to view your invoices. [Log in]"
**If logged in but no invoices match:** The page shows: "You have no invoices yet."

### Setting up client accounts

1. Go to **Users → Add New**
2. Use the same email address you enter in the invoice's Client Email field
3. Set their Role to **Subscriber** (they don't need admin access)
4. Send them their login credentials
5. When they log in and visit the `[my_invoices]` page, they see their invoices

---

## Shortcode Reference

### [my_invoices]

Displays the logged-in client's invoice history in a table.

**Basic usage:**
```
[my_invoices]
```

**All attributes:**
```
[my_invoices limit="20"]
```

| Attribute | Default | Description |
|---|---|---|
| `limit` | `20` | Maximum number of invoices to show |

**What the table shows:**
- Invoice number
- Invoice title (description)
- Due date
- Grand total (subtotal + tax applied at current tax rate)
- Status badge (Draft / Sent / Paid / Overdue)

**Examples:**
```
[my_invoices]
```
Shows up to 20 invoices for the logged-in client.

```
[my_invoices limit="5"]
```
Shows only the 5 most recent invoices.

---

## Invoice Status Workflow

```
Draft
  │
  │ (you fill in details and publish)
  ▼
Sent ──────────────────► Overdue
  │                         │
  │ (client pays)           │ (client pays)
  ▼                         ▼
Paid ◄─────────────────────┘
```

| Status | Meaning | How to set |
|---|---|---|
| **Draft** | Created but not sent to client | Default on creation |
| **Sent** | Emailed to client, awaiting payment | Manually after sending |
| **Paid** | Payment received | Click ✓ Mark Paid in list, or change dropdown |
| **Overdue** | Past due date, not paid | Manually if client misses the due date |

---

## Dashboard Widget

After activation, a **Invoice Manager** widget appears on the WordPress admin home page (`/wp-admin/`). It shows:

- **Total Revenue (Paid):** Sum of all paid invoice grand totals (subtotal + tax)
- **Outstanding Invoices:** Number of invoices with status Sent or Overdue
- **View All Invoices →** link to the invoice list

The totals are cached for 24 hours for performance. The cache is automatically cleared when:
- An invoice is marked as paid (via the ✓ Mark Paid button)
- An invoice status is manually updated and saved

---

## REST API

The plugin provides two REST endpoints for payment gateway integration.

### GET — List Invoices

```
GET /wp-json/wpim/v1/invoices
```

Requires the caller to be authenticated as a user with the `manage_invoices` capability (WordPress Application Passwords recommended).

**Query parameters:**

| Parameter | Type | Description |
|---|---|---|
| `status` | string | Filter by status: `draft`, `sent`, `paid`, `overdue` |
| `per_page` | integer | Number of results (default 50) |

**Example:**
```
GET https://yoursite.com/wp-json/wpim/v1/invoices?status=sent
```

**Response format:**
```json
[
  {
    "id": 42,
    "title": "Web Design — March 2025",
    "invoice_number": "INV-1001",
    "client_name": "Jane Smith",
    "client_email": "jane@example.com",
    "due_date": "2025-03-31",
    "status": "sent",
    "total": 1200.00
  }
]
```

### POST — Mark Invoice Paid (Webhook)

```
POST /wp-json/wpim/v1/invoices/{id}/pay
```

For payment gateway webhooks (e.g. Stripe, PayPal). Requires the `X-WPIM-Secret` request header to match the webhook secret stored in `wpim_options['webhook_secret']`.

**Example (Stripe webhook handler calling this endpoint):**
```
POST https://yoursite.com/wp-json/wpim/v1/invoices/42/pay
X-WPIM-Secret: your-secret-key-here
```

**Response:**
```json
{ "success": true, "invoice_id": 42 }
```

**Setting the webhook secret:** Add `webhook_secret` to the `wpim_options` array in the database using `wp_options` table or WP-CLI:
```bash
wp option patch insert wpim_options webhook_secret "your-very-long-secret-key"
```

---

## FAQ

**The client sees "Please log in" even though they are logged in.**

The shortcode checks `is_user_logged_in()`. If this returns false even when logged in, there may be a caching conflict — the page is being served from cache before WordPress runs. Add the portal page URL to your caching plugin's exclusion list.

**The client is logged in but sees "You have no invoices yet."**

The email in the invoice's **Client Email** field must exactly match the client's WordPress user email. Check both values for typos or leading/trailing spaces.

**The invoice number is blank.**

Invoice numbers are assigned on the first **Save/Publish**. If you created an invoice before the plugin was fully activated, open the invoice and click Update — the number will be assigned.

**The tax is wrong on the portal.**

The portal calculates tax using the current **Tax Rate** in Settings at the time the page is viewed, not at the time the invoice was sent. If you change the tax rate, existing invoice totals in the portal will change. For invoices that need a fixed historical total, consider recording the tax as a line item instead.

**Can I add multiple clients to one invoice?**

No — each invoice has one client email. Create separate invoices for each client.

**Can I print or download invoices as PDF?**

Not in this version. Use your browser's Print function (Ctrl+P / Cmd+P) on the invoice edit screen, or install a PDF printer extension.

**The "Mark Paid" button does nothing.**

Open the browser console (F12). If you see a 403 error, the admin nonce may have expired — refresh the page and try again. If you see a different error, check that `manage_invoices` capability is assigned to your user role (it is assigned to Administrator by default).

**Can Editors or other roles create invoices?**

Only Administrators have `manage_invoices` by default. To grant access to other roles, add the capability:
```php
$editor = get_role( 'editor' );
$editor->add_cap( 'manage_invoices' );
```
Add this to your theme's `functions.php` or run it once with WP-CLI.