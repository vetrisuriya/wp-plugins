=== WP Invoice & Billing Manager ===
Contributors:      vetrisuriya
Tags:              invoice, billing, client portal, payment, accounting
Requires at least: 6.0
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      8.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Create, send, and track invoices inside WordPress. Client portal shortcode, line items, payment reminders, and a REST API for payment gateway integration.

== Description ==

**WP Invoice & Billing Manager** turns your WordPress site into a lightweight invoicing system. Create invoices with line items, send them to clients by email, track payment status, and let clients view their own invoices through a front-end portal.

= Core Features =

* **Invoices CPT** — dedicated admin area under Invoices with a custom list table
* **Line items** — add multiple services/products per invoice stored in a custom database table
* **Auto invoice numbers** — sequential numbers (e.g. INV-1001) assigned automatically on first save
* **Client details** — client name, email, and address stored as post meta
* **Status tracking** — Draft → Sent → Paid / Overdue
* **Send invoice email** — sends invoice details to the client's email with one click
* **Payment reminders** — send a reminder email to overdue clients from the invoice list
* **Mark as paid** — one-click status update from the invoice list table
* **`[my_invoices]` shortcode** — client portal showing a logged-in client their own invoices
* **Dashboard widget** — shows total revenue (paid) and outstanding invoice count on wp-admin home
* **Tax calculation** — configurable tax rate applied automatically to invoice totals
* **Currency settings** — set your currency symbol (€, £, $, ₹, etc.)
* **REST API** — GET invoices and POST payment confirmation from a payment gateway webhook
* **Clean uninstall** — drops the line items table and removes all options on deletion

= Shortcodes =

`[my_invoices]`
`[my_invoices limit="10"]`

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload**
2. Go to **Invoices → Settings** and fill in your Company Name, Currency, and Tax Rate
3. Go to **Invoices → Create Invoice** to write your first invoice
4. Add `[my_invoices]` to a page for client self-service access

== Frequently Asked Questions ==

= How does the client portal work? =
Add `[my_invoices]` to any page. When a client logs in and visits that page, they see a table of all invoices where the Client Email matches their WordPress account email. Visitors who are not logged in see a login prompt.

= How do invoice numbers work? =
Invoice numbers are assigned automatically on first save. The counter starts at 1000 (so the first invoice is INV-1001). You can change the prefix in **Invoices → Settings**. The counter is stored in `wp_options` and increments by one for each new invoice.

= Can I change the currency? =
Yes — go to **Invoices → Settings → Currency Symbol** and enter any symbol (e.g. £, €, ₹).

= How do I send a payment reminder? =
In the Invoices list table, find the invoice and click **✉ Remind** in the Actions column. This sends an email to the client's email address.

= How does the REST API work? =
The GET endpoint (`/wp-json/wpim/v1/invoices`) requires the user to be logged in with the `manage_invoices` capability. The POST endpoint (`/wp-json/wpim/v1/invoices/{id}/pay`) requires a secret key sent in the `X-WPIM-Secret` request header — this is for payment gateway webhooks. Set the secret in the database directly (`wpim_options['webhook_secret']`) for now; a UI for this is planned.

= What happens to invoices when I uninstall? =
The `wpim_line_items` database table is dropped. Plugin options are deleted. Invoice posts (`wpim_invoice` CPT) remain as orphaned data in `wp_posts` — delete them manually before uninstalling if you want a clean removal.

== Screenshots ==

1. Invoice list table with status badges, amount, due date, and action buttons.
2. Invoice edit screen with Client Details, Invoice Details, and Line Items meta boxes.
3. [my_invoices] client portal on the front end.
4. Dashboard widget showing revenue and outstanding count.
5. Settings page — company info, currency, tax rate, invoice prefix.

== Changelog ==

= 1.0.0 =
* Initial release. Invoices CPT, line items DB table, auto invoice numbers, client portal shortcode, send invoice email, payment reminders, mark paid, dashboard widget, REST API, Settings API.

== Upgrade Notice ==

= 1.0.0 =
Initial release. No upgrade steps required.