/* global WPIMAdmin, jQuery */
( function ( $ ) {
    'use strict';

    /* ── Mark invoice as paid ──────────────────────────────────── */
    $( document ).on( 'click', '.wpim-mark-paid', function () {
        var $btn        = $( this );
        var invoiceId   = $btn.data( 'invoice-id' );
        var $statusCell = $btn.closest( 'tr' ).find( '.wpim-status-cell, .column-wpim_status' );

        if ( ! window.confirm( WPIMAdmin.strings.confirm_paid ) ) return;
        $btn.prop( 'disabled', true );

        $.post( WPIMAdmin.ajax_url, {
            action:     'wpim_mark_paid',
            nonce:      WPIMAdmin.nonce,
            invoice_id: invoiceId,
        }, function ( res ) {
            if ( res.success ) {
                $statusCell.html( '<span class="wpim-badge wpim-badge-paid">Paid</span>' );
                $btn.closest( '.wpim-actions, .column-wpim_actions' ).html( '✓' );
            } else {
                alert( res.data.message );
                $btn.prop( 'disabled', false );
            }
        } );
    } );

    /* ── Send payment reminder ─────────────────────────────────── */
    $( document ).on( 'click', '.wpim-send-reminder', function () {
        var $btn      = $( this );
        var invoiceId = $btn.data( 'invoice-id' );
        $btn.prop( 'disabled', true ).text( WPIMAdmin.strings.sending );

        $.post( WPIMAdmin.ajax_url, {
            action:     'wpim_send_reminder',
            nonce:      WPIMAdmin.nonce,
            invoice_id: invoiceId,
        }, function ( res ) {
            alert( res.success ? WPIMAdmin.strings.sent : WPIMAdmin.strings.failed );
            $btn.prop( 'disabled', false ).text( WPIMAdmin.strings.remind );
        } );
    } );

    /* ── Line items — add / remove rows + live total calc ─────── */
    var $table    = $( '#wpim-line-items-table' );
    var currency  = ( WPIMAdmin && WPIMAdmin.currency ) ? WPIMAdmin.currency : '$';
    var taxRate   = parseFloat( $( '#wpim_tax_rate' ).val() ) || 0;

    function calcTotals() {
        var subtotal = 0;
        $table.find( '.wpim-line-row' ).each( function () {
            var qty   = parseFloat( $( this ).find( '.wpim-qty'   ).val() ) || 0;
            var price = parseFloat( $( this ).find( '.wpim-price' ).val() ) || 0;
            var sub   = parseFloat( ( qty * price ).toFixed( 2 ) );
            $( this ).find( '.wpim-subtotal' ).text( currency + sub.toFixed( 2 ) );
            subtotal += sub;
        } );
        var tax   = parseFloat( ( subtotal * taxRate / 100 ).toFixed( 2 ) );
        var grand = parseFloat( ( subtotal + tax ).toFixed( 2 ) );
        $( '#wpim-total-subtotal' ).text( currency + subtotal.toFixed( 2 ) );
        $( '#wpim-total-tax'      ).text( currency + tax.toFixed( 2 ) );
        $( '#wpim-total-grand'    ).text( currency + grand.toFixed( 2 ) );
    }

    // Initial calculation on page load.
    if ( $table.length ) calcTotals();

    // Recalculate on input change.
    $table.on( 'input', '.wpim-qty, .wpim-price', calcTotals );

    // Add a new row.
    $( document ).on( 'click', '.wpim-add-row', function () {
        var idx  = $table.find( '.wpim-line-row' ).length;
        var row  =
            '<tr class="wpim-line-row">' +
            '<td><input type="text"   name="wpim_items[' + idx + '][description]" value="" class="large-text" placeholder="Service description…"></td>' +
            '<td><input type="number" name="wpim_items[' + idx + '][quantity]"    value="1" step="0.01" min="0" class="small-text wpim-qty"></td>' +
            '<td><input type="number" name="wpim_items[' + idx + '][unit_price]"  value="0" step="0.01" min="0" class="small-text wpim-price"></td>' +
            '<td class="wpim-subtotal">' + currency + '0.00</td>' +
            '<td><button type="button" class="button button-small wpim-remove-row">✕</button></td>' +
            '</tr>';
        $table.find( 'tbody' ).append( row );
        calcTotals();
    } );

    // Remove a row.
    $table.on( 'click', '.wpim-remove-row', function () {
        $( this ).closest( 'tr' ).remove();
        calcTotals();
    } );

}( jQuery ) );