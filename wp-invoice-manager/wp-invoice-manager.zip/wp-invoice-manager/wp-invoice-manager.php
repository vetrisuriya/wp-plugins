<?php
/**
 * Plugin Name:       WP Invoice & Billing Manager
 * Plugin URI:        https://vetrisuriya.in/wp-invoice-manager
 * Description:       Create, send, and track invoices inside WordPress. Includes a client portal shortcode, line items, payment reminders, and a REST API for payment gateway integration.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Vetri Suriya
 * License:           GPL-2.0-or-later
 * Text Domain:       wp-invoice-manager
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'WPIM_VERSION',  '1.0.0' );
define( 'WPIM_DIR',      plugin_dir_path( __FILE__ ) );
define( 'WPIM_URL',      plugin_dir_url( __FILE__ ) );
define( 'WPIM_BASENAME', plugin_basename( __FILE__ ) );

/*
 * FIX — require activator at file root level BEFORE register_activation_hook.
 *
 * ORIGINAL BUG:
 *   register_activation_hook() was called before WPIM_Activator was loaded.
 *   WPIM_Activator was only required inside plugins_loaded, which fires AFTER
 *   the activation hook → Fatal error: Class "WPIM_Activator" not found.
 */
require_once WPIM_DIR . 'includes/class-wpim-activator.php';

register_activation_hook(   __FILE__, array( 'WPIM_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WPIM_Activator', 'deactivate' ) );

add_action( 'plugins_loaded', function () {
    load_plugin_textdomain( 'wp-invoice-manager', false, dirname( WPIM_BASENAME ) . '/languages' );

    // Load all classes — activator already loaded above.
    $classes = array(
        'WPIM_Line_Items_DB', 'WPIM_CPT', 'WPIM_Meta',
        'WPIM_Invoice_Number', 'WPIM_Settings', 'WPIM_Shortcodes',
        'WPIM_Ajax', 'WPIM_Rest_Api', 'WPIM_Email',
        'WPIM_Admin', 'WPIM_Capabilities',
    );

    foreach ( $classes as $class ) {
        require_once WPIM_DIR . 'includes/class-'
            . strtolower( str_replace( '_', '-', $class ) ) . '.php';
    }

    new WPIM_CPT();
    new WPIM_Meta();
    new WPIM_Settings();
    new WPIM_Shortcodes();
    new WPIM_Ajax();
    new WPIM_Rest_Api();
    new WPIM_Admin();

    WPIM_Activator::maybe_upgrade();
} );