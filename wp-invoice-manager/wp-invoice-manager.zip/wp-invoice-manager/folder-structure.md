wp-invoice-manager/
│
├── wp-invoice-manager.php         ← Bootstrap + plugin header
├── uninstall.php                  ← Drop table, delete options
├── readme.txt
│
├── includes/
│   ├── class-wpim-activator.php   ← DB table + caps setup
│   ├── class-wpim-cpt.php         ← Invoices CPT
│   ├── class-wpim-meta.php        ← Meta boxes (client info, line items)
│   ├── class-wpim-line-items-db.php ← CRUD for wp_wpim_line_items
│   ├── class-wpim-invoice-number.php ← Options API counter
│   ├── class-wpim-settings.php    ← Settings API (currency, tax, company)
│   ├── class-wpim-shortcodes.php  ← [my_invoices] client portal
│   ├── class-wpim-ajax.php        ← Mark paid, send reminder
│   ├── class-wpim-rest-api.php    ← REST endpoints
│   ├── class-wpim-email.php       ← wp_mail wrappers
│   ├── class-wpim-admin.php       ← Dashboard widget + admin list
│   └── class-wpim-capabilities.php
│
├── admin/
│   ├── css/wpim-admin.css
│   └── js/wpim-admin.js
│
├── public/
│   ├── css/wpim-public.css
│   └── js/wpim-public.js
│
└── languages/
    └── wp-invoice-manager.pot