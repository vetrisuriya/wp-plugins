=== WP Knowledge Base & FAQ System ===
Contributors:      vetrisuriya
Donate link:       https://vetrisuriya.in/donate
Tags:              knowledge base, faq, accordion, search, help desk
Requires at least: 6.0
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      8.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A complete self-service knowledge base for WordPress. Searchable articles, FAQ accordion, helpful vote buttons, Popular Articles widget, and a REST API. No page builders required.

== Description ==

**WP Knowledge Base & FAQ System** turns your WordPress site into a professional support center. Visitors can search articles, browse FAQ categories, and vote on whether content was helpful — all without leaving your site.

= Core Features =

* **KB Articles CPT** — dedicated post type with categories and tags
* **Live search** — `[kb_search]` shortcode with instant AJAX results as the visitor types
* **FAQ accordion** — `[faq_accordion]` shortcode for collapsible question-and-answer lists
* **Helpful vote buttons** — "Was this article helpful? 👍 / 👎" appended to every article automatically
* **View counter** — tracks impressions per article in a custom `wpkb_stats` database table
* **Popular Articles widget** — sidebar widget showing the most-viewed articles
* **Difficulty badge** — tag each article as Beginner, Intermediate, or Advanced via the edit screen
* **Last Reviewed date** — show visitors when the article was last checked for accuracy
* **REST API** — `GET /wp-json/wpkb/v1/articles` for headless or mobile use
* **Transient caching** — search and FAQ results are cached automatically for performance
* **Clean uninstall** — all data removed when the plugin is deleted

= Shortcodes =

**Search box:**
`[kb_search]`
`[kb_search placeholder="Find an answer…" limit="8"]`

**FAQ accordion:**
`[faq_accordion]`
`[faq_accordion category="billing" limit="10" open="0"]`

See the full shortcode reference in the **How To Use** section below.

= Who Is This For? =

* SaaS products that need a self-service help center
* E-commerce stores with product FAQs
* Service businesses documenting processes for clients
* Agencies building support portals for clients

= Privacy =

* Tracks article view counts in a custom database table (no personal data stored)
* Uses a browser cookie to prevent duplicate votes (30-day expiry, no personal data)
* Does not send any data to external servers
* On plugin deletion, all data is permanently removed

== Installation ==

= Automatic Installation =

1. Go to **Plugins → Add New**
2. Search for **WP Knowledge Base FAQ**
3. Click **Install Now**, then **Activate**

= Manual Installation =

1. Download the plugin `.zip`
2. Go to **Plugins → Add New → Upload Plugin**
3. Upload the `.zip` and click **Install Now → Activate**

= After Activation =

1. Go to **Knowledge Base → Add New** to create your first article
2. Go to **Knowledge Base → Categories** to organise articles by topic
3. Add `[kb_search]` to your main help page
4. Add `[faq_accordion]` to any page where you want an accordion FAQ
5. Go to **Knowledge Base → Settings** to customise search placeholder and vote labels

== Frequently Asked Questions ==

= How do I display a search box? =

Add `[kb_search]` to any page, post, or widget. Results appear as the visitor types — no page reload needed.

= How do I display an FAQ accordion? =

Add `[faq_accordion]` to any page. To show only one category, use `[faq_accordion category="your-category-slug"]`. Article order in the accordion follows the **Order** field in the article editor (drag-and-drop order in the list table).

= How do vote buttons work? =

Every article automatically gets 👍 / 👎 buttons added below the content. Visitors click once; a cookie prevents duplicate votes for 30 days. Vote counts are shown in brackets next to each button.

= Can I show only articles from a specific category? =

Yes — use the `category` attribute with the category slug:
`[faq_accordion category="getting-started"]`

= How do I see which articles are most popular? =

Go to **Appearance → Widgets** and add the **Popular KB Articles** widget to any sidebar. You can also check view counts in the Knowledge Base article list (the Views column).

= How do I change the "Yes, this helped!" label? =

Go to **Knowledge Base → Settings → Vote Button Labels**.

= Can I hide vote buttons on a specific article? =

Add a Custom Field named `wpkb_disable_votes` with value `1` to the article. The CPT class checks for this meta key before appending the vote box.

= Does the search work in WordPress Multisite? =

Yes — the plugin is per-site. Each site in a network has its own articles, stats table, and settings.

= How do I use the REST API? =

Send a GET request to `/wp-json/wpkb/v1/articles`. Optional query parameters:
* `search=keyword` — full-text search
* `category=slug` — filter by category slug
* `per_page=10` — results per page (default 10)
* `page=1` — page number for pagination

= What happens to my data if I uninstall the plugin? =

All plugin data is permanently removed: the `wpkb_stats` database table, all `wpkb_options` and `wpkb_version` options, all cached transients, and the `manage_kb_articles` capability from all roles. Your KB articles themselves (stored as WordPress posts) are **not** deleted — they remain in `wp_posts` as orphaned custom post type records. To remove articles too, delete them manually before uninstalling.

= Why does my theme not style the KB articles? =

KB articles use the theme's `single.php` template by default. For custom styling, add `single-wpkb_article.php` to your theme or child theme. The plugin adds the vote box and article meta via the `the_content` filter, so they work with any theme.

== Screenshots ==

1. **KB article list** — custom columns for difficulty, views, votes, and last reviewed date.
2. **Article edit screen** — difficulty level and last reviewed date in the sidebar meta box.
3. **Live search** — `[kb_search]` shortcode showing instant AJAX results.
4. **FAQ accordion** — `[faq_accordion]` with one item open.
5. **Vote buttons** — helpful / not helpful buttons appended automatically.
6. **Popular Articles widget** — sidebar showing most-viewed articles with view counts.
7. **Settings page** — search placeholder and vote label configuration.

== Changelog ==

= 1.0.0 =
*Release date: 2024-01-15*

* Initial release
* KB Articles custom post type (wpkb_article)
* wpkb_category (hierarchical) and wpkb_tag (flat) taxonomies
* Custom database table: wpkb_stats (views, votes_yes, votes_no per article)
* [kb_search] shortcode with live AJAX search and 5-minute transient cache
* [faq_accordion] shortcode with category and open-item control
* Helpful vote buttons via the_content filter with cookie-based duplicate prevention
* View counter via wp hook on singular article pages
* Popular Articles sidebar widget with 1-hour transient cache
* Difficulty level meta box (Beginner / Intermediate / Advanced)
* Last Reviewed date meta box
* Settings API page under Knowledge Base menu
* REST API endpoint: GET /wpkb/v1/articles
* Clean uninstall via uninstall.php

== Upgrade Notice ==

= 1.0.0 =
Initial release. No upgrade steps required.