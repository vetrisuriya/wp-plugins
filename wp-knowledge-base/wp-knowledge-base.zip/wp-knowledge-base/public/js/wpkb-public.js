/* global WPKBData, jQuery */
( function ( $ ) {
    'use strict';

    var searchTimer;

    /* ── Live KB Search ────────────────────────────────────────── */
    $( '#wpkb-search-input' ).on( 'keyup input', function () {
        clearTimeout( searchTimer );
        var query    = $( this ).val().trim();
        var limit    = $( this ).data( 'limit' ) || 5;
        var $results = $( '#wpkb-search-results' );

        if ( query.length < 2 ) { $results.hide().empty(); return; }

        searchTimer = setTimeout( function () {
            $results.html( '<p class="wpkb-no-results">Searching…</p>' ).show();
            $.post( WPKBData.ajax_url, {
                action: 'wpkb_search', nonce: WPKBData.nonce, query: query, limit: limit,
            }, function ( res ) {
                $results.empty();
                if ( res.success && res.data.results.length ) {
                    $.each( res.data.results, function ( i, item ) {
                        $results.append(
                            '<a class="wpkb-result-item" href="' + item.url + '" role="option">' +
                            '<strong>' + $( '<div>' ).text( item.title ).html() + '</strong>' +
                            '<span>' + $( '<div>' ).text( item.excerpt ).html() + '</span>' +
                            '</a>'
                        );
                    } );
                    $results.show();
                } else {
                    $results.html( '<p class="wpkb-no-results">No results found for "' + $( '<div>' ).text( query ).html() + '".</p>' ).show();
                }
            } );
        }, 350 );
    } );

    $( document ).on( 'click', function ( e ) {
        if ( ! $( e.target ).closest( '.wpkb-search-wrap' ).length ) {
            $( '#wpkb-search-results' ).hide();
        }
    } );

    $( document ).on( 'keydown', '#wpkb-search-input', function ( e ) {
        if ( e.key === 'Escape' ) $( '#wpkb-search-results' ).hide();
    } );

    /* ── FAQ Accordion ─────────────────────────────────────────── */
    $( document ).on( 'click', '.wpkb-accordion-trigger', function () {
        var $item    = $( this ).closest( '.wpkb-accordion-item' );
        var $content = $item.find( '.wpkb-accordion-content' );
        var isOpen   = $item.hasClass( 'wpkb-open' );

        /* Close all */
        $( '.wpkb-accordion-item.wpkb-open' ).each( function () {
            $( this ).removeClass( 'wpkb-open' );
            $( this ).find( '.wpkb-accordion-content' ).slideUp( 200 );
            $( this ).find( '.wpkb-accordion-trigger' ).attr( 'aria-expanded', 'false' );
            $( this ).find( '.wpkb-accordion-icon' ).text( '+' );
        } );

        /* Open clicked (if was closed) */
        if ( ! isOpen ) {
            $item.addClass( 'wpkb-open' );
            $content.slideDown( 200 );
            $( this ).attr( 'aria-expanded', 'true' ).find( '.wpkb-accordion-icon' ).text( '−' );
        }
    } );

    /* ── Vote Buttons ──────────────────────────────────────────── */
    $( document ).on( 'click', '.wpkb-vote-btn', function () {
        var $btn      = $( this );
        var articleId = $btn.data( 'article' );
        var vote      = $btn.data( 'vote' );
        var $box      = $( '#wpkb-vote-' + articleId );

        $box.find( '.wpkb-vote-btn' ).prop( 'disabled', true );

        $.post( WPKBData.ajax_url, {
            action: 'wpkb_vote', nonce: WPKBData.nonce, article_id: articleId, vote: vote,
        }, function ( res ) {
            if ( res.success ) {
                $box.find( '.wpkb-vote-buttons' ).html(
                    '<p class="wpkb-voted-message">✅ ' + res.data.message + '</p>'
                );
            } else {
                $box.find( '.wpkb-vote-question' ).text( res.data.message );
                $box.find( '.wpkb-vote-btn' ).prop( 'disabled', false );
            }
        } );
    } );

}( jQuery ) );