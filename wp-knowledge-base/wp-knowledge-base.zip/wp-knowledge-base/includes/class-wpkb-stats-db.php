<?php
/**
 * Stats DB — views and votes CRUD
 * FILE: wp-knowledge-base/includes/class-wpkb-stats-db.php
 * @package WP_Knowledge_Base
 */
defined( 'ABSPATH' ) || exit;

class WPKB_Stats_DB {

    private string $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'wpkb_stats';
    }

    public function record_view( int $article_id ): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( $wpdb->prepare(
            "INSERT INTO {$this->table} (article_id, views)
             VALUES (%d, 1)
             ON DUPLICATE KEY UPDATE views = views + 1",
            $article_id
        ) );
        delete_transient( 'wpkb_popular_articles' );
    }

    public function record_vote( int $article_id, string $vote ): void {
        global $wpdb;
        $column = 'yes' === $vote ? 'votes_yes' : 'votes_no';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( $wpdb->prepare(
            "INSERT INTO {$this->table} (article_id, {$column})
             VALUES (%d, 1)
             ON DUPLICATE KEY UPDATE {$column} = {$column} + 1",
            $article_id
        ) );
    }

    public function get_votes( int $article_id ): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT votes_yes, votes_no FROM {$this->table} WHERE article_id = %d",
            $article_id
        ), ARRAY_A );
        return array( 'yes' => $row['votes_yes'] ?? 0, 'no' => $row['votes_no'] ?? 0 );
    }

    public function get_popular( int $limit = 5 ): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT article_id, views FROM {$this->table} ORDER BY views DESC LIMIT %d",
            $limit
        ), ARRAY_A ) ?: array();
    }
}