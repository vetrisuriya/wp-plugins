<?php
/**
 * Plugin Activation / Deactivation
 * FILE: wp-knowledge-base/includes/class-wpkb-activator.php
 *
 * Loaded at the ROOT LEVEL of wp-knowledge-base.php (before register_activation_hook).
 * Must NOT be inside plugins_loaded — the activation hook fires before that.
 *
 * @package WP_Knowledge_Base
 */

defined( 'ABSPATH' ) || exit;

class WPKB_Activator {

    public static function activate(): void {
        self::check_requirements();
        self::create_stats_table();
        self::add_capabilities();
        self::set_default_options();
        update_option( 'wpkb_version', WPKB_VERSION, false );
        flush_rewrite_rules();
        set_transient( 'wpkb_activation_redirect', true, 30 );
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }

    public static function maybe_upgrade(): void {
        $installed = get_option( 'wpkb_version', '0.0.0' );
        if ( version_compare( $installed, WPKB_VERSION, '>=' ) ) return;
        self::add_capabilities();
        update_option( 'wpkb_version', WPKB_VERSION, false );
    }

    private static function check_requirements(): void {
        if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
            wp_die(
                sprintf( 'WP Knowledge Base requires PHP 8.0+. Your server runs PHP %s.', PHP_VERSION ),
                'PHP Version Error',
                array( 'back_link' => true )
            );
        }
    }

    private static function create_stats_table(): void {
        global $wpdb;
        $table           = $wpdb->prefix . 'wpkb_stats';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
  id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  article_id  BIGINT(20) UNSIGNED NOT NULL,
  views       BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
  votes_yes   INT(11) UNSIGNED NOT NULL DEFAULT 0,
  votes_no    INT(11) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  UNIQUE KEY article_id (article_id)
) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    private static function add_capabilities(): void {
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin->add_cap( 'manage_kb_articles' );
        }
    }

    private static function set_default_options(): void {
        add_option( 'wpkb_options', array(
            'search_placeholder' => 'Search knowledge base…',
            'articles_per_page'  => 10,
            'vote_yes_label'     => 'Yes, this helped!',
            'vote_no_label'      => 'No, I need more help.',
        ), '', false );
    }
}