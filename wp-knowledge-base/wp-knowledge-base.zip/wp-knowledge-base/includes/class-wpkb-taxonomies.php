<?php
/**
 * KB Taxonomies: wpkb_category + wpkb_tag
 * FILE: wp-knowledge-base/includes/class-wpkb-taxonomies.php
 * @package WP_Knowledge_Base
 */
defined( 'ABSPATH' ) || exit;

class WPKB_Taxonomies {

    public function __construct() {
        add_action( 'init', array( $this, 'register' ) );
    }

    public function register(): void {
        // Category — hierarchical (like folders).
        register_taxonomy( 'wpkb_category', 'wpkb_article', array(
            'labels' => array(
                'name'          => _x( 'KB Categories', 'taxonomy general name', 'wp-knowledge-base' ),
                'singular_name' => _x( 'KB Category',  'taxonomy singular name', 'wp-knowledge-base' ),
                'add_new_item'  => __( 'Add New Category', 'wp-knowledge-base' ),
                'menu_name'     => __( 'Categories',       'wp-knowledge-base' ),
            ),
            'hierarchical'      => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => array( 'slug' => 'kb-category' ),
        ) );

        // Tag — flat (like labels).
        register_taxonomy( 'wpkb_tag', 'wpkb_article', array(
            'labels' => array(
                'name'          => _x( 'KB Tags', 'taxonomy general name', 'wp-knowledge-base' ),
                'singular_name' => _x( 'KB Tag',  'taxonomy singular name', 'wp-knowledge-base' ),
                'menu_name'     => __( 'Tags', 'wp-knowledge-base' ),
            ),
            'hierarchical'      => false,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => array( 'slug' => 'kb-tag' ),
        ) );
    }
}