<?php
/**
 * Article Meta Boxes: Difficulty level + Last reviewed date
 * FILE: wp-knowledge-base/includes/class-wpkb-meta.php
 * @package WP_Knowledge_Base
 */
defined( 'ABSPATH' ) || exit;

class WPKB_Meta {

    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
        add_action( 'save_post',      array( $this, 'save' ) );
    }

    public function add_meta_boxes(): void {
        add_meta_box(
            'wpkb_article_meta',
            __( 'Article Details', 'wp-knowledge-base' ),
            array( $this, 'render' ),
            'wpkb_article',
            'side',
            'high'
        );
    }

    public function render( WP_Post $post ): void {
        wp_nonce_field( 'wpkb_meta_save', 'wpkb_meta_nonce' );
        $difficulty = get_post_meta( $post->ID, '_wpkb_difficulty', true ) ?: 'beginner';
        $reviewed   = get_post_meta( $post->ID, '_wpkb_reviewed_date', true );
        ?>
        <p>
            <label for="wpkb_difficulty" style="font-weight:600;display:block;margin-bottom:4px;">
                <?php esc_html_e( 'Difficulty Level', 'wp-knowledge-base' ); ?>
            </label>
            <select id="wpkb_difficulty" name="wpkb_difficulty" style="width:100%">
                <?php
                $levels = array(
                    'beginner'     => __( '🟢 Beginner',     'wp-knowledge-base' ),
                    'intermediate' => __( '🟡 Intermediate', 'wp-knowledge-base' ),
                    'advanced'     => __( '🔴 Advanced',     'wp-knowledge-base' ),
                );
                foreach ( $levels as $val => $label ) {
                    printf(
                        '<option value="%s"%s>%s</option>',
                        esc_attr( $val ),
                        selected( $difficulty, $val, false ),
                        esc_html( $label )
                    );
                }
                ?>
            </select>
        </p>
        <p>
            <label for="wpkb_reviewed_date" style="font-weight:600;display:block;margin-bottom:4px;">
                <?php esc_html_e( 'Last Reviewed Date', 'wp-knowledge-base' ); ?>
            </label>
            <input type="date"
                   id="wpkb_reviewed_date"
                   name="wpkb_reviewed_date"
                   value="<?php echo esc_attr( $reviewed ); ?>"
                   style="width:100%">
            <span style="font-size:11px;color:#646970;">
                <?php esc_html_e( 'Shown to readers as "Last updated" on the article.', 'wp-knowledge-base' ); ?>
            </span>
        </p>
        <?php
    }

    public function save( int $post_id ): void {
        if ( ! isset( $_POST['wpkb_meta_nonce'] ) ) return;
        if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wpkb_meta_nonce'] ) ), 'wpkb_meta_save' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        $difficulty = sanitize_text_field( $_POST['wpkb_difficulty'] ?? '' );
        if ( in_array( $difficulty, array( 'beginner', 'intermediate', 'advanced' ), true ) ) {
            update_post_meta( $post_id, '_wpkb_difficulty', $difficulty );
        }

        $reviewed = sanitize_text_field( $_POST['wpkb_reviewed_date'] ?? '' );
        update_post_meta( $post_id, '_wpkb_reviewed_date', $reviewed );
    }
}