<?php
/**
 * AJAX Handlers: vote + live search
 * FILE: wp-knowledge-base/includes/class-wpkb-ajax.php
 * @package WP_Knowledge_Base
 */
defined( 'ABSPATH' ) || exit;

class WPKB_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_wpkb_vote',          array( $this, 'handle_vote' ) );
        add_action( 'wp_ajax_nopriv_wpkb_vote',   array( $this, 'handle_vote' ) );
        add_action( 'wp_ajax_wpkb_search',        array( $this, 'handle_search' ) );
        add_action( 'wp_ajax_nopriv_wpkb_search', array( $this, 'handle_search' ) );
    }

    public function handle_vote(): void {
        check_ajax_referer( 'wpkb_nonce', 'nonce' );

        $article_id = absint( $_POST['article_id'] ?? 0 );
        $vote       = sanitize_text_field( $_POST['vote'] ?? '' );

        if ( ! $article_id || 'wpkb_article' !== get_post_type( $article_id ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid article.', 'wp-knowledge-base' ) ) );
        }
        if ( ! in_array( $vote, array( 'yes', 'no' ), true ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid vote type.', 'wp-knowledge-base' ) ) );
        }

        // Cookie-based duplicate vote prevention.
        $cookie_key = 'wpkb_voted_' . $article_id;
        if ( isset( $_COOKIE[ $cookie_key ] ) ) {
            wp_send_json_error( array( 'message' => __( 'You have already voted on this article.', 'wp-knowledge-base' ) ) );
        }

        $stats = new WPKB_Stats_DB();
        $stats->record_vote( $article_id, $vote );
        setcookie( $cookie_key, '1', time() + ( 30 * DAY_IN_SECONDS ), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );

        $votes = $stats->get_votes( $article_id );
        wp_send_json_success( array(
            'message'   => __( 'Thanks for your feedback!', 'wp-knowledge-base' ),
            'votes_yes' => $votes['yes'],
            'votes_no'  => $votes['no'],
        ) );
    }

    public function handle_search(): void {
        check_ajax_referer( 'wpkb_nonce', 'nonce' );

        $query = sanitize_text_field( $_POST['query'] ?? '' );
        $limit = absint( $_POST['limit'] ?? 5 );

        if ( strlen( $query ) < 2 ) {
            wp_send_json_success( array( 'results' => array() ) );
        }

        $cache_key = 'wpkb_search_' . md5( $query . $limit );
        $results   = get_transient( $cache_key );

        if ( false === $results ) {
            $q       = new WP_Query( array(
                'post_type'      => 'wpkb_article',
                'posts_per_page' => $limit,
                'post_status'    => 'publish',
                's'              => $query,
            ) );
            $results = array();
            foreach ( $q->posts as $post ) {
                $results[] = array(
                    'id'      => $post->ID,
                    'title'   => $post->post_title,
                    'excerpt' => wp_trim_words( $post->post_content, 15 ),
                    'url'     => get_permalink( $post->ID ),
                );
            }
            set_transient( $cache_key, $results, 5 * MINUTE_IN_SECONDS );
        }

        wp_send_json_success( array( 'results' => $results ) );
    }
}