<?php
/**
 * Shortcodes: [kb_search] and [faq_accordion]
 * FILE: wp-knowledge-base/includes/class-wpkb-shortcodes.php
 * @package WP_Knowledge_Base
 */
defined( 'ABSPATH' ) || exit;

class WPKB_Shortcodes {

    public function __construct() {
        add_shortcode( 'kb_search',     array( $this, 'render_search' ) );
        add_shortcode( 'faq_accordion', array( $this, 'render_faq' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
    }

    public function enqueue(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) ) return;

        $needs = has_shortcode( $post->post_content, 'kb_search' )
              || has_shortcode( $post->post_content, 'faq_accordion' )
              || is_singular( 'wpkb_article' );

        if ( ! $needs ) return;

        wp_enqueue_style(  'wpkb-public', WPKB_URL . 'public/css/wpkb-public.css', array(), WPKB_VERSION );
        wp_enqueue_script( 'wpkb-public', WPKB_URL . 'public/js/wpkb-public.js',  array( 'jquery' ), WPKB_VERSION, true );
        wp_localize_script( 'wpkb-public', 'WPKBData', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wpkb_nonce' ),
        ) );
    }

    /**
     * [kb_search placeholder="Search…" limit="5"]
     */
    public function render_search( array $atts ): string {
        $opts = get_option( 'wpkb_options', array() );
        $atts = shortcode_atts( array(
            'placeholder' => $opts['search_placeholder'] ?? __( 'Search articles…', 'wp-knowledge-base' ),
            'limit'       => $opts['articles_per_page']  ?? 5,
        ), $atts, 'kb_search' );

        ob_start();
        ?>
        <div class="wpkb-search-wrap">
            <div class="wpkb-search-inner">
                <span class="wpkb-search-icon" aria-hidden="true">🔍</span>
                <input type="search"
                       id="wpkb-search-input"
                       class="wpkb-search-input"
                       placeholder="<?php echo esc_attr( $atts['placeholder'] ); ?>"
                       data-limit="<?php echo absint( $atts['limit'] ); ?>"
                       autocomplete="off"
                       aria-label="<?php echo esc_attr( $atts['placeholder'] ); ?>">
            </div>
            <div id="wpkb-search-results"
                 class="wpkb-search-results"
                 role="listbox"
                 aria-live="polite"
                 style="display:none;"></div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * [faq_accordion category="billing" limit="10" open="0"]
     */
    public function render_faq( array $atts ): string {
        $atts = shortcode_atts( array(
            'category' => '',
            'limit'    => 10,
            'open'     => 0,    // 0 = first item open; -1 = all closed
            'ordered'  => 'true',
        ), $atts, 'faq_accordion' );

        $args = array(
            'post_type'      => 'wpkb_article',
            'posts_per_page' => absint( $atts['limit'] ),
            'post_status'    => 'publish',
            'orderby'        => 'menu_order',
            'order'          => 'ASC',
        );

        if ( $atts['category'] ) {
            $args['tax_query'] = array( array(
                'taxonomy' => 'wpkb_category',
                'field'    => 'slug',
                'terms'    => sanitize_text_field( $atts['category'] ),
            ) );
        }

        $cache_key = 'wpkb_faq_' . md5( serialize( $atts ) );
        $articles  = get_transient( $cache_key );

        if ( false === $articles ) {
            $articles = ( new WP_Query( $args ) )->posts;
            set_transient( $cache_key, $articles, HOUR_IN_SECONDS );
        }

        if ( empty( $articles ) ) {
            return '<p class="wpkb-no-results">' . esc_html__( 'No FAQ articles found.', 'wp-knowledge-base' ) . '</p>';
        }

        ob_start();
        echo '<div class="wpkb-accordion" role="list">';
        foreach ( $articles as $i => $article ) {
            $is_open = ( (int) $atts['open'] === $i );
            ?>
            <div class="wpkb-accordion-item <?php echo $is_open ? 'wpkb-open' : ''; ?>" role="listitem">
                <button class="wpkb-accordion-trigger"
                        aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>"
                        aria-controls="wpkb-panel-<?php echo esc_attr( $article->ID ); ?>">
                    <span class="wpkb-accordion-title"><?php echo esc_html( $article->post_title ); ?></span>
                    <span class="wpkb-accordion-icon" aria-hidden="true"><?php echo $is_open ? '−' : '+'; ?></span>
                </button>
                <div class="wpkb-accordion-content"
                     id="wpkb-panel-<?php echo esc_attr( $article->ID ); ?>"
                     <?php echo $is_open ? '' : 'style="display:none"'; ?>>
                    <?php echo wp_kses_post( apply_filters( 'the_content', $article->post_content ) ); ?>
                    <p class="wpkb-read-more">
                        <a href="<?php echo esc_url( get_permalink( $article->ID ) ); ?>">
                            <?php esc_html_e( 'Read full article →', 'wp-knowledge-base' ); ?>
                        </a>
                    </p>
                </div>
            </div>
            <?php
        }
        echo '</div>';
        return ob_get_clean();
    }
}