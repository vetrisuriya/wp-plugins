<?php
/**
 * REST API: GET /wpkb/v1/articles
 * FILE: wp-knowledge-base/includes/class-wpkb-rest-api.php
 * @package WP_Knowledge_Base
 */
defined( 'ABSPATH' ) || exit;

class WPKB_Rest_Api {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes(): void {
        register_rest_route( 'wpkb/v1', '/articles', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_articles' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'search'   => array( 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'category' => array( 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'per_page' => array( 'type' => 'integer', 'default' => 10, 'sanitize_callback' => 'absint' ),
                'page'     => array( 'type' => 'integer', 'default' => 1,  'sanitize_callback' => 'absint' ),
            ),
        ) );
    }

    public function get_articles( WP_REST_Request $request ): WP_REST_Response {
        $args = array(
            'post_type'      => 'wpkb_article',
            'posts_per_page' => $request->get_param( 'per_page' ),
            'paged'          => $request->get_param( 'page' ),
            'post_status'    => 'publish',
        );
        if ( $s = $request->get_param( 'search' ) )   $args['s'] = $s;
        if ( $c = $request->get_param( 'category' ) ) {
            $args['tax_query'] = array( array( 'taxonomy' => 'wpkb_category', 'field' => 'slug', 'terms' => $c ) );
        }

        $query  = new WP_Query( $args );
        $stats  = new WPKB_Stats_DB();
        $data   = array();

        foreach ( $query->posts as $post ) {
            $votes    = $stats->get_votes( $post->ID );
            $terms    = get_the_terms( $post->ID, 'wpkb_category' );
            $data[]   = array(
                'id'         => $post->ID,
                'title'      => $post->post_title,
                'excerpt'    => get_the_excerpt( $post ),
                'url'        => get_permalink( $post->ID ),
                'difficulty' => get_post_meta( $post->ID, '_wpkb_difficulty', true ) ?: 'beginner',
                'reviewed'   => get_post_meta( $post->ID, '_wpkb_reviewed_date', true ),
                'categories' => $terms ? wp_list_pluck( $terms, 'name' ) : array(),
                'votes_yes'  => (int) $votes['yes'],
                'votes_no'   => (int) $votes['no'],
            );
        }

        $response = new WP_REST_Response( $data, 200 );
        $response->header( 'X-WP-Total',      $query->found_posts );
        $response->header( 'X-WP-TotalPages', $query->max_num_pages );
        return $response;
    }
}