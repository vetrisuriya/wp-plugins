<?php
/**
 * Custom Post Type: KB Articles
 * FILE: wp-knowledge-base/includes/class-wpkb-cpt.php
 * @package WP_Knowledge_Base
 */
defined( 'ABSPATH' ) || exit;

class WPKB_CPT {

    public function __construct() {
        add_action( 'init',        array( $this, 'register' ) );
        add_filter( 'the_content', array( $this, 'append_vote_buttons' ) );
        add_action( 'admin_init',  array( $this, 'maybe_redirect' ) );
    }

    public function register(): void {
        register_post_type( 'wpkb_article', array(
            'labels' => array(
                'name'               => _x( 'KB Articles', 'post type general name', 'wp-knowledge-base' ),
                'singular_name'      => _x( 'KB Article',  'post type singular name', 'wp-knowledge-base' ),
                'add_new'            => __( 'Add New',          'wp-knowledge-base' ),
                'add_new_item'       => __( 'Add New Article',  'wp-knowledge-base' ),
                'edit_item'          => __( 'Edit Article',     'wp-knowledge-base' ),
                'new_item'           => __( 'New Article',      'wp-knowledge-base' ),
                'view_item'          => __( 'View Article',     'wp-knowledge-base' ),
                'search_items'       => __( 'Search Articles',  'wp-knowledge-base' ),
                'not_found'          => __( 'No articles found.', 'wp-knowledge-base' ),
                'not_found_in_trash' => __( 'No articles in trash.', 'wp-knowledge-base' ),
                'menu_name'          => __( 'Knowledge Base',   'wp-knowledge-base' ),
            ),
            'public'            => true,
            'has_archive'       => true,
            'rewrite'           => array( 'slug' => 'kb' ),
            'supports'          => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'page-attributes' ),
            'show_in_rest'      => true,
            'menu_icon'         => 'dashicons-book-alt',
            'menu_position'     => 6,
            'capability_type'   => 'post',
        ) );
    }

    /** Append "Was this helpful?" vote buttons after article content. */
    public function append_vote_buttons( string $content ): string {
        if ( ! is_singular( 'wpkb_article' ) || is_admin() ) {
            return $content;
        }

        $article_id = get_the_ID();
        $stats      = new WPKB_Stats_DB();
        $votes      = $stats->get_votes( $article_id );
        $opts       = get_option( 'wpkb_options', array() );
        $yes_label  = $opts['vote_yes_label'] ?? __( 'Yes, this helped!', 'wp-knowledge-base' );
        $no_label   = $opts['vote_no_label']  ?? __( 'No, I need more help.', 'wp-knowledge-base' );

        ob_start();
        ?>
        <div class="wpkb-vote-box" id="wpkb-vote-<?php echo esc_attr( $article_id ); ?>">
            <p class="wpkb-vote-question">
                <?php esc_html_e( 'Was this article helpful?', 'wp-knowledge-base' ); ?>
            </p>
            <div class="wpkb-vote-buttons">
                <button class="wpkb-vote-btn wpkb-vote-btn--yes"
                        data-article="<?php echo esc_attr( $article_id ); ?>"
                        data-vote="yes">
                    👍 <?php echo esc_html( $yes_label ); ?>
                    <span class="wpkb-vote-count">(<?php echo absint( $votes['yes'] ); ?>)</span>
                </button>
                <button class="wpkb-vote-btn wpkb-vote-btn--no"
                        data-article="<?php echo esc_attr( $article_id ); ?>"
                        data-vote="no">
                    👎 <?php echo esc_html( $no_label ); ?>
                    <span class="wpkb-vote-count">(<?php echo absint( $votes['no'] ); ?>)</span>
                </button>
            </div>
        </div>
        <?php
        return $content . ob_get_clean();
    }

    public function maybe_redirect(): void {
        if ( ! get_transient( 'wpkb_activation_redirect' ) ) return;
        delete_transient( 'wpkb_activation_redirect' );
        if ( isset( $_GET['activate-multi'] ) ) return;
        wp_safe_redirect( admin_url( 'edit.php?post_type=wpkb_article&welcome=1' ) );
        exit;
    }
}