<?php
/**
 * Popular KB Articles Widget
 * FILE: wp-knowledge-base/includes/class-wpkb-widget.php
 * @package WP_Knowledge_Base
 */
defined( 'ABSPATH' ) || exit;

class WPKB_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'wpkb_popular',
            __( 'Popular KB Articles', 'wp-knowledge-base' ),
            array( 'description' => __( 'Shows the most-viewed knowledge base articles.', 'wp-knowledge-base' ) )
        );
        add_action( 'widgets_init', function () { register_widget( 'WPKB_Widget' ); } );
    }

    public function widget( $args, $instance ): void {
        $title = apply_filters( 'widget_title', $instance['title'] ?? '' );
        $limit = absint( $instance['limit'] ?? 5 );

        echo wp_kses_post( $args['before_widget'] );
        if ( $title ) echo wp_kses_post( $args['before_title'] . esc_html( $title ) . $args['after_title'] );

        $popular = get_transient( 'wpkb_popular_articles' );
        if ( false === $popular ) {
            $rows    = ( new WPKB_Stats_DB() )->get_popular( $limit );
            $popular = array();
            foreach ( $rows as $row ) {
                $post = get_post( absint( $row['article_id'] ) );
                if ( $post && 'publish' === $post->post_status ) {
                    $popular[] = array(
                        'title' => $post->post_title,
                        'url'   => get_permalink( $post->ID ),
                        'views' => absint( $row['views'] ),
                    );
                }
            }
            set_transient( 'wpkb_popular_articles', $popular, HOUR_IN_SECONDS );
        }

        if ( ! empty( $popular ) ) {
            echo '<ul class="wpkb-popular-list">';
            foreach ( $popular as $item ) {
                printf(
                    '<li><a href="%s">%s</a> <span class="wpkb-views">(%s)</span></li>',
                    esc_url( $item['url'] ),
                    esc_html( $item['title'] ),
                    sprintf( esc_html__( '%d views', 'wp-knowledge-base' ), $item['views'] )
                );
            }
            echo '</ul>';
        }

        echo wp_kses_post( $args['after_widget'] );
    }

    public function form( $instance ): void {
        $title = $instance['title'] ?? __( 'Popular Articles', 'wp-knowledge-base' );
        $limit = $instance['limit'] ?? 5;
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'wp-knowledge-base' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>"><?php esc_html_e( 'Number of articles:', 'wp-knowledge-base' ); ?></label>
            <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>" type="number" value="<?php echo esc_attr( $limit ); ?>" min="1" max="20">
        </p>
        <?php
    }

    public function update( $new_instance, $old_instance ): array {
        return array(
            'title' => sanitize_text_field( $new_instance['title'] ),
            'limit' => absint( $new_instance['limit'] ),
        );
    }
}