<?php
/**
 * Settings API
 * FILE: wp-knowledge-base/includes/class-wpkb-settings.php
 * @package WP_Knowledge_Base
 */
defined( 'ABSPATH' ) || exit;

class WPKB_Settings {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_page' ) );
        add_action( 'admin_init', array( $this, 'register' ) );
    }

    public function add_page(): void {
        add_submenu_page(
            'edit.php?post_type=wpkb_article',
            __( 'KB Settings', 'wp-knowledge-base' ),
            __( 'Settings',    'wp-knowledge-base' ),
            'manage_options',
            'wpkb-settings',
            array( $this, 'render' )
        );
    }

    public function register(): void {
        register_setting( 'wpkb_group', 'wpkb_options', array( 'sanitize_callback' => array( $this, 'sanitize' ) ) );

        add_settings_section( 'wpkb_search', __( 'Search Settings', 'wp-knowledge-base' ), '__return_false', 'wpkb-settings' );
        add_settings_field( 'search_placeholder', __( 'Search Placeholder',  'wp-knowledge-base' ), array( $this, 'field_placeholder' ), 'wpkb-settings', 'wpkb_search' );
        add_settings_field( 'articles_per_page',  __( 'Articles Per Page',   'wp-knowledge-base' ), array( $this, 'field_per_page' ),    'wpkb-settings', 'wpkb_search' );

        add_settings_section( 'wpkb_votes', __( 'Vote Button Labels', 'wp-knowledge-base' ), '__return_false', 'wpkb-settings' );
        add_settings_field( 'vote_yes_label', __( 'Helpful Button Label',     'wp-knowledge-base' ), array( $this, 'field_vote_yes' ), 'wpkb-settings', 'wpkb_votes' );
        add_settings_field( 'vote_no_label',  __( 'Not Helpful Button Label', 'wp-knowledge-base' ), array( $this, 'field_vote_no' ),  'wpkb-settings', 'wpkb_votes' );
    }

    private function val( string $key, $default = '' ) {
        return get_option( 'wpkb_options', array() )[ $key ] ?? $default;
    }

    public function field_placeholder(): void {
        echo '<input type="text" name="wpkb_options[search_placeholder]" class="large-text" value="' . esc_attr( $this->val( 'search_placeholder', 'Search knowledge base…' ) ) . '">';
    }
    public function field_per_page(): void {
        echo '<input type="number" name="wpkb_options[articles_per_page]" min="1" max="50" value="' . esc_attr( $this->val( 'articles_per_page', 10 ) ) . '">';
        echo '<p class="description">' . esc_html__( 'Number of articles shown per page in search results.', 'wp-knowledge-base' ) . '</p>';
    }
    public function field_vote_yes(): void {
        echo '<input type="text" name="wpkb_options[vote_yes_label]" class="regular-text" value="' . esc_attr( $this->val( 'vote_yes_label', 'Yes, this helped!' ) ) . '">';
    }
    public function field_vote_no(): void {
        echo '<input type="text" name="wpkb_options[vote_no_label]" class="regular-text" value="' . esc_attr( $this->val( 'vote_no_label', 'No, I need more help.' ) ) . '">';
    }

    public function sanitize( $input ): array {
        return array(
            'search_placeholder' => sanitize_text_field( $input['search_placeholder'] ?? '' ),
            'articles_per_page'  => absint( $input['articles_per_page'] ?? 10 ),
            'vote_yes_label'     => sanitize_text_field( $input['vote_yes_label'] ?? '' ),
            'vote_no_label'      => sanitize_text_field( $input['vote_no_label'] ?? '' ),
        );
    }

    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Knowledge Base Settings', 'wp-knowledge-base' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'wpkb_group' ); do_settings_sections( 'wpkb-settings' ); submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public static function get( string $key, $default = '' ) {
        return get_option( 'wpkb_options', array() )[ $key ] ?? $default;
    }
}