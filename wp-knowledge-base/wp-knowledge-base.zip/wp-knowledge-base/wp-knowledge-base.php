<?php
/**
 * Plugin Name:       WP Knowledge Base & FAQ System
 * Plugin URI:        https://vetrisuriya.in/wp-knowledge-base
 * Description:       A complete self-service knowledge base. Searchable articles, FAQ accordion, Popular Articles widget, view tracking, helpful votes, and REST API.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Vetri Suriya
 * License:           GPL-2.0-or-later
 * Text Domain:       wp-knowledge-base
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'WPKB_VERSION',  '1.0.0' );
define( 'WPKB_DIR',      plugin_dir_path( __FILE__ ) );
define( 'WPKB_URL',      plugin_dir_url( __FILE__ ) );
define( 'WPKB_BASENAME', plugin_basename( __FILE__ ) );

/*
 * FIX — Load activator HERE (file root level), BEFORE register_activation_hook.
 *
 * If it stays inside plugins_loaded (as originally written), WordPress fires
 * the activation hook BEFORE plugins_loaded runs, so the class doesn't exist
 * yet → Fatal error: Class "WPKB_Activator" not found.
 */
require_once WPKB_DIR . 'includes/class-wpkb-activator.php';

register_activation_hook( __FILE__, array( 'WPKB_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WPKB_Activator', 'deactivate' ) );

add_action( 'plugins_loaded', function () {

    load_plugin_textdomain( 'wp-knowledge-base', false, dirname( WPKB_BASENAME ) . '/languages' );

    // All other classes load here (after WordPress is fully bootstrapped).
    // class-wpkb-activator.php is already required above — do NOT list it again.
    $classes = array(
        'WPKB_Stats_DB', 'WPKB_CPT', 'WPKB_Taxonomies', 'WPKB_Meta',
        'WPKB_Settings', 'WPKB_Shortcodes', 'WPKB_Widget',
        'WPKB_Ajax', 'WPKB_Rest_Api',
    );

    foreach ( $classes as $class ) {
        require_once WPKB_DIR . 'includes/class-'
            . strtolower( str_replace( '_', '-', $class ) )
            . '.php';
    }

    new WPKB_CPT();
    new WPKB_Taxonomies();
    new WPKB_Meta();
    new WPKB_Settings();
    new WPKB_Shortcodes();
    new WPKB_Widget();
    new WPKB_Ajax();
    new WPKB_Rest_Api();

    // Auto-track article views.
    add_action( 'wp', 'wpkb_track_article_view' );

    // Run upgrade check on every load.
    WPKB_Activator::maybe_upgrade();
} );

/**
 * Record a view when a single KB article is loaded on the front end.
 */
function wpkb_track_article_view(): void {
    if ( is_singular( 'wpkb_article' ) && ! is_admin() ) {
        ( new WPKB_Stats_DB() )->record_view( get_the_ID() );
    }
}