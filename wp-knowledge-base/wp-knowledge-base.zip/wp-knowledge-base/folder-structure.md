wp-knowledge-base/
│
├── wp-knowledge-base.php          ← Bootstrap
├── uninstall.php
├── readme.txt
│
├── includes/
│   ├── class-wpkb-activator.php   ← DB table + caps
│   ├── class-wpkb-cpt.php         ← Articles CPT
│   ├── class-wpkb-taxonomies.php  ← Category + Tag taxonomies
│   ├── class-wpkb-meta.php        ← Difficulty, reviewed date meta boxes
│   ├── class-wpkb-stats-db.php    ← Views + votes CRUD
│   ├── class-wpkb-settings.php    ← Settings API
│   ├── class-wpkb-shortcodes.php  ← [kb_search], [faq_accordion]
│   ├── class-wpkb-widget.php      ← Popular Articles widget
│   ├── class-wpkb-ajax.php        ← Vote + search handlers
│   └── class-wpkb-rest-api.php    ← REST endpoints
│
├── public/
│   ├── css/wpkb-public.css
│   └── js/wpkb-public.js
│
├── admin/
│   └── css/wpkb-admin.css
│
└── languages/
    └── wp-knowledge-base.pot