# WP Knowledge Base & FAQ System — User Guide

## Table of Contents

- [What This Plugin Does](#what-this-plugin-does)
- [After Activation](#after-activation)
- [Step 1: Create Categories](#step-1-create-categories)
- [Step 2: Write Articles](#step-2-write-articles)
- [Step 3: Add Shortcodes to Pages](#step-3-add-shortcodes-to-pages)
- [Shortcode Reference](#shortcode-reference)
  - [[kb_search]](#kb_search)
  - [[faq_accordion]](#faq_accordion)
- [Vote Buttons](#vote-buttons)
- [Settings Page](#settings-page)
- [Popular Articles Widget](#popular-articles-widget)
- [REST API](#rest-api)
- [FAQ](#faq)

---

## What This Plugin Does

WP Knowledge Base gives your site a self-service help center with four main features:

| Feature | Where it shows |
|---|---|
| **Live search box** | Any page using `[kb_search]` |
| **FAQ accordion** | Any page using `[faq_accordion]` |
| **Vote buttons** | Automatically on every KB article |
| **Popular Articles** | Any sidebar using the widget |

All KB articles are a separate content type from regular posts. They appear under **Knowledge Base** in your admin sidebar and have their own categories, tags, and custom fields.

---

## After Activation

When you activate the plugin, WordPress redirects you to the KB articles list and creates:

- A new admin menu: **Knowledge Base**
- A new database table: `wp_wpkb_stats` (stores views and votes)
- A settings page under **Knowledge Base → Settings**

---

## Step 1: Create Categories

Organise your knowledge base into topics before writing articles.

1. Go to **Knowledge Base → Categories**
2. Click **Add New Category**
3. Enter a **Name** (e.g. "Getting Started")
4. The **Slug** is generated automatically (e.g. `getting-started`) — this slug is used in shortcodes
5. Categories are hierarchical — you can create sub-categories by setting a **Parent**
6. Click **Add New Category**

You can also create **Tags** under **Knowledge Base → Tags** for cross-topic labelling.

---

## Step 2: Write Articles

Each KB article is a full WordPress post with a few extra fields.

1. Go to **Knowledge Base → Add New**
2. Write your article title and content using the normal WordPress editor
3. In the **right sidebar**, find the **Article Details** box:

### Difficulty Level

Choose one of:
- 🟢 **Beginner** — no prior knowledge needed
- 🟡 **Intermediate** — some experience required
- 🔴 **Advanced** — technical or expert-level content

This badge is displayed on the article page and returned by the REST API.

### Last Reviewed Date

Enter the date you last checked this article for accuracy. This is shown on the article as "Last reviewed: [date]" so readers can judge how current the information is.

4. Under **Categories**, tick the relevant category
5. Set **Order** (under **Page Attributes**) to control the position in the FAQ accordion — lower numbers appear first
6. Click **Publish**

---

## Step 3: Add Shortcodes to Pages

### Create a Help Centre page

1. Go to **Pages → Add New**
2. Name it "Help Center" or "Support"
3. In the page content, add:

```
[kb_search]
```

4. Publish the page and add it to your navigation menu

### Create an FAQ page

1. Go to **Pages → Add New**
2. Name it "FAQ"
3. Add:

```
[faq_accordion]
```

4. To show only articles from one category:

```
[faq_accordion category="billing"]
```

5. Publish the page

---

## Shortcode Reference

---

### [kb_search]

Displays a live search box. As the visitor types, matching articles appear below the input — no page reload.

**Basic usage:**

```
[kb_search]
```

**All attributes:**

```
[kb_search placeholder="Find an answer…" limit="8"]
```

| Attribute | Default | Description |
|---|---|---|
| `placeholder` | Value from Settings | The grey hint text inside the search box |
| `limit` | `5` | Maximum number of results shown in the dropdown |

**Examples:**

```
[kb_search]
```
Search box with defaults from Settings page.

```
[kb_search placeholder="Search our help articles…" limit="10"]
```
Custom placeholder text, shows up to 10 results.

**How it works:**

- Typing begins triggering search after **2 characters**
- Results appear after a **350ms pause** (debounce — avoids firing on every keystroke)
- Each result shows the article title and a short excerpt
- Clicking a result navigates to the full article page
- Clicking outside the box closes the results dropdown
- Pressing `Escape` closes the dropdown

---

### [faq_accordion]

Displays KB articles as a collapsible accordion. Each article title is a clickable toggle — clicking it expands the article content below. Only one item is open at a time.

**Basic usage:**

```
[faq_accordion]
```

**All attributes:**

```
[faq_accordion category="billing" limit="10" open="0"]
```

| Attribute | Default | Description |
|---|---|---|
| `category` | *(all)* | Slug of the KB Category to show. Leave empty to show all categories |
| `limit` | `10` | Maximum number of articles to show |
| `open` | `0` | Index of the item to open by default. `0` = first item open, `1` = second item open, `-1` = all closed |

**Examples:**

```
[faq_accordion]
```
Shows all published KB articles as an accordion. First article is open by default.

```
[faq_accordion category="getting-started"]
```
Shows only articles in the "getting-started" category.

```
[faq_accordion category="billing" limit="5" open="-1"]
```
Shows up to 5 articles from the "billing" category. All items start closed.

```
[faq_accordion category="shipping" open="2"]
```
Shows shipping articles with the third item (index 2) open on page load.

**How it works:**

- Articles are ordered by the **Order** field (set in the Page Attributes box on the article edit screen)
- Clicking an open item closes it
- Clicking a different item closes the current one and opens the new one
- Each item has a "Read full article →" link at the bottom pointing to the full article page
- Results are cached for 1 hour — editing an article clears the cache automatically

**Controlling article order in the accordion:**

1. Open a KB article
2. In the right sidebar, scroll to **Page Attributes → Order**
3. Set a number — lower numbers appear first (0, 1, 2…)
4. Articles with the same order number are sorted alphabetically

---

## Vote Buttons

Vote buttons are **added automatically** to the bottom of every KB article. You do not need to add a shortcode.

The buttons show:

```
Was this article helpful?
👍 Yes, this helped! (12)    👎 No, I need more help. (3)
```

The number in brackets is the total votes for that option.

### How voting works

- Clicking a button submits the vote via AJAX (no page reload)
- After voting, the buttons are replaced with a thank-you message
- A browser cookie prevents the same visitor from voting again on the same article for **30 days**
- If a visitor tries to vote again, they see "You have already voted on this article"

### Customising the button labels

Go to **Knowledge Base → Settings → Vote Button Labels** and change:
- **Helpful Button Label** — default: "Yes, this helped!"
- **Not Helpful Button Label** — default: "No, I need more help."

### Disabling vote buttons on a specific article

1. Open the article in the editor
2. Open **Custom Fields** (enable via Screen Options at the top if not visible)
3. Add a custom field named `wpkb_disable_votes` with value `1`
4. Update the article

### Viewing vote counts

Vote totals are shown on the article page next to each button. There is no admin summary screen for votes — they are stored in the `wpkb_stats` database table and accessible via the REST API.

---

## Settings Page

Go to **Knowledge Base → Settings** to configure:

| Setting | Default | Description |
|---|---|---|
| **Search Placeholder** | "Search knowledge base…" | The hint text in the `[kb_search]` input box |
| **Articles Per Page** | 10 | Default number of results shown in the search dropdown |
| **Helpful Button Label** | "Yes, this helped!" | Text on the 👍 vote button |
| **Not Helpful Button Label** | "No, I need more help." | Text on the 👎 vote button |

Click **Save Changes** after editing any setting.

---

## Popular Articles Widget

The **Popular KB Articles** widget shows the most-viewed articles in any sidebar.

### Adding the widget

1. Go to **Appearance → Widgets**
2. Find **Popular KB Articles** in the available widgets list
3. Drag it to a sidebar, or click **+** and search for it in the block editor widgets screen
4. Set:
   - **Title** — the heading shown above the list (e.g. "Popular Articles")
   - **Number of articles** — how many to display (1–20)
5. Click **Save**

### How view counting works

- A view is counted each time a visitor loads a single KB article page
- Views are stored in the `wpkb_stats` database table
- The widget reads the top N articles by view count
- Results are cached for **1 hour** — busy sites may see a slight delay before newly popular articles appear in the list

---

## REST API

The plugin registers a public REST API endpoint for reading KB articles. No authentication is required.

### Endpoint

```
GET /wp-json/wpkb/v1/articles
```

### Query Parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `search` | string | — | Full-text keyword search |
| `category` | string | — | Filter by category slug |
| `per_page` | integer | 10 | Number of results per page |
| `page` | integer | 1 | Page number for pagination |

### Example Requests

Get all articles:
```
GET https://yoursite.com/wp-json/wpkb/v1/articles
```

Search for "password reset":
```
GET https://yoursite.com/wp-json/wpkb/v1/articles?search=password+reset
```

Articles in the "billing" category, page 2:
```
GET https://yoursite.com/wp-json/wpkb/v1/articles?category=billing&page=2&per_page=5
```

### Response Format

```json
[
  {
    "id": 42,
    "title": "How to reset your password",
    "excerpt": "Follow these steps to reset your account password…",
    "url": "https://yoursite.com/kb/how-to-reset-your-password/",
    "difficulty": "beginner",
    "reviewed": "2024-12-01",
    "categories": ["Account Management"],
    "votes_yes": 24,
    "votes_no": 2
  }
]
```

### Pagination Headers

The response includes two headers:
- `X-WP-Total` — total number of matching articles
- `X-WP-TotalPages` — total number of pages

---

## FAQ

**Articles are not showing in the accordion. What should I check?**

1. Make sure the articles are **Published** (not Draft or Pending)
2. Check the category slug matches exactly — go to **Knowledge Base → Categories** and copy the slug
3. Make sure the `limit` attribute is high enough to include all your articles
4. If you recently published or edited articles, the cache may be stale — wait up to 1 hour, or clear your caching plugin

**The search box shows no results. What should I check?**

1. Make sure you have at least one Published KB article
2. Type at least **2 characters** — shorter queries return no results
3. Check that your theme is not blocking the AJAX request (open the browser console and look for errors on the Network tab)
4. Go to **Settings → Permalinks** and click **Save Changes** — this refreshes WordPress rewrite rules

**Can I use the shortcodes in a widget area?**

Yes — any widget area that supports the Classic Widget or a Text/HTML widget can accept shortcodes.

**Can I show multiple search boxes on the same page?**

Yes — each `[kb_search]` instance works independently. The search input has the ID `wpkb-search-input`, so if you place multiple shortcodes on one page, only the first one will connect to the results dropdown. For multiple search boxes, use the REST API with custom JavaScript instead.

**How do I translate the plugin?**

All visible strings use the text domain `wp-knowledge-base`. Use Loco Translate or WPML's String Translation. A `.pot` template file is in the `/languages/` folder.

**The vote buttons are showing on regular posts, not just KB articles. What is wrong?**

This should not happen — the vote buttons use `is_singular('wpkb_article')` to check the post type. If you see them elsewhere, check whether another plugin or theme is filtering `the_content` in an unexpected context.

**How do I change the URL slug for KB articles?**

Go to **Knowledge Base → Settings**, change the slug field, save, then go to **Settings → Permalinks** and click **Save Changes** to regenerate rewrite rules.

> **Note:** The current version stores the slug as `kb` hardcoded in `class-wpkb-cpt.php`. To change it, edit the `'rewrite' => array( 'slug' => 'kb' )` line and flush rewrite rules.