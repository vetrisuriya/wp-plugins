<?php
/**
 * Uninstall — removes ALL plugin data permanently.
 * FILE: wp-knowledge-base/uninstall.php
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

// Drop stats table.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpkb_stats" );

// Remove options.
delete_option( 'wpkb_options' );
delete_option( 'wpkb_version' );

// Remove all plugin transients.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wpkb_%' OR option_name LIKE '_transient_timeout_wpkb_%'" );

// Remove capability from all roles.
global $wp_roles;
if ( ! isset( $wp_roles ) ) $wp_roles = new WP_Roles();
foreach ( array_keys( $wp_roles->roles ) as $slug ) {
    $role = get_role( $slug );
    if ( $role ) $role->remove_cap( 'manage_kb_articles' );
}