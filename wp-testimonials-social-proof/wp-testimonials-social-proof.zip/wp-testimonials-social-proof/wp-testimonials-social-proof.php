<?php
/**
 * Plugin Name:       WP Testimonials & Social Proof
 * Plugin URI:        https://vetrisuriya.in/wp-testimonials-social-proof
 * Description:       A complete testimonial management system with star ratings, front-end submission, AJAX filtering, REST API, and a sidebar widget.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Vetri Suriya
 * Author URI:        https://vetrisuriya.in/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-testimonials-social-proof
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'WPTSM_VERSION',  '1.0.0' );
define( 'WPTSM_DIR',      plugin_dir_path( __FILE__ ) );
define( 'WPTSM_URL',      plugin_dir_url( __FILE__ ) );
define( 'WPTSM_BASENAME', plugin_basename( __FILE__ ) );

// Simple class autoloader.
spl_autoload_register( function ( $class ) {
    if ( strpos( $class, 'WPTSM_' ) !== 0 ) {
        return;
    }
    $file = WPTSM_DIR . 'includes/class-' . strtolower( str_replace( '_', '-', $class ) ) . '.php';
    if ( file_exists( $file ) ) {
        require_once $file;
    }
} );

register_activation_hook( __FILE__, array( 'WPTSM_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

add_action( 'plugins_loaded', 'wptsm_load_textdomain' );
function wptsm_load_textdomain() {
    load_plugin_textdomain(
        'wp-testimonials-social-proof',
        false,
        dirname( WPTSM_BASENAME ) . '/languages'
    );
}

add_action( 'plugins_loaded', 'wptsm_bootstrap' );
function wptsm_bootstrap() {
    new WPTSM_CPT();
    new WPTSM_Meta();
    new WPTSM_Settings();
    new WPTSM_Shortcodes();
    new WPTSM_Widget();
    new WPTSM_Ajax();
    new WPTSM_Rest_Api();
    new WPTSM_Admin_Columns();
    new WPTSM_Capabilities();
}