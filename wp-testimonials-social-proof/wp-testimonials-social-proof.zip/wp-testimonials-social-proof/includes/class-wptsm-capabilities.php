<?php
/**
 * Custom Capabilities Manager
 *
 * FILE:    wp-testimonials-social-proof/includes/class-wptsm-capabilities.php
 * LOADED:  By the main WPTSM class via the autoloader on every page load.
 *
 * Responsibilities:
 *  1. Define all custom capabilities the plugin uses.
 *  2. Map custom capabilities to WordPress primitive capabilities
 *     (edit_posts, delete_posts, etc.) via the 'map_meta_cap' filter.
 *  3. Guard every admin page, AJAX handler, and REST endpoint with
 *     current_user_can() using the correct capability.
 *  4. Provide helpers: add_capabilities(), remove_capabilities(),
 *     user_can_moderate().
 *  5. Add a "Testimonial Moderator" role on activation if the
 *     Settings option is enabled.
 *
 * CAPABILITY DESIGN PRINCIPLE:
 *  WordPress uses two types of capabilities:
 *
 *  a) Primitive caps   — checked directly: 'edit_posts', 'manage_options'
 *  b) Meta caps        — resolved at runtime: 'edit_post', 'delete_post'
 *                         (singular, with a post ID argument)
 *
 *  This plugin registers primitive capabilities for plugin-level actions
 *  (moderate_testimonials) and uses map_meta_cap to handle per-object
 *  checks (edit this specific testimonial, delete this specific testimonial)
 *  correctly for non-Administrator roles.
 *
 * @package WP_Testimonials_Social_Proof
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPTSM_Capabilities {

    // ──────────────────────────────────────────────────────────────────
    // Capability constants
    //
    // Using constants instead of bare strings prevents typos causing
    // silent security failures. PHPStan/Psalm can also catch usages of
    // undefined constants, but not undefined string literals.
    // ──────────────────────────────────────────────────────────────────

    /**
     * Grants access to:
     *  - Approve / reject / move-to-pending testimonials
     *  - View the Testimonials admin list table
     *  - Edit testimonial content and meta
     *
     * Intentionally does NOT grant:
     *  - Access to plugin Settings page (requires manage_options)
     *  - Access to CSV export (requires manage_options)
     *  - Delete testimonials permanently (requires delete_testimonials)
     */
    const MODERATE = 'moderate_testimonials';

    /**
     * Grants ability to delete any testimonial permanently.
     * Assigned only to Administrator by default.
     * Kept separate from MODERATE so you can give Editors moderation
     * rights without giving them permanent delete rights.
     */
    const DELETE = 'delete_testimonials';

    /**
     * Grants edit access to testimonial content and meta.
     * Assigned to Administrator and optionally to Editor.
     */
    const EDIT = 'edit_testimonials';

    /**
     * All capabilities this plugin registers, mapped to which role
     * receives them by default.
     * Used by add_capabilities() and remove_capabilities().
     *
     * Format: 'capability' => [ 'role_slug', ... ]
     */
    const CAP_MAP = array(
        self::MODERATE => array( 'administrator' ),
        self::DELETE   => array( 'administrator' ),
        self::EDIT     => array( 'administrator' ),
    );

    // ──────────────────────────────────────────────────────────────────
    // Boot — called from WPTSM::init() on every page load
    // ──────────────────────────────────────────────────────────────────

    /**
     * Register all hooks this class needs.
     *
     * @return void
     */
    public function init(): void {
        // Map meta capabilities (edit_post/delete_post with a post ID)
        // to our custom primitive caps for the wptsm_testimonial CPT.
        add_filter( 'map_meta_cap', array( $this, 'map_meta_cap' ), 10, 4 );

        // Add admin menu visibility check.
        add_action( 'admin_init', array( $this, 'restrict_admin_pages' ) );
    }

    // ──────────────────────────────────────────────────────────────────
    // map_meta_cap filter
    // ──────────────────────────────────────────────────────────────────

    /**
     * Map WordPress meta capabilities to our custom primitive capabilities
     * for the wptsm_testimonial post type.
     *
     * WHAT IS map_meta_cap?
     *
     * When you call current_user_can( 'edit_post', 312 ) on a post of
     * type 'wptsm_testimonial', WordPress fires the 'map_meta_cap' filter
     * to determine which primitive capability to check against the user's
     * role. By default, 'edit_post' maps to 'edit_posts'. This filter
     * lets us remap it to our own 'edit_testimonials' cap instead, keeping
     * the plugin's permission model isolated from core post capabilities.
     *
     * Without this filter, anyone with 'edit_posts' (Authors, Contributors)
     * could edit testimonials — which is almost certainly not what you want.
     *
     * @param string[]  $caps    Array of primitive capabilities required.
     * @param string    $cap     The meta capability being checked.
     * @param int       $user_id The user ID performing the check.
     * @param mixed[]   $args    Arguments; [0] is the post ID for post caps.
     *
     * @return string[]  Modified array of required primitive capabilities.
     */
    public function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array {

        // Only intercept capabilities related to our CPT.
        // Get the post type of the object being checked.
        $post_id = isset( $args[0] ) ? (int) $args[0] : 0;

        if ( $post_id && get_post_type( $post_id ) !== 'wptsm_testimonial' ) {
            return $caps; // Not our CPT — don't touch the caps array.
        }

        switch ( $cap ) {

            // ── Reading (viewing) a testimonial ───────────────────────
            // Allow public reading since CPT is public = false but
            // we need admins and editors to view testimonials.
            case 'read_post':
                $caps = array( self::MODERATE );
                break;

            // ── Editing a specific testimonial ────────────────────────
            case 'edit_post':
                $post = $post_id ? get_post( $post_id ) : null;
                if ( $post ) {
                    // Authors can edit their own testimonials (if submitted
                    // while logged in). Others need EDIT or MODERATE cap.
                    if ( (int) $post->post_author === $user_id ) {
                        $caps = array( self::EDIT );
                    } else {
                        $caps = array( self::MODERATE );
                    }
                } else {
                    $caps = array( self::EDIT );
                }
                break;

            // ── Editing all testimonials (no specific ID) ─────────────
            case 'edit_posts':
                if ( get_post_type( $post_id ) === 'wptsm_testimonial' || ! $post_id ) {
                    $caps = array( self::EDIT );
                }
                break;

            // ── Deleting a specific testimonial ───────────────────────
            case 'delete_post':
                $caps = array( self::DELETE );
                break;

            // ── Publishing a testimonial (approving it) ───────────────
            case 'publish_post':
                $caps = array( self::MODERATE );
                break;
        }

        return $caps;
    }

    // ──────────────────────────────────────────────────────────────────
    // Admin page restriction
    // ──────────────────────────────────────────────────────────────────

    /**
     * Redirect non-authorised users away from the plugin Settings page.
     *
     * The Settings page is registered with 'manage_options' as its
     * capability (standard WordPress practice for plugin settings).
     * Users with only 'moderate_testimonials' can access the CPT list
     * table but not the Settings, REST API key, or CSV export.
     *
     * This method adds an extra wp_die() guard on direct URL access.
     * The menu item itself is hidden by WordPress because they lack
     * the registered capability — this is belt-and-suspenders protection.
     *
     * @return void
     */
    public function restrict_admin_pages(): void {
        if ( ! is_admin() ) {
            return;
        }

        $current_page = $_GET['page'] ?? '';

        // Settings page: requires manage_options.
        if ( 'wptsm-settings' === $current_page && ! current_user_can( 'manage_options' ) ) {
            wp_die(
                esc_html__( 'You do not have permission to access this page.', 'wp-testimonials-social-proof' ),
                esc_html__( 'Permission Denied', 'wp-testimonials-social-proof' ),
                array( 'response' => 403, 'back_link' => true )
            );
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Static helpers — used by Activator, Settings UI, and uninstall.php
    // ──────────────────────────────────────────────────────────────────

    /**
     * Add all plugin capabilities to their default roles.
     *
     * Called from:
     *  - WPTSM_Activator::activate()  (first activation)
     *  - WPTSM_Activator::maybe_upgrade()  (after updates)
     *  - Settings page save (when "Grant Editor moderation" is toggled on)
     *
     * Uses add_cap() which is idempotent — calling it on a role that
     * already has the cap does nothing, so this is safe to call repeatedly.
     *
     * @param bool $include_editor Whether to grant moderate_testimonials to
     *                             the Editor role. Controlled by Settings.
     * @return void
     */
    public static function add_capabilities( bool $include_editor = false ): void {

        foreach ( self::CAP_MAP as $cap => $roles ) {
            foreach ( $roles as $role_slug ) {
                $role = get_role( $role_slug );
                if ( $role ) {
                    $role->add_cap( $cap );
                }
            }
        }

        // Optional: grant Editor the moderation cap.
        if ( $include_editor ) {
            $editor = get_role( 'editor' );
            if ( $editor ) {
                $editor->add_cap( self::MODERATE );
                $editor->add_cap( self::EDIT );
            }
        }
    }

    /**
     * Remove ALL plugin capabilities from ALL roles.
     *
     * Called from:
     *  - uninstall.php  (on permanent plugin removal)
     *
     * Loops all roles (not just those in CAP_MAP) because an admin
     * may have manually assigned our caps to custom roles via a
     * role management plugin. We must clean up all of them.
     *
     * @return void
     */
    public static function remove_capabilities(): void {
        global $wp_roles;

        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new WP_Roles();
        }

        $all_caps = array_keys( self::CAP_MAP );

        foreach ( $wp_roles->roles as $role_slug => $role_data ) {
            $role = get_role( $role_slug );
            if ( ! $role ) {
                continue;
            }
            foreach ( $all_caps as $cap ) {
                // remove_cap() does nothing if the cap is not present —
                // safe to call on every role.
                $role->remove_cap( $cap );
            }
        }
    }

    /**
     * Check if the current user can moderate testimonials.
     *
     * Convenience wrapper so the rest of the codebase uses one call
     * instead of repeating the capability string literal everywhere.
     * This also makes it easy to change the permission check logic
     * in one place (e.g. add a settings-based override).
     *
     * @return bool
     */
    public static function user_can_moderate(): bool {
        return current_user_can( self::MODERATE );
    }

    /**
     * Check if the current user can permanently delete testimonials.
     *
     * @return bool
     */
    public static function user_can_delete(): bool {
        return current_user_can( self::DELETE );
    }

    /**
     * Check if the current user can edit testimonial content.
     *
     * @return bool
     */
    public static function user_can_edit(): bool {
        return current_user_can( self::EDIT );
    }

    /**
     * Check if the current user can access the plugin Settings page.
     *
     * Separate from MODERATE because Settings contains REST API keys,
     * export, and configuration that moderators should not access.
     *
     * @return bool
     */
    public static function user_can_manage_settings(): bool {
        return current_user_can( 'manage_options' );
    }

    // ──────────────────────────────────────────────────────────────────
    // Optional: Create a dedicated "Testimonial Moderator" role
    // ──────────────────────────────────────────────────────────────────

    /**
     * Add a "Testimonial Moderator" role.
     *
     * Called from the Settings page when the admin enables the option
     * "Create dedicated Moderator role".
     *
     * This role has exactly the capabilities needed to moderate testimonials
     * and nothing else — it cannot write blog posts, access other admin pages,
     * or manage plugin settings. Principle of least privilege.
     *
     * @return WP_Role|null  The created role, or null if it already exists.
     */
    public static function add_moderator_role(): ?WP_Role {
        // add_role() returns null if the role already exists — do not overwrite.
        $role = add_role(
            'testimonial_moderator',
            __( 'Testimonial Moderator', 'wp-testimonials-social-proof' ),
            array(
                // WordPress core caps needed to access wp-admin at all.
                'read'                   => true,

                // Our custom caps.
                self::MODERATE           => true,
                self::EDIT               => true,

                // Intentionally NOT included:
                // self::DELETE          // Cannot permanently delete.
                // 'manage_options'      // Cannot access Settings.
                // 'edit_posts'          // Cannot write blog posts.
                // 'upload_files'        // Cannot upload media.
            )
        );

        return $role; // null if role already existed; WP_Role if created.
    }

    /**
     * Remove the "Testimonial Moderator" role.
     *
     * Called from Settings when the option is disabled, and from
     * uninstall.php. WordPress automatically unassigns the role from
     * any users who had it, reverting them to the default Subscriber role.
     *
     * @return void
     */
    public static function remove_moderator_role(): void {
        remove_role( 'testimonial_moderator' );
    }

    // ──────────────────────────────────────────────────────────────────
    // Capability reference: where each cap is checked in the plugin
    // ──────────────────────────────────────────────────────────────────
    //
    // moderate_testimonials:
    //   class-wptsm-ajax.php       → handle_submission() before wp_insert_post
    //   class-wptsm-ajax.php       → handle_filter()     before WP_Query
    //   class-wptsm-admin.php      → render_list_table() menu registration
    //   class-wptsm-rest-api.php   → toggle_status()     endpoint permission_callback
    //
    // delete_testimonials:
    //   class-wptsm-ajax.php       → handle_bulk_delete() action
    //   map_meta_cap filter above   → delete_post on wptsm_testimonial
    //
    // edit_testimonials:
    //   map_meta_cap filter above   → edit_post on wptsm_testimonial
    //   class-wptsm-meta-boxes.php → save_meta() before update_post_meta
    //
    // manage_options:
    //   class-wptsm-settings.php   → settings page menu & form save
    //   class-wptsm-ajax.php       → handle_export() CSV download
    //   class-wptsm-rest-api.php   → get_leads() endpoint permission_callback
    //
}