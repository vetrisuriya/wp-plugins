<?php
// includes/class-wptsm-ajax.php
defined( 'ABSPATH' ) || exit;

class WPTSM_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_wptsm_submit',        array( $this, 'handle_submission' ) );
        add_action( 'wp_ajax_nopriv_wptsm_submit',  array( $this, 'handle_submission' ) );
        add_action( 'wp_ajax_wptsm_filter',         array( $this, 'handle_filter' ) );
        add_action( 'wp_ajax_nopriv_wptsm_filter',  array( $this, 'handle_filter' ) );
    }

    // ── New testimonial submission from front-end form ─────────────
    public function handle_submission() {
        check_ajax_referer( 'wptsm_submit_nonce', 'nonce' );

        if ( '1' !== WPTSM_Settings::get( 'allow_submissions', '1' ) ) {
            wp_send_json_error( array( 'message' => __( 'Submissions are closed.', 'wp-testimonials-social-proof' ) ) );
        }

        $name    = sanitize_text_field( $_POST['name']    ?? '' );
        $email   = sanitize_email(      $_POST['email']   ?? '' );
        $company = sanitize_text_field( $_POST['company'] ?? '' );
        $role    = sanitize_text_field( $_POST['role']    ?? '' );
        $content = wp_kses_post(        $_POST['content'] ?? '' );
        $rating  = min( 5, max( 1, absint( $_POST['rating'] ?? 5 ) ) );

        if ( ! $name || ! is_email( $email ) || ! $content ) {
            wp_send_json_error( array( 'message' => __( 'Please fill in all required fields.', 'wp-testimonials-social-proof' ) ) );
        }

        $auto_approve = '1' === WPTSM_Settings::get( 'auto_approve', '0' );
        $status       = $auto_approve ? 'publish' : 'pending';

        $post_id = wp_insert_post( array(
            'post_type'    => 'wptsm_testimonial',
            'post_title'   => $name,
            'post_content' => $content,
            'post_status'  => $status,
            'post_author'  => 0,
            'meta_input'   => array(
                '_wptsm_rating'  => $rating,
                '_wptsm_company' => $company,
                '_wptsm_position' => $role,
                '_wptsm_email'   => $email,
            ),
        ), true );

        if ( is_wp_error( $post_id ) ) {
            wp_send_json_error( array( 'message' => $post_id->get_error_message() ) );
        }

        // Notify admin.
        $email_handler = new WPTSM_Email();
        $email_handler->notify_admin( $name, $email, $content, $rating );

        $message = $auto_approve
            ? __( 'Thank you! Your testimonial is live.', 'wp-testimonials-social-proof' )
            : __( 'Thank you! Your testimonial is pending review.', 'wp-testimonials-social-proof' );

        wp_send_json_success( array( 'message' => $message ) );
    }

    // ── AJAX filter: rating or category filter ─────────────────────
    public function handle_filter() {
        check_ajax_referer( 'wptsm_filter_nonce', 'nonce' );

        $rating   = absint( $_POST['rating']   ?? 0 );
        $category = sanitize_text_field( $_POST['category'] ?? '' );
        $limit    = absint( $_POST['limit']    ?? 6 );

        $meta_query = array();
        if ( $rating > 0 ) {
            $meta_query[] = array(
                'key'     => '_wptsm_rating',
                'value'   => $rating,
                'compare' => '>=',
                'type'    => 'NUMERIC',
            );
        }

        $query_args = array(
            'post_type'      => 'wptsm_testimonial',
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
            'meta_query'     => $meta_query,
        );

        if ( ! empty( $category ) ) {
            $query_args['tax_query'] = array( array(
                'taxonomy' => 'wptsm_category',
                'field'    => 'slug',
                'terms'    => $category,
            ) );
        }

        $query = new WP_Query( $query_args );
        $html  = '';
        $show_rating = '1' === WPTSM_Settings::get( 'show_rating', '1' );

        if ( $query->have_posts() ) {
            foreach ( $query->posts as $t ) {
                $t_rating  = absint( get_post_meta( $t->ID, '_wptsm_rating', true ) );
                $t_company = get_post_meta( $t->ID, '_wptsm_company', true );
                $html     .= '<div class="wptsm-card">';
                $html     .= '<div class="wptsm-content">' . wp_kses_post( wpautop( $t->post_content ) ) . '</div>';
                if ( $show_rating && $t_rating ) {
                    $html .= '<div class="wptsm-stars">' . esc_html( str_repeat( '★', $t_rating ) . str_repeat( '☆', 5 - $t_rating ) ) . '</div>';
                }
                $html .= '<div class="wptsm-author"><strong>' . esc_html( $t->post_title ) . '</strong>';
                if ( $t_company ) {
                    $html .= ' — ' . esc_html( $t_company );
                }
                $html .= '</div></div>';
            }
        } else {
            $html = '<p class="wptsm-empty">' . esc_html__( 'No testimonials match your filter.', 'wp-testimonials-social-proof' ) . '</p>';
        }

        wp_send_json_success( array( 'html' => $html ) );
    }
}