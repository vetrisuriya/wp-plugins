<?php
// includes/class-wptsm-admin-columns.php
defined( 'ABSPATH' ) || exit;

class WPTSM_Admin_Columns {

    public function __construct() {
        add_filter( 'manage_wptsm_testimonial_posts_columns',       array( $this, 'add_columns' ) );
        add_action( 'manage_wptsm_testimonial_posts_custom_column', array( $this, 'render_column' ), 10, 2 );
        add_filter( 'manage_edit-wptsm_testimonial_sortable_columns', array( $this, 'sortable_columns' ) );
    }

    public function add_columns( array $columns ): array {
        $new = array();
        foreach ( $columns as $key => $label ) {
            $new[ $key ] = $label;
            if ( 'title' === $key ) {
                $new['wptsm_rating']   = __( 'Rating', 'wp-testimonials-social-proof' );
                $new['wptsm_company']  = __( 'Company', 'wp-testimonials-social-proof' );
                $new['wptsm_featured'] = __( 'Featured', 'wp-testimonials-social-proof' );
            }
        }
        return $new;
    }

    public function render_column( string $column, int $post_id ) {
        switch ( $column ) {
            case 'wptsm_rating':
                $rating = absint( get_post_meta( $post_id, '_wptsm_rating', true ) );
                echo esc_html( str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating ) );
                break;
            case 'wptsm_company':
                echo esc_html( get_post_meta( $post_id, '_wptsm_company', true ) );
                break;
            case 'wptsm_featured':
                $featured = get_post_meta( $post_id, '_wptsm_featured', true );
                echo '1' === $featured ? '<span style="color:gold;">★</span>' : '—';
                break;
        }
    }

    public function sortable_columns( array $columns ): array {
        $columns['wptsm_rating'] = 'wptsm_rating';
        return $columns;
    }
}