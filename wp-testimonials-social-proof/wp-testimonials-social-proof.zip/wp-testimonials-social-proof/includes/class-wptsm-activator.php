<?php
/**
 * Plugin Activation Handler
 *
 * FILE:    wp-testimonials-social-proof/includes/class-wptsm-activator.php
 * CALLED:  register_activation_hook( __FILE__, array( 'WPTSM_Activator', 'activate' ) )
 *          in wp-testimonials-social-proof.php
 *
 * Responsibilities on first activation and on re-activation after updates:
 *  1. Register the CPT and taxonomy so rewrite rules are built correctly.
 *  2. Flush rewrite rules (once — expensive operation, must not run on every request).
 *  3. Add the `moderate_testimonials` capability to the Administrator role.
 *  4. Store the plugin version in wp_options for future upgrade checks.
 *  5. Set safe default options if they do not already exist.
 *  6. Schedule the cleanup WP-Cron event.
 *
 * WHY A SEPARATE CLASS?
 *  Activation code runs exactly once per activation event. Putting it in
 *  functions.php or the main plugin file would require defensive checks on
 *  every page load. A dedicated class keeps the concern isolated, testable,
 *  and easy to extend with upgrade routines.
 *
 * @package WP_Testimonials_Social_Proof
 * @since   1.0.0
 */

defined( 'ABSPATH' ) || exit;

class WPTSM_Activator {

    /**
     * Run on plugin activation.
     *
     * WordPress calls this inside a try/catch. If we throw or trigger a
     * fatal error here, WordPress will deactivate the plugin automatically
     * and show the error to the admin — good fail-fast behaviour.
     *
     * @return void
     */
    public static function activate(): void {

        // ── 1. Capability check ─────────────────────────────────────
        // Only administrators should be activating plugins.
        // This guard is belt-and-suspenders; WordPress already checks
        // activate_plugins capability before running the hook.
        if ( ! current_user_can( 'activate_plugins' ) ) {
            wp_die(
                esc_html__( 'You do not have permission to activate this plugin.', 'wp-testimonials-social-proof' ),
                esc_html__( 'Permission Error', 'wp-testimonials-social-proof' ),
                array( 'back_link' => true )
            );
        }

        // ── 2. PHP & WordPress version requirements ─────────────────
        self::check_requirements();

        // ── 3. Register CPT + taxonomy ──────────────────────────────
        // Must register before flush_rewrite_rules() so WordPress has
        // the correct rewrite slugs to compile into the rules table.
        // We do NOT fire the full 'init' action here — we call the
        // registration methods directly to avoid side effects.
        self::register_post_type_for_flush();
        self::register_taxonomy_for_flush();

        // ── 4. Flush rewrite rules ──────────────────────────────────
        // IMPORTANT: Only call flush_rewrite_rules() during activation
        // (or deactivation). Calling it on every request is a severe
        // performance problem — it rebuilds the entire rewrite rule
        // database and can cause visible slowdowns on large sites.
        flush_rewrite_rules();

        // ── 5. Add capabilities to roles ───────────────────────────
        // Capabilities are stored inside the WP_User_Meta entry for
        // each role in wp_options. They persist across requests —
        // we only add them once on activation (idempotent: add_cap
        // does nothing if the cap already exists).
        self::add_capabilities();

        // ── 6. Save default plugin options ─────────────────────────
        self::set_default_options();

        // ── 7. Store installed version for upgrade path ─────────────
        // Used by WPTSM_Activator::maybe_upgrade() on plugins_loaded
        // to run future migration routines only when the stored version
        // is older than the current WPTSM_VERSION constant.
        update_option( 'wptsm_version', WPTSM_VERSION, false );

        // ── 8. Schedule WP-Cron cleanup event ──────────────────────
        self::schedule_cron();

        // ── 9. Set activation redirect flag ────────────────────────
        // After activation WordPress redirects to the Plugins page.
        // We set a transient here; the main plugin class checks for it
        // on admin_init and redirects to the Settings → Welcome page.
        set_transient( 'wptsm_activation_redirect', true, 30 );
    }

    /**
     * Run version-upgrade routines on every page load.
     * Called from add_action( 'plugins_loaded', ... ) in the main file.
     *
     * Pattern: compare stored version to WPTSM_VERSION constant.
     * Only run migration code when the stored version is older.
     * Always update the stored version at the end.
     *
     * @return void
     */
    public static function maybe_upgrade(): void {
        $installed = get_option( 'wptsm_version', '0.0.0' );

        if ( version_compare( $installed, WPTSM_VERSION, '>=' ) ) {
            return; // Already up to date — exit early (most common path).
        }

        // ── Future upgrade routines ──────────────────────────────────
        // Example pattern for a future 1.1.0 release:
        //
        // if ( version_compare( $installed, '1.1.0', '<' ) ) {
        //     self::upgrade_to_1_1_0();
        // }

        // Always ensure capabilities are present after upgrades.
        self::add_capabilities();

        // Bump the stored version to current.
        update_option( 'wptsm_version', WPTSM_VERSION, false );
    }

    // ──────────────────────────────────────────────────────────────────
    // Private helpers
    // ──────────────────────────────────────────────────────────────────

    /**
     * Check that the server meets minimum requirements.
     * wp_die() with a helpful message if not — prevents activation on
     * environments that would cause fatal errors at runtime.
     */
    private static function check_requirements(): void {
        // PHP version.
        if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
            wp_die(
                sprintf(
                    /* translators: %s: PHP version number */
                    esc_html__( 'WP Testimonials requires PHP 8.0 or higher. Your server is running PHP %s.', 'wp-testimonials-social-proof' ),
                    PHP_VERSION
                ),
                esc_html__( 'PHP Version Error', 'wp-testimonials-social-proof' ),
                array( 'back_link' => true )
            );
        }

        // WordPress version.
        global $wp_version;
        if ( version_compare( $wp_version, '6.0', '<' ) ) {
            wp_die(
                sprintf(
                    /* translators: %s: WordPress version number */
                    esc_html__( 'WP Testimonials requires WordPress 6.0 or higher. You are running WordPress %s.', 'wp-testimonials-social-proof' ),
                    $wp_version
                ),
                esc_html__( 'WordPress Version Error', 'wp-testimonials-social-proof' ),
                array( 'back_link' => true )
            );
        }
    }

    /**
     * Register the CPT — minimal registration used only at activation time
     * to ensure flush_rewrite_rules() has the correct slug.
     *
     * The full registration (with all labels, columns, etc.) happens in
     * class-wptsm-cpt.php on the 'init' hook every page load.
     * Here we need only the 'rewrite' argument to produce correct rules.
     */
    private static function register_post_type_for_flush(): void {
        if ( post_type_exists( 'wptsm_testimonial' ) ) {
            return; // Already registered by init — nothing to do.
        }

        register_post_type( 'wptsm_testimonial', array(
            'public'      => false, // No public front-end URLs.
            'has_archive' => false,
            'rewrite'     => false, // No rewrite rules needed — CPT is not public.
        ) );
    }

    /**
     * Register the taxonomy at activation for flush purposes.
     */
    private static function register_taxonomy_for_flush(): void {
        if ( taxonomy_exists( 'wptsm_category' ) ) {
            return;
        }

        register_taxonomy( 'wptsm_category', 'wptsm_testimonial', array(
            'public'  => false,
            'rewrite' => false,
        ) );
    }

    /**
     * Add the moderate_testimonials capability to the Administrator role,
     * and optionally to the Editor role.
     *
     * WHY add_cap() on the role object, not current_user_can()?
     *
     * WordPress stores role capabilities in wp_options as part of the
     * 'wp_user_roles' option. Calling $role->add_cap() modifies that
     * option directly and the change persists across requests.
     * This is different from user meta — role caps apply to every user
     * in that role automatically.
     *
     * These capabilities are REMOVED in uninstall.php and in
     * class-wptsm-capabilities.php::remove_capabilities() so the
     * wp_user_roles option is left clean after uninstallation.
     */
    private static function add_capabilities(): void {
        // Administrator — full management.
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            // moderate_testimonials: approve/reject/delete testimonials.
            $admin->add_cap( 'moderate_testimonials' );
            // edit_testimonials: edit content and meta of any testimonial.
            $admin->add_cap( 'edit_testimonials' );
        }

        // Editor — moderate only (cannot access plugin Settings page,
        // which requires manage_options).
        // Change this to match your desired role permissions.
        $settings   = get_option( 'wptsm_settings', array() );
        $grant_edit = ! empty( $settings['editor_can_moderate'] ) && '1' === $settings['editor_can_moderate'];

        if ( $grant_edit ) {
            $editor = get_role( 'editor' );
            if ( $editor ) {
                $editor->add_cap( 'moderate_testimonials' );
            }
        }
    }

    /**
     * Set default plugin options using add_option() — which does nothing
     * if the option already exists. Safe to call on every activation
     * (including re-activations after updates) without overwriting
     * settings the admin has already configured.
     *
     * add_option() vs update_option():
     *  - add_option()    → inserts ONLY if the key does not exist. Safe.
     *  - update_option() → always overwrites. Would reset user settings.
     */
    private static function set_default_options(): void {
        $defaults = array(
            // Moderation.
            'auto_approve'         => '0',       // Pending review by default.
            'editor_can_moderate'  => '0',       // Editors cannot approve by default.

            // Display defaults.
            'per_page'             => '9',
            'default_layout'       => 'grid',
            'default_columns'      => '3',
            'show_filter'          => '0',
            'show_summary'         => '0',
            'clamp_lines'          => '0',       // 0 = no truncation.

            // Form.
            'enable_submission'    => '1',
            'require_login'        => '0',
            'show_company'         => '1',
            'show_role'            => '1',
            'max_content_length'   => '1000',

            // Notifications.
            'notify_admin'         => '1',
            'notify_email'         => get_option( 'admin_email', '' ),

            // Design.
            'primary_color'        => '#7c3aed',
            'star_color'           => '#f59e0b',
            'card_radius'          => '12',      // px

            // Schema.
            'inject_schema'        => '1',
            'schema_type'          => 'LocalBusiness',

            // REST API.
            'rest_public'          => '1',       // GET endpoint public.
        );

        // add_option with autoload = false for most settings.
        // The main WPTSM_Settings class reads via get_option('wptsm_settings').
        add_option( 'wptsm_settings', $defaults, '', false );

        // Counters — always start at 0 if not already set.
        add_option( 'wptsm_total_submissions', 0, '', false );
        add_option( 'wptsm_total_approved',    0, '', false );
    }

    /**
     * Schedule the WP-Cron event that purges expired transient cache entries.
     *
     * wp_schedule_event() does nothing if the event is already scheduled —
     * safe to call on re-activation.
     *
     * The event fires the 'wptsm_purge_transients' action, which is handled
     * in the main WPTSM class:
     *
     *   add_action( 'wptsm_purge_transients', array( $this, 'purge_transients' ) );
     *
     * WHY cron?
     *   Transients with a TTL are cleaned up by WordPress automatically when
     *   they expire and are next accessed. But transients that are never
     *   re-requested (e.g. from a deleted shortcode) may linger indefinitely.
     *   This daily cron sweeps them up proactively.
     */
    private static function schedule_cron(): void {
        if ( ! wp_next_scheduled( 'wptsm_purge_transients' ) ) {
            wp_schedule_event(
                time(),         // Start: immediately.
                'daily',        // Recurrence: once per day.
                'wptsm_purge_transients'
            );
        }
    }

    /**
     * Plugin deactivation cleanup.
     *
     * Called by register_deactivation_hook() in the main file.
     * Lighter than uninstall — remove scheduled events and flush rules
     * but keep all data intact (the admin may be re-activating shortly).
     *
     * @return void
     */
    public static function deactivate(): void {
        // Remove scheduled cron event.
        $timestamp = wp_next_scheduled( 'wptsm_purge_transients' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'wptsm_purge_transients' );
        }

        // Flush rewrite rules so the CPT slug is removed from the rules table.
        flush_rewrite_rules();
    }

}