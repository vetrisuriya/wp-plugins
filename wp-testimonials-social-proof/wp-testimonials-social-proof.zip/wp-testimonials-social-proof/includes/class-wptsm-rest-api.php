<?php
// includes/class-wptsm-rest-api.php
defined( 'ABSPATH' ) || exit;

class WPTSM_Rest_Api {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes() {
        // GET all testimonials.
        register_rest_route( 'wptsm/v1', '/testimonials', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_testimonials' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'rating'   => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'limit'    => array( 'type' => 'integer', 'default' => 10, 'sanitize_callback' => 'absint' ),
                'category' => array( 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
            ),
        ) );

        // POST — submit a new testimonial (requires nonce via header or body).
        register_rest_route( 'wptsm/v1', '/submit', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'submit_testimonial' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function get_testimonials( WP_REST_Request $request ): WP_REST_Response {
        $args = array(
            'post_type'      => 'wptsm_testimonial',
            'post_status'    => 'publish',
            'posts_per_page' => $request->get_param( 'limit' ) ?: 10,
        );

        $rating = $request->get_param( 'rating' );
        if ( $rating ) {
            $args['meta_query'] = array( array(
                'key'     => '_wptsm_rating',
                'value'   => $rating,
                'compare' => '>=',
                'type'    => 'NUMERIC',
            ) );
        }

        $query        = new WP_Query( $args );
        $testimonials = array_map( array( $this, 'format' ), $query->posts );

        return new WP_REST_Response( $testimonials, 200 );
    }

    public function submit_testimonial( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( '1' !== WPTSM_Settings::get( 'allow_submissions', '1' ) ) {
            return new WP_Error( 'submissions_closed', __( 'Submissions are closed.', 'wp-testimonials-social-proof' ), array( 'status' => 403 ) );
        }

        $name    = sanitize_text_field( $request->get_param( 'name' ) ?? '' );
        $content = wp_kses_post( $request->get_param( 'content' ) ?? '' );
        $email   = sanitize_email( $request->get_param( 'email' ) ?? '' );
        $rating  = min( 5, max( 1, absint( $request->get_param( 'rating' ) ?? 5 ) ) );

        if ( ! $name || ! $content || ! is_email( $email ) ) {
            return new WP_Error( 'invalid_data', __( 'Name, email, and content are required.', 'wp-testimonials-social-proof' ), array( 'status' => 400 ) );
        }

        $status  = '1' === WPTSM_Settings::get( 'auto_approve', '0' ) ? 'publish' : 'pending';
        $post_id = wp_insert_post( array(
            'post_type'    => 'wptsm_testimonial',
            'post_title'   => $name,
            'post_content' => $content,
            'post_status'  => $status,
            'meta_input'   => array(
                '_wptsm_rating' => $rating,
                '_wptsm_email'  => $email,
            ),
        ), true );

        if ( is_wp_error( $post_id ) ) {
            return new WP_Error( 'insert_failed', $post_id->get_error_message(), array( 'status' => 500 ) );
        }

        return new WP_REST_Response( array( 'id' => $post_id, 'status' => $status ), 201 );
    }

    private function format( WP_Post $post ): array {
        return array(
            'id'          => $post->ID,
            'author'      => $post->post_title,
            'content'     => wp_strip_all_tags( $post->post_content ),
            'rating'      => (int) get_post_meta( $post->ID, '_wptsm_rating',   true ),
            'company'     => get_post_meta( $post->ID, '_wptsm_company',  true ),
            'position'    => get_post_meta( $post->ID, '_wptsm_position', true ),
            'website'     => get_post_meta( $post->ID, '_wptsm_website',  true ),
            'date'        => $post->post_date,
            'impressions' => (int) get_post_meta( $post->ID, '_wptsm_impressions', true ),
        );
    }
}