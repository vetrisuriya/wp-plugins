<?php
// includes/class-wptsm-cpt.php
defined( 'ABSPATH' ) || exit;

class WPTSM_CPT {

    public function __construct() {
        add_action( 'init', array( $this, 'register_testimonial_cpt' ) );
        add_action( 'init', array( $this, 'register_testimonial_category' ) );
    }

    public function register_testimonial_cpt() {
        $labels = array(
            'name'               => _x( 'Testimonials', 'post type general name', 'wp-testimonials-social-proof' ),
            'singular_name'      => _x( 'Testimonial', 'post type singular name', 'wp-testimonials-social-proof' ),
            'add_new_item'       => __( 'Add New Testimonial', 'wp-testimonials-social-proof' ),
            'edit_item'          => __( 'Edit Testimonial', 'wp-testimonials-social-proof' ),
            'view_item'          => __( 'View Testimonial', 'wp-testimonials-social-proof' ),
            'search_items'       => __( 'Search Testimonials', 'wp-testimonials-social-proof' ),
            'not_found'          => __( 'No testimonials found.', 'wp-testimonials-social-proof' ),
            'menu_name'          => __( 'Testimonials', 'wp-testimonials-social-proof' ),
            'all_items'          => __( 'All Testimonials', 'wp-testimonials-social-proof' ),
        );

        register_post_type(
            'wptsm_testimonial',
            array(
                'labels'             => $labels,
                'public'             => false,       // Not publicly browsable by URL.
                'publicly_queryable' => false,
                'show_ui'            => true,
                'show_in_menu'       => true,
                'capability_type'    => 'post',
                'has_archive'        => false,
                'hierarchical'       => false,
                'supports'           => array( 'title', 'editor', 'thumbnail' ),
                'menu_icon'          => 'dashicons-format-quote',
                'menu_position'      => 25,
                'show_in_rest'       => false, // We have a custom REST endpoint.
            )
        );
    }

    public function register_testimonial_category() {
        register_taxonomy(
            'wptsm_category',
            'wptsm_testimonial',
            array(
                'label'             => __( 'Testimonial Categories', 'wp-testimonials-social-proof' ),
                'hierarchical'      => true,
                'show_ui'           => true,
                'show_admin_column' => true,
                'show_in_rest'      => false,
                'rewrite'           => false,
            )
        );
    }
}