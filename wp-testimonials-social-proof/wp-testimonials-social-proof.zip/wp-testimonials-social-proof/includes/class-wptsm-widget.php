<?php
// includes/class-wptsm-widget.php
defined( 'ABSPATH' ) || exit;

class WPTSM_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'wptsm_featured_widget',
            __( 'Featured Testimonials', 'wp-testimonials-social-proof' ),
            array( 'description' => __( 'Display featured testimonials in your sidebar.', 'wp-testimonials-social-proof' ) )
        );
        add_action( 'widgets_init', function () {
            register_widget( 'WPTSM_Widget' );
        } );
    }

    public function widget( $args, $instance ) {
        $title    = apply_filters( 'widget_title', $instance['title'] ?? '' );
        $limit    = absint( $instance['limit'] ?? 2 );
        $min_rate = absint( $instance['min_rating'] ?? 4 );

        echo wp_kses_post( $args['before_widget'] );
        if ( $title ) {
            echo wp_kses_post( $args['before_title'] ) . esc_html( $title ) . wp_kses_post( $args['after_title'] );
        }

        $cache_key = 'wptsm_widget_' . $limit . '_' . $min_rate;
        $posts     = get_transient( $cache_key );

        if ( false === $posts ) {
            $q = new WP_Query( array(
                'post_type'      => 'wptsm_testimonial',
                'post_status'    => 'publish',
                'posts_per_page' => $limit,
                'meta_query'     => array(
                    array( 'key' => '_wptsm_featured', 'value' => '1' ),
                    array( 'key' => '_wptsm_rating', 'value' => $min_rate, 'compare' => '>=', 'type' => 'NUMERIC' ),
                ),
            ) );
            $posts = $q->posts;
            set_transient( $cache_key, $posts, 30 * MINUTE_IN_SECONDS );
        }

        if ( ! empty( $posts ) ) {
            echo '<div class="wptsm-widget-list">';
            foreach ( $posts as $t ) {
                $rating  = absint( get_post_meta( $t->ID, '_wptsm_rating', true ) );
                $company = get_post_meta( $t->ID, '_wptsm_company', true );
                echo '<blockquote class="wptsm-widget-quote">';
                echo '<p>' . esc_html( wp_trim_words( $t->post_content, 20 ) ) . '</p>';
                echo '<footer>— <strong>' . esc_html( $t->post_title ) . '</strong>';
                if ( $company ) echo ', ' . esc_html( $company );
                echo '<br>' . esc_html( str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating ) );
                echo '</footer></blockquote>';
            }
            echo '</div>';
        } else {
            echo '<p>' . esc_html__( 'No featured testimonials yet.', 'wp-testimonials-social-proof' ) . '</p>';
        }

        echo wp_kses_post( $args['after_widget'] );
    }

    public function form( $instance ) {
        $title      = esc_attr( $instance['title']      ?? __( 'What Our Clients Say', 'wp-testimonials-social-proof' ) );
        $limit      = absint( $instance['limit']         ?? 2 );
        $min_rating = absint( $instance['min_rating']    ?? 4 );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'wp-testimonials-social-proof' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>"><?php esc_html_e( 'Number to show:', 'wp-testimonials-social-proof' ); ?></label>
            <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>" type="number" value="<?php echo esc_attr( $limit ); ?>" min="1" max="10">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'min_rating' ) ); ?>"><?php esc_html_e( 'Minimum rating (1–5):', 'wp-testimonials-social-proof' ); ?></label>
            <input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'min_rating' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'min_rating' ) ); ?>" type="number" value="<?php echo esc_attr( $min_rating ); ?>" min="1" max="5">
        </p>
        <?php
    }

    public function update( $new_instance, $old_instance ): array {
        return array(
            'title'      => sanitize_text_field( $new_instance['title'] ),
            'limit'      => absint( $new_instance['limit'] ),
            'min_rating' => min( 5, max( 1, absint( $new_instance['min_rating'] ) ) ),
        );
    }
}