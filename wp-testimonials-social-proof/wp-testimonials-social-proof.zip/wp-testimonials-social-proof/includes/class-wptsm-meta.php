<?php
// includes/class-wptsm-meta.php
defined( 'ABSPATH' ) || exit;

class WPTSM_Meta {

    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
        add_action( 'save_post_wptsm_testimonial', array( $this, 'save_meta' ) );
    }

    public function add_meta_boxes() {
        add_meta_box(
            'wptsm_details',
            __( 'Testimonial Details', 'wp-testimonials-social-proof' ),
            array( $this, 'render_meta_box' ),
            'wptsm_testimonial',
            'side',
            'high'
        );
    }

    public function render_meta_box( WP_Post $post ) {
        wp_nonce_field( 'wptsm_save_meta', 'wptsm_meta_nonce' );

        $rating   = get_post_meta( $post->ID, '_wptsm_rating',   true ) ?: '5';
        $company  = get_post_meta( $post->ID, '_wptsm_company',  true );
        $position = get_post_meta( $post->ID, '_wptsm_position', true );
        $website  = get_post_meta( $post->ID, '_wptsm_website',  true );
        $featured = get_post_meta( $post->ID, '_wptsm_featured', true );
        ?>
        <p>
            <label for="wptsm_rating"><strong><?php esc_html_e( 'Star Rating', 'wp-testimonials-social-proof' ); ?></strong></label><br>
            <select id="wptsm_rating" name="wptsm_rating">
                <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                    <option value="<?php echo esc_attr( $i ); ?>" <?php selected( $rating, $i ); ?>>
                        <?php echo esc_html( $i ); ?> ★
                    </option>
                <?php endfor; ?>
            </select>
        </p>
        <p>
            <label for="wptsm_company"><strong><?php esc_html_e( 'Company', 'wp-testimonials-social-proof' ); ?></strong></label><br>
            <input type="text" id="wptsm_company" name="wptsm_company" value="<?php echo esc_attr( $company ); ?>" class="widefat">
        </p>
        <p>
            <label for="wptsm_position"><strong><?php esc_html_e( 'Position / Role', 'wp-testimonials-social-proof' ); ?></strong></label><br>
            <input type="text" id="wptsm_position" name="wptsm_position" value="<?php echo esc_attr( $position ); ?>" class="widefat">
        </p>
        <p>
            <label for="wptsm_website"><strong><?php esc_html_e( 'Website URL', 'wp-testimonials-social-proof' ); ?></strong></label><br>
            <input type="url" id="wptsm_website" name="wptsm_website" value="<?php echo esc_attr( $website ); ?>" class="widefat">
        </p>
        <p>
            <label>
                <input type="checkbox" name="wptsm_featured" value="1" <?php checked( $featured, '1' ); ?>>
                <?php esc_html_e( 'Mark as Featured', 'wp-testimonials-social-proof' ); ?>
            </label>
        </p>
        <?php
    }

    public function save_meta( int $post_id ) {
        if ( ! isset( $_POST['wptsm_meta_nonce'] ) ||
             ! wp_verify_nonce( $_POST['wptsm_meta_nonce'], 'wptsm_save_meta' ) ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        $rating   = isset( $_POST['wptsm_rating'] )   ? absint( $_POST['wptsm_rating'] )              : 5;
        $rating   = min( 5, max( 1, $rating ) ); // Clamp 1–5.
        $company  = isset( $_POST['wptsm_company'] )  ? sanitize_text_field( $_POST['wptsm_company'] )  : '';
        $position = isset( $_POST['wptsm_position'] ) ? sanitize_text_field( $_POST['wptsm_position'] ) : '';
        $website  = isset( $_POST['wptsm_website'] )  ? esc_url_raw( $_POST['wptsm_website'] )          : '';
        $featured = isset( $_POST['wptsm_featured'] ) ? '1'                                              : '0';

        update_post_meta( $post_id, '_wptsm_rating',   $rating );
        update_post_meta( $post_id, '_wptsm_company',  $company );
        update_post_meta( $post_id, '_wptsm_position', $position );
        update_post_meta( $post_id, '_wptsm_website',  $website );
        update_post_meta( $post_id, '_wptsm_featured', $featured );

        // Invalidate transient cache whenever a testimonial is saved.
        $this->delete_all_testimonial_transients();
    }

    private function delete_all_testimonial_transients() {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_wptsm_%'
                OR option_name LIKE '_transient_timeout_wptsm_%'"
        );
    }
}