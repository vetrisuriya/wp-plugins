<?php
// includes/class-wptsm-email.php
defined( 'ABSPATH' ) || exit;

class WPTSM_Email {

    public function notify_admin( string $author, string $email, string $content, int $rating ): bool {
        $to      = WPTSM_Settings::get( 'notify_email', get_option( 'admin_email' ) );
        $subject = sprintf(
            /* translators: %s: site name */
            __( '[%s] New Testimonial Submitted', 'wp-testimonials-social-proof' ),
            get_bloginfo( 'name' )
        );

        $stars = str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating );

        $body = sprintf(
            /* translators: 1: author, 2: email, 3: stars, 4: content excerpt, 5: admin URL */
            __(
                "A new testimonial has been submitted.\n\nAuthor: %1\$s\nEmail: %2\$s\nRating: %3\$s\n\n\"%4\$s\"\n\nReview it here: %5\$s",
                'wp-testimonials-social-proof'
            ),
            $author,
            $email,
            $stars,
            wp_trim_words( $content, 30 ),
            admin_url( 'edit.php?post_type=wptsm_testimonial&post_status=pending' )
        );

        return wp_mail( $to, $subject, $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );
    }
}