<?php
// includes/class-wptsm-shortcodes.php
defined( 'ABSPATH' ) || exit;

class WPTSM_Shortcodes {

    public function __construct() {
        add_shortcode( 'testimonials',      array( $this, 'render_testimonials' ) );
        add_shortcode( 'testimonial_form',  array( $this, 'render_submission_form' ) );
        add_action( 'wp_enqueue_scripts',   array( $this, 'maybe_enqueue_assets' ) );
    }

    public function maybe_enqueue_assets() {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) ) {
            return;
        }
        $has_sc = has_shortcode( $post->post_content, 'testimonials' ) ||
                  has_shortcode( $post->post_content, 'testimonial_form' );
        if ( ! $has_sc ) {
            return;
        }

        wp_enqueue_style( 'wptsm-public', WPTSM_URL . 'public/css/wptsm-public.css', array(), WPTSM_VERSION );
        wp_enqueue_script( 'wptsm-public', WPTSM_URL . 'public/js/wptsm-public.js', array( 'jquery' ), WPTSM_VERSION, true );
        wp_localize_script( 'wptsm-public', 'WPTSMData', array(
            'ajax_url'     => admin_url( 'admin-ajax.php' ),
            'filter_nonce' => wp_create_nonce( 'wptsm_filter_nonce' ),
            'submit_nonce' => wp_create_nonce( 'wptsm_submit_nonce' ),
            'strings'      => array(
                'submit_success' => __( 'Thank you! Your testimonial has been received.', 'wp-testimonials-social-proof' ),
                'submit_error'   => __( 'Submission failed. Please try again.', 'wp-testimonials-social-proof' ),
                'loading'        => __( 'Loading…', 'wp-testimonials-social-proof' ),
            ),
        ) );
    }

    /**
     * [testimonials category="product" rating="5" limit="6" layout="grid"]
     */
    public function render_testimonials( array $atts ): string {

        $atts = shortcode_atts( array(
            'layout'       => 'grid',
            'columns'      => 3,
            'count'        => 9,
            'rating'       => 0,
            'category'     => '',
            'featured'     => 'false',
            'show_filter'  => 'false',
            'show_summary' => 'false',
            'orderby'      => 'date',
            'order'        => 'DESC',
            'clamp'        => 0,
            'autoplay'     => 0,
            'schema'       => 'true',
        ), $atts, 'testimonials' );

        // Backward compatibility for 'limit' attribute
        if ( isset( $atts['limit'] ) && ! empty( $atts['limit'] ) ) {
            $atts['count'] = $atts['limit'];
        }


        $cache_key     = 'wptsm_' . md5( serialize( $atts ) );
        $testimonials  = get_transient( $cache_key );

        if ( false === $testimonials ) {
            $meta_query = array( 'relation' => 'AND' );

            if ( ! empty( $atts['rating'] ) && intval($atts['rating']) > 0 ) {
                $meta_query[] = array(
                    'key'     => '_wptsm_rating',
                    'value'   => absint( $atts['rating'] ),
                    'compare' => '>=',
                    'type'    => 'NUMERIC',
                );
            }

            if ( $atts['featured'] === '1' || $atts['featured'] === 'true' ) {
                $meta_query[] = array(
                    'key'   => '_wptsm_featured',
                    'value' => '1',
                );
            }

            $query_args = array(
                'post_type'      => 'wptsm_testimonial',
                'post_status'    => 'publish',
                'posts_per_page' => absint( $atts['count'] ),
                'orderby'        => sanitize_text_field( $atts['orderby'] ),
                'order'          => sanitize_text_field( $atts['order'] ),
                'meta_query'     => $meta_query,
            );

            if ( ! empty( $atts['category'] ) ) {
                $query_args['tax_query'] = array( array(
                    'taxonomy' => 'wptsm_category',
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field( $atts['category'] ),
                ) );
            }

            $query        = new WP_Query( $query_args );
            $testimonials = $query->posts;
            set_transient( $cache_key, $testimonials, 30 * MINUTE_IN_SECONDS );
        }

        if ( empty( $testimonials ) ) {
            return '<p class="wptsm-empty">' . esc_html__( 'No testimonials found.', 'wp-testimonials-social-proof' ) . '</p>';
        }

        ob_start();
        $show_rating = '1' === WPTSM_Settings::get( 'show_rating', '1' );
        $layout_class = 'wptsm-layout-' . sanitize_html_class( $atts['layout'] );
        $show_filter  = ( $atts['show_filter'] === '1' || $atts['show_filter'] === 'true' );
        ?>
        <div class="wptsm-wrap">
            <?php if ( $show_filter ) : ?>
            <div class="wptsm-filters">
                <select id="wptsm-filter-rating" class="wptsm-filter-select wptsm-filter-rating" aria-label="<?php esc_attr_e( 'Filter by rating', 'wp-testimonials-social-proof' ); ?>">
                    <option value="">— <?php esc_html_e( 'All Ratings', 'wp-testimonials-social-proof' ); ?> —</option>
                    <?php for ( $i = 5; $i >= 1; $i-- ) : ?>
                        <option value="<?php echo $i; ?>"><?php echo esc_html( $i . ' ★ ' . ( $i === 1 ? __( 'and up', 'wp-testimonials-social-proof' ) : __( 'and up', 'wp-testimonials-social-proof' ) ) ); ?></option>
                    <?php endfor; ?>
                </select>
                <?php
                // Get categories for filter dropdown
                $categories = get_terms( array(
                    'taxonomy'   => 'wptsm_category',
                    'hide_empty' => true,
                ) );
                if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) :
                ?>
                <select id="wptsm-filter-category" class="wptsm-filter-select wptsm-filter-category" aria-label="<?php esc_attr_e( 'Filter by category', 'wp-testimonials-social-proof' ); ?>">
                    <option value="">— <?php esc_html_e( 'All Categories', 'wp-testimonials-social-proof' ); ?> —</option>
                    <?php foreach ( $categories as $cat ) : ?>
                        <option value="<?php echo esc_attr( $cat->slug ); ?>"><?php echo esc_html( $cat->name ); ?></option>
                    <?php endforeach; ?>
                </select>
                <?php endif; ?>
                <span class="wptsm-filter-count"><?php echo count( $testimonials ); ?> <?php esc_html_e( 'results', 'wp-testimonials-social-proof' ); ?></span>
            </div>
            <?php endif; ?>
            <div class="wptsm-wrapper <?php echo esc_attr( $layout_class ); ?>" id="wptsm-container" data-filter-nonce="<?php echo esc_attr( wp_create_nonce( 'wptsm_filter_nonce' ) ); ?>">
                <?php foreach ( $testimonials as $t ) :
                    $rating   = absint( get_post_meta( $t->ID, '_wptsm_rating',   true ) );
                    $company  = get_post_meta( $t->ID, '_wptsm_company',  true );
                    $position = get_post_meta( $t->ID, '_wptsm_position', true );
                    $website  = get_post_meta( $t->ID, '_wptsm_website',  true );
                    $avatar   = get_avatar( get_the_author_meta( 'email', $t->post_author ), 60 );

                    // Increment impression counter (lightweight metadata tracking).
                    $impressions = (int) get_post_meta( $t->ID, '_wptsm_impressions', true );
                    update_post_meta( $t->ID, '_wptsm_impressions', $impressions + 1 );
                ?>
                <div class="wptsm-card" data-rating="<?php echo esc_attr( $rating ); ?>">
                    <div class="wptsm-content">
                        <?php echo wp_kses_post( wpautop( $t->post_content ) ); ?>
                    </div>
                    <?php if ( $show_rating && $rating ) : ?>
                    <div class="wptsm-stars" aria-label="<?php echo esc_attr( sprintf( __( '%d out of 5 stars', 'wp-testimonials-social-proof' ), $rating ) ); ?>">
                        <?php echo esc_html( str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating ) ); ?>
                    </div>
                    <?php endif; ?>
                    <div class="wptsm-author">
                        <?php echo wp_kses_post( $avatar ); ?>
                        <div class="wptsm-author-info">
                            <strong class="wptsm-author-name">
                                <?php if ( $website ) : ?>
                                    <a href="<?php echo esc_url( $website ); ?>" rel="noopener noreferrer" target="_blank"><?php echo esc_html( $t->post_title ); ?></a>
                                <?php else : ?>
                                    <?php echo esc_html( $t->post_title ); ?>
                                <?php endif; ?>
                            </strong>
                            <?php if ( $position || $company ) : ?>
                            <span class="wptsm-author-role">
                                <?php echo esc_html( implode( ', ', array_filter( array( $position, $company ) ) ) ); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * [testimonial_form]
     * Renders a public form for visitors to submit a testimonial.
     */
    public function render_submission_form( array $atts ): string {
        if ( '1' !== WPTSM_Settings::get( 'allow_submissions', '1' ) ) {
            return '<p>' . esc_html__( 'Testimonial submissions are currently closed.', 'wp-testimonials-social-proof' ) . '</p>';
        }

        ob_start();
        ?>
        <div class="wptsm-wrap">
            <div id="wptsm-form-message" role="alert" aria-live="polite"></div>
            <form id="wptsm-submission-form" class="wptsm-submission-form" method="post" autocomplete="off" novalidate>
                <h2 class="wptsm-form-title"><?php esc_html_e( 'Share Your Testimonial', 'wp-testimonials-social-proof' ); ?></h2>
                <p class="wptsm-form-subtitle"><?php esc_html_e( 'Tell us about your experience. We\'d love to hear from you!', 'wp-testimonials-social-proof' ); ?></p>

                <!-- Honeypot field (hidden from users) -->
                <div class="wptsm-hp-field">
                    <input type="text" name="website_url" class="wptsm-hp-input" tabindex="-1" autocomplete="off" />
                </div>

                <!-- Name Field -->
                <div class="wptsm-form-row">
                    <label for="wptsm-f-name" class="wptsm-field-label">
                        <?php esc_html_e( 'Your Name', 'wp-testimonials-social-proof' ); ?>
                        <span class="wptsm-req" aria-label="required">*</span>
                    </label>
                    <input 
                        type="text" 
                        id="wptsm-f-name" 
                        name="name"
                        class="wptsm-input" 
                        placeholder="<?php esc_attr_e( 'John Doe', 'wp-testimonials-social-proof' ); ?>"
                        required 
                        aria-required="true"
                        aria-describedby="wptsm-f-name-error"
                    />
                    <span class="wptsm-field-error" id="wptsm-f-name-error" role="alert"></span>
                </div>

                <!-- Email Field -->
                <div class="wptsm-form-row">
                    <label for="wptsm-f-email" class="wptsm-field-label">
                        <?php esc_html_e( 'Email Address', 'wp-testimonials-social-proof' ); ?>
                        <span class="wptsm-req" aria-label="required">*</span>
                    </label>
                    <input 
                        type="email" 
                        id="wptsm-f-email" 
                        name="email"
                        class="wptsm-input" 
                        placeholder="<?php esc_attr_e( 'you@example.com', 'wp-testimonials-social-proof' ); ?>"
                        required 
                        aria-required="true"
                        aria-describedby="wptsm-f-email-error"
                    />
                    <span class="wptsm-field-error" id="wptsm-f-email-error" role="alert"></span>
                </div>

                <!-- Company & Role Fields (2-column on desktop) -->
                <div class="wptsm-form-row wptsm-form-row--2col">
                    <div>
                        <label for="wptsm-f-company" class="wptsm-field-label">
                            <?php esc_html_e( 'Company / Organization', 'wp-testimonials-social-proof' ); ?>
                        </label>
                        <input 
                            type="text" 
                            id="wptsm-f-company" 
                            name="company"
                            class="wptsm-input" 
                            placeholder="<?php esc_attr_e( 'Your Company', 'wp-testimonials-social-proof' ); ?>"
                            aria-describedby="wptsm-f-company-error"
                        />
                        <span class="wptsm-field-error" id="wptsm-f-company-error" role="alert"></span>
                    </div>
                    <div>
                        <label for="wptsm-f-role" class="wptsm-field-label">
                            <?php esc_html_e( 'Position / Role', 'wp-testimonials-social-proof' ); ?>
                        </label>
                        <input 
                            type="text" 
                            id="wptsm-f-role" 
                            name="role"
                            class="wptsm-input" 
                            placeholder="<?php esc_attr_e( 'CEO, Manager, etc.', 'wp-testimonials-social-proof' ); ?>"
                            aria-describedby="wptsm-f-role-error"
                        />
                        <span class="wptsm-field-error" id="wptsm-f-role-error" role="alert"></span>
                    </div>
                </div>

                <!-- Star Rating -->
                <div class="wptsm-form-row">
                    <label class="wptsm-field-label">
                        <?php esc_html_e( 'Star Rating', 'wp-testimonials-social-proof' ); ?>
                        <span class="wptsm-req" aria-label="required">*</span>
                    </label>
                    <div class="wptsm-star-picker-wrap">
                        <span class="wptsm-star-picker" role="slider" aria-valuemin="1" aria-valuemax="5" aria-valuenow="0" tabindex="0" aria-label="<?php esc_attr_e( 'Select your star rating', 'wp-testimonials-social-proof' ); ?>">
                            <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                                <button 
                                    type="button" 
                                    class="wptsm-star-picker__btn" 
                                    data-value="<?php echo $i; ?>" 
                                    aria-label="<?php echo esc_attr( sprintf( __( 'Rate %d stars', 'wp-testimonials-social-proof' ), $i ) ); ?>"
                                    aria-pressed="false"
                                >★</button>
                            <?php endfor; ?>
                        </span>
                        <input type="hidden" class="wptsm-rating-input" value="" aria-hidden="true" />
                        <span class="wptsm-star-picker-hint" aria-live="polite"></span>
                    </div>
                    <span class="wptsm-field-error" id="wptsm-f-rating-error" role="alert"></span>
                </div>

                <!-- Testimonial Content -->
                <div class="wptsm-form-row">
                    <label for="wptsm-f-content" class="wptsm-field-label">
                        <?php esc_html_e( 'Your Testimonial', 'wp-testimonials-social-proof' ); ?>
                        <span class="wptsm-req" aria-label="required">*</span>
                    </label>
                    <textarea 
                        id="wptsm-f-content" 
                        name="content"
                        class="wptsm-textarea" 
                        rows="6" 
                        maxlength="2000"
                        placeholder="<?php esc_attr_e( 'Share your experience with us...', 'wp-testimonials-social-proof' ); ?>"
                        required 
                        aria-required="true"
                        aria-describedby="wptsm-f-content-error wptsm-f-content-count"
                    ></textarea>
                    <div class="wptsm-char-count" id="wptsm-f-content-count">0 / 2000</div>
                    <span class="wptsm-field-error" id="wptsm-f-content-error" role="alert"></span>
                </div>

                <!-- Submit Button -->
                <button 
                    type="submit" 
                    id="wptsm-submit-btn" 
                    class="wptsm-submit-btn"
                    aria-busy="false"
                >
                    <?php esc_html_e( 'Submit Testimonial', 'wp-testimonials-social-proof' ); ?>
                </button>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }
}