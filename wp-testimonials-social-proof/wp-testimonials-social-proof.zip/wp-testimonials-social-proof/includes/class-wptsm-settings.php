<?php
// includes/class-wptsm-settings.php
defined( 'ABSPATH' ) || exit;

class WPTSM_Settings {

    const OPTION_KEY = 'wptsm_options';

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
    }

    public static function get( string $key, $default = '' ) {
        $options = get_option( self::OPTION_KEY, array() );
        return $options[ $key ] ?? $default;
    }

    public function add_settings_page() {
        add_submenu_page(
            'edit.php?post_type=wptsm_testimonial',
            __( 'Testimonial Settings', 'wp-testimonials-social-proof' ),
            __( 'Settings', 'wp-testimonials-social-proof' ),
            'manage_options',
            'wptsm-settings',
            array( $this, 'render_page' )
        );
    }

    public function register_settings() {
        register_setting( 'wptsm_group', self::OPTION_KEY, array(
            'sanitize_callback' => array( $this, 'sanitize' ),
        ) );

        // ── Section: Display ──────────────────────────────────────
        add_settings_section( 'wptsm_display', __( 'Display Settings', 'wp-testimonials-social-proof' ), '__return_false', 'wptsm-settings' );

        add_settings_field( 'per_page', __( 'Testimonials Per Page', 'wp-testimonials-social-proof' ),
            function () {
                $val = self::get( 'per_page', 6 );
                echo '<input type="number" name="' . esc_attr( self::OPTION_KEY ) . '[per_page]" value="' . esc_attr( $val ) . '" min="1" max="50" />';
            },
            'wptsm-settings', 'wptsm_display'
        );

        add_settings_field( 'show_rating', __( 'Show Star Ratings', 'wp-testimonials-social-proof' ),
            function () {
                $checked = checked( self::get( 'show_rating', '1' ), '1', false );
                echo '<input type="checkbox" name="' . esc_attr( self::OPTION_KEY ) . '[show_rating]" value="1" ' . $checked . ' />';
            },
            'wptsm-settings', 'wptsm_display'
        );

        // ── Section: Submissions ──────────────────────────────────
        add_settings_section( 'wptsm_submissions', __( 'Front-End Submissions', 'wp-testimonials-social-proof' ), '__return_false', 'wptsm-settings' );

        add_settings_field( 'allow_submissions', __( 'Allow Public Submissions', 'wp-testimonials-social-proof' ),
            function () {
                $checked = checked( self::get( 'allow_submissions', '1' ), '1', false );
                echo '<input type="checkbox" name="' . esc_attr( self::OPTION_KEY ) . '[allow_submissions]" value="1" ' . $checked . ' />';
            },
            'wptsm-settings', 'wptsm_submissions'
        );

        add_settings_field( 'auto_approve', __( 'Auto-Approve Submissions', 'wp-testimonials-social-proof' ),
            function () {
                $checked = checked( self::get( 'auto_approve', '0' ), '1', false );
                echo '<input type="checkbox" name="' . esc_attr( self::OPTION_KEY ) . '[auto_approve]" value="1" ' . $checked . ' />';
                echo '<p class="description">' . esc_html__( 'When off, new submissions go to "Pending Review".', 'wp-testimonials-social-proof' ) . '</p>';
            },
            'wptsm-settings', 'wptsm_submissions'
        );

        add_settings_field( 'notify_email', __( 'Notification Email', 'wp-testimonials-social-proof' ),
            function () {
                $val = self::get( 'notify_email', get_option( 'admin_email' ) );
                echo '<input type="email" name="' . esc_attr( self::OPTION_KEY ) . '[notify_email]" value="' . esc_attr( $val ) . '" class="regular-text" />';
            },
            'wptsm-settings', 'wptsm_submissions'
        );
    }

    public function sanitize( array $input ): array {
        return array(
            'per_page'          => min( 50, max( 1, absint( $input['per_page'] ?? 6 ) ) ),
            'show_rating'       => ! empty( $input['show_rating'] ) ? '1' : '0',
            'allow_submissions' => ! empty( $input['allow_submissions'] ) ? '1' : '0',
            'auto_approve'      => ! empty( $input['auto_approve'] ) ? '1' : '0',
            'notify_email'      => sanitize_email( $input['notify_email'] ?? '' ),
        );
    }

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Testimonial Settings', 'wp-testimonials-social-proof' ); ?></h1>

            <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; margin-bottom: 24px; max-width: 700px;">
                <h2 style="margin-top:0;">How to Use</h2>
                <p><strong>Display testimonials anywhere:</strong></p>
                <pre style="background:#f6f8fa; padding:8px; border-radius:4px;">[testimonials]</pre>
                <p>You can add the <code>[testimonials]</code> shortcode to any page, post, or widget to display your testimonials. <br>
                <em>Example:</em> <code>[testimonials count="9" layout="grid" show_filter="true" category="product"]</code></p>

                <h2>Display Testimonial Submission Form</h2>
                <p><strong>Show a form for visitors to submit testimonials:</strong></p>
                <pre style="background:#f6f8fa; padding:8px; border-radius:4px;">[testimonial_form]</pre>
                <p>Use the <code>[testimonial_form]</code> shortcode to display a public form where visitors can submit their testimonials. <br>
                <em>Note:</em> Make sure "Allow Public Submissions" is enabled in settings below.</p>

                <h2>Testimonials Shortcode Parameters</h2>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li><code>count</code> - Number of testimonials to display (default: 9)</li>
                    <li><code>layout</code> - Display layout: "grid" or "slider" (default: grid)</li>
                    <li><code>columns</code> - Grid columns for layout (default: 3)</li>
                    <li><code>category</code> - Filter by category slug</li>
                    <li><code>rating</code> - Minimum star rating to display (1-5, default: 0)</li>
                    <li><code>featured</code> - Show only featured testimonials (true/false)</li>
                    <li><code>show_filter</code> - Display filter dropdowns (true/false)</li>
                    <li><code>orderby</code> - Sort by: "date" or "title" (default: date)</li>
                    <li><code>order</code> - Sort order: "DESC" or "ASC" (default: DESC)</li>
                </ul>

                <h2>Viewing and Using Ratings</h2>
                <p>Each testimonial can have a star rating (1–5). Ratings are shown in the admin list table as stars.<br>
                To view or edit ratings, go to <strong>Testimonials</strong> in the admin menu and check the “Rating” column.</p>

                <h2>Love this plugin?</h2>
                <p>If you find <strong>WP Testimonials Social Proof</strong> helpful, please <a href="https://wordpress.org/plugins/wp-testimonials-social-proof/#reviews" target="_blank">leave us a 5-star review</a>! Your feedback helps us improve and grow.</p>
            </div>

            <form method="post" action="options.php">
                <?php
                settings_fields( 'wptsm_group' );
                do_settings_sections( 'wptsm-settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
}