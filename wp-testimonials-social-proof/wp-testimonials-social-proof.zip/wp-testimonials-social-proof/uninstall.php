<?php
// uninstall.php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

// Remove all testimonial posts and meta.
$post_ids = $wpdb->get_col(
    "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'wptsm_testimonial'"
);
foreach ( $post_ids as $id ) {
    wp_delete_post( (int) $id, true );
}

// Remove plugin options.
delete_option( 'wptsm_options' );
delete_option( 'wptsm_total_submissions' );
delete_option( 'wptsm_version' );

// Remove transients.
$wpdb->query(
    "DELETE FROM {$wpdb->options}
     WHERE option_name LIKE '_transient_wptsm_%'
        OR option_name LIKE '_transient_timeout_wptsm_%'"
);

// Remove capabilities.
$role = get_role( 'administrator' );
if ( $role ) {
    $role->remove_cap( 'moderate_testimonials' );
}