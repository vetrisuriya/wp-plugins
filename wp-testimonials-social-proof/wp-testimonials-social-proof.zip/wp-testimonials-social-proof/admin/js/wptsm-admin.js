/* ══════════════════════════════════════════════════════════════════
   FILE: wp-testimonials-social-proof/admin/js/wptsm-admin.js
   Enqueued by: class-wptsm-settings.php → enqueue_admin_assets()
   Depends on:  jquery, wp-color-picker
   ══════════════════════════════════════════════════════════════════ */
 
/**
 * wptsm-admin.js
 *
 * Features:
 *  1. Settings tab navigation (no page reload)
 *  2. WordPress Colour Picker with preset swatches
 *  3. Star rating picker in meta box
 *  4. Shortcode builder — live shortcode string update
 *  5. Copy shortcode to clipboard
 *  6. Bulk quick-approve AJAX
 *  7. Settings form confirmation before reset
 */
 
 
( function ( $, window ) {
    'use strict';
 
    var ADMIN = ( typeof WPTSMAdmin !== 'undefined' ) ? WPTSMAdmin : {};
 
    $( function () {
        initTabs();
        initColourPicker();
        initMetaStarPicker();
        initShortcodeBuilder();
        initBulkApprove();
        initResetConfirm();
    } );
 
    // 1.  Settings tab navigation
    function initTabs() {
        var $btns   = $( '.wptsm-tab-btn' );
        var $panels = $( '.wptsm-tab-panel' );
 
        // Restore last active tab from sessionStorage
        var saved = sessionStorage.getItem( 'wptsm_tab' );
        if ( saved ) {
            $btns.removeClass( 'is-active' ).filter( '[data-tab="' + saved + '"]' ).addClass( 'is-active' );
            $panels.removeClass( 'is-active' ).filter( '#wptsm-tab-' + saved ).addClass( 'is-active' );
        } else {
            $btns.first().addClass( 'is-active' );
            $panels.first().addClass( 'is-active' );
        }
 
        $btns.on( 'click', function () {
            var tab = $( this ).data( 'tab' );
            $btns.removeClass( 'is-active' );
            $( this ).addClass( 'is-active' );
            $panels.removeClass( 'is-active' );
            $( '#wptsm-tab-' + tab ).addClass( 'is-active' );
            sessionStorage.setItem( 'wptsm_tab', tab );
        } );
    }
 
    // 2.  WordPress Colour Picker
    function initColourPicker() {
        $( '.wptsm-colour-picker' ).wpColorPicker( {
            change: function () {
                schedulePreviewRefresh();
            }
        } );
 
        $( '.wptsm-colour-swatch' ).on( 'click', function () {
            var color = $( this ).data( 'colour' );
            $( this ).closest( '.wptsm-field-input' ).find( '.wptsm-colour-picker' ).wpColorPicker( 'color', color );
            $( '.wptsm-colour-swatch' ).removeClass( 'is-active' );
            $( this ).addClass( 'is-active' );
        } );
    }
 
    // 3.  Meta box star rating picker (radio-based)
    function initMetaStarPicker() {
        var $wrap    = $( '#wptsm-meta-rating-wrap' );
        if ( ! $wrap.length ) return;
 
        var hints    = ADMIN.ratingHints || [ '', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent' ];
        var $text    = $wrap.find( '.wptsm-mb-rating-text' );
 
        $wrap.find( 'input[type="radio"]' ).on( 'change', function () {
            var val = parseInt( $( this ).val(), 10 );
            $text.text( hints[ val ] || '' );
        } ).filter( ':checked' ).trigger( 'change' );
 
        $wrap.find( 'label' ).on( 'mouseenter', function () {
            var val = parseInt( $( this ).prev( 'input' ).val(), 10 );
            $text.text( hints[ val ] || '' );
        } );
        $wrap.find( '.wptsm-mb-star-picker' ).on( 'mouseleave', function () {
            var checked = $( this ).find( 'input:checked' ).val();
            $text.text( hints[ parseInt( checked, 10 ) ] || '' );
        } );
    }
 
    // 4.  Shortcode builder — live update
    function initShortcodeBuilder() {
        var $builder = $( '.wptsm-sc-builder' );
        if ( ! $builder.length ) return;
 
        var $output  = $builder.find( '.wptsm-sc-output' );
 
        function buildShortcode() {
            var parts = [ '[testimonials' ];
            $builder.find( '.wptsm-sc-field-row' ).each( function () {
                var $inp = $( this ).find( 'select, input' );
                var attr = $inp.attr( 'name' );
                var val  = $inp.val();
                if ( attr && val && val !== $inp.data( 'default' ) ) {
                    parts.push( ' ' + attr + '="' + escHtml( val ) + '"' );
                }
            } );
            parts.push( ']' );
            $output.text( parts.join( '' ) );
        }
 
        $builder.find( 'select, input' ).on( 'change input', buildShortcode );
        buildShortcode();
 
        // Copy on click
        $output.on( 'click', function () {
            var code = $( this ).text().trim();
            navigator.clipboard.writeText( code )
                .then( function () {
                    $output.addClass( 'is-copied' );
                    setTimeout( function () { $output.removeClass( 'is-copied' ); }, 2000 );
                } )
                .catch( function () {
                    // Fallback
                    var $tmp = $( '<textarea>' ).val( code ).appendTo( 'body' );
                    $tmp[0].select();
                    document.execCommand( 'copy' );
                    $tmp.remove();
                    $output.addClass( 'is-copied' );
                    setTimeout( function () { $output.removeClass( 'is-copied' ); }, 2000 );
                } );
        } );
    }
 
    // 5.  Bulk quick-approve via AJAX
    function initBulkApprove() {
        $( document ).on( 'click', '.wptsm-quick-approve', function ( e ) {
            e.preventDefault();
            var $btn = $( this );
            var id   = $btn.data( 'id' );
            if ( ! id ) return;
 
            $btn.text( '…' ).prop( 'disabled', true );
 
            $.post( ADMIN.ajaxUrl, {
                action: 'wptsm_quick_approve',
                nonce:  ADMIN.nonce,
                id:     id,
            }, function ( res ) {
                if ( res.success ) {
                    $btn.closest( 'tr' ).find( '.post-state' ).text( 'Published' );
                    $btn.remove();
                } else {
                    $btn.text( 'Error' );
                }
            } );
        } );
    }
 
    // 6.  Reset settings confirm
    function initResetConfirm() {
        $( '#wptsm-reset-btn' ).on( 'click', function ( e ) {
            if ( ! window.confirm( ADMIN.l10n.resetConfirm || 'Reset all settings to defaults? This cannot be undone.' ) ) {
                e.preventDefault();
            }
        } );
    }
 
    // Utility
    function escHtml( str ) {
        return String( str )
            .replace( /&/g, '&amp;' )
            .replace( /</g, '&lt;' )
            .replace( />/g, '&gt;' )
            .replace( /"/g, '&quot;' );
    }
 
    function schedulePreviewRefresh() {
        clearTimeout( window._wptsmPrevTimer );
        window._wptsmPrevTimer = setTimeout( function () {
            var $frame = $( '#wptsm-preview-frame' );
            if ( $frame.length ) {
                var src = $frame.attr( 'src' ).replace( /&_t=\d+/, '' ) + '&_t=' + Date.now();
                $frame.attr( 'src', src );
            }
        }, 800 );
    }
 
}( jQuery, window ) );