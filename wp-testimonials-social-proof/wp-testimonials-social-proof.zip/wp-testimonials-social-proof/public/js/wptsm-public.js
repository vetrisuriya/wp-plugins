/**
 * WP Testimonials & Social Proof
 * FILE: wp-testimonials-social-proof/public/js/wptsm-public.js
 *
 * Enqueued by: class-wptsm-shortcodes.php → maybe_enqueue_assets()
 * Depends on:  wp_localize_script( 'wptsm-public', 'WPTSMData', [...] )
 *
 * Features:
 *  01. Star Rating Picker (interactive click/keyboard)
 *  02. Front-End Submission Form (AJAX + honeypot + validation)
 *  03. AJAX Filter (rating + category dropdowns)
 *  04. Load More (AJAX pagination)
 *  05. Carousel / Slider (touch + keyboard + autoplay)
 *  06. Read More / Truncation toggle
 *  07. Rating Distribution bar animation (on scroll)
 *  08. Schema.org AggregateRating JSON-LD (injected)
 *  09. Proof counter strip animation
 *  10. Lazy-load avatars (IntersectionObserver)
 *  11. Accessibility: focus trap, ARIA live regions
 */

/* global WPTSMData, jQuery */
( function ( $, document, window ) {
    'use strict';

    /* ── Data passed from PHP via wp_localize_script ─────────────
       WPTSMData = {
         ajax_url,
         submit_nonce, filter_nonce, load_nonce,
         shortcode_id,
         clamp_lines,     // integer, 0 = no clamp
         autoplay,        // seconds or 0
         slide_cols,      // 1-3
         schema_data,     // {avg, count, min, max, name, url} or null
         strings: { loading, load_more, no_more, error, rating_hints[1..5] }
       }
    ────────────────────────────────────────────────────────────── */

    var D = ( typeof WPTSMData !== 'undefined' ) ? WPTSMData : {};

    /* ── Initialise on DOM ready ─────────────────────────────── */
    $( function () {
        initStarPicker();
        initSubmissionForm();
        initAjaxFilter();
        initLoadMore();
        initCarousel();
        initReadMore();
        initDistBars();
        injectSchemaOrg();
        initCounterStrip();
        initLazyAvatars();
    } );

    /* ══════════════════════════════════════════════════════════════
       01.  STAR RATING PICKER
    ══════════════════════════════════════════════════════════════ */
    function initStarPicker() {
        $( '.wptsm-star-picker' ).each( function () {
            var $picker = $( this );
            var $input  = $picker.siblings( 'input[type="hidden"].wptsm-rating-input' );
            var $hint   = $picker.siblings( '.wptsm-star-picker-hint' );
            var hints   = D.strings && D.strings.rating_hints
                ? D.strings.rating_hints
                : [ '', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent' ];
            var current = parseInt( $input.val(), 10 ) || 0;

            var $btns = $picker.find( '.wptsm-star-picker__btn' );

            /* Mark already-set rating on page load */
            if ( current > 0 ) {
                highlightUpTo( current );
                $hint.text( hints[ current ] || '' ).addClass( 'is-set' );
            }

            /* Hover: preview fill */
            $btns.on( 'mouseenter', function () {
                var val = parseInt( $( this ).data( 'value' ), 10 );
                highlightUpTo( val );
                $hint.text( hints[ val ] || '' );
            } );

            $picker.on( 'mouseleave', function () {
                var saved = parseInt( $input.val(), 10 ) || 0;
                highlightUpTo( saved );
                $hint.text( saved ? ( hints[ saved ] || '' ) : '' );
            } );

            /* Click: set rating */
            $btns.on( 'click', function () {
                var val = parseInt( $( this ).data( 'value' ), 10 );
                $input.val( val ).trigger( 'change' );
                highlightUpTo( val );
                $hint.text( hints[ val ] || '' ).addClass( 'is-set' );
                $btns.removeClass( 'is-active' );
                $btns.filter( '[data-value="' + val + '"]' ).addClass( 'is-active' );
                current = val;
                /* Update ARIA */
                $picker.attr( 'aria-valuenow', val );
            } );

            /* Keyboard: arrow keys */
            $btns.on( 'keydown', function ( e ) {
                var val = parseInt( $( this ).data( 'value' ), 10 );
                if ( e.key === 'ArrowRight' || e.key === 'ArrowUp' ) {
                    e.preventDefault();
                    var next = Math.min( 5, val + 1 );
                    $btns.filter( '[data-value="' + next + '"]' ).trigger( 'click' ).focus();
                }
                if ( e.key === 'ArrowLeft' || e.key === 'ArrowDown' ) {
                    e.preventDefault();
                    var prev = Math.max( 1, val - 1 );
                    $btns.filter( '[data-value="' + prev + '"]' ).trigger( 'click' ).focus();
                }
            } );

            function highlightUpTo( val ) {
                $btns.each( function () {
                    var btnVal = parseInt( $( this ).data( 'value' ), 10 );
                    $( this ).toggleClass( 'is-active', btnVal <= val );
                } );
            }
        } );
    }

    /* ══════════════════════════════════════════════════════════════
       02.  FRONT-END SUBMISSION FORM
    ══════════════════════════════════════════════════════════════ */
    function initSubmissionForm() {
        var $form   = $( '#wptsm-submission-form' );
        var $btn    = $form.find( '#wptsm-submit-btn' );
        var $msg    = $form.find( '#wptsm-form-message' );
        if ( ! $form.length ) return;

        // Character counter for content textarea
        var $content   = $form.find( '#wptsm-f-content' );
        var $charCount = $form.find( '.wptsm-char-count' );
        var maxChars   = parseInt( $content.attr( 'maxlength' ), 10 ) || 0;

        if ( $charCount.length && maxChars ) {
            $content.on( 'input', function () {
                var len = $( this ).val().length;
                $charCount.text( len + ' / ' + maxChars );
                $charCount.toggleClass( 'is-limit', len >= maxChars );
            } );
        }

        // Clear field error on input
        $form.on( 'input change', '.wptsm-input, .wptsm-textarea', function () {
            $( this ).removeClass( 'has-error' );
            // Clear associated error message
            var errorId = $( this ).attr( 'aria-describedby' );
            if ( errorId ) {
                $form.find( '#' + errorId ).text( '' );
            }
        } );

        $btn.on( 'click', handleSubmit );
        $form.on( 'submit', function ( e ) { e.preventDefault(); handleSubmit(); } );

        function fieldError( $el, errorId, msg ) {
            $el.addClass( 'has-error' );
            // Display error in the associated error span
            if ( errorId ) {
                $form.find( '#' + errorId ).text( msg );
            } else {
                // Fallback: create error after element if no error span
                if ( ! $el.siblings( '.wptsm-field-error' ).length ) {
                    $el.after( '<span class="wptsm-field-error" role="alert">' + escHtml( msg ) + '</span>' );
                } else {
                    $el.siblings( '.wptsm-field-error' ).text( msg );
                }
            }
        }

        function handleSubmit() {
            // Clear previous messages
            $msg.removeClass( 'wptsm-success wptsm-error' ).text( '' ).hide();
            $form.find( '.wptsm-input, .wptsm-textarea' ).removeClass( 'has-error' );
            $form.find( '.wptsm-field-error' ).text( '' );

            var name    = $form.find( '#wptsm-f-name' ).val().trim();
            var email   = $form.find( '#wptsm-f-email' ).val().trim();
            var company = $form.find( '#wptsm-f-company' ).val().trim();
            var role    = $form.find( '#wptsm-f-role' ).val().trim();
            var rating  = $form.find( '.wptsm-rating-input' ).val();
            var content = $form.find( '#wptsm-f-content' ).val().trim();
            var honey   = $form.find( '.wptsm-hp-input' ).val();

            /* Client-side validation */
            var valid = true;

            if ( ! name ) {
                fieldError( $form.find( '#wptsm-f-name' ), 'wptsm-f-name-error', D.strings.name_required || 'Name is required.' );
                valid = false;
            }
            if ( ! email ) {
                fieldError( $form.find( '#wptsm-f-email' ), 'wptsm-f-email-error', D.strings.email_required || 'Email is required.' );
                valid = false;
            } else if ( ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( email ) ) {
                fieldError( $form.find( '#wptsm-f-email' ), 'wptsm-f-email-error', D.strings.email_invalid || 'Please enter a valid email.' );
                valid = false;
            }
            if ( ! content ) {
                fieldError( $form.find( '#wptsm-f-content' ), 'wptsm-f-content-error', D.strings.content_required || 'Please share your experience.' );
                valid = false;
            }
            if ( ! rating || rating < 1 ) {
                $form.find( '#wptsm-f-rating-error' ).text( D.strings.rating_required || 'Please select a rating.' );
                $form.find( '.wptsm-star-picker-hint' ).css( 'color', 'var(--wptsm-error)' );
                valid = false;
            } else {
                $form.find( '.wptsm-star-picker-hint' ).css( 'color', '' );
            }

            if ( ! valid ) return;

            /* Honeypot check (client-side guard — real check is server-side) */
            if ( honey ) return;

            setLoading( true );

            $.post( D.ajax_url, {
                action:  'wptsm_submit',
                nonce:   D.submit_nonce,
                name:    name,
                email:   email,
                company: company,
                role:    role,
                rating:  rating,
                content: content,
            } )
            .done( function ( res ) {
                setLoading( false );
                if ( res.success ) {
                    $form.slideUp( 300 );
                    $msg.addClass( 'wptsm-success' )
                        .text( res.data.message || D.strings.success || 'Thank you for your testimonial!' )
                        .slideDown( 300 )
                        .attr( 'role', 'status' );

                    // Analytics event
                    fireEvent( 'testimonial_submitted', { rating: parseInt( rating, 10 ) } );
                } else {
                    setLoading( false );
                    $msg.addClass( 'wptsm-error' )
                        .text( ( res.data && res.data.message ) || D.strings.error || 'Submission failed. Please try again.' )
                        .slideDown( 250 )
                        .attr( 'role', 'alert' );
                }
            } )
            .fail( function () {
                setLoading( false );
                $msg.addClass( 'wptsm-error' )
                    .text( D.strings.error || 'Network error. Please try again.' )
                    .slideDown( 250 )
                    .attr( 'role', 'alert' );
            } );
        }

        function setLoading( loading ) {
            if ( loading ) {
                $btn.prop( 'disabled', true ).attr( 'aria-busy', 'true' );
                $btn.html( '<span class="wptsm-btn-spinner" aria-hidden="true"></span>' +
                    escHtml( D.strings.loading || 'Submitting…' ) );
            } else {
                $btn.prop( 'disabled', false ).attr( 'aria-busy', 'false' );
                $btn.text( D.strings.submit_label || 'Submit Testimonial' );
            }
        }
    }

    /* ══════════════════════════════════════════════════════════════
       03.  AJAX FILTER
    ══════════════════════════════════════════════════════════════ */
    function initAjaxFilter() {
        $( document ).on( 'change', '.wptsm-filter-select', function () {
            var $wrap     = $( this ).closest( '.wptsm-wrap' );
            var $grid     = $wrap.find( '#wptsm-container' );
            var filterNonce = $grid.data( 'filter-nonce' );
            var rating    = $wrap.find( '#wptsm-filter-rating' ).val()   || 0;
            var category  = $wrap.find( '#wptsm-filter-category' ).val() || '';

            // Show skeleton loaders
            $grid.html( buildSkeletons( 3 ) );

            // Reset load-more page counter
            $wrap.find( '.wptsm-load-more-btn' ).data( 'page', 1 ).show();

            $.post( D.ajax_url, {
                action:   'wptsm_filter',
                nonce:    filterNonce,
                rating:   rating,
                category: category,
            } )
            .done( function ( res ) {
                if ( res.success ) {
                    $grid.html( res.data.html );
                    updateResultCount( $wrap, res.data.total || 0 );

                    // Hide load-more if all results returned
                    if ( ! res.data.has_more ) {
                        $wrap.find( '.wptsm-load-more-btn' ).hide();
                    }
                    // Re-init read-more on new cards
                    initReadMore( $grid );
                } else {
                    $grid.html( buildEmpty() );
                }
            } )
            .fail( function () {
                $grid.html( buildEmpty( D.strings.error || 'Could not load testimonials.' ) );
            } );
        } );
    }

    /* ══════════════════════════════════════════════════════════════
       04.  LOAD MORE (AJAX pagination)
    ══════════════════════════════════════════════════════════════ */
    function initLoadMore() {
        $( document ).on( 'click', '.wptsm-load-more-btn', function () {
            var $btn   = $( this );
            var $wrap  = $btn.closest( '.wptsm-wrap' );
            var $grid  = $wrap.find( '#wptsm-container' );
            var page   = ( $btn.data( 'page' ) || 1 ) + 1;
            var nonce  = $btn.data( 'nonce' );
            var rating = $wrap.find( '#wptsm-filter-rating' ).val()   || 0;
            var cat    = $wrap.find( '#wptsm-filter-category' ).val() || '';

            $btn.addClass( 'is-loading' )
                .prop( 'disabled', true )
                .text( D.strings.loading || 'Loading…' );

            $.post( D.ajax_url, {
                action:   'wptsm_filter',
                nonce:    nonce,
                rating:   rating,
                category: cat,
                page:     page,
            } )
            .done( function ( res ) {
                $btn.removeClass( 'is-loading' ).prop( 'disabled', false ).text( D.strings.load_more || 'Load More' );
                if ( res.success && res.data.html ) {
                    $grid.append( res.data.html );
                    $btn.data( 'page', page );
                    if ( ! res.data.has_more ) {
                        $btn.hide();
                        $btn.after( '<p class="wptsm-no-more">' + escHtml( D.strings.no_more || 'All testimonials loaded.' ) + '</p>' );
                    }
                    // Re-init read-more on new cards
                    initReadMore( $( res.data.html ) );
                } else {
                    $btn.hide();
                }
            } )
            .fail( function () {
                $btn.removeClass( 'is-loading' ).prop( 'disabled', false ).text( D.strings.load_more || 'Load More' );
            } );
        } );
    }

    /* ══════════════════════════════════════════════════════════════
       05.  CAROUSEL / SLIDER
    ══════════════════════════════════════════════════════════════ */
    function initCarousel() {
        $( '.wptsm-carousel-wrap' ).each( function () {
            var $wrap   = $( this );
            var $track  = $wrap.find( '.wptsm-carousel-track' );
            var $cards  = $track.children( '.wptsm-card' );
            var $prev   = $wrap.find( '.wptsm-carousel-btn--prev' );
            var $next   = $wrap.find( '.wptsm-carousel-btn--next' );
            var $dots   = $wrap.find( '.wptsm-dot' );
            var $fill   = $wrap.find( '.wptsm-autoplay-fill' );

            if ( ! $track.length || ! $cards.length ) return;

            var cols     = parseInt( $wrap.data( 'cols' ) || D.slide_cols || 1, 10 );
            var total    = $cards.length;
            var current  = 0;
            var automs   = ( parseInt( $wrap.data( 'autoplay' ) || D.autoplay || 0, 10 ) ) * 1000;
            var autoTimer;
            var isPaused = false;

            /* Set CSS variable for slide width */
            $wrap.css( '--wptsm-slide-cols', cols );

            function goTo( idx ) {
                idx = Math.max( 0, Math.min( idx, total - cols ) );
                current = idx;
                var pct = ( 100 / cols ) * idx;
                $track.css( 'transform', 'translateX(-' + pct + '%)' );
                $prev.prop( 'disabled', idx === 0 );
                $next.prop( 'disabled', idx >= total - cols );
                $dots.removeClass( 'is-active' ).eq( idx ).addClass( 'is-active' );
                // ARIA
                $cards.attr( 'aria-hidden', 'true' )
                      .slice( idx, idx + cols )
                      .attr( 'aria-hidden', 'false' );
                resetAutoplay();
            }

            $prev.on( 'click', function () { goTo( current - 1 ); } );
            $next.on( 'click', function () { goTo( current + 1 ); } );
            $dots.on( 'click', function () { goTo( $( this ).index() ); } );

            /* Keyboard navigation */
            $wrap.on( 'keydown', function ( e ) {
                if ( e.key === 'ArrowLeft' )  { e.preventDefault(); goTo( current - 1 ); }
                if ( e.key === 'ArrowRight' ) { e.preventDefault(); goTo( current + 1 ); }
                if ( e.key === 'Home' )       { e.preventDefault(); goTo( 0 ); }
                if ( e.key === 'End' )        { e.preventDefault(); goTo( total - cols ); }
            } );
            $wrap.attr( 'tabindex', '0' );

            /* Touch / swipe support */
            var touchX = null;
            $track[0].addEventListener( 'touchstart', function ( e ) {
                touchX = e.changedTouches[0].clientX;
            }, { passive: true } );
            $track[0].addEventListener( 'touchend', function ( e ) {
                if ( touchX === null ) return;
                var diff = touchX - e.changedTouches[0].clientX;
                if ( Math.abs( diff ) > 40 ) {
                    goTo( diff > 0 ? current + 1 : current - 1 );
                }
                touchX = null;
            }, { passive: true } );

            /* Autoplay */
            function startAutoplay() {
                if ( ! automs || isPaused ) return;
                var duration = automs;
                if ( $fill.length ) {
                    $fill.css( 'transition', 'transform ' + duration + 'ms linear' );
                    $fill.css( 'transform', 'scaleX(1)' );
                }
                autoTimer = setTimeout( function () {
                    goTo( current >= total - cols ? 0 : current + 1 );
                }, duration );
            }
            function resetAutoplay() {
                clearTimeout( autoTimer );
                if ( $fill.length ) {
                    $fill.css( 'transition', 'none' ).css( 'transform', 'scaleX(0)' );
                    // Force reflow
                    void $fill[0].offsetWidth;
                }
                startAutoplay();
            }
            /* Pause autoplay on hover/focus */
            $wrap.on( 'mouseenter focusin', function () {
                isPaused = true;
                clearTimeout( autoTimer );
                if ( $fill.length ) $fill.css( 'transition', 'none' );
            } );
            $wrap.on( 'mouseleave focusout', function () {
                isPaused = false;
                resetAutoplay();
            } );

            /* Init */
            goTo( 0 );
            startAutoplay();
        } );
    }

    /* ══════════════════════════════════════════════════════════════
       06.  READ MORE / TRUNCATION TOGGLE
    ══════════════════════════════════════════════════════════════ */
    function initReadMore( $ctx ) {
        var clamp = parseInt( D.clamp_lines, 10 ) || 0;
        if ( ! clamp ) return;

        var $cards = ( $ctx ? $ctx.find( '.wptsm-card' ) : $( '.wptsm-card' ) );

        $cards.each( function () {
            var $card  = $( this );
            var $quote = $card.find( '.wptsm-card__quote' );
            var $btn   = $card.find( '.wptsm-read-more' );
            if ( ! $quote.length ) return;

            $quote.css( '--wptsm-clamp', clamp );

            // Detect if content overflows
            var scrollH = $quote[0].scrollHeight;
            var clientH = $quote[0].clientHeight;
            if ( scrollH > clientH + 4 ) {
                $card.addClass( 'needs-clamp' );
                $btn.show();
            }

            $btn.on( 'click', function () {
                var expanded = $card.hasClass( 'is-expanded' );
                $card.toggleClass( 'is-expanded', ! expanded );
                $btn.text( expanded
                    ? ( D.strings.read_more || 'Read more' )
                    : ( D.strings.read_less || 'Read less' )
                );
            } );
        } );
    }

    /* ══════════════════════════════════════════════════════════════
       07.  RATING DISTRIBUTION BAR ANIMATION
    ══════════════════════════════════════════════════════════════ */
    function initDistBars() {
        var $bars = $( '.wptsm-dist-row__fill' );
        if ( ! $bars.length ) return;

        /* Start bars at 0, animate to target on scroll */
        $bars.each( function () {
            var target = $( this ).data( 'width' ) || $( this ).width();
            $( this ).css( 'width', '0' );
            $( this ).data( 'target', target );
        } );

        if ( ! window.IntersectionObserver ) {
            $bars.each( function () { $( this ).css( 'width', $( this ).data( 'target' ) ); } );
            return;
        }

        var observer = new IntersectionObserver( function ( entries ) {
            entries.forEach( function ( entry ) {
                if ( entry.isIntersecting ) {
                    var $el = $( entry.target );
                    $el.css( { transition: 'width 1s ease', width: $el.data( 'target' ) } );
                    observer.unobserve( entry.target );
                }
            } );
        }, { threshold: 0.3 } );

        $bars.each( function () { observer.observe( this ); } );
    }

    /* ══════════════════════════════════════════════════════════════
       08.  SCHEMA.ORG AggregateRating JSON-LD
    ══════════════════════════════════════════════════════════════ */
    function injectSchemaOrg() {
        var s = D.schema_data;
        if ( ! s || ! s.count ) return;

        var schema = {
            '@context':      'https://schema.org',
            '@type':         s.type || 'LocalBusiness',
            'name':          s.name || document.title,
            'url':           s.url  || window.location.href,
            'aggregateRating': {
                '@type':        'AggregateRating',
                'ratingValue':  parseFloat( s.avg ).toFixed(1),
                'reviewCount':  parseInt( s.count, 10 ),
                'ratingCount':  parseInt( s.count, 10 ),
                'bestRating':   s.max || 5,
                'worstRating':  s.min || 1,
            }
        };

        var el = document.createElement( 'script' );
        el.type = 'application/ld+json';
        el.textContent = JSON.stringify( schema );
        document.head.appendChild( el );
    }

    /* ══════════════════════════════════════════════════════════════
       09.  PROOF COUNTER STRIP (count-up animation)
    ══════════════════════════════════════════════════════════════ */
    function initCounterStrip() {
        var $items = $( '.wptsm-proof-item__num[data-target]' );
        if ( ! $items.length || ! window.IntersectionObserver ) {
            $items.each( function () { $( this ).text( $( this ).data( 'target' ) ); } );
            return;
        }

        var obs = new IntersectionObserver( function ( entries ) {
            entries.forEach( function ( entry ) {
                if ( ! entry.isIntersecting ) return;
                var $el     = $( entry.target );
                var target  = parseFloat( $el.data( 'target' ) );
                var suffix  = $el.data( 'suffix' ) || '';
                var isFloat = String( target ).indexOf( '.' ) !== -1;
                var start   = performance.now();
                var dur     = 1400;

                function frame( now ) {
                    var p = Math.min( 1, ( now - start ) / dur );
                    var ease = 1 - Math.pow( 1 - p, 3 );
                    var val  = target * ease;
                    $el.text( ( isFloat ? val.toFixed(1) : Math.floor( val ) ) + suffix );
                    if ( p < 1 ) requestAnimationFrame( frame );
                    else $el.text( target + suffix );
                }
                requestAnimationFrame( frame );
                obs.unobserve( entry.target );
            } );
        }, { threshold: 0.5 } );

        $items.each( function () { obs.observe( this ); } );
    }

    /* ══════════════════════════════════════════════════════════════
       10.  LAZY-LOAD AVATARS
    ══════════════════════════════════════════════════════════════ */
    function initLazyAvatars() {
        if ( ! window.IntersectionObserver ) return;
        var obs = new IntersectionObserver( function ( entries ) {
            entries.forEach( function ( entry ) {
                if ( ! entry.isIntersecting ) return;
                var img = entry.target;
                if ( img.dataset.src ) {
                    img.src = img.dataset.src;
                    img.removeAttribute( 'data-src' );
                    img.classList.remove( 'wptsm-avatar--lazy' );
                }
                obs.unobserve( img );
            } );
        }, { rootMargin: '200px' } );

        $( 'img.wptsm-avatar[data-src]' ).each( function () { obs.observe( this ); } );
    }

    /* ══════════════════════════════════════════════════════════════
       Helpers
    ══════════════════════════════════════════════════════════════ */
    function buildSkeletons( n ) {
        var html = '';
        for ( var i = 0; i < n; i++ ) {
            html += '<div class="wptsm-skeleton-card" aria-hidden="true">' +
                '<div class="wptsm-skeleton-stars"></div>' +
                '<div class="wptsm-skeleton-line wptsm-skeleton-line--full"></div>' +
                '<div class="wptsm-skeleton-line wptsm-skeleton-line--full"></div>' +
                '<div class="wptsm-skeleton-line wptsm-skeleton-line--medium"></div>' +
                '<div class="wptsm-skeleton-line wptsm-skeleton-line--short" style="margin-top:.5rem"></div>' +
                '</div>';
        }
        return html;
    }

    function buildEmpty( msg ) {
        return '<div class="wptsm-empty" role="status">' +
            '<div class="wptsm-empty__icon" aria-hidden="true">💬</div>' +
            '<div class="wptsm-empty__title">' + escHtml( D.strings.no_results_title || 'No testimonials found' ) + '</div>' +
            '<div class="wptsm-empty__desc">' + escHtml( msg || D.strings.no_results || 'Try adjusting your filters.' ) + '</div>' +
            '</div>';
    }

    function updateResultCount( $wrap, total ) {
        $wrap.find( '.wptsm-filter-count' ).text( total + ' ' + ( D.strings.results || 'results' ) );
    }

    function escHtml( str ) {
        return String( str )
            .replace( /&/g, '&amp;' )
            .replace( /</g, '&lt;' )
            .replace( />/g, '&gt;' )
            .replace( /"/g, '&quot;' );
    }

    function fireEvent( name, detail ) {
        if ( typeof CustomEvent === 'function' ) {
            document.dispatchEvent( new CustomEvent( 'wptsm:' + name, { bubbles: true, detail: detail } ) );
        }
        // GTM dataLayer push (if available)
        if ( window.dataLayer ) {
            window.dataLayer.push( { event: 'wptsm_' + name, wptsm: detail } );
        }
    }

} )( jQuery, document, window );