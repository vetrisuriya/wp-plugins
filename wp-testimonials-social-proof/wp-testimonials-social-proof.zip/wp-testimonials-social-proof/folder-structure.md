wp-testimonials-social-proof/
│
├── wp-testimonials-social-proof.php   ← Main plugin file
├── uninstall.php                      ← Clean removal
├── readme.txt                         ← Plugin Directory readme
│
├── includes/
│   ├── class-wptsm-activator.php      ← Activation: caps, flush rules
│   ├── class-wptsm-cpt.php            ← CPT + taxonomy registration
│   ├── class-wptsm-meta.php           ← Rating + company meta boxes
│   ├── class-wptsm-settings.php       ← Settings API admin page
│   ├── class-wptsm-shortcodes.php     ← [testimonials] + [testimonial_form]
│   ├── class-wptsm-widget.php         ← Featured Testimonials widget
│   ├── class-wptsm-ajax.php           ← AJAX filter + form submission
│   ├── class-wptsm-rest-api.php       ← REST API endpoints
│   ├── class-wptsm-email.php          ← Submission notification email
│   ├── class-wptsm-admin-columns.php  ← Extra admin list columns
│   └── class-wptsm-capabilities.php   ← moderate_testimonials cap
│
├── admin/
│   ├── css/wptsm-admin.css
│   └── js/wptsm-admin.js
│
├── public/
│   ├── css/wptsm-public.css
│   └── js/wptsm-public.js
│
└── languages/
    └── wp-testimonials-social-proof.pot