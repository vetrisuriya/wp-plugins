/* global sjb_params, jQuery */
/**
 * Smart Job Board — Public JavaScript
 * FILE: smart-job-board/public/assets/public.js
 *
 * Handles:
 *  - Live job search with 400ms debounce
 *  - Application form AJAX submission
 */
( function ( $ ) {
    'use strict';

    var $board   = $( '#sjb-job-board' );
    var $results = $( '#sjb-results' );
    var $keyword = $( '#sjb-keyword' );
    var searchTimer;

    if ( ! $board.length ) return;

    /* ── Live search with debounce ──────────────────────────────── */
    $keyword.on( 'input', function () {
        clearTimeout( searchTimer );
        searchTimer = setTimeout( doSearch, 400 );
    } );

    $( '#sjb-search-btn' ).on( 'click', function ( e ) {
        e.preventDefault();
        doSearch();
    } );

    $keyword.on( 'keydown', function ( e ) {
        if ( 13 === e.which ) { e.preventDefault(); doSearch(); }
    } );

    function doSearch() {
        var keyword = $keyword.val().trim();

        $results.html( '<p class="sjb-loading">' + ( sjb_params.strings.searching || 'Searching…' ) + '</p>' );

        $.ajax( {
            url:    sjb_params.ajax_url,
            type:   'POST',
            data: {
                action:  'sjb_search_jobs',
                nonce:   sjb_params.nonce,
                keyword: keyword,
            },
            success: function ( response ) {
                if ( response.success && response.data.html ) {
                    $results.html( response.data.html );
                } else {
                    $results.html( '<p class="sjb-no-jobs">' + ( sjb_params.strings.no_results || 'No jobs found.' ) + '</p>' );
                }
            },
            error: function () {
                $results.html( '<p class="sjb-no-jobs">' + ( sjb_params.strings.no_results || 'No jobs found.' ) + '</p>' );
            },
        } );
    }

    /* ── Application form AJAX submit ───────────────────────────── */
    $( document ).on( 'submit', '#sjb-application-form', function ( e ) {
        e.preventDefault();

        var $form = $( this );
        var $btn  = $form.find( '.sjb-submit-btn' );
        var $msg  = $( '.sjb-form-message' );
        var jobId = $form.find( '[name="job_id"]' ).val();
        var name  = $form.find( '[name="name"]' ).val().trim();
        var email = $form.find( '[name="email"]' ).val().trim();

        $msg.removeClass( 'sjb-success sjb-error' ).hide();

        if ( ! name || ! email || ! jobId ) {
            $msg.addClass( 'sjb-error' )
                .text( sjb_params.strings.submit_error || 'Please fill in all required fields.' )
                .show();
            return;
        }

        $btn.prop( 'disabled', true ).text( sjb_params.strings.applying || 'Applying…' );

        $.ajax( {
            url:    sjb_params.ajax_url,
            type:   'POST',
            data:   $form.serialize() + '&action=sjb_submit_application&nonce=' + encodeURIComponent( sjb_params.nonce ),
            success: function ( response ) {
                $btn.prop( 'disabled', false ).text( sjb_params.strings.apply_now || 'Apply Now' );
                if ( response.success ) {
                    $msg.addClass( 'sjb-success' ).text( response.data.message ).show();
                    $form[0].reset();
                } else {
                    $msg.addClass( 'sjb-error' ).text( response.data.message ).show();
                }
            },
            error: function () {
                $btn.prop( 'disabled', false ).text( sjb_params.strings.apply_now || 'Apply Now' );
                $msg.addClass( 'sjb-error' ).text( sjb_params.strings.submit_error ).show();
            },
        } );
    } );

}( jQuery ) );