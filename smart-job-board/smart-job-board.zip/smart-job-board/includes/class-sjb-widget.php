<?php
/**
 * Featured Jobs sidebar widget.
 * FILE: smart-job-board/includes/class-sjb-widget.php
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'sjb_featured_jobs_widget', __( 'Featured Jobs', 'smart-job-board' ),
            array( 'description' => __( 'Show featured job listings in any sidebar.', 'smart-job-board' ) )
        );
    }

    public function widget( $args, $instance ): void {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : __( 'Featured Jobs', 'smart-job-board' );
        $count = ! empty( $instance['count'] ) ? absint( $instance['count'] ) : 5;

        $cache_key = 'sjb_widget_featured_' . $count;
        $output    = get_transient( $cache_key );

        if ( false === $output ) {
            $jobs = new WP_Query( array(
                'post_type'      => 'job_listing',
                'post_status'    => 'publish',
                'posts_per_page' => $count,
                'meta_key'       => '_sjb_is_featured',
                'meta_value'     => '1',
            ) );
            ob_start();
            if ( $jobs->have_posts() ) {
                echo '<ul class="sjb-featured-jobs">';
                while ( $jobs->have_posts() ) {
                    $jobs->the_post();
                    $company = get_post_meta( get_the_ID(), '_sjb_company_name', true );
                    $type    = get_post_meta( get_the_ID(), '_sjb_job_type',     true );
                    echo '<li>';
                    echo '<a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a>';
                    if ( $company ) echo '<span class="sjb-widget-company"> · ' . esc_html( $company ) . '</span>';
                    if ( $type )    echo '<span class="sjb-widget-type"> · ' . esc_html( ucfirst( str_replace( '-', ' ', $type ) ) ) . '</span>';
                    echo '</li>';
                }
                echo '</ul>';
                wp_reset_postdata();
            } else {
                echo '<p>' . esc_html__( 'No featured jobs.', 'smart-job-board' ) . '</p>';
            }
            $output = ob_get_clean();
            set_transient( $cache_key, $output, 10 * MINUTE_IN_SECONDS );
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo $args['before_widget'];
        echo $args['before_title'] . esc_html( apply_filters( 'widget_title', $title ) ) . $args['after_title'];
        echo $output; // Sanitized during construction above.
        echo $args['after_widget'];
    }

    public function form( $instance ): void {
        $title = $instance['title'] ?? __( 'Featured Jobs', 'smart-job-board' );
        $count = isset( $instance['count'] ) ? absint( $instance['count'] ) : 5;
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'smart-job-board' ); ?></label>
            <input class="widefat" type="text" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php esc_html_e( 'Number of jobs:', 'smart-job-board' ); ?></label>
            <input class="tiny-text" type="number" min="1" max="20" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" value="<?php echo esc_attr( $count ); ?>">
        </p>
        <?php
    }

    public function update( $new_instance, $old_instance ): array {
        delete_transient( 'sjb_widget_featured_' . absint( $old_instance['count'] ?? 5 ) );
        return array( 'title' => sanitize_text_field( $new_instance['title'] ), 'count' => absint( $new_instance['count'] ) );
    }
}