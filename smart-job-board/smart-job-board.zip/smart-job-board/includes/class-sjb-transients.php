<?php
/**
 * Transient cache helpers.
 * FILE: smart-job-board/includes/class-sjb-transients.php
 *
 * NOTE: Listed in the project structure but NOT written in the reference file.
 * Created from scratch.
 *
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Transients {

    public static function bust_jobs_cache(): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_sjb_jobs_%' OR option_name LIKE '_transient_timeout_sjb_jobs_%' OR option_name LIKE '_transient_sjb_sc_%' OR option_name LIKE '_transient_timeout_sjb_sc_%'" );
    }

    public static function bust_widget_cache(): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_sjb_widget_%' OR option_name LIKE '_transient_timeout_sjb_widget_%'" );
    }

    public static function bust_all(): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_sjb_%' OR option_name LIKE '_transient_timeout_sjb_%'" );
    }
}