<?php
/**
 * Custom capabilities for Smart Job Board.
 * FILE: smart-job-board/includes/class-sjb-capabilities.php
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Capabilities {

    public static function add_caps(): void {
        $caps = array(
            'edit_job', 'read_job', 'delete_job', 'edit_jobs',
            'edit_others_jobs', 'publish_jobs', 'read_private_jobs',
            'delete_jobs', 'delete_private_jobs', 'delete_published_jobs',
            'delete_others_jobs', 'edit_private_jobs', 'edit_published_jobs',
            'manage_job_terms', 'edit_job_terms', 'delete_job_terms', 'assign_job_terms',
            'manage_sjb_applicants',
        );
        foreach ( array( 'administrator', 'editor' ) as $role_name ) {
            $role = get_role( $role_name );
            if ( $role ) {
                foreach ( $caps as $cap ) $role->add_cap( $cap );
            }
        }
    }

    public static function remove_caps(): void {
        $caps = array( 'edit_job', 'read_job', 'delete_job', 'edit_jobs', 'edit_others_jobs', 'publish_jobs', 'read_private_jobs', 'manage_sjb_applicants' );
        foreach ( array( 'administrator', 'editor' ) as $role_name ) {
            $role = get_role( $role_name );
            if ( $role ) {
                foreach ( $caps as $cap ) $role->remove_cap( $cap );
            }
        }
    }

    public static function can_manage_applicants(): bool {
        return current_user_can( 'manage_sjb_applicants' );
    }
}