<?php
/**
 * REST API endpoints.
 * FILE: smart-job-board/includes/class-sjb-rest-api.php
 * Routes: GET /smart-job-board/v1/jobs | GET /jobs/{id} | POST /applications
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Rest_Api {

    const NAMESPACE = 'smart-job-board/v1';

    public function register_routes(): void {
        register_rest_route( self::NAMESPACE, '/jobs', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_jobs' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'per_page' => array( 'default' => 10,  'sanitize_callback' => 'absint' ),
                'page'     => array( 'default' => 1,   'sanitize_callback' => 'absint' ),
                'category' => array( 'default' => '',  'sanitize_callback' => 'sanitize_text_field' ),
                'location' => array( 'default' => '',  'sanitize_callback' => 'sanitize_text_field' ),
                'type'     => array( 'default' => '',  'sanitize_callback' => 'sanitize_text_field' ),
            ),
        ) );
        register_rest_route( self::NAMESPACE, '/jobs/(?P<id>\d+)', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_single_job' ),
            'permission_callback' => '__return_true',
        ) );
        register_rest_route( self::NAMESPACE, '/applications', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'submit_application' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function get_jobs( WP_REST_Request $request ): WP_REST_Response {
        $per_page = $request->get_param( 'per_page' );
        $page     = $request->get_param( 'page' );
        $category = $request->get_param( 'category' );
        $location = $request->get_param( 'location' );

        $cache_key = 'sjb_jobs_' . md5( serialize( $request->get_params() ) );
        $cached    = get_transient( $cache_key );
        if ( false !== $cached ) return rest_ensure_response( $cached );

        $args = array( 'post_type' => 'job_listing', 'post_status' => 'publish', 'posts_per_page' => $per_page, 'paged' => $page );
        $tax_query = array();
        if ( $category ) $tax_query[] = array( 'taxonomy' => 'job_category', 'field' => 'slug', 'terms' => $category );
        if ( $location ) $tax_query[] = array( 'taxonomy' => 'job_location', 'field' => 'slug', 'terms' => $location );
        if ( $tax_query ) $args['tax_query'] = $tax_query;

        $query = new WP_Query( $args );
        $jobs  = array_map( array( $this, 'prepare' ), $query->posts );
        wp_reset_postdata();

        $response = rest_ensure_response( $jobs );
        $response->header( 'X-WP-Total',      $query->found_posts );
        $response->header( 'X-WP-TotalPages', $query->max_num_pages );

        set_transient( $cache_key, $jobs, 5 * MINUTE_IN_SECONDS );
        return $response;
    }

    public function get_single_job( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $post = get_post( absint( $request->get_param( 'id' ) ) );
        if ( ! $post || 'job_listing' !== $post->post_type || 'publish' !== $post->post_status ) {
            return new WP_Error( 'sjb_not_found', __( 'Job not found.', 'smart-job-board' ), array( 'status' => 404 ) );
        }
        $data            = $this->prepare( $post );
        $data['content'] = apply_filters( 'the_content', $post->post_content );
        return rest_ensure_response( $data );
    }

    public function submit_application( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $job_id = absint( $request->get_param( 'job_id' ) );
        $name   = sanitize_text_field( $request->get_param( 'name' ) );
        $email  = sanitize_email( $request->get_param( 'email' ) );
        if ( ! $job_id || ! $name || ! is_email( $email ) ) {
            return new WP_Error( 'sjb_invalid_data', __( 'Missing required fields.', 'smart-job-board' ), array( 'status' => 400 ) );
        }
        $id = SJB_Database::insert_application( array( 'job_id' => $job_id, 'name' => $name, 'email' => $email ) );
        if ( ! $id ) {
            return new WP_Error( 'sjb_insert_failed', __( 'Failed to submit application.', 'smart-job-board' ), array( 'status' => 500 ) );
        }
        return rest_ensure_response( array( 'success' => true, 'message' => __( 'Application submitted.', 'smart-job-board' ), 'id' => $id ) );
    }

    private function prepare( WP_Post $post ): array {
        return array(
            'id'          => $post->ID,
            'title'       => $post->post_title,
            'excerpt'     => get_the_excerpt( $post ),
            'url'         => get_permalink( $post->ID ),
            'company'     => get_post_meta( $post->ID, '_sjb_company_name', true ),
            'company_url' => get_post_meta( $post->ID, '_sjb_company_url', true ),
            'job_type'    => get_post_meta( $post->ID, '_sjb_job_type',    true ),
            'experience'  => get_post_meta( $post->ID, '_sjb_experience',  true ),
            'salary_min'  => (int) get_post_meta( $post->ID, '_sjb_salary_min',  true ),
            'salary_max'  => (int) get_post_meta( $post->ID, '_sjb_salary_max',  true ),
            'deadline'    => get_post_meta( $post->ID, '_sjb_deadline',    true ),
            'is_featured' => (bool) get_post_meta( $post->ID, '_sjb_is_featured', true ),
            'categories'  => wp_get_post_terms( $post->ID, 'job_category', array( 'fields' => 'names' ) ),
            'locations'   => wp_get_post_terms( $post->ID, 'job_location', array( 'fields' => 'names' ) ),
            'date'        => $post->post_date,
        );
    }
}