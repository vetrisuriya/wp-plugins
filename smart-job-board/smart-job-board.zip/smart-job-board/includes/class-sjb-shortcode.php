<?php
/**
 * [smart_job_board] shortcode.
 * FILE: smart-job-board/includes/class-sjb-shortcode.php
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Shortcode {

    /**
     * [smart_job_board category="engineering" location="remote" per_page="5" featured="yes"]
     */
    public function render( $atts ): string {
        $opts = SJB_Settings::get_options();
        $atts = shortcode_atts( array(
            'category' => '',
            'location' => '',
            'per_page' => $opts['jobs_per_page'],
            'featured' => 'no',
            'type'     => '',
        ), $atts, 'smart_job_board' );

        $cache_key = 'sjb_sc_' . md5( serialize( $atts ) );
        $cached    = get_transient( $cache_key );
        if ( false !== $cached ) return $cached;

        $args = array(
            'post_type'      => 'job_listing',
            'post_status'    => 'publish',
            'posts_per_page' => absint( $atts['per_page'] ),
            'orderby'        => 'date',
            'order'          => 'DESC',
        );

        if ( 'yes' === $atts['featured'] ) {
            $args['meta_query'] = array( array( 'key' => '_sjb_is_featured', 'value' => '1' ) );
        }
        if ( $atts['type'] ) {
            $args['meta_query'][] = array( 'key' => '_sjb_job_type', 'value' => sanitize_text_field( $atts['type'] ) );
        }

        $tax_query = array();
        if ( $atts['category'] ) {
            $tax_query[] = array( 'taxonomy' => 'job_category', 'field' => 'slug', 'terms' => sanitize_text_field( $atts['category'] ) );
        }
        if ( $atts['location'] ) {
            $tax_query[] = array( 'taxonomy' => 'job_location', 'field' => 'slug', 'terms' => sanitize_text_field( $atts['location'] ) );
        }
        if ( $tax_query ) {
            $args['tax_query'] = count( $tax_query ) > 1 ? array_merge( array( 'relation' => 'AND' ), $tax_query ) : $tax_query;
        }

        $jobs    = new WP_Query( $args );
        $curr    = $opts['currency_symbol'];

        ob_start();
        if ( $jobs->have_posts() ) {
            ?>
            <div class="sjb-job-board" id="sjb-job-board">
                <div class="sjb-search-bar">
                    <div class="sjb-search-inner">
                        <input type="text" id="sjb-keyword" placeholder="<?php esc_attr_e( 'Search jobs…', 'smart-job-board' ); ?>" autocomplete="off">
                        <button id="sjb-search-btn"><?php esc_html_e( 'Search', 'smart-job-board' ); ?></button>
                    </div>
                </div>
                <div id="sjb-results">
                    <?php while ( $jobs->have_posts() ) : $jobs->the_post();
                        $id       = get_the_ID();
                        $type     = get_post_meta( $id, '_sjb_job_type', true );
                        $company  = get_post_meta( $id, '_sjb_company_name', true );
                        $deadline = get_post_meta( $id, '_sjb_deadline', true );
                        $min      = get_post_meta( $id, '_sjb_salary_min', true );
                        $max      = get_post_meta( $id, '_sjb_salary_max', true );
                        $featured = get_post_meta( $id, '_sjb_is_featured', true );
                    ?>
                    <div class="sjb-job-card <?php echo $featured ? 'sjb-featured' : ''; ?>">
                        <?php if ( $featured ) : ?><span class="sjb-featured-badge">⭐ <?php esc_html_e( 'Featured', 'smart-job-board' ); ?></span><?php endif; ?>
                        <h3 class="sjb-job-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <div class="sjb-job-meta">
                            <?php if ( $company )  : ?><span class="sjb-company">🏢 <?php echo esc_html( $company ); ?></span><?php endif; ?>
                            <?php if ( $type )     : ?><span class="sjb-type sjb-type-<?php echo esc_attr( sanitize_html_class( $type ) ); ?>"><?php echo esc_html( ucfirst( str_replace( '-', ' ', $type ) ) ); ?></span><?php endif; ?>
                            <?php if ( $min && $max ) : ?><span class="sjb-salary">💰 <?php echo esc_html( $curr . number_format( (int)$min ) . ' – ' . $curr . number_format( (int)$max ) ); ?></span><?php endif; ?>
                            <?php if ( $deadline ) : ?><span class="sjb-deadline">📅 <?php printf( esc_html__( 'Apply by %s', 'smart-job-board' ), esc_html( date_i18n( get_option( 'date_format' ), strtotime( $deadline ) ) ) ); ?></span><?php endif; ?>
                        </div>
                        <div class="sjb-excerpt"><?php the_excerpt(); ?></div>
                        <a href="<?php the_permalink(); ?>" class="sjb-btn sjb-btn-view"><?php esc_html_e( 'View Job', 'smart-job-board' ); ?></a>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <?php
        } else {
            echo '<p class="sjb-no-jobs">' . esc_html__( 'No job listings found.', 'smart-job-board' ) . '</p>';
        }
        wp_reset_postdata();

        $html = ob_get_clean();
        set_transient( $cache_key, $html, 10 * MINUTE_IN_SECONDS );
        return $html;
    }
}