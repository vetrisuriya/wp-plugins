<?php
/**
 * Custom DB table for job applications.
 * FILE: smart-job-board/includes/class-sjb-database.php
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Database {

    const TABLE_NAME = 'sjb_applications';

    public static function create_tables(): void {
        global $wpdb;
        $table           = $wpdb->prefix . self::TABLE_NAME;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( "CREATE TABLE {$table} (
  id              bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  job_id          bigint(20) unsigned NOT NULL,
  applicant_name  varchar(100) NOT NULL,
  applicant_email varchar(200) NOT NULL,
  applicant_phone varchar(30) DEFAULT '',
  cover_letter    longtext DEFAULT '',
  resume_url      varchar(500) DEFAULT '',
  status          varchar(20) NOT NULL DEFAULT 'pending',
  ip_address      varchar(45) DEFAULT '',
  applied_at      datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  updated_at      datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY  (id),
  KEY job_id (job_id),
  KEY applicant_email (applicant_email),
  KEY status (status)
) {$charset_collate};" );
        update_option( 'sjb_db_version', '1.0.0' );
    }

    public static function insert_application( array $data ): int|false {
        global $wpdb;
        $result = $wpdb->insert( // phpcs:ignore
            $wpdb->prefix . self::TABLE_NAME,
            array(
                'job_id'          => absint( $data['job_id'] ),
                'applicant_name'  => sanitize_text_field( $data['name'] ),
                'applicant_email' => sanitize_email( $data['email'] ),
                'applicant_phone' => sanitize_text_field( $data['phone'] ?? '' ),
                'cover_letter'    => wp_kses_post( $data['cover_letter'] ?? '' ),
                'resume_url'      => esc_url_raw( $data['resume_url'] ?? '' ),
                'status'          => 'pending',
                'ip_address'      => self::get_client_ip(),
                'applied_at'      => current_time( 'mysql' ),
                'updated_at'      => current_time( 'mysql' ),
            ),
            array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
        );
        return $result ? (int) $wpdb->insert_id : false;
    }

    public static function get_applications_by_job( int $job_id ): array {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE job_id = %d ORDER BY applied_at DESC", $job_id ) ) ?: array(); // phpcs:ignore
    }

    public static function get_all( string $status = '', int $per_page = 50, int $offset = 0 ): array {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        $where = $status ? $wpdb->prepare( 'WHERE status = %s', $status ) : '';
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} {$where} ORDER BY applied_at DESC LIMIT %d OFFSET %d", $per_page, $offset ), ARRAY_A ) ?: array(); // phpcs:ignore
    }

    public static function update_status( int $application_id, string $status ): bool {
        global $wpdb;
        $allowed = array( 'pending', 'reviewed', 'shortlisted', 'rejected' );
        if ( ! in_array( $status, $allowed, true ) ) return false;
        return (bool) $wpdb->update( // phpcs:ignore
            $wpdb->prefix . self::TABLE_NAME,
            array( 'status' => $status, 'updated_at' => current_time( 'mysql' ) ),
            array( 'id' => $application_id ),
            array( '%s', '%s' ), array( '%d' )
        );
    }

    public static function count_by_status( string $status = '' ): int {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        if ( $status ) return absint( $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", $status ) ) ); // phpcs:ignore
        return absint( $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) ); // phpcs:ignore
    }

    public static function drop_tables(): void {
        global $wpdb;
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}" . self::TABLE_NAME ); // phpcs:ignore
    }

    private static function get_client_ip(): string {
        foreach ( array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                $ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
                if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) return $ip;
            }
        }
        return '';
    }
}