<?php
/**
 * Register Job Listing CPT, taxonomies, and meta fields.
 * FILE: smart-job-board/includes/class-sjb-post-type.php
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Post_Type {

    public function register(): void {
        $this->register_post_type();
        $this->register_job_category();
        $this->register_job_location();
        $this->register_meta_fields();
        $this->add_admin_columns();
    }

    private function register_post_type(): void {
        register_post_type( 'job_listing', array(
            'labels' => array(
                'name'               => _x( 'Jobs', 'post type general name', 'smart-job-board' ),
                'singular_name'      => _x( 'Job',  'post type singular name', 'smart-job-board' ),
                'menu_name'          => __( 'Smart Jobs',        'smart-job-board' ),
                'add_new'            => __( 'Add New Job',       'smart-job-board' ),
                'add_new_item'       => __( 'Add New Job Listing','smart-job-board' ),
                'edit_item'          => __( 'Edit Job',          'smart-job-board' ),
                'not_found'          => __( 'No jobs found.',    'smart-job-board' ),
                'not_found_in_trash' => __( 'No jobs in trash.','smart-job-board' ),
            ),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'show_in_rest'       => true,
            'menu_icon'          => 'dashicons-businessman',
            'capability_type'    => array( 'job', 'jobs' ),
            'map_meta_cap'       => true,
            'hierarchical'       => false,
            'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
            'has_archive'        => true,
            'rewrite'            => array( 'slug' => 'jobs', 'with_front' => false ),
            'query_var'          => true,
        ) );
    }

    private function register_job_category(): void {
        register_taxonomy( 'job_category', 'job_listing', array(
            'labels'       => array(
                'name'          => __( 'Job Categories', 'smart-job-board' ),
                'singular_name' => __( 'Job Category',  'smart-job-board' ),
                'add_new_item'  => __( 'Add New Category', 'smart-job-board' ),
            ),
            'hierarchical' => true,
            'public'       => true,
            'show_in_rest' => true,
            'rewrite'      => array( 'slug' => 'job-category' ),
        ) );
    }

    private function register_job_location(): void {
        register_taxonomy( 'job_location', 'job_listing', array(
            'labels'       => array(
                'name'          => __( 'Job Locations', 'smart-job-board' ),
                'singular_name' => __( 'Job Location',  'smart-job-board' ),
                'add_new_item'  => __( 'Add New Location', 'smart-job-board' ),
            ),
            'hierarchical' => false,
            'public'       => true,
            'show_in_rest' => true,
            'rewrite'      => array( 'slug' => 'job-location' ),
        ) );
    }

    private function register_meta_fields(): void {
        $fields = array(
            '_sjb_salary_min'   => 'integer',
            '_sjb_salary_max'   => 'integer',
            '_sjb_job_type'     => 'string',
            '_sjb_deadline'     => 'string',
            '_sjb_company_name' => 'string',
            '_sjb_company_url'  => 'string',
            '_sjb_experience'   => 'string',
            '_sjb_is_featured'  => 'boolean',
        );
        foreach ( $fields as $key => $type ) {
            register_post_meta( 'job_listing', $key, array(
                'single'            => true,
                'type'              => $type,
                'show_in_rest'      => true,
                'sanitize_callback' => 'integer' === $type ? 'absint' : 'sanitize_text_field',
                'auth_callback'     => fn() => current_user_can( 'edit_posts' ),
            ) );
        }
        // Meta boxes.
        add_action( 'add_meta_boxes',        array( $this, 'add_meta_box' ) );
        add_action( 'save_post_job_listing', array( $this, 'save_meta' ) );
    }

    public function add_meta_box(): void {
        add_meta_box( 'sjb_job_details', __( 'Job Details', 'smart-job-board' ),
            array( $this, 'render_meta_box' ), 'job_listing', 'normal', 'high' );
    }

    public function render_meta_box( WP_Post $post ): void {
        wp_nonce_field( 'sjb_save_meta', 'sjb_meta_nonce' );
        $company  = get_post_meta( $post->ID, '_sjb_company_name', true );
        $url      = get_post_meta( $post->ID, '_sjb_company_url', true );
        $type     = get_post_meta( $post->ID, '_sjb_job_type', true );
        $exp      = get_post_meta( $post->ID, '_sjb_experience', true );
        $min      = get_post_meta( $post->ID, '_sjb_salary_min', true );
        $max      = get_post_meta( $post->ID, '_sjb_salary_max', true );
        $deadline = get_post_meta( $post->ID, '_sjb_deadline', true );
        $featured = get_post_meta( $post->ID, '_sjb_is_featured', true );
        ?>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Company Name',   'smart-job-board' ); ?></th><td><input type="text"   name="sjb_company_name" value="<?php echo esc_attr( $company  ); ?>" class="regular-text"></td></tr>
            <tr><th><?php esc_html_e( 'Company URL',    'smart-job-board' ); ?></th><td><input type="url"    name="sjb_company_url"  value="<?php echo esc_attr( $url  ); ?>" class="regular-text"></td></tr>
            <tr><th><?php esc_html_e( 'Job Type',       'smart-job-board' ); ?></th>
                <td><select name="sjb_job_type">
                    <?php foreach ( array( '' => 'Select…', 'full-time' => 'Full-Time', 'part-time' => 'Part-Time', 'remote' => 'Remote', 'contract' => 'Contract', 'internship' => 'Internship' ) as $v => $l ) : ?>
                        <option value="<?php echo esc_attr( $v ); ?>" <?php selected( $type, $v ); ?>><?php echo esc_html( $l ); ?></option>
                    <?php endforeach; ?>
                </select></td></tr>
            <tr><th><?php esc_html_e( 'Experience',     'smart-job-board' ); ?></th><td><input type="text" name="sjb_experience"  value="<?php echo esc_attr( $exp ); ?>" placeholder="e.g. 2+ years" class="regular-text"></td></tr>
            <tr><th><?php esc_html_e( 'Salary Min ($)', 'smart-job-board' ); ?></th><td><input type="number" name="sjb_salary_min" value="<?php echo esc_attr( $min ); ?>" min="0" class="small-text"></td></tr>
            <tr><th><?php esc_html_e( 'Salary Max ($)', 'smart-job-board' ); ?></th><td><input type="number" name="sjb_salary_max" value="<?php echo esc_attr( $max ); ?>" min="0" class="small-text"></td></tr>
            <tr><th><?php esc_html_e( 'Application Deadline', 'smart-job-board' ); ?></th><td><input type="date" name="sjb_deadline" value="<?php echo esc_attr( $deadline ); ?>"></td></tr>
            <tr><th><?php esc_html_e( 'Featured Job',   'smart-job-board' ); ?></th><td><input type="checkbox" name="sjb_is_featured" value="1" <?php checked( $featured, '1' ); ?>> <label><?php esc_html_e( 'Show in Featured Jobs widget and filter', 'smart-job-board' ); ?></label></td></tr>
        </table>
        <?php
    }

    public function save_meta( int $post_id ): void {
        if ( ! isset( $_POST['sjb_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['sjb_meta_nonce'] ) ), 'sjb_save_meta' ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        $text_fields = array( 'sjb_company_name' => '_sjb_company_name', 'sjb_job_type' => '_sjb_job_type', 'sjb_experience' => '_sjb_experience', 'sjb_deadline' => '_sjb_deadline' );
        foreach ( $text_fields as $post_key => $meta_key ) {
            if ( isset( $_POST[ $post_key ] ) ) update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $post_key ] ) ) );
        }
        if ( isset( $_POST['sjb_company_url'] ) ) update_post_meta( $post_id, '_sjb_company_url', esc_url_raw( wp_unslash( $_POST['sjb_company_url'] ) ) );
        if ( isset( $_POST['sjb_salary_min']  ) ) update_post_meta( $post_id, '_sjb_salary_min',  absint( $_POST['sjb_salary_min'] ) );
        if ( isset( $_POST['sjb_salary_max']  ) ) update_post_meta( $post_id, '_sjb_salary_max',  absint( $_POST['sjb_salary_max'] ) );
        update_post_meta( $post_id, '_sjb_is_featured', isset( $_POST['sjb_is_featured'] ) ? '1' : '0' );
        SJB_Transients::bust_jobs_cache();
    }

    private function add_admin_columns(): void {
        add_filter( 'manage_job_listing_posts_columns',       array( $this, 'columns' ) );
        add_action( 'manage_job_listing_posts_custom_column', array( $this, 'column_content' ), 10, 2 );
    }

    public function columns( array $cols ): array {
        return array(
            'cb'            => $cols['cb'],
            'title'         => __( 'Job Title',  'smart-job-board' ),
            'sjb_company'   => __( 'Company',    'smart-job-board' ),
            'sjb_type'      => __( 'Type',       'smart-job-board' ),
            'sjb_salary'    => __( 'Salary',     'smart-job-board' ),
            'sjb_deadline'  => __( 'Deadline',   'smart-job-board' ),
            'sjb_featured'  => __( '⭐ Featured','smart-job-board' ),
            'taxonomy-job_category' => __( 'Category', 'smart-job-board' ),
            'date'          => __( 'Published',  'smart-job-board' ),
        );
    }

    public function column_content( string $col, int $post_id ): void {
        switch ( $col ) {
            case 'sjb_company':  echo esc_html( get_post_meta( $post_id, '_sjb_company_name', true ) ?: '—' ); break;
            case 'sjb_type':     echo esc_html( get_post_meta( $post_id, '_sjb_job_type',     true ) ?: '—' ); break;
            case 'sjb_deadline': echo esc_html( get_post_meta( $post_id, '_sjb_deadline',     true ) ?: '—' ); break;
            case 'sjb_featured': echo get_post_meta( $post_id, '_sjb_is_featured', true ) ? '⭐' : '—'; break;
            case 'sjb_salary':
                $min = get_post_meta( $post_id, '_sjb_salary_min', true );
                $max = get_post_meta( $post_id, '_sjb_salary_max', true );
                echo ( $min && $max ) ? esc_html( '$' . number_format( $min ) . ' – $' . number_format( $max ) ) : '—';
                break;
        }
    }
}