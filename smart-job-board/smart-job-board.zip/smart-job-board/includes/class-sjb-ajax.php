<?php
/**
 * AJAX: job search + application submission.
 * FILE: smart-job-board/includes/class-sjb-ajax.php
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Ajax {

    public function search_jobs(): void {
        check_ajax_referer( 'sjb_nonce', 'nonce' );
        $keyword  = sanitize_text_field( wp_unslash( $_POST['keyword']  ?? '' ) );
        $category = sanitize_text_field( wp_unslash( $_POST['category'] ?? '' ) );
        $location = sanitize_text_field( wp_unslash( $_POST['location'] ?? '' ) );

        $args = array( 'post_type' => 'job_listing', 'post_status' => 'publish', 'posts_per_page' => 20 );
        if ( $keyword )  $args['s'] = $keyword;

        $tax_query = array();
        if ( $category ) $tax_query[] = array( 'taxonomy' => 'job_category', 'field' => 'slug', 'terms' => $category );
        if ( $location ) $tax_query[] = array( 'taxonomy' => 'job_location', 'field' => 'slug', 'terms' => $location );
        if ( $tax_query ) $args['tax_query'] = $tax_query;

        $jobs    = new WP_Query( $args );
        $curr    = SJB_Settings::get_options()['currency_symbol'];
        $html    = '';

        if ( $jobs->have_posts() ) {
            while ( $jobs->have_posts() ) {
                $jobs->the_post();
                $id      = get_the_ID();
                $type    = get_post_meta( $id, '_sjb_job_type', true );
                $company = get_post_meta( $id, '_sjb_company_name', true );
                $min     = get_post_meta( $id, '_sjb_salary_min', true );
                $max     = get_post_meta( $id, '_sjb_salary_max', true );
                $html   .= '<div class="sjb-job-card">';
                $html   .= '<h3><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3>';
                $html   .= '<div class="sjb-job-meta">';
                if ( $company ) $html .= '<span class="sjb-company">🏢 ' . esc_html( $company ) . '</span>';
                if ( $type )    $html .= '<span class="sjb-type sjb-type-' . esc_attr( sanitize_html_class( $type ) ) . '">' . esc_html( ucfirst( str_replace( '-', ' ', $type ) ) ) . '</span>';
                if ( $min && $max ) $html .= '<span class="sjb-salary">💰 ' . esc_html( $curr . number_format( (int)$min ) . ' – ' . $curr . number_format( (int)$max ) ) . '</span>';
                $html   .= '</div>';
                $html   .= '<a href="' . esc_url( get_permalink() ) . '" class="sjb-btn sjb-btn-view">' . esc_html__( 'View Job', 'smart-job-board' ) . '</a>';
                $html   .= '</div>';
            }
            wp_reset_postdata();
        } else {
            $html = '<p class="sjb-no-jobs">' . esc_html__( 'No jobs found matching your search.', 'smart-job-board' ) . '</p>';
        }

        wp_send_json_success( array( 'html' => $html ) );
    }

    public function submit_application(): void {
        check_ajax_referer( 'sjb_nonce', 'nonce' );

        $job_id       = absint( $_POST['job_id'] ?? 0 );
        $name         = sanitize_text_field( wp_unslash( $_POST['name']  ?? '' ) );
        $email        = sanitize_email(      wp_unslash( $_POST['email'] ?? '' ) );
        $phone        = sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) );
        $cover_letter = sanitize_textarea_field( wp_unslash( $_POST['cover_letter'] ?? '' ) );

        if ( ! $job_id || ! $name || ! $email ) {
            wp_send_json_error( array( 'message' => __( 'Please fill in all required fields.', 'smart-job-board' ) ) );
        }
        if ( ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'smart-job-board' ) ) );
        }

        $job = get_post( $job_id );
        if ( ! $job || 'publish' !== $job->post_status || 'job_listing' !== $job->post_type ) {
            wp_send_json_error( array( 'message' => __( 'Invalid job listing.', 'smart-job-board' ) ) );
        }

        // Prevent duplicate applications.
        global $wpdb;
        $table    = $wpdb->prefix . SJB_Database::TABLE_NAME;
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE job_id = %d AND applicant_email = %s LIMIT 1", $job_id, $email ) ); // phpcs:ignore
        if ( $existing ) {
            wp_send_json_error( array( 'message' => __( 'You have already applied for this job.', 'smart-job-board' ) ) );
        }

        $insert_id = SJB_Database::insert_application( array(
            'job_id'       => $job_id,
            'name'         => $name,
            'email'        => $email,
            'phone'        => $phone,
            'cover_letter' => $cover_letter,
        ) );

        if ( ! $insert_id ) {
            wp_send_json_error( array( 'message' => __( 'Failed to submit application. Please try again.', 'smart-job-board' ) ) );
        }

        $this->notify_admin( $job, $name, $email );

        wp_send_json_success( array( 'message' => __( 'Application submitted! We will be in touch soon.', 'smart-job-board' ) ) );
    }

    private function notify_admin( WP_Post $job, string $name, string $email ): void {
        $options = SJB_Settings::get_options();
        $subject = sprintf( __( 'New Application for: %s', 'smart-job-board' ), $job->post_title );
        $message = sprintf(
            __( "New application received:\n\nApplicant: %1\$s\nEmail: %2\$s\nJob: %3\$s\n\nView all applicants in your WordPress admin.", 'smart-job-board' ),
            $name, $email, $job->post_title
        );
        wp_mail( $options['admin_email'], $subject, $message );
    }
}