<?php
/**
 * Settings API for Smart Job Board.
 * FILE: smart-job-board/includes/class-sjb-settings.php
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Settings {

    const OPTION_GROUP = 'sjb_settings_group';
    const OPTION_NAME  = 'sjb_settings';

    public function register_settings(): void {
        register_setting( self::OPTION_GROUP, self::OPTION_NAME, array( 'sanitize_callback' => array( $this, 'sanitize_settings' ) ) );

        add_settings_section( 'sjb_general_section', __( 'General Settings', 'smart-job-board' ), array( $this, 'general_section_callback' ), 'sjb_settings_page' );
        add_settings_field( 'jobs_per_page',       __( 'Jobs Per Page',         'smart-job-board' ), array( $this, 'jobs_per_page_field'       ), 'sjb_settings_page', 'sjb_general_section' );
        add_settings_field( 'admin_email',         __( 'Notification Email',    'smart-job-board' ), array( $this, 'admin_email_field'         ), 'sjb_settings_page', 'sjb_general_section' );
        add_settings_field( 'allow_resume_upload', __( 'Allow Resume Upload',   'smart-job-board' ), array( $this, 'allow_resume_upload_field' ), 'sjb_settings_page', 'sjb_general_section' );
        add_settings_field( 'currency_symbol',     __( 'Currency Symbol',       'smart-job-board' ), array( $this, 'currency_symbol_field'     ), 'sjb_settings_page', 'sjb_general_section' );
    }

    public function add_settings_page(): void {
        add_submenu_page( 'edit.php?post_type=job_listing',
            __( 'Job Board Settings', 'smart-job-board' ),
            __( 'Settings',           'smart-job-board' ),
            'manage_options', 'sjb_settings', array( $this, 'render_settings_page' )
        );
    }

    public function render_settings_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Permission denied.', 'smart-job-board' ) );
        ?>
        <div class="wrap"><h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form method="post" action="options.php">
            <?php settings_fields( self::OPTION_GROUP ); do_settings_sections( 'sjb_settings_page' ); submit_button( __( 'Save Settings', 'smart-job-board' ) ); ?>
        </form></div>
        <?php
    }

    public function general_section_callback(): void { echo '<p>' . esc_html__( 'Configure general settings for the Smart Job Board.', 'smart-job-board' ) . '</p>'; }

    public function jobs_per_page_field(): void {
        $v = absint( self::get_options()['jobs_per_page'] );
        echo '<input type="number" name="' . esc_attr( self::OPTION_NAME ) . '[jobs_per_page]" value="' . esc_attr( $v ) . '" min="1" max="100" class="small-text">';
        echo '<p class="description">' . esc_html__( 'Number of job listings to show per page.', 'smart-job-board' ) . '</p>';
    }
    public function admin_email_field(): void {
        $v = self::get_options()['admin_email'];
        echo '<input type="email" name="' . esc_attr( self::OPTION_NAME ) . '[admin_email]" value="' . esc_attr( $v ) . '" class="regular-text">';
    }
    public function allow_resume_upload_field(): void {
        $v = (bool) self::get_options()['allow_resume_upload'];
        echo '<input type="checkbox" name="' . esc_attr( self::OPTION_NAME ) . '[allow_resume_upload]" value="1"' . checked( $v, true, false ) . '>';
        echo ' <label>' . esc_html__( 'Allow applicants to upload a resume (PDF/DOC).', 'smart-job-board' ) . '</label>';
    }
    public function currency_symbol_field(): void {
        $v = self::get_options()['currency_symbol'];
        echo '<input type="text" name="' . esc_attr( self::OPTION_NAME ) . '[currency_symbol]" value="' . esc_attr( $v ) . '" size="5">';
        echo '<p class="description">' . esc_html__( 'Symbol shown before salary (e.g. $, £, €).', 'smart-job-board' ) . '</p>';
    }

    public function sanitize_settings( $input ): array {
        return array(
            'jobs_per_page'       => absint( $input['jobs_per_page'] ?? 10 ),
            'admin_email'         => sanitize_email( $input['admin_email'] ?? '' ),
            'allow_resume_upload' => isset( $input['allow_resume_upload'] ) ? 1 : 0,
            'currency_symbol'     => sanitize_text_field( $input['currency_symbol'] ?? '$' ),
        );
    }

    public static function get_options(): array {
        return wp_parse_args( get_option( self::OPTION_NAME, array() ), array(
            'jobs_per_page'       => 10,
            'admin_email'         => get_option( 'admin_email' ),
            'allow_resume_upload' => 1,
            'currency_symbol'     => '$',
        ) );
    }
}