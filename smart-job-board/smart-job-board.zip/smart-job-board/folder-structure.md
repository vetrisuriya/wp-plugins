smart-job-board/
├── smart-job-board.php          ← Main plugin bootstrap file
├── readme.txt                   ← WordPress.org repository readme (required)
├── uninstall.php                ← Cleanup on plugin delete
├── includes/
│   ├── class-sjb-post-type.php  ← Register CPT and taxonomies
│   ├── class-sjb-database.php   ← Custom DB table creation
│   ├── class-sjb-settings.php   ← Settings API
│   ├── class-sjb-shortcode.php  ← Shortcode rendering
│   ├── class-sjb-ajax.php       ← AJAX handlers
│   ├── class-sjb-rest-api.php   ← REST API endpoints
│   ├── class-sjb-widget.php     ← Featured Jobs widget
│   ├── class-sjb-capabilities.php ← Custom roles/caps
│   └── class-sjb-transients.php ← Cache helpers
├── admin/
│   ├── class-sjb-admin.php      ← Admin menus, meta boxes
│   ├── views/
│   │   ├── settings-page.php
│   │   └── applicants-page.php
│   └── assets/
│       ├── admin.css
│       └── admin.js
├── public/
│   ├── views/
│   │   ├── job-listing.php
│   │   └── single-job.php
│   └── assets/
│       ├── public.css
│       └── public.js
└── languages/
    └── smart-job-board.pot