<?php
/**
 * Uninstall — runs when the plugin is deleted from the Plugins screen.
 * FILE: smart-job-board/uninstall.php
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Remove all plugin options.
delete_option( 'sjb_settings' );
delete_option( 'sjb_db_version' );

// Remove custom DB table.
global $wpdb;
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}sjb_applications" );

// Clear all plugin transients.
// phpcs:disable WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_sjb_%'" );
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_sjb_%'" );
// phpcs:enable

// Remove all job_listing posts and their postmeta.
$jobs = get_posts( array( 'post_type' => 'job_listing', 'numberposts' => -1, 'post_status' => 'any' ) );
foreach ( $jobs as $job ) {
    wp_delete_post( $job->ID, true );
}

// Remove capabilities from roles.
require_once plugin_dir_path( __FILE__ ) . 'includes/class-sjb-capabilities.php';
SJB_Capabilities::remove_caps();