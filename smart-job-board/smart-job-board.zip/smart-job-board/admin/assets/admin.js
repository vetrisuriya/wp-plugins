/* global sjb_admin, jQuery */
/**
 * Smart Job Board — Admin JavaScript
 * FILE: smart-job-board/admin/assets/admin.js
 *
 * Handles:
 *  - Application status update via AJAX select (Applicants page)
 */
( function ( $ ) {
    'use strict';

    /* ── Application status change ──────────────────────────────── */
    $( document ).on( 'change', '.sjb-status-select', function () {
        var $select = $( this );
        var appId   = $select.data( 'app-id' );
        var status  = $select.val();
        var $row    = $select.closest( 'tr' );

        $select.prop( 'disabled', true );

        $.post( sjb_admin.ajax_url, {
            action:         'sjb_update_application_status',
            nonce:          sjb_admin.nonce,
            application_id: appId,
            status:         status,
        }, function ( res ) {
            $select.prop( 'disabled', false );
            if ( ! res.success ) {
                alert( sjb_admin.strings.updating );
                $select.val( $select.data( 'original' ) );
            }
        } ).fail( function () {
            $select.prop( 'disabled', false ).val( $select.data( 'original' ) );
        } );
    } );

    /* Store original value on page load so we can revert on error */
    $( '.sjb-status-select' ).each( function () {
        $( this ).data( 'original', $( this ).val() );
    } );

}( jQuery ) );