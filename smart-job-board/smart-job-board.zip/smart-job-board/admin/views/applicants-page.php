<?php
/**
 * Admin view: All Applicants list with status filter and stat cards.
 * FILE: smart-job-board/admin/views/applicants-page.php
 *
 * NOTE: Listed in the plugin structure but NEVER written in the reference.
 * Created from scratch.
 *
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

function sjb_render_applicants_page(): void {
    $status_filter = sanitize_text_field( $_GET['status'] ?? '' );
    $job_filter    = absint( $_GET['job_id'] ?? 0 );
    $per_page      = 25;
    $paged         = max( 1, absint( $_GET['paged'] ?? 1 ) );
    $offset        = ( $paged - 1 ) * $per_page;

    $counts = array(
        'all'         => SJB_Database::count_by_status(),
        'pending'     => SJB_Database::count_by_status( 'pending' ),
        'reviewed'    => SJB_Database::count_by_status( 'reviewed' ),
        'shortlisted' => SJB_Database::count_by_status( 'shortlisted' ),
        'rejected'    => SJB_Database::count_by_status( 'rejected' ),
    );

    global $wpdb;
    $table       = $wpdb->prefix . SJB_Database::TABLE_NAME;
    $where_parts = array( '1=1' );
    $values      = array();

    if ( $status_filter ) {
        $where_parts[] = 'status = %s';
        $values[]      = $status_filter;
    }
    if ( $job_filter ) {
        $where_parts[] = 'job_id = %d';
        $values[]      = $job_filter;
    }

    $where = implode( ' AND ', $where_parts );
    $sql   = "SELECT * FROM {$table} WHERE {$where} ORDER BY applied_at DESC LIMIT %d OFFSET %d";
    $values[] = $per_page;
    $values[] = $offset;

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
    $applications = $wpdb->get_results( $wpdb->prepare( $sql, ...$values ), ARRAY_A ) ?: array();

    $status_labels = array(
        'pending'     => array( 'label' => __( 'Pending',     'smart-job-board' ), 'color' => '#d97706' ),
        'reviewed'    => array( 'label' => __( 'Reviewed',    'smart-job-board' ), 'color' => '#2271b1' ),
        'shortlisted' => array( 'label' => __( 'Shortlisted', 'smart-job-board' ), 'color' => '#059669' ),
        'rejected'    => array( 'label' => __( 'Rejected',    'smart-job-board' ), 'color' => '#dc2626' ),
    );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'All Applicants', 'smart-job-board' ); ?></h1>

        <!-- Stat cards -->
        <div style="display:flex;gap:1rem;flex-wrap:wrap;margin:1rem 0;">
            <?php foreach ( $status_labels as $slug => $info ) : ?>
            <div style="background:#fff;border:1px solid #ddd;border-top:4px solid <?php echo esc_attr( $info['color'] ); ?>;border-radius:4px;padding:1rem 1.5rem;min-width:110px;text-align:center;">
                <div style="font-size:1.75rem;font-weight:800;"><?php echo absint( $counts[ $slug ] ); ?></div>
                <div style="font-size:.8125rem;color:#64748b;"><?php echo esc_html( $info['label'] ); ?></div>
            </div>
            <?php endforeach; ?>
            <div style="background:#fff;border:1px solid #ddd;border-top:4px solid #475569;border-radius:4px;padding:1rem 1.5rem;min-width:110px;text-align:center;">
                <div style="font-size:1.75rem;font-weight:800;"><?php echo absint( $counts['all'] ); ?></div>
                <div style="font-size:.8125rem;color:#64748b;"><?php esc_html_e( 'Total', 'smart-job-board' ); ?></div>
            </div>
        </div>

        <!-- Status filter tabs -->
        <ul class="subsubsub">
            <?php
            $tabs  = array( '' => __( 'All', 'smart-job-board' ) ) + wp_list_pluck( $status_labels, 'label' );
            $count_map = array( '' => 'all' ) + array_combine( array_keys( $status_labels ), array_keys( $status_labels ) );
            $links = array();
            foreach ( $tabs as $slug => $label ) {
                $url     = add_query_arg( array( 'post_type' => 'job_listing', 'page' => 'sjb-applicants', 'status' => $slug ), admin_url( 'edit.php' ) );
                $current = $status_filter === $slug ? ' class="current"' : '';
                $links[] = '<li><a href="' . esc_url( $url ) . '"' . $current . '>' . esc_html( $label ) . ' <span class="count">(' . absint( $counts[ $count_map[ $slug ] ] ) . ')</span></a>';
            }
            echo implode( ' | ', $links );
            ?>
        </ul>

        <!-- Job filter -->
        <form method="get" style="margin-top:1rem;">
            <input type="hidden" name="post_type" value="job_listing">
            <input type="hidden" name="page" value="sjb-applicants">
            <?php if ( $status_filter ) : ?><input type="hidden" name="status" value="<?php echo esc_attr( $status_filter ); ?>"><?php endif; ?>
            <select name="job_id">
                <option value=""><?php esc_html_e( '— Filter by Job —', 'smart-job-board' ); ?></option>
                <?php
                $jobs = get_posts( array( 'post_type' => 'job_listing', 'posts_per_page' => -1, 'post_status' => array( 'publish', 'draft' ) ) );
                foreach ( $jobs as $j ) {
                    printf( '<option value="%d"%s>%s</option>', $j->ID, selected( $job_filter, $j->ID, false ), esc_html( $j->post_title ) );
                }
                ?>
            </select>
            <button type="submit" class="button"><?php esc_html_e( 'Filter', 'smart-job-board' ); ?></button>
            <?php if ( $job_filter ) : ?>
                <a href="<?php echo esc_url( add_query_arg( array( 'post_type' => 'job_listing', 'page' => 'sjb-applicants' ), admin_url( 'edit.php' ) ) ); ?>" class="button"><?php esc_html_e( 'Clear', 'smart-job-board' ); ?></a>
            <?php endif; ?>
        </form>

        <?php if ( empty( $applications ) ) : ?>
            <p style="margin-top:1rem;"><?php esc_html_e( 'No applications found.', 'smart-job-board' ); ?></p>
        <?php else : ?>
        <table class="wp-list-table widefat fixed striped" style="margin-top:1rem;">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Applicant',   'smart-job-board' ); ?></th>
                    <th><?php esc_html_e( 'Email',       'smart-job-board' ); ?></th>
                    <th><?php esc_html_e( 'Phone',       'smart-job-board' ); ?></th>
                    <th><?php esc_html_e( 'Job',         'smart-job-board' ); ?></th>
                    <th><?php esc_html_e( 'Status',      'smart-job-board' ); ?></th>
                    <th><?php esc_html_e( 'Applied',     'smart-job-board' ); ?></th>
                    <th><?php esc_html_e( 'Cover Letter','smart-job-board' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $applications as $app ) :
                    $job   = get_post( absint( $app['job_id'] ) );
                    $badge = $status_labels[ $app['status'] ] ?? array( 'label' => ucfirst( $app['status'] ), 'color' => '#64748b' );
                ?>
                <tr data-app-id="<?php echo absint( $app['id'] ); ?>">
                    <td><?php echo esc_html( $app['applicant_name'] ); ?></td>
                    <td><a href="mailto:<?php echo esc_attr( $app['applicant_email'] ); ?>"><?php echo esc_html( $app['applicant_email'] ); ?></a></td>
                    <td><?php echo esc_html( $app['applicant_phone'] ?: '—' ); ?></td>
                    <td><?php echo $job ? '<a href="' . esc_url( get_edit_post_link( $job->ID ) ) . '">' . esc_html( $job->post_title ) . '</a>' : '—'; ?></td>
                    <td>
                        <select class="sjb-status-select" data-app-id="<?php echo absint( $app['id'] ); ?>" style="font-size:.8125rem;">
                            <?php foreach ( $status_labels as $slug => $info ) : ?>
                                <option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $app['status'], $slug ); ?>><?php echo esc_html( $info['label'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $app['applied_at'] ) ) ); ?></td>
                    <td>
                        <?php if ( $app['cover_letter'] ) : ?>
                            <details><summary style="cursor:pointer;font-size:.8125rem;"><?php esc_html_e( 'View', 'smart-job-board' ); ?></summary>
                            <div style="max-width:320px;font-size:.8125rem;white-space:pre-wrap;"><?php echo esc_html( $app['cover_letter'] ); ?></div></details>
                        <?php else : ?>—<?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php
}