<?php
/**
 * Admin view: Settings page helper.
 * FILE: smart-job-board/admin/views/settings-page.php
 *
 * The Settings API renders via WSTS_Settings::render_settings_page()
 * which is already registered in class-sjb-settings.php.
 * This file provides supplementary content if needed.
 *
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;
// Rendered by SJB_Settings::render_settings_page() via Settings API.