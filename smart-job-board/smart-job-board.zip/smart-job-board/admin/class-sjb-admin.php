<?php
/**
 * Admin: Applicants page + asset enqueue.
 * FILE: smart-job-board/admin/class-sjb-admin.php
 *
 * NOTE: Listed in the plugin structure but NEVER written in the reference file.
 * Created from scratch.
 *
 * @package SmartJobBoard
 */
defined( 'ABSPATH' ) || exit;

class SJB_Admin {

    public function enqueue_scripts( string $hook ): void {
        $screen = get_current_screen();
        $is_job_screen = $screen && (
            'job_listing' === $screen->post_type ||
            false !== strpos( $hook, 'sjb' )
        );
        if ( ! $is_job_screen ) return;

        wp_enqueue_style(  'sjb-admin', SJB_PLUGIN_URL . 'admin/assets/admin.css', array(), SJB_VERSION );
        wp_enqueue_script( 'sjb-admin', SJB_PLUGIN_URL . 'admin/assets/admin.js',  array( 'jquery' ), SJB_VERSION, true );
        wp_localize_script( 'sjb-admin', 'sjb_admin', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'sjb_admin_nonce' ),
            'strings'  => array(
                'confirm_delete' => __( 'Are you sure you want to delete this application?', 'smart-job-board' ),
                'updating'       => __( 'Updating…', 'smart-job-board' ),
            ),
        ) );
    }

    public function add_applicants_page(): void {
        add_submenu_page(
            'edit.php?post_type=job_listing',
            __( 'All Applicants', 'smart-job-board' ),
            __( 'Applicants',     'smart-job-board' ),
            'manage_sjb_applicants',
            'sjb-applicants',
            array( $this, 'render_applicants_page' )
        );
    }

    public function render_applicants_page(): void {
        if ( ! current_user_can( 'manage_sjb_applicants' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'smart-job-board' ) );
        }
        require_once SJB_PLUGIN_DIR . 'admin/views/applicants-page.php';
        sjb_render_applicants_page();
    }
}