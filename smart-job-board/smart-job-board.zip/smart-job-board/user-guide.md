# Smart Job Board — User Guide

## Table of Contents

- [What This Plugin Does](#what-this-plugin-does)
- [After Activation](#after-activation)
- [Step 1: Configure Settings](#step-1-configure-settings)
- [Step 2: Create Taxonomies](#step-2-create-taxonomies)
- [Step 3: Post a Job](#step-3-post-a-job)
- [Step 4: Add Shortcodes to Pages](#step-4-add-shortcodes-to-pages)
- [Shortcode Reference](#shortcode-reference)
  - [[smart_job_board]](#smart_job_board)
- [Application Form](#application-form)
- [Managing Applicants](#managing-applicants)
- [Featured Jobs Widget](#featured-jobs-widget)
- [REST API](#rest-api)
- [FAQ](#faq)

---

## What This Plugin Does

Smart Job Board adds a complete recruitment system to WordPress. Employers post jobs with rich details, visitors browse and search a card grid, and applicants submit applications directly through the site.

| Feature | Where |
|---|---|
| **Job listing grid** | Any page with `[smart_job_board]` |
| **Post a new job** | **Smart Jobs → Add New Job** |
| **Job Categories** | **Smart Jobs → Job Categories** |
| **Job Locations** | **Smart Jobs → Job Locations** |
| **Applicants** | **Smart Jobs → Applicants** |
| **Settings** | **Smart Jobs → Settings** |

---

## After Activation

On activation the plugin:

- Creates the `wp_sjb_applications` database table
- Adds job management capabilities to the Administrator and Editor roles
- Adds a **Smart Jobs** menu to the WordPress admin sidebar
- Registers the `job_listing` CPT, `job_category` and `job_location` taxonomies

---

## Step 1: Configure Settings

Go to **Smart Jobs → Settings**.

| Setting | Default | Description |
|---|---|---|
| **Jobs Per Page** | `10` | Default number of job cards shown per page when no `per_page` attribute is used in the shortcode |
| **Notification Email** | Admin email | New application notifications are sent to this address |
| **Allow Resume Upload** | ✅ | Stores a resume URL field in the applications table |
| **Currency Symbol** | `$` | Shown before salary amounts on job cards (e.g. `$`, `£`, `€`) |

Click **Save Settings**.

---

## Step 2: Create Taxonomies

### Job Categories

Organise jobs into topics (e.g. Engineering, Design, Marketing).

1. Go to **Smart Jobs → Job Categories**
2. Click **Add New Job Category**
3. Enter a **Name** (e.g. "Engineering") and **Slug** is generated automatically (e.g. `engineering`)
4. Click **Add New Job Category**

Categories are hierarchical — you can create sub-categories (e.g. Engineering → Backend, Engineering → Frontend).

### Job Locations

Tag jobs with location terms (e.g. Remote, London, New York).

1. Go to **Smart Jobs → Job Locations**
2. Add locations the same way as categories
3. Slug examples: `remote`, `london`, `new-york`

> **Finding slugs:** The slug is shown in the Slug column of the taxonomy list. Use it in shortcode attributes.

---

## Step 3: Post a Job

1. Go to **Smart Jobs → Add New Job**
2. Enter the **job title** as the post title (e.g. "Senior Backend Engineer")
3. Write the **full job description** in the main content editor (requirements, responsibilities, benefits)
4. Add a **Featured Image** — shown as a thumbnail on the job card (optional)
5. Fill in the **Job Details** meta box:

| Field | Description |
|---|---|
| **Company Name** | Shown on the job card |
| **Company URL** | Link to the company website |
| **Job Type** | Full-Time / Part-Time / Remote / Contract / Internship — shown as a colour-coded badge |
| **Experience** | Free text (e.g. "2+ years", "Senior level") |
| **Salary Min ($)** | Minimum salary — shown as "$50,000" |
| **Salary Max ($)** | Maximum salary — shown as "$50,000 – $70,000" |
| **Application Deadline** | Date after which the job is considered expired |
| **Featured Job** | ✅ Tick to mark as featured — shows ⭐ badge on card and gold border |

6. Assign **Job Category** and **Job Location** in the right sidebar
7. Click **Publish**

> **Finding the Job ID:** After publishing, look at the URL — `post.php?post=42`. The number after `post=` is the job ID used in the application form.

---

## Step 4: Add Shortcodes to Pages

### Jobs listing page

1. Go to **Pages → Add New**
2. Title it "Jobs" or "Careers"
3. Add:

```
[smart_job_board]
```

4. Publish and add to your navigation menu

### Category-specific pages

Create separate pages for different departments or locations:

```
[smart_job_board category="engineering"]
[smart_job_board category="design" location="remote"]
[smart_job_board type="internship"]
```

---

## Shortcode Reference

### [smart_job_board]

Displays a responsive card grid of published job listings with a live keyword search bar.

**Basic usage:**

```
[smart_job_board]
```

**All attributes:**

```
[smart_job_board category="engineering" location="remote" per_page="6" featured="yes" type="full-time"]
```

| Attribute | Default | Description |
|---|---|---|
| `category` | *(all)* | Job Category **slug** to filter by. Leave empty for all. |
| `location` | *(all)* | Job Location **slug** to filter by. Leave empty for all. |
| `type` | *(all)* | Job type to filter by. Options: `full-time`, `part-time`, `remote`, `contract`, `internship` |
| `per_page` | Settings value | Maximum jobs to display. Overrides the Settings default. |
| `featured` | `"no"` | Set to `"yes"` to show only Featured jobs. |

**Examples:**

```
[smart_job_board]
```
All published jobs, default per_page from settings.

```
[smart_job_board per_page="6"]
```
Show 6 jobs maximum.

```
[smart_job_board category="engineering"]
```
Only engineering jobs.

```
[smart_job_board category="design" location="remote"]
```
Design jobs in the remote location.

```
[smart_job_board featured="yes"]
```
Only jobs marked as Featured.

```
[smart_job_board category="marketing" type="full-time" per_page="4"]
```
Up to 4 full-time marketing jobs.

```
[smart_job_board type="internship"]
```
All internship listings across categories.

**What each card shows:**

- Featured badge (⭐ if featured)
- Job title (linked to the single job page)
- Company name
- Job type badge (colour-coded)
- Salary range (if both min and max are set)
- Application deadline
- Job excerpt
- View Job button

**Live search:**

The search bar filters jobs by keyword as you type (400ms debounce). It searches post titles and content via WordPress `WP_Query` with the `s` parameter. The results update without a page reload.

**Caching:**

Shortcode output is cached using transients for 10 minutes. The cache is automatically cleared whenever a job is saved or updated.

---

## Application Form

The application form is rendered on the **single job post page**. Add the following HTML to your single job template or a dedicated Apply page:

```html
<div class="sjb-application-form-wrap">
    <h3>Apply for This Position</h3>
    <div class="sjb-form-message"></div>
    <form id="sjb-application-form">
        <input type="hidden" name="job_id" value="YOUR_JOB_ID">

        <div class="sjb-form-field">
            <label>Full Name <span class="sjb-req">*</span></label>
            <input type="text" name="name" required autocomplete="name">
        </div>

        <div class="sjb-form-field">
            <label>Email Address <span class="sjb-req">*</span></label>
            <input type="email" name="email" required autocomplete="email">
        </div>

        <div class="sjb-form-field">
            <label>Phone Number</label>
            <input type="tel" name="phone" autocomplete="tel">
        </div>

        <div class="sjb-form-field">
            <label>Cover Letter</label>
            <textarea name="cover_letter" rows="5" placeholder="Tell us why you're a great fit…"></textarea>
        </div>

        <button type="submit" class="sjb-btn sjb-submit-btn">Apply Now</button>
    </form>
</div>
```

Replace `YOUR_JOB_ID` with the actual WordPress post ID of the job.

**What happens on submission:**

1. AJAX sends the form data with a nonce for security
2. The server checks for a duplicate application (same email + same job)
3. If valid, the application is saved to `wp_sjb_applications`
4. An email notification is sent to the admin email address
5. A success message replaces the submit button

**Duplicate detection:**

If a visitor submits the same email address for the same job twice, they see: "You have already applied for this job." No duplicate is stored.

---

## Managing Applicants

### Viewing applications

Go to **Smart Jobs → Applicants**.

The page shows a table of all applications with:

| Column | Description |
|---|---|
| **Applicant** | Full name |
| **Email** | Clickable email link (opens mail client) |
| **Phone** | Phone number (if provided) |
| **Job** | Job title (linked to the edit screen) |
| **Status** | Dropdown: Pending / Reviewed / Shortlisted / Rejected |
| **Applied** | Date the application was submitted |
| **Cover Letter** | Expandable `<details>` preview |

### Filtering

**Status tabs** at the top: All · Pending · Reviewed · Shortlisted · Rejected

**Job dropdown**: Filter to see only applications for a specific job posting.

### Updating application status

Change the Status dropdown in any row — it saves via AJAX immediately. No page reload needed.

**Status meanings:**

| Status | Meaning |
|---|---|
| **Pending** | New application, not yet reviewed |
| **Reviewed** | Application has been read |
| **Shortlisted** | Candidate is being considered for interview |
| **Rejected** | Application has been declined |

---

## Featured Jobs Widget

The **Featured Jobs** sidebar widget shows a list of jobs with the Featured flag ticked.

### Adding the widget

1. Go to **Appearance → Widgets**
2. Find **Featured Jobs** in the widget list
3. Drag it to a sidebar or widget area
4. Configure:
   - **Title** — heading above the list (e.g. "Now Hiring")
   - **Number of jobs** — how many featured jobs to show (1–20)
5. Click **Save**

### What it shows

- Job title (linked to the single job page)
- Company name
- Job type

Widget output is cached using transients for **10 minutes**. The cache is cleared automatically when widget settings are changed.

---

## REST API

All job list and single job endpoints are **public** — no authentication required. The applications POST endpoint is also public but validates data server-side.

### GET — List Jobs

```
GET /wp-json/smart-job-board/v1/jobs
```

**Query parameters:**

| Parameter | Default | Description |
|---|---|---|
| `per_page` | `10` | Number of results |
| `page` | `1` | Page number |
| `category` | — | Category slug filter |
| `location` | — | Location slug filter |

**Response headers:** `X-WP-Total`, `X-WP-TotalPages`

**Response:**
```json
[
  {
    "id": 42,
    "title": "Senior Backend Engineer",
    "excerpt": "We are looking for…",
    "url": "https://yoursite.com/jobs/senior-backend-engineer/",
    "company": "Acme Corp",
    "company_url": "https://acme.com",
    "job_type": "full-time",
    "experience": "3+ years",
    "salary_min": 60000,
    "salary_max": 90000,
    "deadline": "2025-07-31",
    "is_featured": true,
    "categories": ["Engineering"],
    "locations": ["Remote"],
    "date": "2025-06-01 09:00:00"
  }
]
```

### GET — Single Job

```
GET /wp-json/smart-job-board/v1/jobs/{id}
```

Returns all fields above plus `content` (full HTML of the job description).

Returns `404` if the job is not found or not published.

### POST — Submit Application

```
POST /wp-json/smart-job-board/v1/applications
```

**Body (JSON or form-data):**

| Field | Required | Description |
|---|---|---|
| `job_id` | Yes | WordPress post ID of the job |
| `name` | Yes | Applicant full name |
| `email` | Yes | Valid email address |

**Response:**
```json
{ "success": true, "message": "Application submitted.", "id": 15 }
```

Returns `400` for missing fields, `500` for database errors.

---

## FAQ

**The job cards load but the search bar does nothing.**

Check the browser console (F12). If you see a 400 or 0 error on the AJAX request, the nonce may have expired — refresh the page. If the script doesn't load at all, confirm the page has `[smart_job_board]` in its content (the JS only loads on pages with the shortcode).

**Jobs are showing stale results after I updated a post.**

The shortcode output is cached for 10 minutes. When you save a job post, the cache is automatically cleared. If results are still stale, your hosting may have a server-level page cache — clear it from your caching plugin (e.g. W3 Total Cache, WP Rocket).

**The salary doesn't show on the card.**

Both Salary Min AND Salary Max must be set. If only one is filled in, the salary is not shown. Set both values in the Job Details meta box.

**The application form sends no email.**

WordPress uses the server's default PHP `mail()` function. On most shared hosts this goes to spam or fails silently. Install **WP Mail SMTP** and connect it to Gmail, SendGrid, or Mailgun. Test delivery with **WP Mail SMTP → Email Test**.

**How do I find the category or location slug?**

Go to **Smart Jobs → Job Categories** (or Job Locations). The Slug column shows the value to use in shortcode attributes.

**Can I have jobs expire automatically after their deadline?**

Not in this version — the deadline is stored as post meta and shown on the card as informational text. To auto-expire jobs, add a WP-Cron job that queries for jobs where `_sjb_deadline < today` and sets `post_status = 'draft'`.

**Can I export applications to CSV?**

No built-in export. Query the database directly:
```sql
SELECT a.id, a.applicant_name, a.applicant_email, a.applicant_phone,
       a.status, a.applied_at, p.post_title AS job_title
FROM wp_sjb_applications a
JOIN wp_posts p ON a.job_id = p.ID
ORDER BY a.applied_at DESC;
```

Export via phpMyAdmin → Export → CSV. Or use WP All Export targeting the custom table.

**How do I remove all plugin data?**

Go to **Plugins → Installed Plugins** → **Delete** Smart Job Board. The `uninstall.php` file automatically drops the `sjb_applications` table, removes all transients, deletes all `job_listing` posts, and strips capabilities from all roles.