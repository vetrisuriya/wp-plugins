<?php
/**
 * Plugin Name:       Smart Job Board
 * Plugin URI:        https://vetrisuriya.in/smart-job-board
 * Description:       A complete job board for WordPress. Post jobs, collect applications, filter listings by category and location, and manage applicants — all without external services.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Vetri Suriya
 * License:           GPL v2 or later
 * Text Domain:       smart-job-board
 * Domain Path:       /languages
 * @package SmartJobBoard
 */

defined( 'ABSPATH' ) || exit;

define( 'SJB_VERSION',         '1.0.0' );
define( 'SJB_PLUGIN_DIR',      plugin_dir_path( __FILE__ ) );
define( 'SJB_PLUGIN_URL',      plugin_dir_url( __FILE__ ) );
define( 'SJB_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/*
 * FATAL ERROR ROOT CAUSE (same as Plugins 02 and 03):
 *
 * smart_job_board() is called at the BOTTOM of this file — meaning it runs
 * on EVERY WordPress page load, not just activation. That call reaches
 * load_dependencies() which uses require_once on all class files.
 * Since NO class files existed as real .php files, PHP threw:
 *   Fatal error: require_once(): Failed to open required file 'class-sjb-post-type.php'
 * on every single page load — breaking the entire site.
 *
 * FIX: Create all class files as real .php files.
 * The singleton bootstrap structure is architecturally correct.
 */
final class Smart_Job_Board {

    private static ?Smart_Job_Board $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_dependencies();
        $this->set_locale();
        $this->define_hooks();
    }

    private function load_dependencies(): void {
        require_once SJB_PLUGIN_DIR . 'includes/class-sjb-post-type.php';
        require_once SJB_PLUGIN_DIR . 'includes/class-sjb-database.php';
        require_once SJB_PLUGIN_DIR . 'includes/class-sjb-settings.php';
        require_once SJB_PLUGIN_DIR . 'includes/class-sjb-shortcode.php';
        require_once SJB_PLUGIN_DIR . 'includes/class-sjb-ajax.php';
        require_once SJB_PLUGIN_DIR . 'includes/class-sjb-rest-api.php';
        require_once SJB_PLUGIN_DIR . 'includes/class-sjb-widget.php';
        require_once SJB_PLUGIN_DIR . 'includes/class-sjb-capabilities.php';
        require_once SJB_PLUGIN_DIR . 'includes/class-sjb-transients.php';
        require_once SJB_PLUGIN_DIR . 'admin/class-sjb-admin.php';
    }

    private function set_locale(): void {
        add_action( 'plugins_loaded', function (): void {
            load_plugin_textdomain( 'smart-job-board', false, dirname( SJB_PLUGIN_BASENAME ) . '/languages/' );
        } );
    }

    private function define_hooks(): void {
        $post_type = new SJB_Post_Type();
        add_action( 'init', array( $post_type, 'register' ) );

        $settings = new SJB_Settings();
        add_action( 'admin_init', array( $settings, 'register_settings' ) );
        add_action( 'admin_menu', array( $settings, 'add_settings_page' ) );

        $shortcode = new SJB_Shortcode();
        add_shortcode( 'smart_job_board', array( $shortcode, 'render' ) );

        $ajax = new SJB_Ajax();
        add_action( 'wp_ajax_sjb_search_jobs',          array( $ajax, 'search_jobs' ) );
        add_action( 'wp_ajax_nopriv_sjb_search_jobs',   array( $ajax, 'search_jobs' ) );
        add_action( 'wp_ajax_sjb_submit_application',        array( $ajax, 'submit_application' ) );
        add_action( 'wp_ajax_nopriv_sjb_submit_application', array( $ajax, 'submit_application' ) );

        $rest = new SJB_Rest_Api();
        add_action( 'rest_api_init', array( $rest, 'register_routes' ) );

        add_action( 'widgets_init', function () { register_widget( 'SJB_Widget' ); } );

        $admin = new SJB_Admin();
        add_action( 'admin_enqueue_scripts', array( $admin, 'enqueue_scripts' ) );
        add_action( 'admin_menu',            array( $admin, 'add_applicants_page' ) );

        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_public_scripts' ) );

        // Bust REST transient cache when a job is saved.
        add_action( 'save_post_job_listing', array( 'SJB_Transients', 'bust_jobs_cache' ) );

        // Redirect to welcome screen on first activation.
        add_action( 'admin_init', array( $this, 'maybe_redirect' ) );
    }

    public function enqueue_public_scripts(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) || ! has_shortcode( $post->post_content, 'smart_job_board' ) ) return;
        // Also enqueue on single job listings.
        if ( ! is_singular( 'job_listing' ) && ! has_shortcode( $post->post_content, 'smart_job_board' ) ) return;

        wp_enqueue_style(  'sjb-public', SJB_PLUGIN_URL . 'public/assets/public.css', array(), SJB_VERSION );
        wp_enqueue_script( 'sjb-public', SJB_PLUGIN_URL . 'public/assets/public.js',  array( 'jquery' ), SJB_VERSION, true );
        wp_localize_script( 'sjb-public', 'sjb_params', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'sjb_nonce' ),
            'strings'  => array(
                'searching'    => __( 'Searching…',                           'smart-job-board' ),
                'no_results'   => __( 'No jobs found.',                       'smart-job-board' ),
                'submit_error' => __( 'Please fill in all required fields.',  'smart-job-board' ),
                'applying'     => __( 'Applying…',                           'smart-job-board' ),
                'apply_now'    => __( 'Apply Now',                           'smart-job-board' ),
            ),
        ) );
    }

    public function maybe_redirect(): void {
        if ( ! get_transient( 'sjb_activation_redirect' ) ) return;
        delete_transient( 'sjb_activation_redirect' );
        if ( isset( $_GET['activate-multi'] ) ) return;
        wp_safe_redirect( admin_url( 'edit.php?post_type=job_listing&welcome=1' ) );
        exit;
    }
}

register_activation_hook( __FILE__, function (): void {
    require_once SJB_PLUGIN_DIR . 'includes/class-sjb-database.php';
    SJB_Database::create_tables();
    require_once SJB_PLUGIN_DIR . 'includes/class-sjb-capabilities.php';
    SJB_Capabilities::add_caps();
    flush_rewrite_rules();
    set_transient( 'sjb_activation_redirect', true, 30 );
} );

register_deactivation_hook( __FILE__, function (): void {
    flush_rewrite_rules();
} );

function smart_job_board(): Smart_Job_Board {
    return Smart_Job_Board::instance();
}
smart_job_board();