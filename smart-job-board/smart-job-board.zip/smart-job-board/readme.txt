=== Smart Job Board ===
Contributors:      vetrisuriya
Tags:              jobs, job board, careers, recruitment, applications
Requires at least: 5.8
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      7.4
License:           GPL v2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A complete job board for WordPress. Post jobs, collect applications, and filter listings by category, location, and type — no external services needed.

== Description ==

**Smart Job Board** turns your WordPress site into a full-featured job board. Employers post jobs with salary ranges, deadlines, and job types. Visitors browse and search with live filtering. Applicants submit applications directly through the site.

= Core Features =

* **`[smart_job_board]` shortcode** — responsive card grid with live keyword search, category, location, and type filters
* **Job Details meta box** — Company Name, URL, Job Type, Experience, Salary Min/Max, Deadline, Featured flag
* **Job Categories** — hierarchical taxonomy (e.g. Engineering → Backend)
* **Job Locations** — flat taxonomy (e.g. Remote, London, New York)
* **Applications DB table** — `sjb_applications` stores name, email, phone, cover letter, status, IP, timestamps
* **Duplicate detection** — one application per email per job enforced at submission
* **Admin notification email** — `wp_mail()` alert on every new application
* **Applicants admin page** — filter by status and job, update status (Pending / Reviewed / Shortlisted / Rejected) via AJAX
* **Featured Jobs widget** — sidebar widget with transient caching (10 min)
* **REST API** — `GET /smart-job-board/v1/jobs` · `GET /jobs/{id}` · `POST /applications`
* **Transient caching** — shortcode and REST API responses cached; busted on job save
* **Clean uninstall** — drops DB table, all transients, all job posts, and all capabilities

= Shortcodes =

`[smart_job_board]`
`[smart_job_board category="engineering" location="remote" per_page="6" featured="yes" type="full-time"]`

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload Plugin**
2. Go to **Smart Jobs → Settings** and configure Jobs Per Page, Notification Email, and Currency Symbol
3. Create **Job Categories** and **Job Locations** under the Smart Jobs menu
4. Go to **Smart Jobs → Add New Job** to publish your first listing
5. Add `[smart_job_board]` to any page
6. Add an **Application Form** to each job's single-post page or a dedicated Apply page

== Frequently Asked Questions ==

= How do I add the application form? =

The application form is rendered on the single job post template. Add `[smart_job_board]` to your jobs listing page. The individual job page uses the standard WordPress single post template — if your theme supports it, the application form HTML can be added via the `the_content` filter or a page builder on each job post.

Alternatively, build a standalone Apply page with a hidden `job_id` input and point the job cards to it.

= How do I filter jobs in the shortcode? =

Use shortcode attributes: `category`, `location`, `type`, and `featured`. All values must be the term slug (not the name). To find a slug, go to **Smart Jobs → Job Categories** and look at the Slug column.

= What is a Featured Job? =

Any job with the **Featured Job** checkbox ticked in the Job Details meta box. Featured jobs show a ⭐ badge on the card and are highlighted with a gold border. They also appear in the **Featured Jobs** sidebar widget. Use `featured="yes"` in the shortcode to show only featured jobs.

= Can applicants upload a resume? =

Resume upload support is enabled in settings. The resume URL is stored in the applications table. Front-end file upload UI requires adding an `<input type="file">` to the application form and handling upload via `wp_handle_upload()`.

= How do I change application status? =

Go to **Smart Jobs → Applicants**. The Status column has a dropdown for each applicant — changing it saves via AJAX immediately. Status options: Pending, Reviewed, Shortlisted, Rejected.

= How does the REST API work? =

All job endpoints are public (no authentication needed). The `POST /applications` endpoint requires a valid job ID, name, and email. See the user guide for full response formats.

== Screenshots ==

1. Job card grid with search bar and category/type badges.
2. Featured job card with gold border and ⭐ badge.
3. Single job page with application form.
4. Admin — Job Details meta box with salary, deadline, and featured fields.
5. Admin — Applicants page with status filter tabs and inline status update.
6. Featured Jobs sidebar widget.
7. Settings page — jobs per page, notification email, currency symbol.

== Changelog ==

= 1.0.0 =
* Initial release. Job Listing CPT, Job Categories + Locations taxonomies, Job Details meta box, Applications DB table, [smart_job_board] shortcode, live AJAX search, application submission with duplicate check, admin notification email, Applicants admin page, Featured Jobs widget, REST API, transient caching, clean uninstall.

== Upgrade Notice ==

= 1.0.0 =
Initial release. No upgrade steps required.