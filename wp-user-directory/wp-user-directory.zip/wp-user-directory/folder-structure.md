wp-user-directory/
│
├── wp-user-directory.php          ← Bootstrap + plugin header
├── uninstall.php
├── readme.txt
│
├── includes/
│   ├── class-wpud-activator.php   ← Caps setup
│   ├── class-wpud-user-meta.php   ← Profile fields in WP admin user screen
│   ├── class-wpud-taxonomy.php    ← Department taxonomy (user bridge)
│   ├── class-wpud-settings.php    ← Settings API
│   ├── class-wpud-shortcodes.php  ← [user_directory], [edit_my_profile]
│   ├── class-wpud-ajax.php        ← Live search handler
│   ├── class-wpud-rest-api.php    ← Members REST endpoint
│   └── class-wpud-capabilities.php
│
├── admin/
│   ├── css/wpud-admin.css
│   └── js/wpud-admin.js
│
├── public/
│   ├── css/wpud-public.css
│   └── js/wpud-public.js
│
└── languages/
    └── wp-user-directory.pot