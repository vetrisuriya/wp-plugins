<?php
/**
 * Plugin Name:       WP User Directory Pro
 * Plugin URI:        https://vetrisuriya.in/wp-user-directory
 * Description:       A searchable, filterable member directory for WordPress. Extended profile fields, front-end directory, live AJAX search, front-end profile editing, and REST API.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Vetri Suriya
 * License:           GPL-2.0-or-later
 * Text Domain:       wp-user-directory
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'WPUD_VERSION',  '1.0.0' );
define( 'WPUD_DIR',      plugin_dir_path( __FILE__ ) );
define( 'WPUD_URL',      plugin_dir_url( __FILE__ ) );
define( 'WPUD_BASENAME', plugin_basename( __FILE__ ) );

/*
 * FIX — Require activator at the FILE ROOT LEVEL, before register_activation_hook.
 *
 * Original code had register_activation_hook() BEFORE the class was loaded
 * (class was inside plugins_loaded which fires AFTER the activation hook).
 * Result: Fatal error: Class "WPUD_Activator" not found.
 */
require_once WPUD_DIR . 'includes/class-wpud-activator.php';

register_activation_hook(   __FILE__, array( 'WPUD_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WPUD_Activator', 'deactivate' ) );

add_action( 'plugins_loaded', function () {
    load_plugin_textdomain( 'wp-user-directory', false, dirname( WPUD_BASENAME ) . '/languages' );

    // Load all other classes — activator already loaded above.
    $classes = array(
        'WPUD_User_Meta', 'WPUD_Taxonomy', 'WPUD_Settings',
        'WPUD_Shortcodes', 'WPUD_Ajax', 'WPUD_Rest_Api', 'WPUD_Capabilities',
    );

    foreach ( $classes as $class ) {
        require_once WPUD_DIR . 'includes/class-'
            . strtolower( str_replace( '_', '-', $class ) ) . '.php';
    }

    new WPUD_User_Meta();
    new WPUD_Taxonomy();
    new WPUD_Settings();
    new WPUD_Shortcodes();
    new WPUD_Ajax();
    new WPUD_Rest_Api();

    WPUD_Activator::maybe_upgrade();

    // Bust transient cache when settings change.
    add_action( 'update_option_wpud_options', 'wpud_bust_directory_transients' );
} );

function wpud_bust_directory_transients(): void {
    global $wpdb;
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $wpdb->query(
        "DELETE FROM {$wpdb->options}
         WHERE option_name LIKE '_transient_wpud_directory_%'
            OR option_name LIKE '_transient_timeout_wpud_directory_%'"
    );
}