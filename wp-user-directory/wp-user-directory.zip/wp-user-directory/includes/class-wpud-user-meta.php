<?php
/**
 * Extended Profile Fields — stored in wp_usermeta
 * FILE: wp-user-directory/includes/class-wpud-user-meta.php
 * @package WP_User_Directory
 */
defined( 'ABSPATH' ) || exit;

class WPUD_User_Meta {

    /** All profile fields managed by this plugin. */
    public static function get_fields(): array {
        return array(
            'wpud_phone'      => array( 'label' => __( 'Phone Number',             'wp-user-directory' ), 'type' => 'text',     'sanitize' => 'sanitize_text_field'     ),
            'wpud_department' => array( 'label' => __( 'Department',               'wp-user-directory' ), 'type' => 'text',     'sanitize' => 'sanitize_text_field'     ),
            'wpud_skills'     => array( 'label' => __( 'Skills (comma-separated)', 'wp-user-directory' ), 'type' => 'text',     'sanitize' => 'sanitize_text_field'     ),
            'wpud_linkedin'   => array( 'label' => __( 'LinkedIn URL',             'wp-user-directory' ), 'type' => 'url',      'sanitize' => 'esc_url_raw'             ),
            'wpud_location'   => array( 'label' => __( 'Location / City',          'wp-user-directory' ), 'type' => 'text',     'sanitize' => 'sanitize_text_field'     ),
            'wpud_public_bio' => array( 'label' => __( 'Public Bio',               'wp-user-directory' ), 'type' => 'textarea', 'sanitize' => 'sanitize_textarea_field' ),
        );
    }

    public function __construct() {
        add_action( 'show_user_profile',        array( $this, 'render_fields' ) );
        add_action( 'edit_user_profile',        array( $this, 'render_fields' ) );
        add_action( 'personal_options_update',  array( $this, 'save_fields'   ) );
        add_action( 'edit_user_profile_update', array( $this, 'save_fields'   ) );
    }

    public function render_fields( WP_User $user ): void {
        ?>
        <h3><?php esc_html_e( 'Directory Profile', 'wp-user-directory' ); ?></h3>
        <table class="form-table">
        <?php foreach ( self::get_fields() as $key => $field ) :
            $value = get_user_meta( $user->ID, $key, true ); ?>
            <tr>
                <th><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
                <td>
                    <?php if ( 'textarea' === $field['type'] ) : ?>
                        <textarea id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" class="large-text" rows="4"><?php echo esc_textarea( $value ); ?></textarea>
                    <?php else : ?>
                        <input type="<?php echo esc_attr( $field['type'] ); ?>" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>" class="regular-text">
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </table>
        <?php
    }

    public function save_fields( int $user_id ): void {
        if ( ! current_user_can( 'edit_user', $user_id ) ) return;
        foreach ( self::get_fields() as $key => $field ) {
            if ( isset( $_POST[ $key ] ) ) {
                update_user_meta( $user_id, $key, call_user_func( $field['sanitize'], $_POST[ $key ] ) );
            }
        }
        delete_transient( 'wpud_directory_cache' );
    }

    public static function get_profile( int $user_id ): array {
        $user    = get_userdata( $user_id );
        if ( ! $user ) return array();
        $profile = array(
            'id'           => $user_id,
            'display_name' => $user->display_name,
            'email'        => $user->user_email,
            'avatar'       => get_avatar_url( $user_id, array( 'size' => 96 ) ),
        );
        foreach ( self::get_fields() as $key => $field ) {
            $profile[ $key ] = get_user_meta( $user_id, $key, true ) ?: '';
        }
        return $profile;
    }
}