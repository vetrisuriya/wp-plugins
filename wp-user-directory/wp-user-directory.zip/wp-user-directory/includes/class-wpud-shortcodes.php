<?php
/**
 * Shortcodes: [user_directory] and [edit_my_profile]
 * FILE: wp-user-directory/includes/class-wpud-shortcodes.php
 * @package WP_User_Directory
 */
defined( 'ABSPATH' ) || exit;

class WPUD_Shortcodes {

    public function __construct() {
        add_shortcode( 'user_directory',  array( $this, 'render_directory'    ) );
        add_shortcode( 'edit_my_profile', array( $this, 'render_edit_profile' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
    }

    public function enqueue(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) ) return;
        if (
            ! has_shortcode( $post->post_content, 'user_directory' ) &&
            ! has_shortcode( $post->post_content, 'edit_my_profile' )
        ) return;

        wp_enqueue_style(  'wpud-public', WPUD_URL . 'public/css/wpud-public.css', array(), WPUD_VERSION );
        wp_enqueue_script( 'wpud-public', WPUD_URL . 'public/js/wpud-public.js',  array( 'jquery' ), WPUD_VERSION, true );
        wp_localize_script( 'wpud-public', 'WPUDData', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wpud_nonce' ),
            'strings'  => array(
                'searching'    => __( 'Searching…', 'wp-user-directory' ),
                'no_results'   => __( 'No members found.', 'wp-user-directory' ),
                'save_success' => __( 'Profile saved successfully.', 'wp-user-directory' ),
                'save_error'   => __( 'Error saving profile. Please try again.', 'wp-user-directory' ),
            ),
        ) );
    }

    /**
     * [user_directory department="engineering" per_page="12" role="editor"]
     */
    public function render_directory( array $atts ): string {
        $opts = get_option( 'wpud_options', array() );
        $atts = shortcode_atts( array(
            'department' => '',
            'per_page'   => $opts['per_page'] ?? 12,
            'role'       => '',
            'orderby'    => 'display_name',
            'order'      => 'ASC',
        ), $atts, 'user_directory' );

        $roles    = ! empty( $atts['role'] )
            ? array_map( 'trim', explode( ',', $atts['role'] ) )
            : (array) ( $opts['roles_to_show'] ?? array( 'subscriber' ) );

        $cache_key = 'wpud_directory_' . md5( serialize( $atts ) . implode( ',', $roles ) );
        $users     = get_transient( $cache_key );

        if ( false === $users ) {
            $args = array(
                'role__in' => $roles,
                'number'   => absint( $atts['per_page'] ),
                'orderby'  => sanitize_text_field( $atts['orderby'] ),
                'order'    => 'ASC' === strtoupper( $atts['order'] ) ? 'ASC' : 'DESC',
                'fields'   => 'ID',
            );
            if ( $atts['department'] ) {
                $args['meta_query'] = array( array(
                    'key'     => 'wpud_department',
                    'value'   => sanitize_text_field( $atts['department'] ),
                    'compare' => 'LIKE',
                ) );
            }
            $users = get_users( $args );
            set_transient( $cache_key, $users, 30 * MINUTE_IN_SECONDS );
        }

        if ( empty( $users ) ) {
            return '<p class="wpud-no-results">' . esc_html__( 'No members found.', 'wp-user-directory' ) . '</p>';
        }

        ob_start();
        ?>
        <div class="wpud-directory-wrap">
            <div class="wpud-search-bar">
                <span class="wpud-search-icon" aria-hidden="true">🔍</span>
                <input type="search"
                       id="wpud-live-search"
                       class="wpud-search-input"
                       placeholder="<?php esc_attr_e( 'Search by name, department, or skill…', 'wp-user-directory' ); ?>"
                       aria-label="<?php esc_attr_e( 'Search members', 'wp-user-directory' ); ?>"
                       autocomplete="off">
            </div>
            <div id="wpud-directory-grid" class="wpud-grid" role="list">
                <?php foreach ( $users as $user_id ) :
                    $profile = WPUD_User_Meta::get_profile( $user_id ); ?>
                <div class="wpud-member-card" role="listitem"
                     data-name="<?php echo esc_attr( strtolower( $profile['display_name'] ) ); ?>">
                    <img src="<?php echo esc_url( $profile['avatar'] ); ?>"
                         alt="<?php echo esc_attr( $profile['display_name'] ); ?>"
                         class="wpud-avatar" loading="lazy" width="96" height="96">
                    <h3 class="wpud-name"><?php echo esc_html( $profile['display_name'] ); ?></h3>
                    <?php if ( $profile['wpud_department'] ) : ?>
                        <p class="wpud-dept"><?php echo esc_html( $profile['wpud_department'] ); ?></p>
                    <?php endif; ?>
                    <?php if ( $profile['wpud_location'] ) : ?>
                        <p class="wpud-location">📍 <?php echo esc_html( $profile['wpud_location'] ); ?></p>
                    <?php endif; ?>
                    <?php if ( $profile['wpud_skills'] ) : ?>
                        <div class="wpud-skills">
                            <?php foreach ( array_map( 'trim', explode( ',', $profile['wpud_skills'] ) ) as $skill ) : ?>
                                <span class="wpud-skill-tag"><?php echo esc_html( $skill ); ?></span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <?php if ( $profile['wpud_public_bio'] ) : ?>
                        <p class="wpud-bio"><?php echo esc_html( wp_trim_words( $profile['wpud_public_bio'], 20 ) ); ?></p>
                    <?php endif; ?>
                    <div class="wpud-card-footer">
                        <?php if ( ! empty( $opts['show_email'] ) && '1' === $opts['show_email'] ) : ?>
                            <a href="mailto:<?php echo esc_attr( $profile['email'] ); ?>" class="wpud-contact-link">✉ <?php esc_html_e( 'Email', 'wp-user-directory' ); ?></a>
                        <?php endif; ?>
                        <?php if ( $profile['wpud_linkedin'] ) : ?>
                            <a href="<?php echo esc_url( $profile['wpud_linkedin'] ); ?>" class="wpud-linkedin-link" target="_blank" rel="noopener noreferrer">in <?php esc_html_e( 'LinkedIn', 'wp-user-directory' ); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * [edit_my_profile] — logged-in user updates their own profile fields.
     */
    public function render_edit_profile( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<p class="wpud-login-notice">' .
                esc_html__( 'Please log in to edit your profile.', 'wp-user-directory' ) .
                ' <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">' .
                esc_html__( 'Log in', 'wp-user-directory' ) . '</a></p>';
        }

        $user_id = get_current_user_id();
        $profile = WPUD_User_Meta::get_profile( $user_id );

        ob_start();
        ?>
        <div class="wpud-edit-profile">
            <div id="wpud-profile-message" role="alert" aria-live="polite" style="display:none;"></div>
            <?php foreach ( WPUD_User_Meta::get_fields() as $key => $field ) : ?>
            <div class="wpud-form-field">
                <label class="wpud-label" for="<?php echo esc_attr( $key ); ?>">
                    <?php echo esc_html( $field['label'] ); ?>
                </label>
                <?php if ( 'textarea' === $field['type'] ) : ?>
                    <textarea id="<?php echo esc_attr( $key ); ?>"
                              name="<?php echo esc_attr( $key ); ?>"
                              class="wpud-field wpud-textarea"
                              rows="4"><?php echo esc_textarea( $profile[ $key ] ?? '' ); ?></textarea>
                <?php else : ?>
                    <input type="<?php echo esc_attr( $field['type'] ); ?>"
                           id="<?php echo esc_attr( $key ); ?>"
                           name="<?php echo esc_attr( $key ); ?>"
                           class="wpud-field"
                           value="<?php echo esc_attr( $profile[ $key ] ?? '' ); ?>">
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            <button type="button" id="wpud-save-profile" class="wpud-btn wpud-btn--primary">
                <?php esc_html_e( 'Save Profile', 'wp-user-directory' ); ?>
            </button>
        </div>
        <?php
        return ob_get_clean();
    }
}