<?php
/**
 * AJAX Handlers: live search + front-end profile save
 * FILE: wp-user-directory/includes/class-wpud-ajax.php
 * @package WP_User_Directory
 */
defined( 'ABSPATH' ) || exit;

class WPUD_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_wpud_live_search',        array( $this, 'live_search'   ) );
        add_action( 'wp_ajax_nopriv_wpud_live_search', array( $this, 'live_search'   ) );
        add_action( 'wp_ajax_wpud_save_profile',       array( $this, 'save_profile'  ) );
    }

    /** Live search — returns HTML cards matching the query. */
    public function live_search(): void {
        check_ajax_referer( 'wpud_nonce', 'nonce' );

        $search = sanitize_text_field( $_POST['search'] ?? '' );
        $opts   = get_option( 'wpud_options', array() );
        $roles  = (array) ( $opts['roles_to_show'] ?? array( 'subscriber' ) );

        $base_args = array( 'role__in' => $roles, 'number' => 20, 'fields' => 'ID' );

        if ( $search ) {
            $name_users = get_users( array_merge( $base_args, array(
                'search'         => '*' . $search . '*',
                'search_columns' => array( 'display_name', 'user_login' ),
            ) ) );
            $meta_users = get_users( array_merge( $base_args, array(
                'meta_query' => array(
                    'relation' => 'OR',
                    array( 'key' => 'wpud_skills',     'value' => $search, 'compare' => 'LIKE' ),
                    array( 'key' => 'wpud_department',  'value' => $search, 'compare' => 'LIKE' ),
                    array( 'key' => 'wpud_location',    'value' => $search, 'compare' => 'LIKE' ),
                ),
            ) ) );
            $user_ids = array_unique( array_merge( $name_users, $meta_users ) );
        } else {
            $user_ids = get_users( $base_args );
        }

        if ( empty( $user_ids ) ) {
            wp_send_json_success( array( 'html' => '<p class="wpud-no-results">' . esc_html__( 'No members found.', 'wp-user-directory' ) . '</p>' ) );
        }

        ob_start();
        foreach ( $user_ids as $user_id ) {
            $profile = WPUD_User_Meta::get_profile( $user_id );
            ?>
            <div class="wpud-member-card">
                <img src="<?php echo esc_url( $profile['avatar'] ); ?>" alt="<?php echo esc_attr( $profile['display_name'] ); ?>" class="wpud-avatar" loading="lazy" width="96" height="96">
                <h3 class="wpud-name"><?php echo esc_html( $profile['display_name'] ); ?></h3>
                <?php if ( $profile['wpud_department'] ) : ?>
                    <p class="wpud-dept"><?php echo esc_html( $profile['wpud_department'] ); ?></p>
                <?php endif; ?>
                <?php if ( $profile['wpud_skills'] ) : ?>
                    <div class="wpud-skills">
                        <?php foreach ( array_map( 'trim', explode( ',', $profile['wpud_skills'] ) ) as $skill ) : ?>
                            <span class="wpud-skill-tag"><?php echo esc_html( $skill ); ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            <?php
        }
        wp_send_json_success( array( 'html' => ob_get_clean() ) );
    }

    /** Save logged-in user's own profile via the front-end [edit_my_profile] form. */
    public function save_profile(): void {
        check_ajax_referer( 'wpud_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( array( 'message' => __( 'You must be logged in.', 'wp-user-directory' ) ) );
        }

        $user_id = get_current_user_id();

        foreach ( WPUD_User_Meta::get_fields() as $key => $field ) {
            if ( isset( $_POST[ $key ] ) ) {
                update_user_meta( $user_id, $key, call_user_func( $field['sanitize'], $_POST[ $key ] ) );
            }
        }

        global $wpdb;
        // Bust all directory transients — profile data changed.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wpud_directory_%' OR option_name LIKE '_transient_timeout_wpud_directory_%'" );

        wp_send_json_success( array( 'message' => __( 'Profile updated successfully.', 'wp-user-directory' ) ) );
    }
}