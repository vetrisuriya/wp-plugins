<?php
/**
 * Capabilities
 * FILE: wp-user-directory/includes/class-wpud-capabilities.php
 * @package WP_User_Directory
 */
defined( 'ABSPATH' ) || exit;

class WPUD_Capabilities {

    public static function add(): void {
        foreach ( array( 'administrator', 'editor' ) as $role_slug ) {
            $role = get_role( $role_slug );
            if ( $role ) $role->add_cap( 'manage_user_directory' );
        }
    }

    public static function remove(): void {
        global $wp_roles;
        if ( ! isset( $wp_roles ) ) $wp_roles = new WP_Roles();
        foreach ( array_keys( $wp_roles->roles ) as $role_slug ) {
            $role = get_role( $role_slug );
            if ( $role ) $role->remove_cap( 'manage_user_directory' );
        }
    }
}