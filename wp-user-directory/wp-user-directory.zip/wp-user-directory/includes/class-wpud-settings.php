<?php
/**
 * Settings API: Directory Configuration
 * FILE: wp-user-directory/includes/class-wpud-settings.php
 * @package WP_User_Directory
 */
defined( 'ABSPATH' ) || exit;

class WPUD_Settings {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_page' ) );
        add_action( 'admin_init', array( $this, 'register' ) );
        add_action( 'admin_init', array( $this, 'maybe_redirect' ) );
    }

    public function add_page(): void {
        add_options_page(
            __( 'User Directory Settings', 'wp-user-directory' ),
            __( 'User Directory',          'wp-user-directory' ),
            'manage_options',
            'wpud-settings',
            array( $this, 'render' )
        );
    }

    public function register(): void {
        register_setting( 'wpud_group', 'wpud_options', array( 'sanitize_callback' => array( $this, 'sanitize' ) ) );

        add_settings_section( 'wpud_display', __( 'Display Settings', 'wp-user-directory' ), '__return_false', 'wpud-settings' );
        add_settings_field( 'roles_to_show', __( 'Show Members With Role',     'wp-user-directory' ), array( $this, 'field_roles'      ), 'wpud-settings', 'wpud_display' );
        add_settings_field( 'per_page',      __( 'Members Per Page',           'wp-user-directory' ), array( $this, 'field_per_page'   ), 'wpud-settings', 'wpud_display' );
        add_settings_field( 'show_email',    __( 'Show Email in Directory',    'wp-user-directory' ), array( $this, 'field_show_email' ), 'wpud-settings', 'wpud_display' );
    }

    private function opts(): array { return get_option( 'wpud_options', array() ); }

    public function field_roles(): void {
        $selected = (array) ( $this->opts()['roles_to_show'] ?? array( 'subscriber' ) );
        foreach ( wp_roles()->get_names() as $slug => $name ) {
            printf(
                '<label style="display:block;margin-bottom:4px"><input type="checkbox" name="wpud_options[roles_to_show][]" value="%s" %s> %s</label>',
                esc_attr( $slug ),
                checked( in_array( $slug, $selected, true ), true, false ),
                esc_html( translate_user_role( $name ) )
            );
        }
        echo '<p class="description">' . esc_html__( 'Only users with these roles will appear in the directory.', 'wp-user-directory' ) . '</p>';
    }

    public function field_per_page(): void {
        echo '<input type="number" name="wpud_options[per_page]" value="' . esc_attr( $this->opts()['per_page'] ?? 12 ) . '" min="1" max="100">';
        echo '<p class="description">' . esc_html__( 'Maximum members shown per directory page.', 'wp-user-directory' ) . '</p>';
    }

    public function field_show_email(): void {
        echo '<input type="checkbox" name="wpud_options[show_email]" value="1" ' . checked( '1', $this->opts()['show_email'] ?? '0', false ) . '>';
        echo ' <span class="description">' . esc_html__( 'Tick to display member email addresses publicly in the directory.', 'wp-user-directory' ) . '</span>';
    }

    public function sanitize( $input ): array {
        return array(
            'roles_to_show' => isset( $input['roles_to_show'] ) ? array_map( 'sanitize_text_field', (array) $input['roles_to_show'] ) : array(),
            'per_page'      => absint( $input['per_page'] ?? 12 ),
            'show_email'    => ! empty( $input['show_email'] ) ? '1' : '0',
        );
    }

    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'User Directory Settings', 'wp-user-directory' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'wpud_group' ); do_settings_sections( 'wpud-settings' ); submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function maybe_redirect(): void {
        if ( ! get_transient( 'wpud_activation_redirect' ) ) return;
        delete_transient( 'wpud_activation_redirect' );
        if ( isset( $_GET['activate-multi'] ) ) return;
        wp_safe_redirect( admin_url( 'options-general.php?page=wpud-settings&welcome=1' ) );
        exit;
    }

    public static function get( string $key, $default = '' ) {
        return get_option( 'wpud_options', array() )[ $key ] ?? $default;
    }
}