<?php
/**
 * Department Taxonomy — bridges users and a shadow CPT so WordPress
 * taxonomy UI can be used for user grouping without a third-party plugin.
 * FILE: wp-user-directory/includes/class-wpud-taxonomy.php
 * @package WP_User_Directory
 */
defined( 'ABSPATH' ) || exit;

class WPUD_Taxonomy {

    public function __construct() {
        add_action( 'init', array( $this, 'register_taxonomy' ) );
    }

    public function register_taxonomy(): void {
        // Register a lightweight shadow post type (not public) used only
        // to attach the department taxonomy — this avoids the need for
        // a user-taxonomy bridge plugin.
        register_post_type( 'wpud_member_shadow', array(
            'public'   => false,
            'rewrite'  => false,
            'supports' => array(),
        ) );

        register_taxonomy( 'wpud_department', 'wpud_member_shadow', array(
            'labels' => array(
                'name'          => _x( 'Departments', 'taxonomy general name', 'wp-user-directory' ),
                'singular_name' => _x( 'Department',  'taxonomy singular name', 'wp-user-directory' ),
                'add_new_item'  => __( 'Add New Department', 'wp-user-directory' ),
                'menu_name'     => __( 'Departments',        'wp-user-directory' ),
            ),
            'hierarchical' => true,
            'show_ui'      => true,
            'rewrite'      => false,
            'show_in_rest' => true,
        ) );
    }
}