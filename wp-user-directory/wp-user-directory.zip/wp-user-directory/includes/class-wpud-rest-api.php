<?php
/**
 * REST API: Members Endpoint
 * FILE: wp-user-directory/includes/class-wpud-rest-api.php
 * Routes: GET /wpud/v1/members  |  GET /wpud/v1/members/{id}
 * @package WP_User_Directory
 */
defined( 'ABSPATH' ) || exit;

class WPUD_Rest_Api {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes(): void {
        register_rest_route( 'wpud/v1', '/members', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_members' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'search'     => array( 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'department' => array( 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'per_page'   => array( 'type' => 'integer', 'default' => 12, 'sanitize_callback' => 'absint' ),
                'page'       => array( 'type' => 'integer', 'default' => 1,  'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'wpud/v1', '/members/(?P<id>\d+)', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_member' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function get_members( WP_REST_Request $request ): WP_REST_Response {
        $opts     = get_option( 'wpud_options', array() );
        $roles    = (array) ( $opts['roles_to_show'] ?? array( 'subscriber' ) );
        $per_page = $request->get_param( 'per_page' );
        $page     = $request->get_param( 'page' );

        $args = array(
            'role__in' => $roles,
            'number'   => $per_page,
            'offset'   => ( $page - 1 ) * $per_page,
            'orderby'  => 'display_name',
            'order'    => 'ASC',
            'fields'   => 'ID',
        );

        if ( $s = $request->get_param( 'search' ) ) {
            $args['search']         = '*' . $s . '*';
            $args['search_columns'] = array( 'display_name' );
        }
        if ( $d = $request->get_param( 'department' ) ) {
            $args['meta_query'] = array( array( 'key' => 'wpud_department', 'value' => $d, 'compare' => 'LIKE' ) );
        }

        $user_ids  = get_users( $args );
        $show_email = ! empty( $opts['show_email'] ) && '1' === $opts['show_email'];
        $data      = array();

        foreach ( $user_ids as $id ) {
            $profile = WPUD_User_Meta::get_profile( $id );
            if ( ! $show_email ) unset( $profile['email'] );
            $data[] = $profile;
        }

        $response = new WP_REST_Response( $data, 200 );
        $response->header( 'X-WPUD-Total', count( get_users( array_merge( $args, array( 'number' => -1 ) ) ) ) );
        $response->header( 'X-WPUD-TotalPages', ceil( count( get_users( array_merge( $args, array( 'number' => -1 ) ) ) ) / $per_page ) );
        return $response;
    }

    public function get_member( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $user_id = absint( $request->get_param( 'id' ) );
        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'not_found', __( 'Member not found.', 'wp-user-directory' ), array( 'status' => 404 ) );
        }
        $profile    = WPUD_User_Meta::get_profile( $user_id );
        $opts       = get_option( 'wpud_options', array() );
        if ( empty( $opts['show_email'] ) || '1' !== $opts['show_email'] ) unset( $profile['email'] );
        return new WP_REST_Response( $profile, 200 );
    }
}