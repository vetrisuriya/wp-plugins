<?php
/**
 * Plugin Activation / Deactivation
 * FILE: wp-user-directory/includes/class-wpud-activator.php
 *
 * Required at the ROOT LEVEL of wp-user-directory.php — before register_activation_hook.
 *
 * @package WP_User_Directory
 */
defined( 'ABSPATH' ) || exit;

class WPUD_Activator {

    public static function activate(): void {
        self::check_requirements();
        self::add_capabilities();
        self::set_default_options();
        update_option( 'wpud_version', WPUD_VERSION, false );
        flush_rewrite_rules();
        set_transient( 'wpud_activation_redirect', true, 30 );
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }

    public static function maybe_upgrade(): void {
        $installed = get_option( 'wpud_version', '0.0.0' );
        if ( version_compare( $installed, WPUD_VERSION, '>=' ) ) return;
        self::add_capabilities();
        update_option( 'wpud_version', WPUD_VERSION, false );
    }

    private static function check_requirements(): void {
        if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
            wp_die(
                sprintf( 'WP User Directory requires PHP 8.0+. Your server runs PHP %s.', PHP_VERSION ),
                'PHP Version Error',
                array( 'back_link' => true )
            );
        }
    }

    private static function add_capabilities(): void {
        foreach ( array( 'administrator', 'editor' ) as $role_slug ) {
            $role = get_role( $role_slug );
            if ( $role ) $role->add_cap( 'manage_user_directory' );
        }
    }

    private static function set_default_options(): void {
        add_option( 'wpud_options', array(
            'roles_to_show' => array( 'subscriber', 'author', 'editor' ),
            'per_page'      => 12,
            'show_email'    => '0',
        ), '', false );
    }
}