# WP User Directory Pro — User Guide

## Table of Contents

- [What This Plugin Does](#what-this-plugin-does)
- [After Activation — First Steps](#after-activation--first-steps)
- [Step 1: Configure Settings](#step-1-configure-settings)
- [Step 2: Fill In User Profiles](#step-2-fill-in-user-profiles)
- [Step 3: Add Shortcodes to Pages](#step-3-add-shortcodes-to-pages)
- [Shortcode Reference](#shortcode-reference)
  - [[user_directory]](#user_directory)
  - [[edit_my_profile]](#edit_my_profile)
- [Live Search](#live-search)
- [REST API](#rest-api)
- [FAQ](#faq)

---

## What This Plugin Does

WP User Directory Pro adds a front-end member directory to your WordPress site using your existing user accounts. No separate member database is needed — it reads from WordPress users and adds extra profile fields.

| Feature | Where |
|---|---|
| **Member card grid** | Any page using `[user_directory]` |
| **Live AJAX search** | Inside the `[user_directory]` shortcode |
| **Self-service profile edit** | Any page using `[edit_my_profile]` |
| **Extended profile fields** | User edit screen in wp-admin |

---

## After Activation — First Steps

When you activate the plugin, WordPress redirects you to **Settings → User Directory**.

1. **Choose which roles appear** in the directory (default: Subscriber, Author, Editor)
2. **Set members per page** (default: 12)
3. **Decide whether to show email** addresses publicly (default: off)
4. Click **Save Changes**

---

## Step 1: Configure Settings

Go to **Settings → User Directory**.

| Setting | What it controls |
|---|---|
| **Show Members With Role** | Tick which WordPress roles appear in the directory. Untick Administrator to hide staff-only accounts. |
| **Members Per Page** | How many cards load in the grid. Can be overridden per shortcode. |
| **Show Email in Directory** | When ticked, member email addresses are shown on their card and returned by the REST API. Off by default for privacy. |

---

## Step 2: Fill In User Profiles

Each WordPress user needs their profile fields filled in for the directory to show useful information.

### Admin fills in profiles

1. Go to **Users → All Users**
2. Click **Edit** on any user
3. Scroll down to the **Directory Profile** section (added by the plugin)
4. Fill in:

| Field | Description |
|---|---|
| **Phone Number** | Direct phone — shown only if you add it to the card template |
| **Department** | Team or division (e.g. "Engineering", "Marketing") — shown on the card and searchable |
| **Skills** | Comma-separated list (e.g. "PHP, JavaScript, MySQL") — shown as coloured badges and searchable |
| **LinkedIn URL** | Full URL (e.g. `https://linkedin.com/in/username`) — shown as a button on the card |
| **Location / City** | City or office location (e.g. "London", "Remote") — shown on the card and searchable |
| **Public Bio** | A short summary visible on the member card (first 20 words shown) |

5. Click **Update User**

### Members fill in their own profiles

If you add `[edit_my_profile]` to a page, logged-in members can update their own Department, Skills, LinkedIn, Location, and Bio directly — without needing admin access.

---

## Step 3: Add Shortcodes to Pages

### Create a Team / Directory page

1. Go to **Pages → Add New**
2. Title it "Our Team" or "Member Directory"
3. Add this in the page content:

```
[user_directory]
```

4. Publish and add it to your navigation menu

### Create a Profile Edit page (for logged-in members)

1. Go to **Pages → Add New**
2. Title it "Edit My Profile" or "My Account"
3. Add:

```
[edit_my_profile]
```

4. Publish (you may want to restrict this page to logged-in users only, e.g. using your theme or a membership plugin)

---

## Shortcode Reference

---

### [user_directory]

Displays members as a responsive grid of cards with a live search bar at the top.

**Basic usage:**

```
[user_directory]
```

**All attributes:**

```
[user_directory department="engineering" per_page="12" role="editor" orderby="display_name" order="ASC"]
```

| Attribute | Default | Description |
|---|---|---|
| `department` | *(all departments)* | Show only members whose Department field contains this value. Case-insensitive partial match. |
| `per_page` | From Settings (default 12) | Maximum number of members to show. |
| `role` | From Settings | WordPress role slug(s) to include. Separate multiple roles with a comma. |
| `orderby` | `display_name` | Sort members by: `display_name`, `registered`, `email` |
| `order` | `ASC` | Sort direction: `ASC` (A→Z) or `DESC` (Z→A) |

**Examples:**

```
[user_directory]
```
Full directory using settings from the Settings page.

```
[user_directory department="engineering"]
```
Shows only members in the Engineering department.

```
[user_directory department="marketing" per_page="6"]
```
Shows up to 6 Marketing department members.

```
[user_directory role="editor,author"]
```
Shows only Editors and Authors.

```
[user_directory orderby="registered" order="DESC"]
```
Shows newest members first.

```
[user_directory department="leadership" per_page="10" role="administrator"]
```
Shows only Administrators in the Leadership department, up to 10 cards.

**What appears on each card:**

- Profile photo (WordPress avatar / Gravatar)
- Display name
- Department (if filled in)
- Location (if filled in)
- Skills as coloured badge tags (if filled in)
- Public Bio excerpt — first 20 words (if filled in)
- Email link (only if "Show Email in Directory" is ticked in Settings)
- LinkedIn button (if a URL is filled in)

**Performance note:** Directory results are cached for 30 minutes. If a user updates their profile and you want the directory to refresh immediately, you can clear your caching plugin's cache or wait for the transient to expire.

---

### [edit_my_profile]

Displays a form that lets the currently logged-in user update their own Directory Profile fields. Visitors who are not logged in see a "Please log in" message with a login link instead.

**Basic usage:**

```
[edit_my_profile]
```

**No attributes** — the form always shows the current user's fields.

**Fields shown in the form:**

- Phone Number
- Department
- Skills (comma-separated)
- LinkedIn URL
- Location / City
- Public Bio

**How it works:**

1. The logged-in user fills in the form
2. They click **Save Profile**
3. The form submits via AJAX — no page reload
4. A success message appears: "Profile saved successfully"
5. The directory cache is automatically cleared so changes appear in `[user_directory]` immediately

**Restricting this page to logged-in users:**

The `[edit_my_profile]` shortcode already handles the login check — non-logged-in visitors see a message, not the form. However, if you want the page itself to redirect to the login page before loading, use your theme's redirect functionality or a plugin like "Members" or "Restrict User Access".

---

## Live Search

The `[user_directory]` shortcode includes a live search bar at the top of the directory. No shortcode attribute is needed to enable it.

### What it searches

As the visitor types, the search queries:

- **Display name** — matches partial name (e.g. "john" finds "John Smith")
- **Department** — matches partial department name
- **Skills** — matches any skill in the comma-separated list
- **Location** — matches city or location name

### How it works

- Typing triggers a server-side search after **400ms** of inactivity (debounce)
- Results replace the card grid via AJAX — no page reload
- Pressing **Escape** clears the search and restores the full directory
- Empty search restores the original full directory

### Behaviour

- The search is performed server-side (not filtered client-side) — this means it always queries the live database and respects the roles configured in Settings
- Short queries (1 character) are skipped to avoid excessive AJAX requests
- Results include members matching either the name/login search OR the meta (skills/department/location) search, merged and deduplicated

---

## REST API

The plugin registers two public REST API endpoints for reading member data. No authentication is required. Email is only included if "Show Email in Directory" is enabled in Settings.

### List Members

```
GET /wp-json/wpud/v1/members
```

**Query parameters:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `search` | string | — | Search by display name |
| `department` | string | — | Filter by department (partial match) |
| `per_page` | integer | 12 | Results per page |
| `page` | integer | 1 | Page number |

**Example requests:**

```
GET https://yoursite.com/wp-json/wpud/v1/members
GET https://yoursite.com/wp-json/wpud/v1/members?search=john
GET https://yoursite.com/wp-json/wpud/v1/members?department=engineering&per_page=5
GET https://yoursite.com/wp-json/wpud/v1/members?page=2&per_page=10
```

**Response headers:**
- `X-WPUD-Total` — total number of matching members
- `X-WPUD-TotalPages` — total pages

**Response format:**

```json
[
  {
    "id": 5,
    "display_name": "Jane Smith",
    "avatar": "https://secure.gravatar.com/avatar/...",
    "wpud_phone": "+1 555 0100",
    "wpud_department": "Engineering",
    "wpud_skills": "PHP, JavaScript, MySQL",
    "wpud_linkedin": "https://linkedin.com/in/janesmith",
    "wpud_location": "San Francisco",
    "wpud_public_bio": "Senior developer with 10 years of WordPress experience."
  }
]
```

### Get Single Member

```
GET /wp-json/wpud/v1/members/{id}
```

Replace `{id}` with the WordPress user ID.

**Example:**

```
GET https://yoursite.com/wp-json/wpud/v1/members/5
```

Returns the same format as above but for one member. Returns a 404 error if the user does not exist.

---

## FAQ

**Members are not showing in the directory. What should I check?**

1. Go to **Settings → User Directory** and confirm the correct roles are ticked
2. Check that members have those roles assigned (go to **Users → All Users** and check the Role column)
3. Confirm the members have published (not deleted or blocked) accounts
4. Check that the page has the `[user_directory]` shortcode in the content, not in a widget or theme template

**The live search is not working.**

1. Open your browser's developer console (F12) and check for JavaScript errors on the Network tab
2. Make sure the page has the shortcode in the content (not just a widget) — the plugin only loads its scripts on pages with the shortcode
3. Check that your hosting does not block `admin-ajax.php` requests (some aggressive firewalls do this)

**Changes to a profile are not showing in the directory.**

Directory results are cached for 30 minutes. After saving a profile (either from wp-admin or via `[edit_my_profile]`), the cache is cleared automatically — but if you use an external caching plugin (WP Rocket, LiteSpeed Cache, W3 Total Cache), you may need to also clear that plugin's page cache.

**Can I show the directory to guests (non-logged-in visitors)?**

Yes — `[user_directory]` is public by default. Only `[edit_my_profile]` requires login.

**Can I add custom profile fields?**

The current version supports 6 built-in fields. To add more, edit the `WPUD_User_Meta::get_fields()` array in `class-wpud-user-meta.php` following the same pattern as the existing fields. Each field needs: `label`, `type` (`text`, `url`, `email`, or `textarea`), and `sanitize` (a sanitisation function name).

**Can I filter the directory by multiple departments?**

The current `department` attribute supports one value. For multi-department filtering, use separate `[user_directory]` shortcodes on the same page (one per department) with headings between them.

**How do I control the order of members?**

Use the `orderby` and `order` attributes:

```
[user_directory orderby="registered" order="DESC"]
```

Supported `orderby` values: `display_name` (default), `registered`, `email`.

**Is the REST API private?**

The REST API is public — anyone who knows the URL can query it. Email addresses are excluded unless you enable "Show Email in Directory" in Settings. To add authentication, add a custom `permission_callback` in `class-wpud-rest-api.php`.