/* global WPUDData, jQuery */
( function ( $ ) {
    'use strict';

    var searchTimer;

    /* ── Live search ──────────────────────────────────────────── */
    $( '#wpud-live-search' ).on( 'input keyup', function () {
        clearTimeout( searchTimer );
        var query = $( this ).val().trim();
        var $grid = $( '#wpud-directory-grid' );

        if ( query.length === 0 ) {
            // Reset to full grid — reload page or restore cached HTML.
            // Store original HTML on page load so we can restore it.
            if ( $grid.data( 'original' ) ) {
                $grid.html( $grid.data( 'original' ) ).css( 'opacity', 1 );
            }
            return;
        }

        searchTimer = setTimeout( function () {
            $grid.css( 'opacity', 0.45 );
            $.post( WPUDData.ajax_url, {
                action: 'wpud_live_search',
                nonce:  WPUDData.nonce,
                search: query,
            }, function ( res ) {
                if ( res.success ) {
                    $grid.html( res.data.html ).css( 'opacity', 1 );
                }
            } );
        }, 400 );
    } );

    // Store original grid HTML on page load for reset.
    var $grid = $( '#wpud-directory-grid' );
    if ( $grid.length ) {
        $grid.data( 'original', $grid.html() );
    }

    // Clear search on Escape key.
    $( '#wpud-live-search' ).on( 'keydown', function ( e ) {
        if ( e.key === 'Escape' ) {
            $( this ).val( '' ).trigger( 'input' );
        }
    } );

    /* ── Front-end profile save ────────────────────────────────── */
    $( '#wpud-save-profile' ).on( 'click', function () {
        var $btn     = $( this );
        var $message = $( '#wpud-profile-message' );

        var data = { action: 'wpud_save_profile', nonce: WPUDData.nonce };
        $( '.wpud-field' ).each( function () {
            data[ $( this ).attr( 'name' ) ] = $( this ).val();
        } );

        $btn.prop( 'disabled', true ).text( 'Saving…' );
        $message.hide().removeClass( 'wpud-success wpud-error' );

        $.post( WPUDData.ajax_url, data, function ( res ) {
            $btn.prop( 'disabled', false ).text( 'Save Profile' );
            $message
                .addClass( res.success ? 'wpud-success' : 'wpud-error' )
                .text( res.success ? WPUDData.strings.save_success : WPUDData.strings.save_error )
                .show();
            if ( res.success ) {
                setTimeout( function () { $message.fadeOut(); }, 4000 );
            }
        } );
    } );

}( jQuery ) );