=== WP User Directory Pro ===
Contributors:      vetrisuriya
Donate link:       https://vetrisuriya.in/donate
Tags:              user directory, member directory, staff directory, user profiles, team
Requires at least: 6.0
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      8.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A searchable, filterable member directory for WordPress. Extended profile fields, live AJAX search, front-end profile editing, and a REST API. No page builders required.

== Description ==

**WP User Directory Pro** turns your WordPress user list into a professional, searchable member directory. Use it for team pages, staff listings, member portals, or community directories.

= Core Features =

* **Extended profile fields** — adds Phone, Department, Skills, LinkedIn, Location, and Public Bio to every user's admin profile screen
* **`[user_directory]` shortcode** — displays members in a responsive card grid with live AJAX search
* **Live search** — filters members by name, department, skill, or location as the visitor types (no page reload)
* **`[edit_my_profile]` shortcode** — lets logged-in members update their own profile from the front end
* **Filter by role** — choose which user roles appear in the directory via Settings
* **Filter by department** — show only one department using a shortcode attribute
* **Transient caching** — directory results cached for 30 minutes for performance
* **REST API** — `GET /wp-json/wpud/v1/members` and `GET /wp-json/wpud/v1/members/{id}` for headless use
* **Privacy control** — email addresses hidden by default; toggle in Settings
* **Clean uninstall** — all user meta and options removed when plugin is deleted

= Shortcodes =

**Member directory:**
`[user_directory]`
`[user_directory department="engineering" per_page="12" role="editor"]`

**Front-end profile editor:**
`[edit_my_profile]`

See the full shortcode reference below.

== Installation ==

= Automatic =

1. Go to **Plugins → Add New**
2. Search **WP User Directory Pro**
3. Click **Install Now → Activate**

= Manual =

1. Upload the plugin `.zip` via **Plugins → Add New → Upload Plugin**
2. Click **Activate**

= After Activation =

1. Go to **Settings → User Directory** and choose which roles appear in the directory
2. Edit any user under **Users → All Users** to fill in their Directory Profile fields
3. Add `[user_directory]` to any page
4. Add `[edit_my_profile]` to a "My Profile" page (visible only to logged-in users)

== Frequently Asked Questions ==

= How do I display the member directory? =

Add `[user_directory]` to any page or post. Members with the roles selected in **Settings → User Directory** will appear automatically.

= How do I show only one department? =

Use the `department` attribute:
`[user_directory department="marketing"]`

The value must match the Department field entered on the user's profile exactly (case-insensitive partial match).

= How do I let members edit their own profiles? =

Create a new page, add `[edit_my_profile]`, and publish it. Only logged-in users can see and submit the form — visitors see a "Please log in" message instead.

= Can I choose which user roles appear? =

Yes — go to **Settings → User Directory → Show Members With Role** and tick the roles you want.

= Are email addresses shown publicly? =

No — email is hidden by default. Tick **Show Email in Directory** in Settings to enable it. The REST API also respects this setting.

= How do I use the REST API? =

Send a GET request to `/wp-json/wpud/v1/members`. See the REST API section below.

= What happens to user data when I uninstall? =

All extended profile meta (`wpud_phone`, `wpud_department`, `wpud_skills`, `wpud_linkedin`, `wpud_location`, `wpud_public_bio`) is deleted from every user. Plugin options and transients are also removed. Standard WordPress user accounts are NOT deleted.

== Screenshots ==

1. **Member directory** — responsive card grid with live search bar.
2. **Member card** — avatar, name, department, skills, location, and LinkedIn link.
3. **Admin profile fields** — Directory Profile section added to the user edit screen.
4. **Front-end profile editor** — `[edit_my_profile]` shortcode form.
5. **Settings page** — role selection, per-page count, and email visibility.

== Changelog ==

= 1.0.0 =
* Initial release
* Extended profile fields: phone, department, skills, LinkedIn, location, public bio
* [user_directory] shortcode with grid layout, live AJAX search, department filter
* [edit_my_profile] shortcode for front-end self-service profile editing
* Settings API: role selection, per-page count, email visibility
* REST API: GET /wpud/v1/members and GET /wpud/v1/members/{id}
* Transient caching (30 min) with cache-bust on profile save and settings change
* manage_user_directory capability for Administrator and Editor roles
* Clean uninstall removing all user meta and plugin options

== Upgrade Notice ==

= 1.0.0 =
Initial release. No upgrade steps required.