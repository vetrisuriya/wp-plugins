/* WP User Directory Pro — Admin JS
 * FILE: wp-user-directory/admin/js/wpud-admin.js
 * Currently minimal — placeholder for future admin features
 * such as bulk profile approval or directory column sorting.
 */
( function ( $ ) {
    'use strict';
    // Admin JS initialises here.
} ( jQuery ) );