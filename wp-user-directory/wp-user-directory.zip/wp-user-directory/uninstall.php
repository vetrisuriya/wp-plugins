<?php
/**
 * Uninstall — removes ALL plugin data permanently.
 * FILE: wp-user-directory/uninstall.php
 * Renamed from wpud-uninstall.php → uninstall.php in plugin root.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Must load capabilities class to call ::remove().
require_once __DIR__ . '/includes/class-wpud-capabilities.php';

global $wpdb;

// Remove all extended profile meta from every user.
foreach ( array( 'wpud_phone', 'wpud_department', 'wpud_skills', 'wpud_linkedin', 'wpud_location', 'wpud_public_bio' ) as $key ) {
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $wpdb->delete( $wpdb->usermeta, array( 'meta_key' => $key ) );
}

// Remove plugin options.
delete_option( 'wpud_options' );
delete_option( 'wpud_version' );

// Remove all directory transients.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wpud_%' OR option_name LIKE '_transient_timeout_wpud_%'" );

// Remove capabilities from all roles.
WPUD_Capabilities::remove();