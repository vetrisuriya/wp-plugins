<?php
/**
 * uninstall.php — Runs when the plugin is deleted from the WordPress Plugins screen.
 * FILE: wp-pricing-table/uninstall.php
 *
 * NOTE: This block stores all its data inside post_content as block comment
 * delimiters — there are no custom database tables or options to clean up.
 * The block content remains in posts after plugin deletion (as raw HTML comment
 * text), which is the correct WordPress behaviour for block plugins.
 *
 * If future versions add options or meta, add cleanup here.
 *
 * @package WP_Pricing_Table
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Nothing to clean up for v1.0.0.
// Block data lives in post_content as block delimiter comments.
// Block styles/scripts are registered via block.json and removed automatically.