/**
 * assets/frontend.js — Front-end only JavaScript.
 * FILE: wp-pricing-table/assets/frontend.js
 *
 * Loaded by block.json "viewScript" — only on pages where this block is used.
 * Handles the monthly/annual billing toggle without a page reload.
 *
 * VANILLA JS — no jQuery, no external dependencies.
 */
( function () {
    'use strict';

    document.addEventListener( 'DOMContentLoaded', function () {
        document.querySelectorAll( '.wptb-pricing-table' ).forEach( function ( table ) {
            var toggleBtns    = table.querySelectorAll( '.wptb-toggle-btn' );
            var monthlyPrices = table.querySelectorAll( '.wptb-monthly-price' );
            var annualPrices  = table.querySelectorAll( '.wptb-annual-price' );

            if ( ! toggleBtns.length ) return;

            toggleBtns.forEach( function ( btn ) {
                btn.addEventListener( 'click', function () {
                    var period = this.dataset.period; // 'monthly' or 'annual'

                    // Update active button state + ARIA.
                    toggleBtns.forEach( function ( b ) {
                        var isActive = b.dataset.period === period;
                        b.classList.toggle( 'wptb-active', isActive );
                        b.setAttribute( 'aria-pressed', isActive ? 'true' : 'false' );
                    } );

                    // Toggle price visibility.
                    monthlyPrices.forEach( function ( el ) {
                        el.style.display = period === 'monthly' ? '' : 'none';
                    } );
                    annualPrices.forEach( function ( el ) {
                        el.style.display = period === 'annual' ? '' : 'none';
                    } );
                } );
            } );
        } );
    } );
}() );