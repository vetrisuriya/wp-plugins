/**
 * src/style-helpers.js — Shared utility functions for the Pricing Table block.
 * FILE: wp-pricing-table/src/style-helpers.js
 *
 * Import in edit.js: import { generatePlanId, validateColor, formatPrice } from './style-helpers';
 */

/**
 * Generate a unique plan ID string.
 * @returns {string} e.g. "plan-1719000000000"
 */
export function generatePlanId() {
    return 'plan-' + Date.now();
}

/**
 * Validate a hex color string.
 * @param {string} color - The color to validate.
 * @param {string} fallback - Fallback color if invalid.
 * @returns {string} A valid hex color.
 */
export function validateColor( color, fallback = '#4f46e5' ) {
    if ( typeof color !== 'string' ) return fallback;
    const hex = color.trim();
    return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test( hex ) ? hex : fallback;
}

/**
 * Format a price string for display.
 * @param {string|number} amount - The numeric price.
 * @param {string} currency - The currency symbol.
 * @returns {string} e.g. "$29"
 */
export function formatPrice( amount, currency = '$' ) {
    const num = parseFloat( amount );
    if ( isNaN( num ) ) return currency + '0';
    return currency + ( Number.isInteger( num ) ? num : num.toFixed( 2 ) );
}

/**
 * Calculate annual savings percentage.
 * @param {string|number} monthly - Monthly price.
 * @param {string|number} annual  - Annual price (per month equivalent).
 * @returns {number} Savings percentage rounded to nearest integer.
 */
export function savingsPercent( monthly, annual ) {
    const m = parseFloat( monthly );
    const a = parseFloat( annual );
    if ( ! m || ! a || a >= m ) return 0;
    return Math.round( ( 1 - a / m ) * 100 );
}

/**
 * Build CSS class string for a plan card.
 * @param {boolean} isFeatured - Whether the plan is marked as featured.
 * @param {string}  extraClass - Any additional class.
 * @returns {string} Class string.
 */
export function planCardClass( isFeatured, extraClass = '' ) {
    const classes = [ 'wptb-plan-card' ];
    if ( isFeatured ) classes.push( 'wptb-plan-featured' );
    if ( extraClass ) classes.push( extraClass );
    return classes.join( ' ' );
}

/**
 * Clone a plan object safely (no shared references).
 * @param {Object} plan - The plan to clone.
 * @returns {Object} A deep-cloned plan object.
 */
export function clonePlan( plan ) {
    return {
        ...plan,
        features: [ ...( plan.features || [] ) ],
    };
}