/**
 * src/index.js — Block registration entry point (JSX build source).
 * FILE: wp-pricing-table/src/index.js
 *
 * @wordpress/scripts compiles this file to build/index.js.
 * Run `npm run build` to generate the build directory.
 */
import { registerBlockType, registerBlockStyle, registerBlockVariation } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';

import Edit from './edit';
import save from './save';
import metadata from '../block.json';

// Import the patterns registration (also registered server-side in PHP).
import './patterns';

// Register the block — metadata drives all attributes, supports, and styles.
registerBlockType( metadata.name, {
    edit: Edit,
    save,
} );

// Block Styles — also declared in block.json "styles" array.
// Registering from JS as well ensures they appear immediately in the editor.
registerBlockStyle( 'wp-pricing-table/pricing-table', {
    name:      'cards',
    label:     __( 'Cards', 'wp-pricing-table' ),
    isDefault: true,
} );
registerBlockStyle( 'wp-pricing-table/pricing-table', {
    name:  'bordered',
    label: __( 'Bordered', 'wp-pricing-table' ),
} );
registerBlockStyle( 'wp-pricing-table/pricing-table', {
    name:  'minimal',
    label: __( 'Minimal', 'wp-pricing-table' ),
} );

// Block Variations — pre-configured column count presets.
registerBlockVariation( 'wp-pricing-table/pricing-table', {
    name:        'two-column',
    title:       __( 'Pricing Table — 2 Plans', 'wp-pricing-table' ),
    description: __( 'Side-by-side comparison of two plans.', 'wp-pricing-table' ),
    icon:        'columns',
    attributes:  { columns: 2 },
    isDefault:   true,
} );
registerBlockVariation( 'wp-pricing-table/pricing-table', {
    name:        'three-column',
    title:       __( 'Pricing Table — 3 Plans', 'wp-pricing-table' ),
    description: __( 'Three pricing tiers: Starter, Pro, Enterprise.', 'wp-pricing-table' ),
    icon:        'layout',
    attributes:  { columns: 3 },
} );