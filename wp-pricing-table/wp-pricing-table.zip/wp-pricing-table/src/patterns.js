/**
 * src/patterns.js — Block Patterns registered via JavaScript.
 * FILE: wp-pricing-table/src/patterns.js
 *
 * NOTE: Patterns are also registered in PHP (wp-pricing-table.php) which
 * is the preferred method for the Plugin Directory (server-side, works
 * without JS). This JS file is kept for completeness and for any pattern
 * that needs JS-only block attributes.
 *
 * Import this file in src/index.js: import './patterns';
 */
import { registerBlockPattern, registerBlockPatternCategory } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';

registerBlockPatternCategory( 'wp-pricing-table', {
    label: __( 'Pricing Tables', 'wp-pricing-table' ),
} );

registerBlockPattern( 'wp-pricing-table/startup-saas', {
    title:       __( 'Startup SaaS Pricing — 3 Plans', 'wp-pricing-table' ),
    description: __( 'Starter, Pro, and Enterprise tiers with monthly/annual toggle and savings badge.', 'wp-pricing-table' ),
    categories:  [ 'wp-pricing-table', 'featured' ],
    content:     '<!-- wp:wp-pricing-table/pricing-table {"columns":3,"showToggle":true,"annualSavingsBadge":"Save 20%"} /-->',
} );

registerBlockPattern( 'wp-pricing-table/two-plan-simple', {
    title:       __( 'Simple Free vs Pro', 'wp-pricing-table' ),
    description: __( 'Clean side-by-side layout comparing a free tier with a paid plan.', 'wp-pricing-table' ),
    categories:  [ 'wp-pricing-table' ],
    content:     '<!-- wp:wp-pricing-table/pricing-table {"columns":2,"showToggle":false} /-->',
} );

registerBlockPattern( 'wp-pricing-table/four-plan-enterprise', {
    title:       __( 'Enterprise Pricing — 4 Tiers', 'wp-pricing-table' ),
    description: __( 'Four pricing tiers for enterprise products with annual billing default.', 'wp-pricing-table' ),
    categories:  [ 'wp-pricing-table' ],
    content:     '<!-- wp:wp-pricing-table/pricing-table {"columns":4,"showToggle":true} /-->',
} );