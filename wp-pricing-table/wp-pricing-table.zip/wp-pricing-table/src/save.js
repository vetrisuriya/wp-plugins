/**
 * src/save.js — Save component for the Pricing Table block.
 * FILE: wp-pricing-table/src/save.js
 *
 * Returns null because this is a DYNAMIC BLOCK.
 *
 * A dynamic block uses a PHP render_callback (render.php) to generate
 * its HTML output at page-load time. WordPress stores only the block
 * attributes as a comment delimiter in post_content:
 *
 *   <!-- wp:wp-pricing-table/pricing-table {"columns":3,...} /-->
 *
 * Returning null from save() means:
 *  1. No static HTML is stored in the database.
 *  2. The PHP callback always renders fresh, up-to-date markup.
 *  3. Plugin updates can change the HTML structure without triggering
 *     "This block contains unexpected content" validation errors.
 *  4. Translations work correctly (strings come from PHP at render time).
 *
 * @see render.php
 * @see https://developer.wordpress.org/block-editor/how-to-guides/block-tutorial/creating-dynamic-blocks/
 */
export default function save() {
    return null;
}