/**
 * src/variations.js — Block Variations for the Pricing Table block.
 * FILE: wp-pricing-table/src/variations.js
 *
 * Block Variations appear in the block inserter as pre-configured
 * instances of the block — like choosing a column layout when inserting
 * a Columns block.
 *
 * Import in src/index.js: import './variations';
 * (Already imported via index.js using registerBlockVariation inline.)
 */
import { registerBlockVariation } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';

registerBlockVariation( 'wp-pricing-table/pricing-table', {
    name:        'two-column',
    title:       __( 'Pricing Table — 2 Plans', 'wp-pricing-table' ),
    description: __( 'Side-by-side comparison of two pricing plans.', 'wp-pricing-table' ),
    icon:        'columns',
    attributes:  { columns: 2 },
    isDefault:   true,
} );

registerBlockVariation( 'wp-pricing-table/pricing-table', {
    name:        'three-column',
    title:       __( 'Pricing Table — 3 Plans', 'wp-pricing-table' ),
    description: __( 'Three pricing tiers: Starter, Pro, and Enterprise.', 'wp-pricing-table' ),
    icon:        'layout',
    attributes:  { columns: 3 },
} );

registerBlockVariation( 'wp-pricing-table/pricing-table', {
    name:        'four-column',
    title:       __( 'Pricing Table — 4 Plans', 'wp-pricing-table' ),
    description: __( 'Four pricing tiers for a wide range of customer segments.', 'wp-pricing-table' ),
    icon:        'grid-view',
    attributes:  { columns: 4 },
} );