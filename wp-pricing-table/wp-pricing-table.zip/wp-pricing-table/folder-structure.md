wp-pricing-table/
├── wp-pricing-table.php       ← wpptb-wp-pricing-table.php
├── block.json                 ← wpptb-block.json
├── render.php                 ← wpptb-render.php
├── uninstall.php              ← wpptb-uninstall.php
├── readme.txt                 ← wpptb-readme.txt
├── package.json               ← wpptb-package.json
├── .wp-env.json               ← wpptb-wp-env.json
│
├── build/
│   ├── index.js               ← wpptb-build-index.js
│   ├── index.asset.php        ← wpptb-build-index.asset.php
│   ├── style-index.css        ← wpptb-build-style-index.css
│   └── index.css              ← wpptb-build-index.css
│
├── assets/
│   ├── frontend.js            ← wpptb-assets-frontend.js
│   ├── frontend.css           ← wpptb-assets-frontend.css
│   └── editor.css             ← wpptb-assets-editor.css
│
└── src/
    ├── index.js               ← wpptb-src-index.js
    ├── save.js                ← wpptb-src-save.js
    ├── variations.js          ← wpptb-src-variations.js
    ├── patterns.js            ← wpptb-src-patterns.js
    ├── style-helpers.js       ← wpptb-src-style-helpers.js
    └── edit.js                ← copy from reference .md (JSX version)