<?php
/**
 * Plugin Name:       WP Pricing Table Block
 * Plugin URI:        https://example.com/wp-pricing-table
 * Description:       A Gutenberg pricing table block with monthly/annual toggle, feature lists, highlighted plans, and CTA buttons — ready for the WordPress Plugin Directory.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            Your Name
 * Author URI:        https://example.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-pricing-table
 * Domain Path:       /languages
 *
 * @package WP_Pricing_Table
 */

defined( 'ABSPATH' ) || exit;

define( 'WPTB_VERSION', '1.0.0' );
define( 'WPTB_DIR',     plugin_dir_path( __FILE__ ) );
define( 'WPTB_URL',     plugin_dir_url( __FILE__ ) );

/**
 * Register the block.
 * block.json drives everything: scripts, styles, attributes, supports.
 */
add_action( 'init', 'wptb_register_block' );
function wptb_register_block(): void {
    register_block_type(
        WPTB_DIR . 'block.json',
        array(
            'render_callback' => 'wptb_render_pricing_table',
        )
    );
    wptb_register_patterns();
}

/**
 * Load plugin textdomain for translations.
 */
add_action( 'init', 'wptb_load_textdomain' );
function wptb_load_textdomain(): void {
    load_plugin_textdomain(
        'wp-pricing-table',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );
}

/**
 * Register block patterns.
 */
function wptb_register_patterns(): void {
    register_block_pattern_category(
        'wp-pricing-table',
        array( 'label' => __( 'Pricing Tables', 'wp-pricing-table' ) )
    );

    register_block_pattern(
        'wp-pricing-table/startup-pricing',
        array(
            'title'       => __( 'Startup Pricing — 3 Plans', 'wp-pricing-table' ),
            'description' => __( 'A 3-plan pricing table with Starter, Pro, and Enterprise tiers.', 'wp-pricing-table' ),
            'categories'  => array( 'wp-pricing-table', 'featured' ),
            'content'     => '<!-- wp:wp-pricing-table/pricing-table {"columns":3,"showToggle":true,"annualSavingsBadge":"Save 20%"} /-->',
        )
    );

    register_block_pattern(
        'wp-pricing-table/two-plan-simple',
        array(
            'title'       => __( 'Simple 2-Plan Comparison', 'wp-pricing-table' ),
            'description' => __( 'A clean side-by-side Free vs Pro pricing layout.', 'wp-pricing-table' ),
            'categories'  => array( 'wp-pricing-table' ),
            'content'     => '<!-- wp:wp-pricing-table/pricing-table {"columns":2,"showToggle":false} /-->',
        )
    );
}

/**
 * PHP render callback — server-side render for SEO and dynamic output.
 *
 * @param array    $attributes Block attributes from the editor.
 * @param string   $content    Inner blocks content (empty for this block).
 * @param WP_Block $block      Block object.
 * @return string Rendered HTML output.
 */
function wptb_render_pricing_table( array $attributes, string $content, WP_Block $block ): string {
    ob_start();
    require WPTB_DIR . 'render.php';
    return ob_get_clean();
}