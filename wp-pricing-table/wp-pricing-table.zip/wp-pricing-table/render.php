<?php
/**
 * render.php — Server-side render for the Pricing Table block.
 *
 * This file is loaded by wptb_render_pricing_table() via ob_start() / ob_get_clean().
 * Available variables: $attributes (array), $content (string), $block (WP_Block).
 *
 * WHY A PHP RENDER CALLBACK?
 * ─────────────────────────────────────────────────────────────────────
 * Using render.php (a dynamic block with save() = null) means:
 *   1. Output is always generated at request time — translations work correctly.
 *   2. HTML markup can be updated in a plugin release without "Block recovery"
 *      errors on existing posts (no save() output to validate against).
 *   3. PHP logic (sanitisation, conditional output) stays on the server.
 *   4. Block attributes are stored in post_content as a block delimiter comment.
 * ─────────────────────────────────────────────────────────────────────
 *
 * @package WP_Pricing_Table
 */

defined( 'ABSPATH' ) || exit;

$plans         = $attributes['plans']               ?? array();
$show_toggle   = (bool) ( $attributes['showToggle'] ?? true );
$monthly_lbl   = sanitize_text_field( $attributes['toggleMonthlyLabel'] ?? __( 'Monthly', 'wp-pricing-table' ) );
$annual_lbl    = sanitize_text_field( $attributes['toggleAnnualLabel']  ?? __( 'Annual',  'wp-pricing-table' ) );
$savings_badge = sanitize_text_field( $attributes['annualSavingsBadge'] ?? '' );
$columns       = absint( $attributes['columns'] ?? 2 );

// Build wrapper classes — get_block_wrapper_attributes() merges:
//   • block supports classes (color, spacing, typography from Global Styles)
//   • alignment class (alignwide, alignfull)
//   • custom class names added by the user in the editor
$wrapper_attributes = get_block_wrapper_attributes( array(
    'class'      => 'wptb-pricing-table wptb-cols-' . $columns,
    'data-block' => 'wptb-pricing-table',
) );
?>
<div <?php echo wp_kses_data( $wrapper_attributes ); ?>>

    <?php if ( $show_toggle ) : ?>
    <div class="wptb-toggle-wrap" role="group" aria-label="<?php esc_attr_e( 'Billing period', 'wp-pricing-table' ); ?>">
        <button class="wptb-toggle-btn wptb-active" data-period="monthly" aria-pressed="true">
            <?php echo esc_html( $monthly_lbl ); ?>
        </button>
        <button class="wptb-toggle-btn" data-period="annual" aria-pressed="false">
            <?php echo esc_html( $annual_lbl ); ?>
            <?php if ( $savings_badge ) : ?>
                <span class="wptb-savings-badge"><?php echo esc_html( $savings_badge ); ?></span>
            <?php endif; ?>
        </button>
    </div>
    <?php endif; ?>

    <div class="wptb-plans-grid">
        <?php foreach ( $plans as $plan ) :
            $plan_id      = sanitize_html_class( $plan['id']            ?? 'plan' );
            $name         = sanitize_text_field( $plan['name']          ?? '' );
            $currency     = sanitize_text_field( $plan['currency']      ?? '$' );
            $monthly_px   = sanitize_text_field( $plan['monthlyPrice']  ?? '0' );
            $annual_px    = sanitize_text_field( $plan['annualPrice']   ?? '0' );
            $billing_lbl  = sanitize_text_field( $plan['billingLabel']  ?? __( 'per month', 'wp-pricing-table' ) );
            $description  = wp_kses_post( $plan['description']          ?? '' );
            $features     = array_map( 'sanitize_text_field', (array) ( $plan['features'] ?? array() ) );
            $cta_label    = sanitize_text_field( $plan['ctaLabel']      ?? __( 'Get Started', 'wp-pricing-table' ) );
            $cta_url      = esc_url( $plan['ctaUrl']                    ?? '#' );
            $is_featured  = (bool) ( $plan['featured']                  ?? false );
            $feat_label   = sanitize_text_field( $plan['featuredLabel'] ?? '' );
            $accent_color = sanitize_hex_color( $plan['accentColor']    ?? '#4f46e5' );

            $card_class = 'wptb-plan-card';
            if ( $is_featured ) {
                $card_class .= ' wptb-plan-featured';
            }
        ?>
        <div class="<?php echo esc_attr( $card_class ); ?>"
             id="<?php echo esc_attr( $plan_id ); ?>"
             style="--wptb-accent: <?php echo esc_attr( $accent_color ); ?>">

            <?php if ( $is_featured && $feat_label ) : ?>
            <div class="wptb-featured-badge"><?php echo esc_html( $feat_label ); ?></div>
            <?php endif; ?>

            <div class="wptb-plan-header">
                <h3 class="wptb-plan-name"><?php echo esc_html( $name ); ?></h3>
                <div class="wptb-plan-price">
                    <span class="wptb-currency"><?php echo esc_html( $currency ); ?></span>
                    <span class="wptb-amount wptb-monthly-price"><?php echo esc_html( $monthly_px ); ?></span>
                    <span class="wptb-amount wptb-annual-price" style="display:none;"><?php echo esc_html( $annual_px ); ?></span>
                </div>
                <span class="wptb-billing-label"><?php echo esc_html( $billing_lbl ); ?></span>
                <?php if ( $description ) : ?>
                <p class="wptb-plan-description"><?php echo wp_kses_post( $description ); ?></p>
                <?php endif; ?>
            </div>

            <?php if ( ! empty( $features ) ) : ?>
            <ul class="wptb-features-list" aria-label="<?php esc_attr_e( 'Included features', 'wp-pricing-table' ); ?>">
                <?php foreach ( $features as $feature ) : ?>
                <li class="wptb-feature-item">
                    <span class="wptb-feature-icon" aria-hidden="true">✓</span>
                    <?php echo esc_html( $feature ); ?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>

            <div class="wptb-plan-footer">
                <a href="<?php echo esc_url( $cta_url ); ?>"
                   class="wptb-cta-btn"
                   role="button">
                    <?php echo esc_html( $cta_label ); ?>
                </a>
            </div>

        </div>
        <?php endforeach; ?>
    </div>
</div>