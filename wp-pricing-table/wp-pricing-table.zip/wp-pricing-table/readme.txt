=== WP Pricing Table Block ===
Contributors:      yourname
Tags:              pricing table, gutenberg block, pricing plans, billing toggle, saas
Requires at least: 6.4
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      8.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A Gutenberg pricing table block with monthly/annual toggle, feature lists, highlighted plans, and CTA buttons.

== Description ==

**WP Pricing Table Block** adds a professional pricing table to the WordPress block editor. Perfect for SaaS products, agencies, membership sites, and any service business that needs to display pricing plans.

= Key Features =

* **Monthly / Annual billing toggle** — JavaScript toggle switches between prices without any page reload
* **2 to 4 pricing plans** — Add, remove, and reorder plans directly in the editor sidebar
* **Featured plan highlight** — Mark one plan as "Most Popular" with a coloured badge and border accent
* **Feature lists** — Add unlimited features to each plan with green checkmark icons
* **CTA buttons** — Set unique button text and URL per plan
* **Accent colour per plan** — Personalise each plan's colour using a colour picker
* **Three Block Styles** — Cards (default), Bordered, and Minimal visual variants
* **Two Block Variations** — 2-column and 3-column presets in the block inserter
* **Block Patterns** — Pre-filled "Startup Pricing" and "Simple Free vs Pro" patterns
* **PHP dynamic render** — Server-side output for correct translations and SEO
* **Block Supports** — Colour palette, typography, spacing, and alignment controls from Global Styles
* **Accessible** — ARIA labels on toggle buttons, semantic HTML, colour contrast tested

= No Build Required =

This plugin ships with a pre-compiled `build/` directory. Upload and activate — no `npm install` or build step needed to use the block.

If you want to modify the source code, run `npm install && npm run build` from the plugin folder.

= Block Styles =

Three visual styles selectable from the block toolbar Style panel:
* **Cards** (default) — White cards with shadow and hover lift
* **Bordered** — Outline cards, transparent background
* **Minimal** — Borderless, top accent line only

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload Plugin**
2. In the block editor, search for "Pricing Table" or find it in the Design category
3. Insert the block, then configure your plans in the right sidebar
4. Set plan names, prices, features, and CTA button URLs
5. Choose a Block Style from the toolbar if needed

== Frequently Asked Questions ==

= Do I need to run a build step? =

No. The plugin ships with a pre-compiled `build/index.js` that works immediately after activation. The `src/` folder contains the JSX source files for developers who want to customise the block.

= How do I add more than 2 plans? =

Open the block's Inspector Controls (right sidebar). Scroll to the bottom and click **Add Pricing Plan** to add up to 4 plans. Adjust the Columns setting in the Layout panel to match.

= How does the monthly/annual toggle work? =

Each plan has two price fields: Monthly Price and Annual Price (configured in the sidebar). The toggle button switches which price is displayed using vanilla JavaScript — no page reload. The selected period is not stored; it always defaults to Monthly on page load.

= Can I style the block to match my theme? =

Yes. All colours use CSS custom properties (`--wptb-accent`, `--wptb-bg`, etc.) which can be overridden in your theme's `style.css`. The block also respects Global Styles from the Site Editor if you are using a block theme.

= Does the block work with page caching? =

Yes. The billing toggle is pure client-side JavaScript. The PHP render callback outputs both price values (monthly and annual) simultaneously — the toggle just shows/hides them with CSS `display`. No dynamic server requests are made.

= What happens to my pricing tables if I deactivate the plugin? =

The block data is stored as HTML block delimiters in post_content. If you deactivate the plugin, the block will show a "Block type not found" message in the editor, but the front-end will still display the last-rendered HTML. Reactivating the plugin restores full editor functionality.

== Screenshots ==

1. Pricing Table block with two plans and monthly/annual toggle in the front end.
2. Three-column layout showing the Featured plan badge.
3. Block Styles panel — Cards, Bordered, and Minimal options.
4. Inspector Controls panel — plan name, price, features, and CTA configuration.
5. Block Variations in the block inserter — 2-column and 3-column presets.

== Changelog ==

= 1.0.0 =
* Initial release.
* Block registration via block.json (apiVersion 3).
* 2–4 pricing plan columns with monthly/annual toggle.
* PHP dynamic render callback (render.php).
* Three Block Styles: Cards, Bordered, Minimal.
* Two Block Variations: 2-column, 3-column.
* Block Patterns: Startup Pricing, Simple Free vs Pro.
* ARIA-accessible toggle buttons.
* GPL-2.0-or-later license.

== Upgrade Notice ==

= 1.0.0 =
Initial release. No upgrade steps required.