# WP Pricing Table Block — User Guide

## Table of Contents

- [What This Block Does](#what-this-block-does)
- [No Build Required](#no-build-required)
- [Folder Structure](#folder-structure)
- [Installation](#installation)
- [How to Use the Block](#how-to-use-the-block)
  - [Inserting the Block](#inserting-the-block)
  - [Configuring Plans](#configuring-plans)
  - [Monthly / Annual Toggle](#monthly--annual-toggle)
  - [Featured Plan](#featured-plan)
  - [Block Styles](#block-styles)
  - [Block Alignment](#block-alignment)
- [Inspector Controls Reference](#inspector-controls-reference)
- [Block Patterns](#block-patterns)
- [For Developers — Build from Source](#for-developers--build-from-source)
- [FAQ](#faq)

---

## What This Block Does

The **WP Pricing Table Block** adds a professional, fully configurable pricing table to the WordPress block editor. You can:

- Display 2 to 4 pricing plans side by side
- Enable a Monthly / Annual toggle that switches prices with JavaScript (no page reload)
- Mark one plan as "Most Popular" with a highlighted badge
- Add unlimited feature checkmarks per plan
- Set a CTA button with custom text and URL on each plan
- Choose from three visual styles: Cards, Bordered, and Minimal
- Control columns, typography, spacing, and colours from the editor sidebar

---

## No Build Required

This plugin ships with a pre-compiled `build/` directory. You do **not** need Node.js or npm to use it.

Just upload the plugin folder, activate, and insert the block.

If you are a developer and want to modify the JSX source files in `src/`, see the [For Developers](#for-developers--build-from-source) section.

---

## Folder Structure

```
wp-pricing-table/
├── wp-pricing-table.php      ← Main plugin file — registers block + patterns
├── block.json                ← Block metadata, attributes, styles, supports
├── render.php                ← PHP renders HTML on every page load (dynamic block)
├── uninstall.php             ← Cleanup on plugin deletion
├── readme.txt                ← WordPress Plugin Directory readme
│
├── build/                    ← Pre-compiled. WordPress loads these files.
│   ├── index.js              ← Editor JavaScript (block registration + Edit component)
│   ├── index.asset.php       ← Script dependencies + version hash
│   ├── index.css             ← Editor-only styles
│   └── style-index.css       ← Frontend styles (loaded on public pages too)
│
├── assets/
│   ├── frontend.js           ← Monthly/annual toggle (loaded on front end only)
│   ├── frontend.css          ← Source CSS for frontend styles
│   └── editor.css            ← Source CSS for editor-only styles
│
└── src/                      ← JSX source files (for developers who want to build)
    ├── index.js              ← Block registration entry point
    ├── edit.js               ← Edit component (React/JSX)
    ├── save.js               ← Returns null (dynamic block)
    ├── variations.js         ← Block Variations (2-col, 3-col, 4-col)
    ├── patterns.js           ← Block Patterns registration
    └── style-helpers.js      ← Utility functions (generatePlanId, validateColor, etc.)
```

---

## Installation

1. Download the plugin ZIP file
2. Go to **Plugins → Add New → Upload Plugin** in your WordPress admin
3. Select the ZIP file and click **Install Now**
4. Click **Activate Plugin**
5. Open any post or page in the block editor to start using the block

---

## How to Use the Block

### Inserting the Block

Three ways to insert the block:

**Method 1 — Block Inserter:**
Click the **+** button in the editor, search for `Pricing Table`, and click the block to insert it.

**Method 2 — Block Variations:**
In the inserter, you'll see two pre-configured variations:
- **Pricing Table — 2 Plans** — inserts with 2 columns
- **Pricing Table — 3 Plans** — inserts with 3 columns

**Method 3 — Block Patterns:**
Go to the Patterns tab in the inserter. Under **Pricing Tables** you'll find:
- **Startup SaaS Pricing — 3 Plans** — pre-filled with Starter, Pro, Enterprise
- **Simple Free vs Pro** — 2-column free tier vs paid comparison

---

### Configuring Plans

All plan settings are in the **Inspector Controls** panel on the right side of the editor.

Each plan has its own collapsible panel. Click the plan name to expand it.

**Available fields per plan:**

| Field | Description |
|---|---|
| **Plan Name** | The tier name (e.g. Starter, Pro, Enterprise) |
| **Currency Symbol** | Defaults to `$`. Change to `£`, `€`, or any symbol. |
| **Monthly Price** | Price shown when Monthly is selected in the toggle |
| **Annual Price** | Price shown when Annual is selected (typically lower) |
| **Billing Label** | Text below the price (e.g. "per month", "billed annually") |
| **CTA Button Text** | Label on the call-to-action button |
| **CTA Button URL** | Full URL for the CTA link |
| **Mark as Featured** | Highlights this plan with an accent border and badge |
| **Featured Badge Label** | Text in the badge (e.g. "Most Popular", "Best Value") |
| **Features** | Add/remove feature items with checkmarks |

**Adding features:**
Click **+ Add Feature** at the bottom of a plan panel. Type the feature text. Click **✕** to remove a feature.

**Adding a new plan:**
Scroll to the bottom of the Inspector Controls and open **Add Plan → + Add Pricing Plan**. Then expand the new plan panel to configure it.

**Removing a plan:**
Open the plan panel and click **Remove This Plan** at the bottom (only visible when more than one plan exists).

---

### Monthly / Annual Toggle

The toggle bar sits above the pricing plans. When enabled:

- Visitors see two buttons: Monthly and Annual
- Clicking Annual shows each plan's Annual Price and hides the Monthly Price
- Clicking Monthly reverses this
- No page reload — pure JavaScript

**To configure the toggle:**

Open the **Billing Toggle** panel in Inspector Controls:

| Setting | Description |
|---|---|
| **Show Monthly/Annual Toggle** | Turn the toggle on or off |
| **Monthly Label** | Button text for monthly (default: "Monthly") |
| **Annual Label** | Button text for annual (default: "Annual") |
| **Savings Badge Text** | Small badge next to Annual button (e.g. "Save 20%") — leave blank to hide |

**To set different prices per period:**
Enter the Monthly Price and Annual Price separately in each plan's panel.

---

### Featured Plan

To highlight one plan as recommended:

1. Open the plan panel in Inspector Controls
2. Toggle **Mark as Featured** to ON
3. Set the **Featured Badge Label** (e.g. "Most Popular")

The featured plan gets:
- A coloured badge floating above the card
- A 2px accent-coloured border
- A subtle background tint

Only one plan should be featured at a time for best visual results.

---

### Block Styles

Click the block to select it, then click the **Styles** icon in the block toolbar (looks like a circle half-filled).

| Style | Appearance |
|---|---|
| **Cards** (default) | White cards with drop shadow and hover lift effect |
| **Bordered** | Transparent background with outline border |
| **Minimal** | Borderless, accent top-line only, CTA is an outlined button |

---

### Block Alignment

The block supports Wide and Full alignment. Click the alignment icon in the block toolbar:

- **Default** — fits within the content column
- **Wide** — wider than the content column (requires theme support)
- **Full** — full viewport width

---

## Inspector Controls Reference

| Panel | Setting | Type | Description |
|---|---|---|---|
| Layout | **Number of Columns** | Range (2–4) | How many plans to show per row |
| Billing Toggle | **Show Toggle** | On/Off | Show or hide the Monthly/Annual buttons |
| Billing Toggle | **Monthly Label** | Text | Button label for monthly pricing |
| Billing Toggle | **Annual Label** | Text | Button label for annual pricing |
| Billing Toggle | **Savings Badge Text** | Text | Small pill next to Annual button |
| Each Plan | **Plan Name** | Text | Tier display name |
| Each Plan | **Currency Symbol** | Text | `$`, `£`, `€`, etc. |
| Each Plan | **Monthly Price** | Text | Number shown in Monthly period |
| Each Plan | **Annual Price** | Text | Number shown in Annual period |
| Each Plan | **Billing Label** | Text | e.g. "per month" |
| Each Plan | **CTA Button Text** | Text | Button label |
| Each Plan | **CTA Button URL** | URL | Button destination |
| Each Plan | **Mark as Featured** | Toggle | Highlights this plan visually |
| Each Plan | **Featured Badge Label** | Text | Badge text when featured |
| Each Plan | **Features** | List | Add/remove feature items |
| Add Plan | **+ Add Pricing Plan** | Button | Appends a new default plan |
| Colour | Background, Text | Palette | From Global Styles colour palette |
| Typography | Font Size, Line Height | Controls | From theme typography scale |
| Dimensions | Padding, Margin | Spacing | Theme spacing scale |

---

## Block Patterns

Block Patterns are pre-filled versions of the block available in the Patterns tab of the block inserter under **Pricing Tables**.

| Pattern | Columns | Toggle |
|---|---|---|
| **Startup SaaS Pricing — 3 Plans** | 3 | On, with "Save 20%" badge |
| **Simple Free vs Pro** | 2 | Off |
| **Enterprise Pricing — 4 Tiers** | 4 | On |

---

## For Developers — Build from Source

If you want to customise the block's edit experience or add features, modify the `src/` files and rebuild:

### Requirements
- Node.js 18+ 
- npm 8+

### Setup

```bash
# Navigate to the plugin folder
cd wp-content/plugins/wp-pricing-table

# Install dependencies (~150MB, node_modules)
npm install

# Build for production (output → build/)
npm run build

# Watch mode for development (rebuilds on every file save)
npm run start
```

### Source File Overview

| File | What to edit here |
|---|---|
| `src/edit.js` | The editor interface — controls, RichText fields, canvas preview |
| `src/save.js` | Always returns null (dynamic block — do not add JSX here) |
| `src/variations.js` | Add more column presets |
| `src/patterns.js` | Add more pre-filled pattern content |
| `src/style-helpers.js` | Shared JS utility functions |
| `assets/frontend.css` | Frontend styles → compiled to `build/style-index.css` |
| `assets/editor.css` | Editor-only styles → compiled to `build/index.css` |
| `render.php` | PHP HTML output — update this to change the front-end markup |
| `block.json` | Add new attributes, change supports, add new block styles |

### Local Environment with @wp-env

```bash
# Install @wordpress/env globally
npm install -g @wordpress/env

# Start local WordPress (Docker required)
wp-env start

# Site: http://localhost:8888
# Admin: http://localhost:8888/wp-admin (user: admin / pass: password)
```

---

## FAQ

**The block isn't showing in the editor.**
Confirm the plugin is activated. Check **Plugins → Installed Plugins**. If activated, check for a PHP error in `debug.log` — enable `WP_DEBUG` and `WP_DEBUG_LOG` in `wp-config.php`.

**The toggle doesn't work on the front end.**
Check that `assets/frontend.js` is in the plugin folder. Open the browser console (F12) and look for JS errors. Confirm your theme isn't blocking scripts with a custom `wp_enqueue_scripts` override.

**The block shows "Block type not found" after deactivation.**
This is expected. Reactivate the plugin to restore full editor functionality. The last-rendered HTML remains visible on the front end even while deactivated.

**I changed prices but the block shows old prices.**
If you're using a page cache plugin (WP Rocket, W3 Total Cache), clear the cache after saving the post. The PHP render callback always generates fresh output; only the page cache can serve stale content.

**How do I change the accent colour?**
Each plan has its own accent colour set via a CSS custom property (`--wptb-accent`). To change the default for all plans, override the CSS variable in your theme's `style.css`:
```css
.wptb-pricing-table {
    --wptb-accent: #e11d48; /* Your brand colour */
}
```

**Can I add more than 4 plans?**
The RangeControl is capped at 4 columns. To support more, change `max: 4` to `max: 6` in `src/edit.js` (or `build/index.js`) and add a responsive CSS breakpoint in `assets/frontend.css`.