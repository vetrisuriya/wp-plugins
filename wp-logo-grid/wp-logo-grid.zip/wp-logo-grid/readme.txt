=== WP Logo / Client Grid Block ===
Contributors:      yourname
Tags:              logo grid, client logos, sponsor logos, trusted by, gutenberg block
Requires at least: 6.4
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      8.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Responsive logo grid with grayscale hover effect, per-logo links, and MediaUpload bulk selection.

== Description ==

**WP Logo / Client Grid Block** adds a professional "Trusted by" or "Our Clients" logo section to any WordPress page.

= Key Features =

* **MediaUpload bulk selection** — select multiple logos at once from the Media Library
* **Grayscale hover reveal** — logos appear desaturated and reveal full color on hover (CSS only, no JS)
* **Equal-height grid** — CSS `max-height` via custom property ensures all logos are the same visual height regardless of aspect ratio
* **Per-logo links** — each logo can have its own URL and an accessible link label for screen readers
* **Move left / right** — reorder logos without leaving the editor
* **2–8 columns** — configurable via sidebar or toolbar dropdown
* **4 Block Styles** — Flat (default), Boxed Cards, Dark Background, Bordered Row
* **Block Transforms** — convert from Gallery or Image blocks; convert back to Gallery
* **4 Block Patterns** — Six Sponsors, As Seen In, Trusted By, Boxed Partners
* **Alt text warning** — editor warning when logos are missing alt text
* **`rel="noopener noreferrer"`** — safe external links when "Open in new tab" is enabled
* **No build step required** — pre-compiled `build/` directory included

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload Plugin**
2. In the block editor, search for **Logo Grid**
3. Insert — an empty placeholder appears with an "Add Logos" button
4. Click the button to open the Media Library; select multiple logos (Shift+click)
5. Logos appear in the grid. Click any logo to set its link in the sidebar.

== Frequently Asked Questions ==

= How do I add multiple logos at once? =
Click the "Add Logos" button or the "+ Add More Logos" button below the grid. In the Media Library, click logos while holding Shift (for a range) or Ctrl/Cmd (for individual selection) to select multiple. All selected logos are added to the grid at once.

= How do I reorder logos? =
Click a logo to select it, then use the ← → buttons that appear above it. Alternatively, remove and re-add logos in the desired order.

= How do I add a link to a logo? =
Click the logo in the editor to select it (blue outline). The right sidebar opens a "Logo N Link" panel where you can enter the URL, an accessible link label, and alt text.

= What is the "Accessible Link Label"? =
Screen readers announce link text. Since the logo image is all that's inside the link element, a text label tells screen readers what the link does — for example, "Visit Acme Inc website". Always fill this in for linked logos.

== Changelog ==

= 1.0.0 =
* Initial release. MediaUpload multi-select. Grayscale hover CSS effect. Per-logo links. 4 Block Styles. Block Transforms from Gallery and Image blocks. 4 Block Patterns. rel="noopener noreferrer" for external links.