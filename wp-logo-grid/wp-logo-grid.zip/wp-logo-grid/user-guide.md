# WP Logo / Client Grid Block — User Guide

## Table of Contents

- [Why This Block Exists](#why-this-block-exists)
- [Folder Structure](#folder-structure)
- [Installation](#installation)
- [How to Use the Block](#how-to-use-the-block)
  - [Inserting the Block](#inserting-the-block)
  - [Adding Logos](#adding-logos)
  - [Adding Links per Logo](#adding-links-per-logo)
  - [Reordering Logos](#reordering-logos)
  - [Removing a Logo](#removing-a-logo)
  - [Columns & Logo Height](#columns--logo-height)
  - [Grayscale Hover Effect](#grayscale-hover-effect)
- [Inspector Controls Reference](#inspector-controls-reference)
- [Block Styles](#block-styles)
- [Block Patterns](#block-patterns)
- [Block Transforms](#block-transforms)
- [Accessibility Features](#accessibility-features)
- [For Developers — Build from Source](#for-developers--build-from-source)
- [FAQ](#faq)

---

## Why This Block Exists

Agency websites, SaaS landing pages, nonprofits (sponsors), event pages (partners), and press pages (As Seen In) all need a logo grid. Without this block, editors use the Gallery block or Image blocks in a row — resulting in:

- Logos cropped to squares (Gallery block uses square crops)
- No equal-height normalisation — logos of different sizes look mismatched
- No grayscale effect — logos visually compete with the page content
- No per-logo custom URL (Gallery block links to media file, not a custom URL)
- No column control tuned for logo grids
- No "hover to reveal colour" — a premium feature in paid plugins

This block solves all of it. Equal-height display via CSS `max-height` custom property, optional grayscale-to-colour hover in pure CSS (no JavaScript), per-logo links with accessible labels, and bulk MediaUpload.

---

## Folder Structure

```
wp-logo-grid/
├── wp-logo-grid.php              ← wplg-wp-logo-grid.php  (standalone + 4 patterns)
├── block.json                    ← wplg-block.json        (at root — FIXED)
├── uninstall.php                 ← wplg-uninstall.php
├── readme.txt                    ← wplg-readme.txt
├── package.json                  ← wplg-package.json
│
├── build/
│   ├── index.js                  ← wplg-build-index.js    (all bugs fixed)
│   ├── index.asset.php           ← wplg-build-index.asset.php
│   ├── style-index.css           ← wplg-build-style-index.css
│   └── editor.css                ← wplg-build-editor.css
│
└── src/
    ├── index.js                  ← wplg-src-index.js      (registerBlockStyle FIXED)
    ├── edit.js                   ← from reference .md     (remove uuid import)
    ├── save.js                   ← wplg-src-save.js
    ├── transforms.js             ← wplg-src-transforms.js (getBlockTransforms removed)
    ├── style.scss                ← from reference .md
    └── editor.scss               ← from reference .md
```

---

## Installation

1. Arrange all files in the structure above
2. ZIP the `wp-logo-grid/` folder
3. Go to **Plugins → Add New → Upload Plugin**
4. Upload and click **Install Now → Activate Plugin**

No `npm install` needed — the `build/` directory is pre-compiled.

---

## How to Use the Block

### Inserting the Block

1. Click the **+** inserter and search for **Logo Grid**
2. Insert — a placeholder appears with an "Add Logos" button
3. Or browse the Patterns tab → **Logo Grid** category for pre-filled layouts

### Adding Logos

**First time:** Click the **Add Logos** button in the placeholder.

**After logos are added:** Click the **+ Add More Logos** button below the grid.

Both buttons open the WordPress Media Library. To add multiple logos at once:
- Hold **Shift** and click to select a range of images
- Hold **Ctrl** (Windows) or **Cmd** (Mac) and click to select individual images
- Click **Select** to add all selected images to the grid

Logos are added in the order you selected them. They can be reordered after insertion.

### Adding Links per Logo

1. Click any logo in the editor canvas — it gets a blue selection border
2. The right sidebar opens a **"Logo N Link"** panel
3. Fill in:
   - **URL** — the full link URL (e.g. `https://acme.com`)
   - **Accessible Link Label** — describes the link for screen readers (e.g. `"Visit Acme Inc website"`)
   - **Alt Text** — describes the image (e.g. `"Acme Inc logo"`)
4. A 🔗 icon appears on the logo in the editor to confirm the link is set

### Reordering Logos

Hover over a logo — the ← → buttons appear in the top-right corner.
- Click **←** to move the logo one position to the left
- Click **→** to move the logo one position to the right

### Removing a Logo

Hover over a logo — the **✕** button appears. Click it to remove the logo from the grid. This does not delete the image from the Media Library.

### Columns & Logo Height

**Columns (2–8):** Inspector Controls → Grid Settings → Columns slider.
Or click the grid icon in the block toolbar for a quick column dropdown.

**Logo Height:** Inspector Controls → Grid Settings → Logo Height (px). All logos scale to this maximum height, preserving their aspect ratio. No logo will be taller than this value.

### Grayscale Hover Effect

Inspector Controls → Hover Effect:
- **Grayscale logos** — converts all logos to black-and-white at 65% opacity
- **Enable hover color reveal** (appears when Grayscale is on) — reveals full colour when a visitor hovers over or focuses a logo

The grayscale effect is **pure CSS** — no JavaScript. It uses `filter: grayscale(100%)` and `transition: filter 0.3s ease`.

---

## Inspector Controls Reference

| Panel | Setting | Default | Description |
|---|---|---|---|
| Grid Settings | **Columns** | 5 | Logos per row. Range: 2–8. Responsive on mobile. |
| Grid Settings | **Logo Height (px)** | 60 | Maximum logo height. All logos scale to match. |
| Grid Settings | **Show Border Between Logos** | Off | Adds subtle border/padding around each logo cell |
| Grid Settings | **Open links in new tab** | On | Adds `target="_blank"` + `rel="noopener noreferrer"` |
| Hover Effect | **Grayscale logos** | On | CSS grayscale filter on all logos |
| Hover Effect | **Enable hover color reveal** | On | Color reveals on hover (visible when Grayscale is on) |
| Logo N Link | **URL** | "" | Link URL for the selected logo |
| Logo N Link | **Accessible Link Label** | "" | Screen reader label for the link |
| Logo N Link | **Alt Text** | from media | Alt text for the image |

---

## Block Styles

Select the block and click the **Styles** icon in the block toolbar.

| Style | Appearance |
|---|---|
| **Flat** (default) | No background, no card — logos sit directly on the page background |
| **Boxed Cards** | Each logo in a white rounded card with a soft shadow (`0 2px 12px rgba(0,0,0,.06)`) |
| **Dark Background** | Entire grid on a `#1a1a2e` dark background; logos become white silhouettes via `filter: brightness(0) invert(1)` |
| **Bordered Row** | Thin top and bottom borders only — clean horizontal divider effect |

---

## Block Patterns

Pre-filled templates in the Patterns tab under **Logo Grid**:

| Pattern | Columns | Height | Grayscale |
|---|---|---|---|
| **Six Sponsor Logos** | 6 | 50px | On with hover reveal |
| **As Seen In — Press Logos** | 5 | 40px | On, no hover |
| **Trusted By — Client Logos** | 5 | 60px | On with hover reveal |
| **Partner Logos — Boxed Cards** | 4 | 70px | Off |

All patterns have empty `logos: []` — insert the pattern then click "Add Logos" to fill in your own logos.

---

## Block Transforms

### Gallery block → Logo Grid

Select a **Gallery block** in the editor. Click **Transform to → Logo Grid** in the block toolbar.

All gallery images become logo items. The gallery's `columns` setting is preserved. Image alt text and link URLs are carried over.

### Image blocks (multi-select) → Logo Grid

Select multiple **Image blocks** simultaneously (Shift+click in List View). Click **Transform to → Logo Grid**.

Each image becomes a logo. The image href (link) maps to the logo's `linkUrl`.

### Logo Grid → Gallery block

Select the Logo Grid block. Click **Transform to → Gallery** to convert all logos back into a standard gallery. Useful if you need caption editing or a lightbox.

---

## Accessibility Features

| Feature | Implementation |
|---|---|
| **`role="list"` on grid** | CSS `display: grid` removes native list semantics in Safari. Explicit ARIA role restores them. |
| **`role="listitem"` per logo** | Paired with `role="list"` — each logo is semantically a list item |
| **Accessible link label** | Every linked logo has `aria-label` on the `<a>` element — screen readers announce the label, not the empty image alt |
| **`rel="noopener noreferrer"`** | All external links use both attributes — prevents reverse tabnapping |
| **Missing alt text warning** | Editor shows a non-dismissible warning when any logo lacks alt text |
| **`loading="lazy"` + `decoding="async"`** | Logos don't block page render; browser decodes them off the main thread |
| **`width` + `height` attributes** | Prevents Cumulative Layout Shift (CLS) — browser reserves correct space before images load |
| **Focus-within for hover reveal** | Keyboard users who tab to a linked logo also trigger the colour reveal (`:focus-within` selector) |

---

## For Developers — Build from Source

### Requirements
- Node.js 18+, npm 8+

### Setup

```bash
cd wp-content/plugins/wp-logo-grid
npm install
npm run build    # → build/index.js, build/style-index.css, build/editor.css
npm run start    # Watch mode
```

### Fixes to apply to `src/edit.js` before building

Copy `edit.js` from `WP_Block_10_Logo_Grid.md`, then:

**Remove the unused uuid import:**
```js
// ❌ Remove this line entirely
import { v4 as uuidv4 } from 'uuid';
```

**Update all text domain references:**
```js
// Change from: 'my-blocks'
// Change to:   'wp-logo-grid'
__( 'Add Logos', 'wp-logo-grid' )
```

**Update block name in any hardcoded references.**

### CSS Custom Properties

The block uses CSS custom properties set on the wrapper element in `save()`:

```js
style: {
    '--logo-columns': columns,    // e.g. 5 → used by grid-template-columns
    '--logo-height':  logoHeight + 'px',  // e.g. "60px" → used by max-height
}
```

To customise, override in your theme's `style.css`:
```css
.wp-block-wp-logo-grid-logo-grid {
    --logo-height: 80px;   /* taller logos */
}
```

---

## FAQ

**The grayscale effect doesn't work.**
Confirm `build/style-index.css` is loading. The wrapper must have `class="has-grayscale"`. If it does but the effect doesn't appear, check if your theme has a CSS reset that overrides `filter`. Also confirm the `.logo-image` class is on the `<img>` element.

**The Block Styles panel is empty.**
This was Bug 1 — `registerBlockStyle()` called with an array. Use `wplg-build-index.js` (pre-compiled, fixed). Or apply the fix to `src/index.js` and rebuild.

**Clicking "Add Logos" doesn't open the Media Library.**
This is usually a permissions issue. `MediaUploadCheck` requires the current user to have the `upload_files` capability. Editors (not Subscribers) should have this capability. Check **Users → [user] → Role**.

**The grid shows logos in one column instead of the configured number.**
Confirm `build/style-index.css` is loading. The CSS uses `grid-template-columns: repeat( var(--logo-columns, 5), 1fr )`. If the CSS file is missing, the grid falls back to a single column. Also check DevTools for the `--logo-columns` custom property on the wrapper element.

**I changed save.js and now existing logo grid blocks show a recovery error.**
Any change to `save()` output breaks block validation for existing posts. Add a block deprecation. See: https://developer.wordpress.org/block-editor/reference-guides/block-api/block-deprecation/

**Logos look distorted/stretched on mobile.**
Confirm `max-width: 100%` is on `.logo-image` — this is in the compiled CSS. The responsive breakpoints cap columns at 4 (≤900px), 3 (≤600px), and 2 (≤400px). If logos still stretch, check if a theme's `img` reset is overriding `width: auto`.