<?php
/**
 * Plugin Name:       WP Logo / Client Grid Block
 * Plugin URI:        https://example.com/wp-logo-grid
 * Description:       A responsive logo grid block with grayscale hover effect, per-logo links, equal-height display, and MediaUpload bulk selection. Perfect for "Trusted By", "Our Clients", "Sponsors", and "As Seen In" sections.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            Your Name
 * Author URI:        https://example.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-logo-grid
 * Domain Path:       /languages
 *
 * @package WP_Logo_Grid
 */

defined( 'ABSPATH' ) || exit;

define( 'WPLG_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPLG_URL', plugin_dir_url( __FILE__ ) );
define( 'WPLG_VER', '1.0.0' );

/**
 * Register the block.
 *
 * Static block (save() returns HTML, not null) — no render_callback.
 * WordPress reads all script/style asset paths from block.json.
 *
 * block.json is at the PLUGIN ROOT so all file:// paths resolve correctly:
 *   "editorScript": "file:./build/index.js"  → wp-logo-grid/build/index.js ✅
 *   "style":        "file:./build/style-index.css"                          ✅
 */
add_action( 'init', 'wplg_register_block' );
function wplg_register_block(): void {
    register_block_type( WPLG_DIR . 'block.json' );

    load_plugin_textdomain(
        'wp-logo-grid',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );
}

/**
 * Register Block Patterns.
 *
 * Patterns registered in PHP (not JS) so they appear in the
 * pattern library without waiting for editor JS to load.
 * Logo arrays are empty — editors add their own logos after inserting.
 */
add_action( 'init', 'wplg_register_patterns' );
function wplg_register_patterns(): void {
    register_block_pattern_category(
        'wp-logo-grid',
        array( 'label' => __( 'Logo Grid', 'wp-logo-grid' ) )
    );

    register_block_pattern(
        'wp-logo-grid/six-sponsors',
        array(
            'title'       => __( 'Six Sponsor Logos', 'wp-logo-grid' ),
            'description' => __( 'A 6-column sponsor logo grid with grayscale hover color reveal.', 'wp-logo-grid' ),
            'categories'  => array( 'wp-logo-grid', 'featured' ),
            'content'     => '<!-- wp:wp-logo-grid/logo-grid {"columns":6,"logoHeight":50,"grayscale":true,"hoverEffect":true,"logos":[]} /-->',
        )
    );

    register_block_pattern(
        'wp-logo-grid/press-logos',
        array(
            'title'       => __( 'As Seen In — Press Logos', 'wp-logo-grid' ),
            'description' => __( 'Press/media logo row for credibility sections.', 'wp-logo-grid' ),
            'categories'  => array( 'wp-logo-grid' ),
            'content'     => '<!-- wp:group {"align":"wide","className":"press-section"} -->
<div class="wp-block-group alignwide press-section">
<!-- wp:heading {"textAlign":"center","level":4} -->
<h4 class="wp-block-heading has-text-align-center">' . esc_html__( 'As seen in', 'wp-logo-grid' ) . '</h4>
<!-- /wp:heading -->
<!-- wp:wp-logo-grid/logo-grid {"columns":5,"logoHeight":40,"grayscale":true,"hoverEffect":false,"logos":[]} /-->
</div>
<!-- /wp:group -->',
        )
    );

    register_block_pattern(
        'wp-logo-grid/trusted-by',
        array(
            'title'       => __( 'Trusted By — Client Logos', 'wp-logo-grid' ),
            'description' => __( 'Full-width "Trusted by" section with heading and logo grid.', 'wp-logo-grid' ),
            'categories'  => array( 'wp-logo-grid' ),
            'content'     => '<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}}} -->
<div class="wp-block-group alignfull" style="padding-top:3rem;padding-bottom:3rem">
<!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="wp-block-heading has-text-align-center">' . esc_html__( 'Trusted by leading companies', 'wp-logo-grid' ) . '</h3>
<!-- /wp:heading -->
<!-- wp:wp-logo-grid/logo-grid {"columns":5,"logoHeight":60,"grayscale":true,"hoverEffect":true,"showBorder":false,"logos":[]} /-->
</div>
<!-- /wp:group -->',
        )
    );

    register_block_pattern(
        'wp-logo-grid/boxed-partners',
        array(
            'title'       => __( 'Partner Logos — Boxed Cards', 'wp-logo-grid' ),
            'description' => __( 'Partner logos displayed in white boxed cards, 4 columns.', 'wp-logo-grid' ),
            'categories'  => array( 'wp-logo-grid' ),
            'content'     => '<!-- wp:wp-logo-grid/logo-grid {"columns":4,"logoHeight":70,"grayscale":false,"hoverEffect":false,"className":"is-style-boxed","logos":[]} /-->',
        )
    );
}