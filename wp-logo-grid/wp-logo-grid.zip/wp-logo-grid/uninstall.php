<?php
/**
 * uninstall.php — Runs on plugin deletion.
 * Logo grid data lives in post_content (block comment delimiters).
 * No custom DB tables or options in v1.0.0.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;