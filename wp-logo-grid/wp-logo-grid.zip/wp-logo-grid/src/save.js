/**
 * src/save.js — Logo Grid static save component.
 * FILE: wp-logo-grid/src/save.js
 *
 * Static save() — no PHP render_callback needed.
 * All logo data is stored in attributes; HTML is generated at edit time.
 * React JSX attributes are auto-escaped — no manual esc_url() needed.
 */
import { useBlockProps } from '@wordpress/block-editor';

export default function save( { attributes } ) {
    const { logos, columns, logoHeight, grayscale, hoverEffect, showBorder, openInNewTab } = attributes;

    if ( !logos?.length ) return null;

    const blockProps = useBlockProps.save( {
        className: [
            grayscale                ? 'has-grayscale'    : '',
            hoverEffect && grayscale ? 'has-hover-reveal' : '',
            showBorder               ? 'has-border'       : '',
        ].filter(Boolean).join(' '),
        style: { '--logo-columns': columns, '--logo-height': `${ logoHeight }px` },
    } );

    return (
        <div { ...blockProps }>
            <div className="logo-grid" role="list">
                { logos.map( ( logo, index ) => {
                    const img = (
                        <img
                            src={ logo.url }
                            alt={ logo.alt || '' }
                            className="logo-image"
                            width={ logo.width  || undefined }
                            height={ logo.height || undefined }
                            loading="lazy"
                            decoding="async"
                        />
                    );
                    return (
                        <div key={ `${ logo.id }-${ index }` } className="logo-item" role="listitem">
                            { logo.linkUrl ? (
                                <a
                                    href={ logo.linkUrl }
                                    className="logo-link"
                                    aria-label={ logo.linkLabel || logo.alt || undefined }
                                    target={ openInNewTab ? '_blank' : undefined }
                                    rel={ openInNewTab ? 'noopener noreferrer' : undefined }
                                >
                                    { img }
                                </a>
                            ) : img }
                        </div>
                    );
                } ) }
            </div>
        </div>
    );
}