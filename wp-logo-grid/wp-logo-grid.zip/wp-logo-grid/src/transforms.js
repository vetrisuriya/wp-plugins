/**
 * src/transforms.js — Block transforms for Logo Grid.
 * FILE: wp-logo-grid/src/transforms.js
 *
 * BUG FIX: Reference imported getBlockTransforms from '@wordpress/blocks'
 * but never used it. Import removed.
 *
 * FROM: core/gallery → Logo Grid (maps gallery images to logos)
 * FROM: core/image (multi-select) → Logo Grid
 * TO:   Logo Grid → core/gallery
 */
import { createBlock } from '@wordpress/blocks'; // getBlockTransforms removed — unused

const transforms = {
    from: [
        {
            type:   'block',
            blocks: [ 'core/gallery' ],
            transform( { images, columns } ) {
                const logos = ( images || [] ).map( ( img ) => ( {
                    id:        img.id      || 0,
                    url:       img.url     || img.fullUrl || '',
                    alt:       img.alt     || '',
                    linkUrl:   img.link    || '',
                    linkLabel: '',
                    width:     img.width   || 0,
                    height:    img.height  || 0,
                } ) );
                return createBlock( 'wp-logo-grid/logo-grid', { logos, columns: columns || 5 } );
            },
        },
        {
            type:         'block',
            blocks:       [ 'core/image' ],
            isMultiBlock: true,
            transform( images ) {
                const logos = images.map( ( img ) => ( {
                    id:        img.attributes.id     || 0,
                    url:       img.attributes.url    || '',
                    alt:       img.attributes.alt    || '',
                    linkUrl:   img.attributes.href   || '',
                    linkLabel: '',
                    width:     img.attributes.width  || 0,
                    height:    img.attributes.height || 0,
                } ) );
                return createBlock( 'wp-logo-grid/logo-grid', { logos } );
            },
        },
    ],
    to: [
        {
            type:   'block',
            blocks: [ 'core/gallery' ],
            transform( { logos, columns } ) {
                return createBlock( 'core/gallery', {
                    images:  logos.map( ( l ) => ( { id: l.id, url: l.url, alt: l.alt, link: l.linkUrl } ) ),
                    columns: columns,
                } );
            },
        },
    ],
};

export default transforms;