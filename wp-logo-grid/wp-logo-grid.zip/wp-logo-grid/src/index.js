/**
 * src/index.js — Logo Grid block entry point (JSX source).
 * FILE: wp-logo-grid/src/index.js
 * Compiled to: build/index.js
 *
 * BUG FIX: registerBlockStyle( name, [array] ) → individual calls.
 */
import { registerBlockType, registerBlockStyle } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import Edit       from './edit';
import save       from './save';
import transforms from './transforms';
import metadata   from '../block.json';
import './style.scss';
import './editor.scss';

/* ── Block Styles — FIXED: one call per style, NOT an array ─────── */
registerBlockStyle( 'wp-logo-grid/logo-grid', { name: 'flat',     label: __('Flat',           'wp-logo-grid'), isDefault: true } );
registerBlockStyle( 'wp-logo-grid/logo-grid', { name: 'boxed',    label: __('Boxed Cards',    'wp-logo-grid') } );
registerBlockStyle( 'wp-logo-grid/logo-grid', { name: 'branded',  label: __('Dark Background','wp-logo-grid') } );
registerBlockStyle( 'wp-logo-grid/logo-grid', { name: 'bordered', label: __('Bordered Row',   'wp-logo-grid') } );

registerBlockType( metadata.name, { edit: Edit, save, transforms } );