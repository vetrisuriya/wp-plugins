wp-logo-grid/
├── wp-logo-grid.php         ← wplg-wp-logo-grid.php
├── block.json               ← wplg-block.json
├── uninstall.php / readme.txt / package.json
├── build/
│   ├── index.js             ← wplg-build-index.js      (all bugs fixed)
│   ├── index.asset.php
│   ├── style-index.css      ← wplg-build-style-index.css
│   └── editor.css           ← wplg-build-editor.css
└── src/
    ├── index.js             ← wplg-src-index.js        (Bug 1 fixed)
    ├── edit.js              ← from reference (remove uuid import)
    ├── save.js              ← wplg-src-save.js
    ├── transforms.js        ← wplg-src-transforms.js   (Bug 3 fixed)
    ├── style.scss           ← from reference as-is
    └── editor.scss          ← from reference as-is