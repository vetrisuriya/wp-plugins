wp-coming-soon-maintenance/
│
├── wp-coming-soon-maintenance.php    ← Main plugin file
├── uninstall.php                     ← Clean removal
├── readme.txt                        ← WordPress.org readme
│
├── includes/
│   ├── class-wpcm-activator.php      ← Activation: DB table, caps, flush
│   ├── class-wpcm-settings.php       ← Settings API (all admin config)
│   ├── class-wpcm-interceptor.php    ← template_redirect intercept logic
│   ├── class-wpcm-template.php       ← Render the holding page HTML
│   ├── class-wpcm-leads-db.php       ← CRUD for wp_wpcm_leads table
│   ├── class-wpcm-ajax.php           ← AJAX email capture handler
│   ├── class-wpcm-rest-api.php       ← REST toggle endpoint
│   ├── class-wpcm-shortcodes.php     ← [coming_soon], [maintenance_mode]
│   ├── class-wpcm-widget.php         ← Countdown Timer widget
│   ├── class-wpcm-email.php          ← wp_mail lead confirmation
│   ├── class-wpcm-dashboard.php      ← Admin dashboard widget (stats)
│   └── class-wpcm-capabilities.php   ← bypass_maintenance_mode cap
│
├── public/
│   ├── css/wpcm-holding.css          ← Styles for the holding page
│   └── js/wpcm-holding.js            ← Countdown timer + AJAX lead form
│
└── languages/
    └── wp-coming-soon-maintenance.pot