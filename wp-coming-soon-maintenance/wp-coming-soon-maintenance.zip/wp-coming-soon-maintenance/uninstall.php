<?php
// uninstall.php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

// Drop leads table.
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpcm_leads" );

// Remove all options.
delete_option( 'wpcm_options' );
delete_option( 'wpcm_version' );
delete_option( 'wpcm_total_visits' );
delete_option( 'wpcm_total_leads' );

// Remove transients.
delete_transient( 'wpcm_lead_count' );

// Remove capabilities from all roles.
global $wp_roles;
if ( ! isset( $wp_roles ) ) {
    $wp_roles = new WP_Roles();
}
foreach ( $wp_roles->role_objects as $role ) {
    $role->remove_cap( 'bypass_maintenance_mode' );
}