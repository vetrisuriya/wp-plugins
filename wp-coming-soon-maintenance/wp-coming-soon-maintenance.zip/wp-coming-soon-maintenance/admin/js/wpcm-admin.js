/* ══════════════════════════════════════════════════════════════════
   FILE: wp-coming-soon-maintenance/admin/js/wpcm-admin.js
   Enqueued by: class-wpcm-settings.php → enqueue_admin_assets()
   Depends on:  jquery, wp-color-picker, wp-media-upload
   ══════════════════════════════════════════════════════════════════ */
 
/**
 * wpcm-admin.js
 * Admin settings panel JavaScript.
 *
 * Features:
 *  1. Mode toggle buttons (Coming Soon / Maintenance / Off) — AJAX save
 *  2. WordPress Colour Picker integration
 *  3. Preset theme selector (swatch grid)
 *  4. Background image upload (wp.media)
 *  5. Live preview iframe refresh
 *  6. Range slider live readout
 *  7. Collapsible settings cards
 *  8. Copy-to-clipboard for REST API key
 *  9. Lead table search filter
 * 10. Export leads CSV download button
 */
( function ( $, wp ) {
    'use strict';
 
    var ADMIN = ( typeof WPCMAdmin !== 'undefined' ) ? WPCMAdmin : {};
 
    /* ── DOM ready ─────────────────────────────────────────── */
    $( function () {
        initModeToggle();
        initColourPicker();
        initPresetThemes();
        initMediaUpload();
        initPreviewRefresh();
        initRangeSliders();
        initCollapsibleCards();
        initCopyKey();
        initLeadSearch();
        initExportLeads();
    } );
 
    /* ════════════════════════════════════════════════════════
       01.  MODE TOGGLE (Coming Soon / Maintenance / Off)
    ════════════════════════════════════════════════════════ */
    function initModeToggle() {
        var $btns   = $( '.wpcm-mode-btn' );
        var $status = $( '.wpcm-status-pill' );
 
        $btns.on( 'click', function () {
            var $btn = $( this );
            var mode = $btn.data( 'mode' );
 
            $btns.removeClass( 'is-active--off is-active--coming-soon is-active--maintenance' );
            $btn.addClass( 'is-active--' + mode );
 
            // Update status pill
            $status
                .removeClass( 'wpcm-status-pill--off wpcm-status-pill--coming-soon wpcm-status-pill--maintenance' )
                .addClass( 'wpcm-status-pill--' + mode )
                .text( $btn.text().trim() );
 
            // Update hidden form field
            $( 'input[name="wpcm_settings[mode]"]' ).val( mode );
 
            // Show mode-specific card sections
            $( '.wpcm-mode-section' ).hide();
            $( '.wpcm-mode-section[data-mode="' + mode + '"]' ).show();
 
            // AJAX save mode immediately (no full save needed)
            $.post( ADMIN.ajaxUrl, {
                action: 'wpcm_toggle_mode',
                nonce:  ADMIN.nonce,
                mode:   mode,
            }, function ( res ) {
                if ( res.success ) {
                    showInlineNotice( $btn, res.data.message || 'Mode updated!', 'success' );
                    refreshPreview();
                }
            } );
        } );
    }
 
    function showInlineNotice( $anchor, message, type ) {
        var cls  = 'notice notice-' + ( type === 'success' ? 'success' : 'error' ) + ' wpcm-inline-notice';
        var $msg = $( '<div class="' + cls + '" style="margin:.5rem 0;padding:.5rem .875rem;">'
            + '<p>' + escHtml( message ) + '</p></div>' );
        $anchor.closest( '.wpcm-mode-bar' ).after( $msg );
        setTimeout( function () { $msg.fadeOut( 400, function () { $( this ).remove(); } ); }, 3000 );
    }
 
    /* ════════════════════════════════════════════════════════
       02.  WORDPRESS COLOUR PICKER
    ════════════════════════════════════════════════════════ */
    function initColourPicker() {
        $( '.wpcm-colour-picker' ).wpColorPicker( {
            change: function ( e, ui ) {
                var $input = $( e.target );
                var prop   = $input.data( 'css-var' );
                var color  = ui.color.toString();
 
                if ( prop ) {
                    document.documentElement.style.setProperty( prop, color );
                    // Also update preview
                    schedulePreviewRefresh();
                }
            },
            clear: function () {
                schedulePreviewRefresh();
            },
        } );
 
        // Preset colour swatches
        $( '.wpcm-colour-swatch' ).on( 'click', function () {
            var colour  = $( this ).data( 'colour' );
            var $picker = $( this ).closest( '.wpcm-colour-wrap' ).find( '.wpcm-colour-picker' );
            $picker.wpColorPicker( 'color', colour );
            $( '.wpcm-colour-swatch' ).removeClass( 'is-active' );
            $( this ).addClass( 'is-active' );
        } );
    }
 
    /* ════════════════════════════════════════════════════════
       03.  PRESET THEME SELECTOR
    ════════════════════════════════════════════════════════ */
    function initPresetThemes() {
        $( '.wpcm-theme-swatch' ).on( 'click', function () {
            var theme = $( this ).data( 'theme' );
 
            $( '.wpcm-theme-swatch' ).removeClass( 'is-active' );
            $( this ).addClass( 'is-active' );
 
            $( 'select[name="wpcm_settings[preset_theme]"]' ).val( theme );
 
            // Update preview iframe body data-theme
            var frame = document.querySelector( '.wpcm-preview-frame' );
            if ( frame && frame.contentDocument && frame.contentDocument.body ) {
                frame.contentDocument.body.dataset.theme = theme;
            } else {
                schedulePreviewRefresh();
            }
        } );
    }
 
    /* ════════════════════════════════════════════════════════
       04.  BACKGROUND IMAGE UPLOAD (wp.media)
    ════════════════════════════════════════════════════════ */
    function initMediaUpload() {
        var mediaFrame;
 
        $( document ).on( 'click', '.wpcm-media-upload-btn', function ( e ) {
            e.preventDefault();
            var $btn     = $( this );
            var $preview = $btn.siblings( '.wpcm-media-preview' );
            var $input   = $btn.siblings( 'input[type="hidden"]' );
 
            if ( mediaFrame ) {
                mediaFrame.open();
                return;
            }
 
            mediaFrame = wp.media( {
                title:    ADMIN.l10n.uploadTitle  || 'Select Background Image',
                button:   { text: ADMIN.l10n.uploadBtn || 'Use This Image' },
                multiple: false,
                library:  { type: 'image' },
            } );
 
            mediaFrame.on( 'select', function () {
                var attachment = mediaFrame.state().get( 'selection' ).first().toJSON();
                var url        = attachment.url;
                var id         = attachment.id;
 
                $input.val( id );
 
                $preview.attr( 'src', url ).removeClass( 'is-empty' );
                $btn.text( ADMIN.l10n.changeBtn || 'Change Image' );
                $btn.siblings( '.wpcm-media-remove-btn' ).show();
 
                schedulePreviewRefresh();
            } );
 
            mediaFrame.open();
        } );
 
        // Remove image
        $( document ).on( 'click', '.wpcm-media-remove-btn', function ( e ) {
            e.preventDefault();
            var $btn     = $( this );
            var $preview = $btn.siblings( '.wpcm-media-preview' );
            var $input   = $btn.siblings( 'input[type="hidden"]' );
            var $upload  = $btn.siblings( '.wpcm-media-upload-btn' );
 
            $input.val( '' );
            $preview.attr( 'src', '' ).addClass( 'is-empty' );
            $upload.text( ADMIN.l10n.uploadBtn || 'Upload Image' );
            $btn.hide();
            schedulePreviewRefresh();
        } );
    }
 
    /* ════════════════════════════════════════════════════════
       05.  LIVE PREVIEW IFRAME
    ════════════════════════════════════════════════════════ */
    var previewTimer = null;
 
    function schedulePreviewRefresh( delay ) {
        clearTimeout( previewTimer );
        previewTimer = setTimeout( refreshPreview, delay || 600 );
    }
 
    function refreshPreview() {
        var frame = $( '.wpcm-preview-frame' );
        if ( ! frame.length ) return;
        var src = frame.attr( 'src' );
        // Add cache-buster
        src = src.replace( /[?&]_wpcm=\d+/, '' );
        src += ( src.indexOf( '?' ) === -1 ? '?' : '&' ) + '_wpcm=' + Date.now();
        frame.attr( 'src', src );
    }
 
    // Refresh preview when any form input changes
    function initPreviewRefresh() {
        $( '.wpcm-settings-form' ).on( 'change keyup', 'input, textarea, select', function () {
            schedulePreviewRefresh( 1000 );
        } );
    }
 
    /* ════════════════════════════════════════════════════════
       06.  RANGE SLIDER LIVE READOUT
    ════════════════════════════════════════════════════════ */
    function initRangeSliders() {
        $( '.wpcm-range-row input[type="range"]' ).on( 'input change', function () {
            var val    = $( this ).val();
            var suffix = $( this ).data( 'suffix' ) || '';
            $( this ).siblings( '.wpcm-range-val' ).text( val + suffix );
        } ).trigger( 'input' ); // Set initial value on page load
    }
 
    /* ════════════════════════════════════════════════════════
       07.  COLLAPSIBLE SETTINGS CARDS
    ════════════════════════════════════════════════════════ */
    function initCollapsibleCards() {
        $( '.wpcm-card-head' ).on( 'click', function () {
            $( this ).closest( '.wpcm-card-wrap' ).toggleClass( 'is-collapsed' );
            // Persist state in localStorage
            var id    = $( this ).closest( '.wpcm-card-wrap' ).attr( 'id' );
            var state = $( this ).closest( '.wpcm-card-wrap' ).hasClass( 'is-collapsed' );
            if ( id ) localStorage.setItem( 'wpcm_card_' + id, state ? '1' : '0' );
        } );
 
        // Restore collapsed state on page load
        $( '.wpcm-card-wrap[id]' ).each( function () {
            var id    = $( this ).attr( 'id' );
            var state = localStorage.getItem( 'wpcm_card_' + id );
            if ( state === '1' ) $( this ).addClass( 'is-collapsed' );
        } );
    }
 
    /* ════════════════════════════════════════════════════════
       08.  COPY REST API KEY TO CLIPBOARD
    ════════════════════════════════════════════════════════ */
    function initCopyKey() {
        $( '.wpcm-copy-btn' ).on( 'click', function () {
            var $btn = $( this );
            var key  = $( this ).siblings( '.wpcm-api-key-display' ).text().trim();
 
            navigator.clipboard.writeText( key )
                .then( function () {
                    $btn.text( ADMIN.l10n.copied || 'Copied!' ).addClass( 'is-copied' );
                    setTimeout( function () {
                        $btn.text( ADMIN.l10n.copy || 'Copy' ).removeClass( 'is-copied' );
                    }, 2500 );
                } )
                .catch( function () {
                    // Fallback for older browsers
                    var $temp = $( '<textarea>' ).val( key ).appendTo( 'body' );
                    $temp[0].select();
                    document.execCommand( 'copy' );
                    $temp.remove();
                    $btn.text( ADMIN.l10n.copied || 'Copied!' ).addClass( 'is-copied' );
                    setTimeout( function () {
                        $btn.text( ADMIN.l10n.copy || 'Copy' ).removeClass( 'is-copied' );
                    }, 2500 );
                } );
        } );
    }
 
    /* ════════════════════════════════════════════════════════
       09.  LEAD TABLE SEARCH FILTER
    ════════════════════════════════════════════════════════ */
    function initLeadSearch() {
        $( '#wpcm-lead-search' ).on( 'input', function () {
            var q = $( this ).val().toLowerCase().trim();
            $( '.wpcm-leads-table tbody tr' ).each( function () {
                var text = $( this ).text().toLowerCase();
                $( this ).toggle( ! q || text.indexOf( q ) !== -1 );
            } );
        } );
    }
 
    /* ════════════════════════════════════════════════════════
       10.  EXPORT LEADS CSV
    ════════════════════════════════════════════════════════ */
    function initExportLeads() {
        $( '#wpcm-export-csv' ).on( 'click', function ( e ) {
            e.preventDefault();
            var $btn = $( this );
            $btn.prop( 'disabled', true ).text( ADMIN.l10n.exporting || 'Exporting…' );
 
            $.post( ADMIN.ajaxUrl, {
                action: 'wpcm_export_leads',
                nonce:  ADMIN.nonce,
            }, function ( res ) {
                $btn.prop( 'disabled', false ).text( ADMIN.l10n.exportBtn || 'Export CSV' );
                if ( res.success && res.data.download_url ) {
                    // Trigger download via temporary hidden link
                    var $a = $( '<a>' )
                        .attr( 'href', res.data.download_url )
                        .attr( 'download', 'wpcm-leads.csv' )
                        .appendTo( 'body' );
                    $a[0].click();
                    $a.remove();
                } else {
                    alert( res.data ? res.data.message : ( ADMIN.l10n.exportError || 'Export failed.' ) );
                }
            } );
        } );
    }
 
    /* ════════════════════════════════════════════════════════
       Utility: basic HTML escape for inline messages
    ════════════════════════════════════════════════════════ */
    function escHtml( str ) {
        return String( str )
            .replace( /&/g, '&amp;' )
            .replace( /</g, '&lt;' )
            .replace( />/g, '&gt;' )
            .replace( /"/g, '&quot;' );
    }
 
} )( jQuery, window.wp );