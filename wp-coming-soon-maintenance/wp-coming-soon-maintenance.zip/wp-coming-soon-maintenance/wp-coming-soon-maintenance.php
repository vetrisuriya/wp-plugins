<?php
/**
 * Plugin Name:       WP Coming Soon & Maintenance
 * Plugin URI:        https://vetrisuriya.in/wp-coming-soon-maintenance
 * Description:       Professional coming soon and maintenance mode screens with email lead capture, countdown timer, REST API toggle, and role-based bypass — no page builders required.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Vetri Suriya
 * Author URI:        https://vetrisuriya.in/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-coming-soon-maintenance
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'WPCM_VERSION',  '1.0.0' );
define( 'WPCM_DIR',      plugin_dir_path( __FILE__ ) );
define( 'WPCM_URL',      plugin_dir_url( __FILE__ ) );
define( 'WPCM_BASENAME', plugin_basename( __FILE__ ) );

// Autoloader.
spl_autoload_register( function ( $class ) {
    if ( strpos( $class, 'WPCM_' ) !== 0 ) {
        return;
    }
    $file = WPCM_DIR . 'includes/class-' . strtolower( str_replace( '_', '-', $class ) ) . '.php';
    if ( file_exists( $file ) ) {
        require_once $file;
    }
} );

register_activation_hook( __FILE__, array( 'WPCM_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WPCM_Activator', 'deactivate' ) );

add_action( 'plugins_loaded', 'wpcm_load_textdomain' );
function wpcm_load_textdomain() {
    load_plugin_textdomain(
        'wp-coming-soon-maintenance',
        false,
        dirname( WPCM_BASENAME ) . '/languages'
    );
}

add_action( 'plugins_loaded', 'wpcm_bootstrap' );
function wpcm_bootstrap() {
    new WPCM_Settings();
    new WPCM_Interceptor();
    new WPCM_Shortcodes();
    new WPCM_Widget();
    new WPCM_Ajax();
    new WPCM_Rest_Api();
    new WPCM_Dashboard();
    new WPCM_Capabilities();
}