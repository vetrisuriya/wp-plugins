=== WP Coming Soon & Maintenance ===
Contributors: vetrisuriya
Tags: coming soon, maintenance, landing page, under construction
Requires at least: 5.0
Tested up to: 7.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A simple and customizable coming soon & maintenance mode plugin for WordPress.

== Description ==

Easily put your site into coming soon or maintenance mode. Customize the look, collect leads, and more.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/wp-coming-soon-maintenance` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Configure the plugin via the dashboard menu.

== Frequently Asked Questions ==

= How do I enable maintenance mode? =
Go to the plugin settings and toggle maintenance mode.

== Screenshots ==

1. Settings page screenshot
2. Example coming soon page

== Changelog ==

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 =
First release.

== Credits ==

Developed by Vetri Suriya.

== License ==

This plugin is licensed under the GPLv2 or later.