/**
 * WP Coming Soon & Maintenance Mode
 * FILE: wp-coming-soon-maintenance/public/js/wpcm-holding.js
 *
 * Enqueued by: class-wpcm-holding-page.php → enqueue_assets()
 * Depends on:  wp_localize_script( 'wpcm-holding', 'WPCMData', [...] )
 *
 * Features:
 *  - Countdown timer with flip animation
 *  - AJAX lead capture form (vanilla JS, no jQuery)
 *  - Floating particle system (canvas — no SVG dependency)
 *  - Typing / typewriter effect on headline
 *  - Scroll / parallax depth on background
 *  - Cookie: remember already-subscribed visitors
 *  - Reduced-motion: respects prefers-reduced-motion
 *  - Admin bar close button
 *  - Window title countdown ("Launching in 3d 4h…")
 *  - Analytics event hooks (fires CustomEvent for GTM / GA4)
 */

( function () {
    'use strict';

    /* ── Helpers ─────────────────────────────────────────────── */
    var Data   = ( typeof WPCMData !== 'undefined' ) ? WPCMData : {};
    var MOTION = ! window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

    function qs( sel, ctx ) { return ( ctx || document ).querySelector( sel ); }
    function qa( sel, ctx ) { return Array.from( ( ctx || document ).querySelectorAll( sel ) ); }

    function pad( n ) { return String( n ).padStart( 2, '0' ); }

    function setCookie( name, value, days ) {
        var d = new Date();
        d.setTime( d.getTime() + days * 864e5 );
        document.cookie = name + '=' + encodeURIComponent( value ) +
            '; expires=' + d.toUTCString() + '; path=/; SameSite=Lax';
    }
    function getCookie( name ) {
        var match = document.cookie.match( '(?:^|; )' + name + '=([^;]*)' );
        return match ? decodeURIComponent( match[1] ) : null;
    }

    function fireEvent( name, detail ) {
        document.dispatchEvent( new CustomEvent( 'wpcm:' + name, { bubbles: true, detail: detail || {} } ) );
    }

    /* ── DOM ready ──────────────────────────────────────────── */
    document.addEventListener( 'DOMContentLoaded', function () {
        initCountdown();
        initLeadForm();
        initTypingEffect();
        initParticles();
        initParallax();
        initSubscribedState();
        initProgressBar();
        initAdminBar();
    } );

    /* ════════════════════════════════════════════════════════════
       01.  COUNTDOWN TIMER
    ════════════════════════════════════════════════════════════ */
    var countdownInterval = null;

    function initCountdown() {
        var el = qs( '#wpcm-countdown' );
        if ( ! el ) return;

        var launchStr = el.dataset.launch;
        if ( ! launchStr ) return;

        // Accept ISO 8601 or 'YYYY-MM-DD HH:MM:SS' formats
        var launchTime = new Date( launchStr.replace( ' ', 'T' ) ).getTime();
        if ( isNaN( launchTime ) ) return;

        var daysEl  = qs( '#wpcm-days',  el );
        var hoursEl = qs( '#wpcm-hours', el );
        var minsEl  = qs( '#wpcm-mins',  el );
        var secsEl  = qs( '#wpcm-secs',  el );

        if ( ! daysEl || ! hoursEl || ! minsEl || ! secsEl ) return;

        // Keep previous values to detect change (for flip animation)
        var prev = { d: '', h: '', m: '', s: '' };

        function flipIfChanged( el, newVal, prevVal ) {
            if ( newVal !== prevVal && MOTION ) {
                el.classList.remove( 'wpcm-flipping' );
                // Force reflow to restart animation
                void el.offsetWidth;
                el.classList.add( 'wpcm-flipping' );
                // Remove class after animation ends
                el.addEventListener( 'animationend', function handler() {
                    el.classList.remove( 'wpcm-flipping' );
                    el.removeEventListener( 'animationend', handler );
                } );
            }
            el.textContent = newVal;
        }

        function tick() {
            var now  = Date.now();
            var diff = launchTime - now;

            if ( diff <= 0 ) {
                // Launch time reached
                clearInterval( countdownInterval );
                daysEl.textContent = hoursEl.textContent = minsEl.textContent = secsEl.textContent = '00';

                // Show "ended" message if element exists
                var endedEl = qs( '.wpcm-cd-ended' );
                if ( endedEl ) {
                    endedEl.hidden     = false;
                    el.hidden          = true;
                }

                // Update page title
                document.title = ( Data.siteTitle || '' );
                fireEvent( 'countdown-ended', {} );
                return;
            }

            var d = Math.floor( diff / 864e5 );
            var h = Math.floor( ( diff % 864e5 ) / 36e5 );
            var m = Math.floor( ( diff % 36e5 ) / 6e4 );
            var s = Math.floor( ( diff % 6e4 ) / 1e3 );

            var pd = pad( d );
            var ph = pad( h );
            var pm = pad( m );
            var ps = pad( s );

            flipIfChanged( daysEl,  pd, prev.d );
            flipIfChanged( hoursEl, ph, prev.h );
            flipIfChanged( minsEl,  pm, prev.m );
            flipIfChanged( secsEl,  ps, prev.s );

            prev = { d: pd, h: ph, m: pm, s: ps };

            // Update window title every minute
            if ( s === 0 ) {
                document.title = d + 'd ' + ph + 'h ' + pm + 'm — ' + ( Data.pageTitle || 'Coming Soon' );
            }
        }

        tick(); // Run immediately so no "00" flash
        countdownInterval = setInterval( tick, 1000 );

        // Initial title update
        document.title = ( Data.pageTitle || 'Coming Soon' );
    }

    /* ════════════════════════════════════════════════════════════
       02.  AJAX LEAD CAPTURE FORM
    ════════════════════════════════════════════════════════════ */
    function initLeadForm() {
        var form    = qs( '.wpcm-form-wrap' );
        var emailEl = qs( '#wpcm-lead-email' );
        var btn     = qs( '#wpcm-lead-btn' );
        var msgEl   = qs( '#wpcm-form-msg' );

        if ( ! btn || ! emailEl ) return;

        btn.addEventListener( 'click', submitLead );

        // Submit on Enter key
        emailEl.addEventListener( 'keydown', function ( e ) {
            if ( e.key === 'Enter' ) {
                e.preventDefault();
                submitLead();
            }
        } );

        // Clear error when user starts typing
        emailEl.addEventListener( 'input', function () {
            if ( msgEl && msgEl.classList.contains( 'wpcm-error-msg' ) ) {
                msgEl.textContent = '';
                msgEl.className   = '';
            }
        } );

        function setMsg( text, type ) {
            if ( ! msgEl ) return;
            msgEl.className   = type === 'success' ? 'wpcm-success-msg' : 'wpcm-error-msg';
            msgEl.textContent = text;
            msgEl.setAttribute( 'role', 'alert' );
        }

        function setLoading( loading ) {
            if ( loading ) {
                btn.disabled = true;
                // Add spinner
                btn.innerHTML = '<span class="wpcm-btn-spinner" aria-hidden="true"></span>'
                    + ( Data.strings.submitting || 'Sending…' );
            } else {
                btn.disabled = false;
                btn.textContent = Data.strings.btn_label || ( Data.btnLabel || 'Notify Me' );
            }
        }

        function submitLead() {
            var email = emailEl.value.trim();

            // Client-side validation
            if ( ! email ) {
                setMsg( Data.strings.email_required || 'Please enter your email address.', 'error' );
                emailEl.focus();
                return;
            }
            if ( ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( email ) ) {
                setMsg( Data.strings.email_invalid || 'Please enter a valid email address.', 'error' );
                emailEl.focus();
                return;
            }

            setLoading( true );
            fireEvent( 'lead-submit-start', { email: email } );

            // Build form data
            var body = new URLSearchParams( {
                action: 'wpcm_capture_lead',
                nonce:  Data.nonce  || '',
                email:  email,
            } );

            fetch( Data.ajax_url || '/wp-admin/admin-ajax.php', {
                method:      'POST',
                credentials: 'same-origin',
                headers:     { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body:        body.toString(),
            } )
            .then( function ( r ) {
                if ( ! r.ok ) throw new Error( 'Network error ' + r.status );
                return r.json();
            } )
            .then( function ( res ) {
                setLoading( false );
                if ( res.success ) {
                    handleSuccess( email, res.data ? res.data.message : '' );
                } else {
                    var code = res.data ? res.data.code : '';
                    var msg  = code === 'duplicate_email'
                        ? ( Data.strings.dup    || 'You\'re already on the list!' )
                        : ( ( res.data && res.data.message ) || Data.strings.error || 'Something went wrong.' );

                    if ( code === 'duplicate_email' ) {
                        // Treat duplicate as soft success
                        handleSuccess( email, msg );
                    } else {
                        setMsg( msg, 'error' );
                        fireEvent( 'lead-submit-fail', { email: email, code: code } );
                    }
                }
            } )
            .catch( function () {
                setLoading( false );
                setMsg( Data.strings.error || 'Connection error. Please try again.', 'error' );
                fireEvent( 'lead-submit-fail', { email: email, code: 'network' } );
            } );
        }

        function handleSuccess( email, message ) {
            var msg = message || Data.strings.success || 'You\'re on the list! We\'ll be in touch.';
            setMsg( msg, 'success' );

            // Hide the input row and show full-width message
            var row = qs( '.wpcm-input-row' );
            if ( row ) row.style.display = 'none';
            var label = qs( '.wpcm-form-label' );
            if ( label ) label.style.display = 'none';

            emailEl.value = '';

            // Set cookie so returning visitors skip the form
            setCookie( 'wpcm_subscribed', '1', 365 );

            fireEvent( 'lead-captured', { email: email } );

            // Scroll to message on mobile
            if ( msgEl && window.innerWidth < 600 ) {
                msgEl.scrollIntoView( { behavior: 'smooth', block: 'center' } );
            }
        }
    }

    /* ════════════════════════════════════════════════════════════
       03.  TYPING / TYPEWRITER EFFECT
    ════════════════════════════════════════════════════════════ */
    function initTypingEffect() {
        var el = qs( '.wpcm-headline[data-typing]' );
        if ( ! el || ! MOTION ) return;

        var phrases  = ( el.dataset.typing || '' ).split( '|' ).map( function ( s ) { return s.trim(); } );
        if ( ! phrases.length || ( phrases.length === 1 && ! phrases[0] ) ) return;

        var cursor   = qs( '.wpcm-cursor' );
        var current  = 0;
        var charIdx  = 0;
        var deleting = false;
        var SPEED_TYPE   = 65;
        var SPEED_DELETE = 35;
        var PAUSE_FULL   = 2400;
        var PAUSE_EMPTY  = 500;
        var timer;

        function type() {
            var phrase = phrases[ current ];

            if ( ! deleting ) {
                charIdx++;
                el.textContent = phrase.slice( 0, charIdx );
                if ( cursor ) el.appendChild( cursor );

                if ( charIdx === phrase.length ) {
                    deleting = true;
                    timer = setTimeout( type, PAUSE_FULL );
                    return;
                }
            } else {
                charIdx--;
                el.textContent = phrase.slice( 0, charIdx );
                if ( cursor ) el.appendChild( cursor );

                if ( charIdx === 0 ) {
                    deleting = false;
                    current  = ( current + 1 ) % phrases.length;
                    timer = setTimeout( type, PAUSE_EMPTY );
                    return;
                }
            }

            timer = setTimeout( type, deleting ? SPEED_DELETE : SPEED_TYPE );
        }

        // Start with first phrase pre-typed, then cycle
        el.textContent = phrases[0];
        if ( cursor ) el.appendChild( cursor );
        charIdx = phrases[0].length;
        timer   = setTimeout( type, PAUSE_FULL );

        // Clean up on page unload
        window.addEventListener( 'unload', function () { clearTimeout( timer ); } );
    }

    /* ════════════════════════════════════════════════════════════
       04.  PARTICLE SYSTEM (Canvas)
    ════════════════════════════════════════════════════════════ */
    function initParticles() {
        // Only use canvas if explicitly opted in via data attribute on body
        if ( ! document.body.dataset.particlesCanvas || ! MOTION ) return;

        var canvas = document.createElement( 'canvas' );
        canvas.className = 'wpcm-particles-canvas';
        canvas.setAttribute( 'aria-hidden', 'true' );
        canvas.style.cssText = [
            'position:fixed', 'inset:0', 'pointer-events:none',
            'z-index:0', 'opacity:.6',
        ].join(';');
        document.body.appendChild( canvas );

        var ctx   = canvas.getContext( '2d' );
        var W, H;
        var parts = [];
        var NUM   = Math.min( 60, Math.floor( window.innerWidth / 20 ) );

        // Primary colour from CSS variable
        var style   = getComputedStyle( document.documentElement );
        var primary = style.getPropertyValue( '--wpcm-primary' ).trim() || '#6c63ff';

        function resize() {
            W = canvas.width  = window.innerWidth;
            H = canvas.height = window.innerHeight;
        }
        resize();
        window.addEventListener( 'resize', resize, { passive: true } );

        // Initialise particles
        for ( var i = 0; i < NUM; i++ ) {
            parts.push( {
                x:   Math.random() * W,
                y:   Math.random() * H + H,  // start below screen
                r:   Math.random() * 5 + 2,
                vx:  ( Math.random() - 0.5 ) * 0.4,
                vy:  -( Math.random() * 0.8 + 0.3 ),
                op:  Math.random() * 0.35 + 0.1,
                col: Math.random() > 0.7 ? '#ff6584' : primary,
            } );
        }

        var raf;
        function draw() {
            ctx.clearRect( 0, 0, W, H );
            parts.forEach( function ( p ) {
                ctx.beginPath();
                ctx.arc( p.x, p.y, p.r, 0, Math.PI * 2 );
                ctx.fillStyle = p.col;
                ctx.globalAlpha = p.op;
                ctx.fill();

                p.x += p.vx;
                p.y += p.vy;

                // Reset particle when it exits top
                if ( p.y + p.r < 0 ) {
                    p.x = Math.random() * W;
                    p.y = H + p.r;
                }
                // Wrap horizontally
                if ( p.x < -p.r ) p.x = W + p.r;
                if ( p.x > W + p.r ) p.x = -p.r;
            } );
            ctx.globalAlpha = 1;
            raf = requestAnimationFrame( draw );
        }

        draw();

        // Pause when tab is hidden
        document.addEventListener( 'visibilitychange', function () {
            if ( document.hidden ) { cancelAnimationFrame( raf ); }
            else { draw(); }
        } );
    }

    /* ════════════════════════════════════════════════════════════
       05.  PARALLAX BACKGROUND
    ════════════════════════════════════════════════════════════ */
    function initParallax() {
        if ( ! MOTION ) return;
        var bg = qs( '.wpcm-bg--image' );
        if ( ! bg ) return;

        var ticking = false;
        window.addEventListener( 'scroll', function () {
            if ( ! ticking ) {
                requestAnimationFrame( function () {
                    var scrollY = window.scrollY || window.pageYOffset;
                    bg.style.transform = 'translateY(' + ( scrollY * 0.25 ) + 'px)';
                    ticking = false;
                } );
                ticking = true;
            }
        }, { passive: true } );
    }

    /* ════════════════════════════════════════════════════════════
       06.  ALREADY-SUBSCRIBED COOKIE CHECK
    ════════════════════════════════════════════════════════════ */
    function initSubscribedState() {
        if ( getCookie( 'wpcm_subscribed' ) !== '1' ) return;

        var form  = qs( '.wpcm-form-wrap' );
        var row   = qs( '.wpcm-input-row' );
        var label = qs( '.wpcm-form-label' );
        var msgEl = qs( '#wpcm-form-msg' );

        if ( row )   row.style.display   = 'none';
        if ( label ) label.style.display = 'none';

        if ( msgEl ) {
            msgEl.className   = 'wpcm-success-msg';
            msgEl.textContent = Data.strings.already_subscribed || 'You\'re already on the list!';
            msgEl.style.padding = '0.75rem 1rem';
        }
    }

    /* ════════════════════════════════════════════════════════════
       07.  PROGRESS BAR ANIMATION
    ════════════════════════════════════════════════════════════ */
    function initProgressBar() {
        var fill = qs( '.wpcm-progress-fill' );
        if ( ! fill ) return;

        // The target width is set via inline style in PHP.
        // Animate from 0 on load for visual impact.
        var target = fill.style.width;
        if ( ! target ) return;

        fill.style.width = '0%';
        // Small delay so CSS transition fires
        setTimeout( function () {
            fill.style.width = target;
        }, 300 );
    }

    /* ════════════════════════════════════════════════════════════
       08.  ADMIN BAR
    ════════════════════════════════════════════════════════════ */
    function initAdminBar() {
        var closeBtn = qs( '#wpcm-admin-bar-close' );
        var bar      = qs( '.wpcm-admin-bar' );
        if ( ! closeBtn || ! bar ) return;

        closeBtn.addEventListener( 'click', function () {
            bar.style.height      = bar.offsetHeight + 'px';
            bar.style.overflow    = 'hidden';
            bar.style.transition  = 'height 0.3s ease, opacity 0.3s ease';
            requestAnimationFrame( function () {
                bar.style.height  = '0';
                bar.style.opacity = '0';
            } );
            bar.addEventListener( 'transitionend', function () {
                bar.remove();
                document.body.classList.remove( 'wpcm-has-admin-bar' );
            }, { once: true } );
        } );
    }

    /* ════════════════════════════════════════════════════════════
       09.  SOCIAL SHARE LINKS (dynamic URLs)
    ════════════════════════════════════════════════════════════ */
    qa( '.wpcm-social__link[data-network]' ).forEach( function ( link ) {
        var network = link.dataset.network;
        var pageUrl = encodeURIComponent( Data.pageUrl || window.location.href );
        var title   = encodeURIComponent( Data.siteTitle || document.title );

        var networks = {
            twitter:   'https://twitter.com/intent/tweet?url=' + pageUrl + '&text=' + title,
            facebook:  'https://www.facebook.com/sharer/sharer.php?u=' + pageUrl,
            linkedin:  'https://www.linkedin.com/shareArticle?mini=true&url=' + pageUrl + '&title=' + title,
            pinterest: 'https://pinterest.com/pin/create/button/?url=' + pageUrl + '&description=' + title,
        };

        if ( networks[ network ] && ! link.href ) {
            link.href = networks[ network ];
        }

        if ( link.href && link.href !== window.location.href ) {
            link.setAttribute( 'target', '_blank' );
            link.setAttribute( 'rel', 'noopener noreferrer' );
        }
    } );

} )();