/**
 * WP Coming Soon & Maintenance Mode
 * FILE: wp-coming-soon-maintenance/public/js/wpcm-widget-timer.js
 *
 * Enqueued by: WPCM_Widget::widget() only when a countdown widget is rendered.
 * Depends on:  None — vanilla JS, no jQuery.
 *
 * Handles all .wpcm-widget-countdown elements on the page.
 */
( function () {
    'use strict';
 
    function pad( n ) { return String( n ).padStart( 2, '0' ); }
 
    document.addEventListener( 'DOMContentLoaded', function () {
        document.querySelectorAll( '.wpcm-widget-countdown[data-launch]' ).forEach( function ( el ) {
            var launch = new Date( el.dataset.launch.replace( ' ', 'T' ) ).getTime();
            if ( isNaN( launch ) ) return;
 
            var dEl = el.querySelector( '.wpcm-w-days' );
            var hEl = el.querySelector( '.wpcm-w-hours' );
            var mEl = el.querySelector( '.wpcm-w-mins' );
            var sEl = el.querySelector( '.wpcm-w-secs' );
 
            function tick() {
                var diff = launch - Date.now();
                if ( diff <= 0 ) {
                    if ( dEl ) dEl.textContent = '0';
                    if ( hEl ) hEl.textContent = '00';
                    if ( mEl ) mEl.textContent = '00';
                    if ( sEl ) sEl.textContent = '00';
                    return;
                }
                var d = Math.floor( diff / 864e5 );
                var h = Math.floor( ( diff % 864e5 ) / 36e5 );
                var m = Math.floor( ( diff % 36e5 ) / 6e4 );
                var s = Math.floor( ( diff % 6e4 ) / 1e3 );
                if ( dEl ) dEl.textContent = d;
                if ( hEl ) hEl.textContent = pad( h );
                if ( mEl ) mEl.textContent = pad( m );
                if ( sEl ) sEl.textContent = pad( s );
            }
 
            tick();
            setInterval( tick, 1000 );
        } );
    } );
} )();
 
 
/* ─────────────────────────────────────────────────────────────────
   END OF wpcm-widget-timer.js
   The following two files are concatenated here for single-download
   convenience. In your plugin, save each block to its own file.
   ─────────────────────────────────────────────────────────────────