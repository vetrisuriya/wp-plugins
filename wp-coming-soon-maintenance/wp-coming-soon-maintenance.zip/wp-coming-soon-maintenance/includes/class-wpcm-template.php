<?php
// includes/class-wpcm-template.php
defined( 'ABSPATH' ) || exit;

class WPCM_Template {

    public function render() {
        $headline    = WPCM_Settings::get( 'headline', __( 'Coming Soon', 'wp-coming-soon-maintenance' ) );
        $message     = WPCM_Settings::get( 'message', '' );
        $launch_date = WPCM_Settings::get( 'launch_date', '' );
        $bg_color    = WPCM_Settings::get( 'bg_color', '#1a1a2e' );
        $text_color  = WPCM_Settings::get( 'text_color', '#ffffff' );
        $bg_image    = WPCM_Settings::get( 'bg_image_url', '' );
        $show_form   = '1' === WPCM_Settings::get( 'show_lead_form', '1' );
        $site_name   = get_bloginfo( 'name' );
        $site_url    = home_url();
        $logo_url    = get_site_icon_url( 80 );

        $bg_style = $bg_image
            ? 'background: url(' . esc_url( $bg_image ) . ') center/cover no-repeat fixed;'
            : 'background-color: ' . esc_attr( $bg_color ) . ';';

        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo( 'charset' ); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php echo esc_html( $headline . ' — ' . $site_name ); ?></title>
            <meta name="robots" content="noindex, nofollow">
            <?php wp_head(); // Allows other plugins to add to head. ?>
            <style>
                *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
                body {
                    <?php echo wp_strip_all_tags( $bg_style ); // sanitized above ?>
                    color: <?php echo esc_attr( $text_color ); ?>;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    text-align: center;
                }
                .wpcm-wrap { max-width: 600px; padding: 2rem; }
                .wpcm-logo { margin-bottom: 1.5rem; }
                .wpcm-headline { font-size: 2.8rem; font-weight: 700; margin-bottom: 1rem; line-height: 1.2; }
                .wpcm-message { font-size: 1.1rem; opacity: .85; margin-bottom: 2rem; line-height: 1.6; }
                .wpcm-countdown { display: flex; justify-content: center; gap: 1.5rem; margin-bottom: 2rem; }
                .wpcm-count-box { background: rgba(255,255,255,.15); border-radius: 8px; padding: .8rem 1.2rem; min-width: 70px; }
                .wpcm-count-num { font-size: 2rem; font-weight: 700; display: block; }
                .wpcm-count-lbl { font-size: .75rem; text-transform: uppercase; letter-spacing: .05em; opacity: .7; }
                .wpcm-lead-form { display: flex; gap: .5rem; max-width: 420px; margin: 0 auto 1.5rem; flex-wrap: wrap; }
                .wpcm-lead-form input[type="email"] {
                    flex: 1; padding: .75rem 1rem; border: none; border-radius: 6px;
                    font-size: 1rem; min-width: 200px;
                }
                .wpcm-btn {
                    padding: .75rem 1.5rem; background: #e94560; color: #fff;
                    border: none; border-radius: 6px; font-size: 1rem; cursor: pointer;
                    transition: background .2s;
                }
                .wpcm-btn:hover { background: #c73652; }
                .wpcm-form-msg { margin-top: .75rem; font-size: .95rem; min-height: 1.2em; }
                .wpcm-success-msg { color: #a8e6cf; }
                .wpcm-error-msg   { color: #ffb3b3; }
            </style>
        </head>
        <body>
            <div class="wpcm-wrap">
                <?php if ( $logo_url ) : ?>
                <div class="wpcm-logo">
                    <a href="<?php echo esc_url( $site_url ); ?>">
                        <img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $site_name ); ?>" width="80" height="80">
                    </a>
                </div>
                <?php endif; ?>

                <h1 class="wpcm-headline"><?php echo esc_html( $headline ); ?></h1>

                <?php if ( $message ) : ?>
                <p class="wpcm-message"><?php echo wp_kses_post( $message ); ?></p>
                <?php endif; ?>

                <?php if ( $launch_date ) : ?>
                <div class="wpcm-countdown" id="wpcm-countdown" data-launch="<?php echo esc_attr( $launch_date ); ?>">
                    <div class="wpcm-count-box">
                        <span class="wpcm-count-num" id="wpcm-days">--</span>
                        <span class="wpcm-count-lbl"><?php esc_html_e( 'Days', 'wp-coming-soon-maintenance' ); ?></span>
                    </div>
                    <div class="wpcm-count-box">
                        <span class="wpcm-count-num" id="wpcm-hours">--</span>
                        <span class="wpcm-count-lbl"><?php esc_html_e( 'Hours', 'wp-coming-soon-maintenance' ); ?></span>
                    </div>
                    <div class="wpcm-count-box">
                        <span class="wpcm-count-num" id="wpcm-mins">--</span>
                        <span class="wpcm-count-lbl"><?php esc_html_e( 'Minutes', 'wp-coming-soon-maintenance' ); ?></span>
                    </div>
                    <div class="wpcm-count-box">
                        <span class="wpcm-count-num" id="wpcm-secs">--</span>
                        <span class="wpcm-count-lbl"><?php esc_html_e( 'Seconds', 'wp-coming-soon-maintenance' ); ?></span>
                    </div>
                </div>
                <?php endif; ?>

                <?php if ( $show_form ) : ?>
                <div class="wpcm-lead-wrap">
                    <div class="wpcm-lead-form">
                        <input type="email" id="wpcm-lead-email" placeholder="<?php esc_attr_e( 'Enter your email…', 'wp-coming-soon-maintenance' ); ?>" />
                        <button type="button" id="wpcm-lead-btn" class="wpcm-btn">
                            <?php esc_html_e( 'Notify Me', 'wp-coming-soon-maintenance' ); ?>
                        </button>
                    </div>
                    <div id="wpcm-form-msg" class="wpcm-form-msg" aria-live="polite"></div>
                </div>
                <?php endif; ?>
            </div>

            <?php
            // Localize AJAX data for the holding page.
            wp_enqueue_script(
                'wpcm-holding',
                WPCM_URL . 'public/js/wpcm-holding.js',
                array( 'jquery' ),
                WPCM_VERSION,
                true
            );
            wp_localize_script( 'wpcm-holding', 'WPCMData', array(
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'wpcm_lead_nonce' ),
                'strings'  => array(
                    'success' => __( 'You\'re on the list! We\'ll notify you on launch.', 'wp-coming-soon-maintenance' ),
                    'error'   => __( 'Something went wrong. Please try again.', 'wp-coming-soon-maintenance' ),
                    'dup'     => __( 'This email is already registered.', 'wp-coming-soon-maintenance' ),
                ),
            ) );
            wp_footer(); // For JS output.
            ?>
        </body>
        </html>
        <?php
    }
}