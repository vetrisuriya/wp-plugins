<?php
// includes/class-wpcm-leads-db.php
class WPCM_Leads_DB {

    private string $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'wpcm_leads';
    }

    public function insert( string $email, string $source = 'holding_page' ): int|WP_Error {
        global $wpdb;

        // Check for duplicate.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $exists = $wpdb->get_var(
            $wpdb->prepare( "SELECT id FROM {$this->table} WHERE email = %s LIMIT 1", $email )
        );

        if ( $exists ) {
            return new WP_Error( 'duplicate_email', __( 'This email is already subscribed.', 'wp-coming-soon-maintenance' ) );
        }

        $result = $wpdb->insert(
            $this->table,
            array(
                'email'      => $email,
                'source'     => sanitize_text_field( $source ),
                'subscribed' => 1,
                'created_at' => current_time( 'mysql' ),
            ),
            array( '%s', '%s', '%d', '%s' )
        );

        if ( false === $result ) {
            return new WP_Error( 'db_error', __( 'Could not save email.', 'wp-coming-soon-maintenance' ) );
        }

        // Clear cached lead count.
        delete_transient( 'wpcm_lead_count' );

        return (int) $wpdb->insert_id;
    }

    public function get_count(): int {
        $count = get_transient( 'wpcm_lead_count' );
        if ( false !== $count ) {
            return (int) $count;
        }

        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table} WHERE subscribed = 1" );
        set_transient( 'wpcm_lead_count', $count, 30 * MINUTE_IN_SECONDS );
        return $count;
    }

    public function get_all(): array {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return $wpdb->get_results(
            "SELECT id, email, source, created_at FROM {$this->table} ORDER BY created_at DESC",
            ARRAY_A
        );
    }

    public function delete( int $id ): bool {
        global $wpdb;
        $result = $wpdb->delete( $this->table, array( 'id' => $id ), array( '%d' ) );
        if ( $result ) {
            delete_transient( 'wpcm_lead_count' );
        }
        return false !== $result;
    }
}