<?php
// includes/class-wpcm-email.php
defined( 'ABSPATH' ) || exit;

class WPCM_Email {

    public function send_lead_confirmation( string $email ): bool {
        $site_name = get_bloginfo( 'name' );
        $site_url  = home_url();

        $subject = sprintf(
            /* translators: %s: site name */
            __( "You're on the list — %s is coming soon!", 'wp-coming-soon-maintenance' ),
            $site_name
        );

        $message = sprintf(
            /* translators: 1: site name, 2: site URL */
            __(
                "Hi there!\n\nThanks for your interest in %1\$s.\n\nWe'll send you a notification as soon as we launch.\n\nIn the meantime, check us out at: %2\$s\n\n— The %1\$s Team",
                'wp-coming-soon-maintenance'
            ),
            $site_name,
            $site_url
        );

        return wp_mail(
            $email,
            $subject,
            $message,
            array( 'Content-Type: text/plain; charset=UTF-8' )
        );
    }

    public function notify_admin_of_lead( string $email ): bool {
        $admin_email = get_option( 'admin_email' );
        $site_name   = get_bloginfo( 'name' );

        $subject = sprintf(
            /* translators: 1: email, 2: site name */
            __( 'New Lead: %1$s subscribed on %2$s', 'wp-coming-soon-maintenance' ),
            $email,
            $site_name
        );

        $db    = new WPCM_Leads_DB();
        $count = $db->get_count();

        $message = sprintf(
            /* translators: 1: email, 2: total leads, 3: admin URL */
            __(
                "New lead captured!\n\nEmail: %1\$s\nTotal leads: %2\$d\n\nView all leads: %3\$s",
                'wp-coming-soon-maintenance'
            ),
            $email,
            $count,
            admin_url( 'options-general.php?page=wpcm-settings' )
        );

        return wp_mail( $admin_email, $subject, $message );
    }
}