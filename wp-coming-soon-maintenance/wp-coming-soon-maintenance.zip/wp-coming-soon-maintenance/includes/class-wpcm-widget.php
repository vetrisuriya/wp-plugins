<?php
// includes/class-wpcm-widget.php
defined( 'ABSPATH' ) || exit;

class WPCM_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'wpcm_countdown_widget',
            __( 'Site Countdown Timer', 'wp-coming-soon-maintenance' ),
            array( 'description' => __( 'Shows a live countdown to the launch date set in Coming Soon settings.', 'wp-coming-soon-maintenance' ) )
        );
        add_action( 'widgets_init', function () {
            register_widget( 'WPCM_Widget' );
        } );
    }

    public function widget( $args, $instance ) {
        $title       = apply_filters( 'widget_title', $instance['title'] ?? '' );
        $launch_date = WPCM_Settings::get( 'launch_date', '' );

        if ( ! $launch_date ) {
            return; // No countdown configured — don't render widget.
        }

        echo wp_kses_post( $args['before_widget'] );
        if ( $title ) {
            echo wp_kses_post( $args['before_title'] ) . esc_html( $title ) . wp_kses_post( $args['after_title'] );
        }

        echo '<div class="wpcm-widget-countdown" data-launch="' . esc_attr( $launch_date ) . '">';
        echo '<span class="wpcm-w-days">--</span> ' . esc_html__( 'days', 'wp-coming-soon-maintenance' );
        echo ' <span class="wpcm-w-hours">--</span> ' . esc_html__( 'hrs', 'wp-coming-soon-maintenance' );
        echo ' <span class="wpcm-w-mins">--</span> ' . esc_html__( 'min', 'wp-coming-soon-maintenance' );
        echo ' <span class="wpcm-w-secs">--</span> ' . esc_html__( 'sec', 'wp-coming-soon-maintenance' );
        echo '</div>';

        // Inline small script for widget (widgets load on admin-visible pages — not holding page).
        wp_enqueue_script( 'wpcm-widget-timer', WPCM_URL . 'public/js/wpcm-widget-timer.js', array(), WPCM_VERSION, true );

        echo wp_kses_post( $args['after_widget'] );
    }

    public function form( $instance ) {
        $title = $instance['title'] ?? __( 'Launching In', 'wp-coming-soon-maintenance' );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
                <?php esc_html_e( 'Title:', 'wp-coming-soon-maintenance' ); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p class="description">
            <?php esc_html_e( 'Launch date is configured in Settings > Coming Soon.', 'wp-coming-soon-maintenance' ); ?>
        </p>
        <?php
    }

    public function update( $new_instance, $old_instance ): array {
        return array( 'title' => sanitize_text_field( $new_instance['title'] ) );
    }
}