<?php
// includes/class-wpcm-interceptor.php
defined( 'ABSPATH' ) || exit;

/**
 * Intercepts all front-end requests when the plugin is active.
 *
 * ASCII flow:
 *
 * Request arrives
 *   ├─ Is admin?         → Allow through (never intercept wp-admin)
 *   ├─ Is REST API?      → Allow through (REST needs to work for toggle endpoint)
 *   ├─ Is login page?    → Allow through
 *   ├─ Mode = Off?       → Allow through
 *   ├─ User has bypass cap or bypass role? → Allow through
 *   └─ Mode = 1 or 2?   → Serve holding page and exit
 *                            Mode 2 also sends HTTP 503 + Retry-After header
 */
class WPCM_Interceptor {

    public function __construct() {
        add_action( 'template_redirect', array( $this, 'maybe_intercept' ), 1 );
    }

    public function maybe_intercept() {
                // Auto-disable coming soon/maintenance mode after launch date.
                $mode = WPCM_Settings::get( 'mode_active', '0' );
                $launch_date = WPCM_Settings::get( 'launch_date', '' );
                if ( $launch_date ) {
                    $now = current_time( 'timestamp' );
                    $launch_ts = strtotime( $launch_date );
                    if ( $launch_ts && $now >= $launch_ts ) {
                        if ( '0' !== $mode ) {
                            $options = get_option( WPCM_Settings::OPTION_KEY, array() );
                            $options['mode_active'] = '0';
                            update_option( WPCM_Settings::OPTION_KEY, $options );
                        }
                        $mode = '0';
                    }
                }
        // Never block admin, REST, cron, or login.
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
            return;
        }
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            return;
        }
        if ( $GLOBALS['pagenow'] === 'wp-login.php' ) {
            return;
        }


        // If mode is off, allow through.
        if ( '0' === $mode ) {
            return;
        }

        // Allow users who have the bypass capability only.
        if ( current_user_can( 'bypass_maintenance_mode' ) ) {
            return;
        }

        // Track unique page visits (simple, non-blocking).
        $visits = (int) get_option( 'wpcm_total_visits', 0 );
        update_option( 'wpcm_total_visits', $visits + 1, false );

        // Maintenance mode: HTTP 503 with Retry-After.
        if ( '2' === $mode ) {
            header( 'HTTP/1.1 503 Service Unavailable' );
            header( 'Status: 503 Service Unavailable' );
            header( 'Retry-After: 3600' ); // Tell bots: try again in 1 hour.
        }

        // Render the holding page and stop all further processing.
        $template = new WPCM_Template();
        $template->render();
        exit;
    }
}