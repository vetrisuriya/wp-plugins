<?php
// includes/class-wpcm-capabilities.php
defined( 'ABSPATH' ) || exit;

class WPCM_Capabilities {

    /**
     * bypass_maintenance_mode
     *
     * Any user with this capability sees the real site even when Coming Soon
     * or Maintenance Mode is active. Assign it to client-review roles like
     * 'editor' or 'contributor' during the build phase.
     *
     * Usage:
     *   WPCM_Capabilities::grant( 'editor' );    // Client can preview site.
     *   WPCM_Capabilities::revoke( 'editor' );   // Remove after launch.
     */
    public static function grant( string $role_name ) {
        $role = get_role( $role_name );
        if ( $role ) {
            $role->add_cap( 'bypass_maintenance_mode' );
        }
    }

    public static function revoke( string $role_name ) {
        $role = get_role( $role_name );
        if ( $role ) {
            $role->remove_cap( 'bypass_maintenance_mode' );
        }
    }

    /**
     * Check if a specific user can bypass (useful for per-user grant).
     * e.g. grant a single user: add_user_meta( $user_id, 'bypass_maintenance_mode', true );
     */
    public static function user_can_bypass( int $user_id ): bool {
        $user = get_user_by( 'id', $user_id );
        return $user && $user->has_cap( 'bypass_maintenance_mode' );
    }
}