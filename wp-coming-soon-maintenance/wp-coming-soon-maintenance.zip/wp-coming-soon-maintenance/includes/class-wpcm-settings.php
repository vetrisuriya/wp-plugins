<?php
// includes/class-wpcm-settings.php
defined( 'ABSPATH' ) || exit;

class WPCM_Settings {

    const OPTION_KEY = 'wpcm_options';

    public function __construct() {
        add_action( 'admin_menu',  array( $this, 'add_menu_page' ) );
        add_action( 'admin_init',  array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
    }

    /** Static helper — call WPCM_Settings::get('key', $default) anywhere. */
    public static function get( string $key, $default = '' ) {
        $options = get_option( self::OPTION_KEY, array() );
        return $options[ $key ] ?? $default;
    }

    public static function is_active(): bool {
        return '1' === self::get( 'mode_active', '0' );
    }

    public function enqueue_admin_assets( string $hook ) {
        if ( 'settings_page_wpcm-settings' !== $hook ) {
            return;
        }
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script(
            'wpcm-admin',
            WPCM_URL . 'admin/js/wpcm-admin.js',
            array( 'wp-color-picker' ),
            WPCM_VERSION,
            true
        );
    }

    public function add_menu_page() {
        add_options_page(
            __( 'Coming Soon & Maintenance', 'wp-coming-soon-maintenance' ),
            __( 'Coming Soon', 'wp-coming-soon-maintenance' ),
            'manage_options',
            'wpcm-settings',
            array( $this, 'render_page' )
        );
    }

    public function register_settings() {
        register_setting( 'wpcm_group', self::OPTION_KEY, array(
            'sanitize_callback' => array( $this, 'sanitize' ),
        ) );

        // ── Section 1: Mode ───────────────────────────────────────
        add_settings_section( 'wpcm_mode_section', __( 'Mode', 'wp-coming-soon-maintenance' ), '__return_false', 'wpcm-settings' );

        add_settings_field( 'mode_active',
            __( 'Activate Mode', 'wp-coming-soon-maintenance' ),
            function () {
                $val = self::get( 'mode_active', '0' );
                echo '<label><input type="radio" name="' . esc_attr( self::OPTION_KEY ) . '[mode_active]" value="0" ' . checked( $val, '0', false ) . '> ' . esc_html__( 'Off (site is live)', 'wp-coming-soon-maintenance' ) . '</label><br>';
                echo '<label><input type="radio" name="' . esc_attr( self::OPTION_KEY ) . '[mode_active]" value="1" ' . checked( $val, '1', false ) . '> ' . esc_html__( 'Coming Soon', 'wp-coming-soon-maintenance' ) . '</label><br>';
                echo '<label><input type="radio" name="' . esc_attr( self::OPTION_KEY ) . '[mode_active]" value="2" ' . checked( $val, '2', false ) . '> ' . esc_html__( 'Maintenance Mode (HTTP 503)', 'wp-coming-soon-maintenance' ) . '</label>';
            },
            'wpcm-settings', 'wpcm_mode_section'
        );

        // Removed 'Allow These Roles to See Site' option.

        // ── Section 2: Content ────────────────────────────────────
        add_settings_section( 'wpcm_content_section', __( 'Page Content', 'wp-coming-soon-maintenance' ), '__return_false', 'wpcm-settings' );

        add_settings_field( 'headline',
            __( 'Headline', 'wp-coming-soon-maintenance' ),
            function () {
                $val = self::get( 'headline', __( 'Coming Soon', 'wp-coming-soon-maintenance' ) );
                echo '<input type="text" name="' . esc_attr( self::OPTION_KEY ) . '[headline]" value="' . esc_attr( $val ) . '" class="large-text" />';
            },
            'wpcm-settings', 'wpcm_content_section'
        );

        add_settings_field( 'message',
            __( 'Sub-message', 'wp-coming-soon-maintenance' ),
            function () {
                $val = self::get( 'message', __( 'We are working hard to bring you something great. Enter your email to be notified on launch.', 'wp-coming-soon-maintenance' ) );
                echo '<textarea name="' . esc_attr( self::OPTION_KEY ) . '[message]" rows="4" class="large-text">' . esc_textarea( $val ) . '</textarea>';
            },
            'wpcm-settings', 'wpcm_content_section'
        );

        add_settings_field( 'launch_date',
            __( 'Launch / End Date', 'wp-coming-soon-maintenance' ),
            function () {
                $val = self::get( 'launch_date', '' );
                echo '<input type="datetime-local" name="' . esc_attr( self::OPTION_KEY ) . '[launch_date]" value="' . esc_attr( $val ) . '" />';
                echo '<p class="description">' . esc_html__( 'Used for the countdown timer.', 'wp-coming-soon-maintenance' ) . '</p>';
            },
            'wpcm-settings', 'wpcm_content_section'
        );

        // ── Section 3: Design ─────────────────────────────────────
        add_settings_section( 'wpcm_design_section', __( 'Design', 'wp-coming-soon-maintenance' ), '__return_false', 'wpcm-settings' );

        add_settings_field( 'bg_color',
            __( 'Background Color', 'wp-coming-soon-maintenance' ),
            function () {
                $val = self::get( 'bg_color', '#1a1a2e' );
                echo '<input type="text" id="wpcm_bg_color" name="' . esc_attr( self::OPTION_KEY ) . '[bg_color]" value="' . esc_attr( $val ) . '" class="wpcm-color-picker" />';
            },
            'wpcm-settings', 'wpcm_design_section'
        );

        add_settings_field( 'text_color',
            __( 'Text Color', 'wp-coming-soon-maintenance' ),
            function () {
                $val = self::get( 'text_color', '#ffffff' );
                echo '<input type="text" id="wpcm_text_color" name="' . esc_attr( self::OPTION_KEY ) . '[text_color]" value="' . esc_attr( $val ) . '" class="wpcm-color-picker" />';
            },
            'wpcm-settings', 'wpcm_design_section'
        );

        add_settings_field( 'bg_image_url',
            __( 'Background Image URL', 'wp-coming-soon-maintenance' ),
            function () {
                $val = self::get( 'bg_image_url', '' );
                echo '<input type="url" name="' . esc_attr( self::OPTION_KEY ) . '[bg_image_url]" value="' . esc_attr( $val ) . '" class="large-text" />';
                echo '<p class="description">' . esc_html__( 'Optional. Leave blank to use background color.', 'wp-coming-soon-maintenance' ) . '</p>';
            },
            'wpcm-settings', 'wpcm_design_section'
        );

        // ── Section 4: Email Leads ────────────────────────────────
        add_settings_section( 'wpcm_leads_section', __( 'Email Lead Capture', 'wp-coming-soon-maintenance' ), '__return_false', 'wpcm-settings' );

        add_settings_field( 'show_lead_form',
            __( 'Show Email Capture Form', 'wp-coming-soon-maintenance' ),
            function () {
                $checked = checked( self::get( 'show_lead_form', '1' ), '1', false );
                echo '<input type="checkbox" name="' . esc_attr( self::OPTION_KEY ) . '[show_lead_form]" value="1" ' . $checked . ' />';
            },
            'wpcm-settings', 'wpcm_leads_section'
        );

        add_settings_field( 'notify_on_lead',
            __( 'Email Admin on New Lead', 'wp-coming-soon-maintenance' ),
            function () {
                $checked = checked( self::get( 'notify_on_lead', '1' ), '1', false );
                echo '<input type="checkbox" name="' . esc_attr( self::OPTION_KEY ) . '[notify_on_lead]" value="1" ' . $checked . ' />';
            },
            'wpcm-settings', 'wpcm_leads_section'
        );
    }

    public function sanitize( array $input ): array {
        $allowed_roles = array_keys( wp_roles()->get_names() );
        $bypass        = array_filter(
            (array) ( $input['bypass_roles'] ?? array( 'administrator' ) ),
            fn( $r ) => in_array( $r, $allowed_roles, true )
        );

        return array(
            'mode_active'     => in_array( $input['mode_active'] ?? '0', array( '0', '1', '2' ), true ) ? $input['mode_active'] : '0',
            'bypass_roles'    => array_values( $bypass ),
            'headline'        => sanitize_text_field( $input['headline']    ?? '' ),
            'message'         => wp_kses_post( $input['message']            ?? '' ),
            'launch_date'     => sanitize_text_field( $input['launch_date'] ?? '' ),
            'bg_color'        => sanitize_hex_color( $input['bg_color']     ?? '#1a1a2e' ) ?? '#1a1a2e',
            'text_color'      => sanitize_hex_color( $input['text_color']   ?? '#ffffff' ) ?? '#ffffff',
            'bg_image_url'    => esc_url_raw( $input['bg_image_url']        ?? '' ),
            'show_lead_form'  => ! empty( $input['show_lead_form'] ) ? '1' : '0',
            'notify_on_lead'  => ! empty( $input['notify_on_lead'] ) ? '1' : '0',
        );
    }

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $mode   = self::get( 'mode_active', '0' );
        $labels = array( '0' => __( 'Off', 'wp-coming-soon-maintenance' ), '1' => __( 'Coming Soon', 'wp-coming-soon-maintenance' ), '2' => __( 'Maintenance', 'wp-coming-soon-maintenance' ) );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Coming Soon & Maintenance Mode', 'wp-coming-soon-maintenance' ); ?></h1>
            <div class="notice notice-<?php echo '0' === $mode ? 'success' : 'warning'; ?>">
                <p>
                    <strong><?php esc_html_e( 'Current status:', 'wp-coming-soon-maintenance' ); ?></strong>
                    <?php echo esc_html( $labels[ $mode ] ?? __( 'Unknown', 'wp-coming-soon-maintenance' ) ); ?>
                </p>
            </div>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'wpcm_group' );
                do_settings_sections( 'wpcm-settings' );
                submit_button( __( 'Save Settings', 'wp-coming-soon-maintenance' ) );
                ?>
            </form>
        </div>
        <?php
    }
}