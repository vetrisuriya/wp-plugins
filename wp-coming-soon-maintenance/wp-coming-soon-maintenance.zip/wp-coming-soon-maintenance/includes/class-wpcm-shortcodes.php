<?php
// includes/class-wpcm-shortcodes.php
defined( 'ABSPATH' ) || exit;

class WPCM_Shortcodes {

    public function __construct() {
        add_shortcode( 'coming_soon',      array( $this, 'render_coming_soon' ) );
        add_shortcode( 'maintenance_mode', array( $this, 'render_maintenance' ) );
        add_shortcode( 'wpcm_lead_count',  array( $this, 'render_lead_count' ) );
    }

    /**
     * [coming_soon] — Renders the full coming soon panel inline on any page.
     * Useful for embedding on a custom page while the rest of the site is live.
     */
    public function render_coming_soon( array $atts ): string {
        $atts = shortcode_atts( array(
            'headline' => WPCM_Settings::get( 'headline', __( 'Coming Soon', 'wp-coming-soon-maintenance' ) ),
            'message'  => WPCM_Settings::get( 'message', '' ),
        ), $atts, 'coming_soon' );

        ob_start();
        ?>
        <div class="wpcm-inline-block">
            <h2><?php echo esc_html( $atts['headline'] ); ?></h2>
            <?php if ( $atts['message'] ) : ?>
            <p><?php echo wp_kses_post( $atts['message'] ); ?></p>
            <?php endif; ?>
            <?php if ( '1' === WPCM_Settings::get( 'show_lead_form', '1' ) ) : ?>
            <div class="wpcm-lead-form">
                <input type="email" id="wpcm-lead-email" placeholder="<?php esc_attr_e( 'Enter your email…', 'wp-coming-soon-maintenance' ); ?>" />
                <button type="button" id="wpcm-lead-btn" class="wpcm-btn"><?php esc_html_e( 'Notify Me', 'wp-coming-soon-maintenance' ); ?></button>
            </div>
            <div id="wpcm-form-msg" class="wpcm-form-msg" aria-live="polite"></div>
            <?php endif; ?>
        </div>
        <?php
        wp_enqueue_script( 'wpcm-holding', WPCM_URL . 'public/js/wpcm-holding.js', array( 'jquery' ), WPCM_VERSION, true );
        wp_localize_script( 'wpcm-holding', 'WPCMData', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'wpcm_lead_nonce' ),
            'strings'  => array(
                'success' => __( "You're on the list!", 'wp-coming-soon-maintenance' ),
                'error'   => __( 'Please try again.', 'wp-coming-soon-maintenance' ),
                'dup'     => __( 'Already subscribed.', 'wp-coming-soon-maintenance' ),
            ),
        ) );
        return ob_get_clean();
    }

    /** [maintenance_mode] — Displays a maintenance notice inline. */
    public function render_maintenance( array $atts ): string {
        $atts = shortcode_atts( array(
            'message' => __( 'This section is currently under maintenance.', 'wp-coming-soon-maintenance' ),
        ), $atts, 'maintenance_mode' );

        return '<div class="wpcm-maintenance-notice">' . wp_kses_post( $atts['message'] ) . '</div>';
    }

    /** [wpcm_lead_count] — Outputs the number of email leads collected. */
    public function render_lead_count( array $atts ): string {
        if ( ! current_user_can( 'manage_options' ) ) {
            return '';
        }
        $db = new WPCM_Leads_DB();
        return '<strong>' . esc_html( number_format_i18n( $db->get_count() ) ) . '</strong>';
    }
}