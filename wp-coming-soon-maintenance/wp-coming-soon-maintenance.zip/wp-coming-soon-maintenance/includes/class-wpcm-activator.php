<?php
// includes/class-wpcm-activator.php
defined( 'ABSPATH' ) || exit;

class WPCM_Activator {

    public static function activate() {
        self::create_leads_table();
        self::add_caps();
        flush_rewrite_rules();
        update_option( 'wpcm_version', WPCM_VERSION );
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    private static function create_leads_table() {
        global $wpdb;

        $table           = $wpdb->prefix . 'wpcm_leads';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            email       VARCHAR(200) NOT NULL,
            source      VARCHAR(100) NOT NULL DEFAULT 'holding_page',
            subscribed  TINYINT(1) NOT NULL DEFAULT 1,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY email (email),
            KEY subscribed (subscribed)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    private static function add_caps() {
        $role = get_role( 'administrator' );
        if ( $role ) {
            $role->add_cap( 'bypass_maintenance_mode' );
        }
    }
}