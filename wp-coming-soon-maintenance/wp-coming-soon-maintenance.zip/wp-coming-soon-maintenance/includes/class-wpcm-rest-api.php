<?php
// includes/class-wpcm-rest-api.php
defined( 'ABSPATH' ) || exit;

/**
 * REST endpoint: POST /wp-json/wpcm/v1/toggle
 * Used by CI/CD pipelines to enable/disable maintenance mode after deploys.
 *
 * Requires: Application Password or Cookie + nonce for authentication.
 * Requires: user must have manage_options capability.
 *
 * Body: { "mode": "0" | "1" | "2" }
 *
 * Response: { "mode": "1", "label": "Coming Soon" }
 */
class WPCM_Rest_Api {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes() {
        register_rest_route( 'wpcm/v1', '/status', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_status' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( 'wpcm/v1', '/toggle', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'toggle_mode' ),
            'permission_callback' => array( $this, 'can_toggle' ),
            'args'                => array(
                'mode' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'enum'              => array( '0', '1', '2' ),
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );

        register_rest_route( 'wpcm/v1', '/leads', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_leads' ),
            'permission_callback' => array( $this, 'can_toggle' ),
        ) );
    }

    public function can_toggle(): bool {
        return current_user_can( 'manage_options' );
    }

    public function get_status( WP_REST_Request $request ): WP_REST_Response {
        $mode   = WPCM_Settings::get( 'mode_active', '0' );
        $labels = array( '0' => 'off', '1' => 'coming_soon', '2' => 'maintenance' );
        $db     = new WPCM_Leads_DB();

        return new WP_REST_Response( array(
            'mode'        => $mode,
            'label'       => $labels[ $mode ] ?? 'unknown',
            'leads_count' => $db->get_count(),
            'total_visits'=> (int) get_option( 'wpcm_total_visits', 0 ),
        ), 200 );
    }

    public function toggle_mode( WP_REST_Request $request ): WP_REST_Response {
        $mode = $request->get_param( 'mode' );

        $options                = get_option( WPCM_Settings::OPTION_KEY, array() );
        $options['mode_active'] = $mode;
        update_option( WPCM_Settings::OPTION_KEY, $options );

        $labels = array( '0' => 'off', '1' => 'coming_soon', '2' => 'maintenance' );

        return new WP_REST_Response( array(
            'success' => true,
            'mode'    => $mode,
            'label'   => $labels[ $mode ],
        ), 200 );
    }

    public function get_leads( WP_REST_Request $request ): WP_REST_Response {
        $db    = new WPCM_Leads_DB();
        $leads = $db->get_all();
        return new WP_REST_Response( array(
            'count' => count( $leads ),
            'leads' => $leads,
        ), 200 );
    }
}