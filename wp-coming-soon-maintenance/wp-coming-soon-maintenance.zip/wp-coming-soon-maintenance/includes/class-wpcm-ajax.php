<?php
// includes/class-wpcm-ajax.php
defined( 'ABSPATH' ) || exit;

class WPCM_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_wpcm_capture_lead',        array( $this, 'capture_lead' ) );
        add_action( 'wp_ajax_nopriv_wpcm_capture_lead', array( $this, 'capture_lead' ) );
    }

    public function capture_lead() {
        check_ajax_referer( 'wpcm_lead_nonce', 'nonce' );

        $email = sanitize_email( $_POST['email'] ?? '' );

        if ( ! is_email( $email ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'wp-coming-soon-maintenance' ) ) );
        }

        $db     = new WPCM_Leads_DB();
        $result = $db->insert( $email );

        if ( is_wp_error( $result ) ) {
            $code = $result->get_error_code();
            wp_send_json_error( array(
                'message' => $result->get_error_message(),
                'code'    => $code,
            ) );
        }

        // Increment Options API counter.
        $total = (int) get_option( 'wpcm_total_leads', 0 );
        update_option( 'wpcm_total_leads', $total + 1, false );

        // Send emails.
        $emailer = new WPCM_Email();
        $emailer->send_lead_confirmation( $email );

        if ( '1' === WPCM_Settings::get( 'notify_on_lead', '1' ) ) {
            $emailer->notify_admin_of_lead( $email );
        }

        wp_send_json_success( array(
            'message' => __( "You're on the list! We'll notify you on launch.", 'wp-coming-soon-maintenance' ),
        ) );
    }
}