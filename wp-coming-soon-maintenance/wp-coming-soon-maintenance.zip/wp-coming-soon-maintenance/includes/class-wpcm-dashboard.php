<?php
// includes/class-wpcm-dashboard.php
defined( 'ABSPATH' ) || exit;

class WPCM_Dashboard {

    public function __construct() {
        add_action( 'wp_dashboard_setup', array( $this, 'add_dashboard_widget' ) );
    }

    public function add_dashboard_widget() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        wp_add_dashboard_widget(
            'wpcm_dashboard_widget',
            __( 'Coming Soon Status', 'wp-coming-soon-maintenance' ),
            array( $this, 'render_widget' )
        );
    }

    public function render_widget() {
        $mode        = WPCM_Settings::get( 'mode_active', '0' );
        $labels      = array( '0' => __( 'Off — site is live', 'wp-coming-soon-maintenance' ), '1' => __( 'Coming Soon', 'wp-coming-soon-maintenance' ), '2' => __( 'Maintenance Mode (503)', 'wp-coming-soon-maintenance' ) );
        $label       = $labels[ $mode ] ?? __( 'Unknown', 'wp-coming-soon-maintenance' );
        $colors      = array( '0' => '#46b450', '1' => '#f0ad4e', '2' => '#dc3232' );
        $color       = $colors[ $mode ] ?? '#000';
        $db          = new WPCM_Leads_DB();
        $leads       = $db->get_count();
        $visits      = number_format_i18n( (int) get_option( 'wpcm_total_visits', 0 ) );
        $launch_date = WPCM_Settings::get( 'launch_date', '' );

        echo '<p><strong>' . esc_html__( 'Current Mode:', 'wp-coming-soon-maintenance' ) . '</strong> ';
        echo '<span style="color:' . esc_attr( $color ) . '; font-weight:bold;">' . esc_html( $label ) . '</span></p>';
        echo '<p><strong>' . esc_html__( 'Email Leads:', 'wp-coming-soon-maintenance' ) . '</strong> ' . esc_html( number_format_i18n( $leads ) ) . '</p>';
        echo '<p><strong>' . esc_html__( 'Holding Page Visits:', 'wp-coming-soon-maintenance' ) . '</strong> ' . esc_html( $visits ) . '</p>';

        if ( $launch_date ) {
            echo '<p><strong>' . esc_html__( 'Launch Date:', 'wp-coming-soon-maintenance' ) . '</strong> ' . esc_html( $launch_date ) . '</p>';
        }

        echo '<p><a href="' . esc_url( admin_url( 'options-general.php?page=wpcm-settings' ) ) . '" class="button">' . esc_html__( 'Configure', 'wp-coming-soon-maintenance' ) . '</a></p>';
    }
}