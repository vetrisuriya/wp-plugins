<?php
/**
 * uninstall.php — Runs on plugin deletion.
 * Timeline data lives in post_content as block comment delimiters.
 * No custom DB tables or options in v1.0.0.
 * @package WP_Timeline
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;