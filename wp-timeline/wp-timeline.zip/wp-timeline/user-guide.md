# WP Timeline Block — User Guide

## Table of Contents

- [Why This Block Exists](#why-this-block-exists)
- [Folder Structure](#folder-structure)
- [Installation](#installation)
- [How to Use the Block](#how-to-use-the-block)
  - [Inserting the Block](#inserting-the-block)
  - [Adding Timeline Items](#adding-timeline-items)
  - [Editing a Timeline Item](#editing-a-timeline-item)
  - [Changing Orientation](#changing-orientation)
  - [Layout Positions](#layout-positions)
  - [Connector Styles](#connector-styles)
  - [Dot Colour per Item](#dot-colour-per-item)
  - [Reordering Items](#reordering-items)
- [Inspector Controls Reference](#inspector-controls-reference)
- [Block Variations](#block-variations)
- [Block Patterns](#block-patterns)
- [Block Context — How Parent Talks to Children](#block-context--how-parent-talks-to-children)
- [Alternating Layout & Why CSS Handles It](#alternating-layout--why-css-handles-it)
- [Accessibility Features](#accessibility-features)
- [For Developers — Build from Source](#for-developers--build-from-source)
- [FAQ](#faq)

---

## Why This Block Exists

Company pages, portfolio sites, and marketing pages all need timeline layouts — company history, hiring steps, project roadmaps. Without a proper block, editors:

- Build timelines from nested columns and heading blocks
- Lose structure when switching themes (CSS classes change)
- Can't reorder items without cut/paste
- Can't apply per-item colours without writing custom CSS
- End up with completely inaccessible markup (`<div>2020</div>` instead of `<time dateTime="2020">`)

This block solves all of these. It uses a **parent/child InnerBlocks architecture** — the parent (Timeline) holds child blocks (Timeline Items), each of which is a full Gutenberg block with a drag handle, toolbar, inspector controls, and its own inner content area.

---

## Folder Structure

```
wp-timeline/
├── wp-timeline.php                     ← wptl-wp-timeline.php
├── timeline-block.json                 ← wptl-timeline-block.json      (at root — FIXED)
├── timeline-item-block.json            ← wptl-timeline-item-block.json (at root — FIXED)
├── uninstall.php                       ← wptl-uninstall.php
├── readme.txt                          ← wptl-readme.txt
├── package.json                        ← wptl-package.json
│
├── build/
│   ├── timeline/
│   │   ├── index.js                    ← wptl-build-timeline-index.js
│   │   ├── index.asset.php             ← wptl-build-timeline-index.asset.php
│   │   ├── style-index.css             ← wptl-build-timeline-style-index.css
│   │   └── editor.css                  ← wptl-build-timeline-editor.css
│   └── timeline-item/
│       ├── index.js                    ← wptl-build-item-index.js      (bugs fixed)
│       └── index.asset.php             ← wptl-build-item-index.asset.php
│
└── src/
    ├── timeline/
    │   ├── index.js                    ← wptl-src-timeline-index.js
    │   ├── edit.js                     ← wptl-src-timeline-edit.js
    │   ├── save.js                     ← wptl-src-timeline-save.js
    │   ├── style.scss                  ← from reference .md
    │   └── editor.scss                 ← from reference .md
    └── timeline-item/
        ├── index.js                    ← wptl-src-item-index.js
        ├── edit.js                     ← wptl-src-item-edit.js         (bugs fixed)
        └── save.js                     ← wptl-src-item-save.js         (dateTime fixed)
```

---

## Installation

1. Arrange all files in the structure above
2. ZIP the `wp-timeline/` folder
3. Go to **Plugins → Add New → Upload Plugin**
4. Upload and click **Install Now → Activate Plugin**

No `npm install` needed — the `build/` directory is pre-compiled.

---

## How to Use the Block

### Inserting the Block

1. Click the **+** inserter in any post or page
2. Search for **Timeline**
3. Insert — two starter timeline items appear automatically (2024, 2025)

**Or use a Pattern:** Patterns tab → **Timeline** category → choose a pre-filled layout.

### Adding Timeline Items

Click the **+ Timeline Item** button that appears at the bottom of the timeline. Each item is its own block with full editing support.

To remove an item: select it and click **Remove block** in the toolbar (⋮ menu) or press Backspace.

### Editing a Timeline Item

**Date field** — Click the date/year text to edit it inline. Only plain text is allowed (no formatting).

**Title (h3)** — Click the title text to edit. Bold and italic are allowed.

**Body content** — Click inside the body area. Any WordPress block can be inserted here (paragraphs, lists, images, buttons, etc.). This uses InnerBlocks — a full block editor experience.

**Dot colour** — Click the item to select it, then open **Inspector Controls → Item Settings → Dot Color** to pick a colour from the site's colour palette.

### Changing Orientation

**Toolbar:** Click the **list-view icon** (Vertical) or **→ icon** (Horizontal) in the block toolbar.

**Sidebar:** Inspector Controls → Timeline Layout → Orientation dropdown.

### Layout Positions

Only applies to vertical orientation:

| Option | Behaviour |
|---|---|
| **All Left** (default) | All items on the left side of the connector |
| **All Right** | All items on the right side |
| **Alternating** | Odd items left, even items right — CSS `:nth-child` handles this |
| **Centered** | Connector line in the centre; items both sides |

### Connector Styles

Inspector Controls → Timeline Layout → Connector Line Style:

| Style | Appearance |
|---|---|
| **Solid** (default) | Solid 2px line |
| **Dashed** | Dashed line segments |
| **Dotted** | Dotted line |
| **None** | No connector line drawn |

Toggle **Show Connector Line** to hide the connector entirely.

### Dot Colour per Item

Each timeline item has its own dot colour. Click any item, open **Inspector Controls → Item Settings**, and use the **Dot Color** colour palette.

The dot colour also affects the shadow ring around each dot (`box-shadow: 0 0 0 4px` with 12% opacity).

### Reordering Items

Drag the **⠿ handle** in any item's block toolbar up or down to reorder.

Or use **View → List View** to drag items in the list panel.

---

## Inspector Controls Reference

### Parent Timeline Block

| Panel | Setting | Default | Description |
|---|---|---|---|
| Timeline Layout | **Orientation** | Vertical | Vertical column or Horizontal row |
| Timeline Layout | **Item Position** | All Left | Left / Right / Alternating / Centered |
| Timeline Layout | **Connector Line Style** | Solid | Solid / Dashed / Dotted / None |
| Timeline Layout | **Show Connector Line** | On | Toggle connector visibility |
| Timeline Layout | **Dot Size (px)** | 16 | Size of the dot circle (8–40px) |

### Child Timeline Item Block

| Panel | Setting | Default | Description |
|---|---|---|---|
| Item Settings | **Dot Color** | #0073aa (blue) | Accent colour for this item's dot |
| Item Settings | **Position Override** | Follow parent | Override this item's side (left/right) — hidden when parent is Alternating |

---

## Block Variations

Block Variations appear as pre-configured Timeline options in the block inserter.

| Variation | Orientation | Layout | Connector |
|---|---|---|---|
| **Company History** | Vertical | Alternating | Solid |
| **Process Steps** | Horizontal | Center | Dashed |
| **Project Roadmap** | Vertical | All Left | Dotted |

---

## Block Patterns

Pre-filled templates in the Patterns tab under **Timeline**:

| Pattern | Items | Description |
|---|---|---|
| **4-Step Company History** | 4 | Alternating vertical; 2018 → 2020 → 2022 → 2024 milestones |
| **3-Step Horizontal Process** | 3 | Apply Online → Get Reviewed → Start Working |
| **Project Roadmap** | 4 | Q1–Q4 2025; Discovery → Design → Development → Launch |

---

## Block Context — How Parent Talks to Children

Block Context is the official WordPress mechanism for parent-to-child data flow. It is declared in `block.json` — no custom React code needed.

### How it works

**1. Parent declares what it provides (`timeline-block.json`):**
```json
"providesContext": {
    "wp-timeline/orientation":   "orientation",
    "wp-timeline/layout":        "layout",
    "wp-timeline/dotSize":       "dotSize",
    "wp-timeline/showConnector": "showConnector"
}
```

**2. Child declares what it reads (`timeline-item-block.json`):**
```json
"usesContext": [
    "wp-timeline/orientation",
    "wp-timeline/layout",
    "wp-timeline/dotSize",
    "wp-timeline/showConnector"
]
```

**3. Child reads from the `context` prop (NOT from `useContext`):**
```js
// ✅ CORRECT — context is a prop injected by WordPress
export default function Edit( { attributes, setAttributes, context } ) {
    const orientation = context[ 'wp-timeline/orientation' ] ?? 'vertical';
}

// ❌ WRONG — this is not how Block Context works
import { useContext } from '@wordpress/element'; // unused!
```

**4. Context is REACTIVE** — when the parent's `orientation` attribute changes, all children re-render immediately with the new value. No event listeners, no `useState`, no explicit data passing.

### What context is NOT available in

Context is **editor-only** — it is not available in `save()`. The save function generates static HTML that goes into the database. For front-end alternating layouts, use CSS `:nth-child()` selectors instead.

---

## Alternating Layout & Why CSS Handles It

For the alternating (left/right) layout, the child `save.js` cannot use context. Instead, the CSS uses `:nth-child()` selectors on the parent wrapper:

```css
/* Odd items (1st, 3rd, 5th...) — left side */
.wp-block-wp-timeline-timeline.is-layout-alternate
    .wp-block-wp-timeline-timeline-item:nth-child(odd) {
    flex-direction: row;
}

/* Even items (2nd, 4th, 6th...) — right side */
.wp-block-wp-timeline-timeline.is-layout-alternate
    .wp-block-wp-timeline-timeline-item:nth-child(even) {
    flex-direction: row-reverse;
    text-align: right;
}
```

This is better than JavaScript because:
- Works with zero runtime processing
- Always correct even after reordering (positions recompute from DOM order)
- Fully cacheable (no server-side calculation needed)
- Works without JavaScript

In the **editor**, the child's `edit()` uses `useSelect → getBlockIndex(clientId)` to derive the alternating side for a live preview. This is purely an editor convenience — not used in the saved HTML.

---

## Accessibility Features

| Feature | Implementation |
|---|---|
| **Semantic `<time>` element** | Date field renders as `<time dateTime="{value}">` — parseable by screen readers and search engines |
| **`aria-hidden` on dot** | The visual dot `<div class="timeline-item__dot">` has `aria-hidden="true"` — decorative, not announced |
| **h3 heading structure** | Title is an h3, maintaining document outline within the timeline |
| **Keyboard navigation** | Each item is a Gutenberg block — fully keyboard-navigable in both editor and frontend |
| **`<time>` dateTime** | For years: `dateTime="2024"`. For full dates, use ISO 8601: `dateTime="2024-03-15"` |

---

## For Developers — Build from Source

### Requirements
- Node.js 18+, npm 8+

### Setup

```bash
cd wp-content/plugins/wp-timeline
npm install
npm run build        # builds both blocks → build/timeline/ + build/timeline-item/
npm run start        # watch mode
```

### Copying SCSS files

Copy `style.scss` and `editor.scss` from the reference file (`WP_Block_08_Timeline.md`) into `src/timeline/`. The SCSS is correct as-is — `@wordpress/scripts` compiles it automatically.

### Fixes already applied to src/ files

| File | Fix |
|---|---|
| `src/timeline-item/edit.js` | Removed unused `useContext` import; added comment |
| `src/timeline-item/save.js` | Added `dateTime` attribute to `<time>` element |
| Both `block.json` files | Paths corrected for standalone plugin root placement |
| `src/*/` | Block names updated: `my-blocks/timeline` → `wp-timeline/timeline` |

---

## FAQ

**The timeline items show but the connector line doesn't appear.**
Confirm `build/timeline/style-index.css` is loading. The connector line uses `::before` on the parent element — if the CSS is missing, the pseudo-element doesn't render. Also check that `showConnector` attribute is `true` and the parent doesn't have the `no-connector` class.

**The alternating layout (left/right) doesn't work on the front end.**
Alternating uses CSS `:nth-child()`. Confirm `build/timeline/style-index.css` contains the `.is-layout-alternate` rules. Open DevTools and inspect the parent wrapper — it should have class `is-layout-alternate`. If the class is present but items aren't alternating, check CSS specificity.

**A child block shows "This block is locked and cannot be modified."**
This happens when `templateLock: 'all'` is set. The pre-compiled `build/timeline/index.js` uses `templateLock: false` — ensure you're using the correct build file.

**The horizontal layout overflows on mobile.**
The CSS includes a responsive fallback that collapses horizontal to vertical at 640px viewport width. If this isn't working, confirm the full `build/timeline/style-index.css` is loaded (not a cached version).

**Colour picker shows "No matching palettes" or is empty.**
The `ColorPalette` component shows the theme's colour palette. If the palette is empty, the theme may not have defined any colours. Add custom colours in **Appearance → Editor → Styles → Colors** or in `theme.json`.

**The dateTime attribute shows wrong data.**
The `dateTime` attribute is set to the raw text value entered in the Date field. For display values like "Q1 2025" or "Spring 2022", the dateTime will be that string — technically invalid ISO 8601, but functionally acceptable. For precise dates, enter in ISO 8601 format: `2025-03-15`.