<?php
/**
 * Plugin Name:       WP Timeline Block
 * Plugin URI:        https://example.com/wp-timeline
 * Description:       A structured timeline block with parent/child InnerBlocks architecture. Supports vertical/horizontal orientation, alternating left-right layout, connector styles, dot colours, and Block Context for parent-to-child communication.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            Your Name
 * Author URI:        https://example.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-timeline
 * Domain Path:       /languages
 *
 * @package WP_Timeline
 */

defined( 'ABSPATH' ) || exit;

define( 'WPTL_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPTL_URL', plugin_dir_url( __FILE__ ) );
define( 'WPTL_VER', '1.0.0' );

/**
 * Register both blocks.
 *
 * PATH FIX vs REFERENCE:
 * ──────────────────────────────────────────────────────────────────
 * Reference nested block.json files inside blocks/timeline/ and
 * blocks/timeline-item/. WordPress resolves file:// paths in block.json
 * RELATIVE TO the block.json file location. So paths like
 * "editorScript": "file:./build/index.js" from blocks/timeline/block.json
 * resolve to blocks/timeline/build/index.js — deeply nested, hard to manage.
 *
 * FIX: Both block.json files are at the PLUGIN ROOT.
 *   timeline-block.json      → "file:./build/timeline/index.js"  ✅
 *   timeline-item-block.json → "file:./build/timeline-item/index.js" ✅
 * ──────────────────────────────────────────────────────────────────
 */
add_action( 'init', 'wptl_register_blocks' );
function wptl_register_blocks(): void {
    // Parent timeline block.
    register_block_type( WPTL_DIR . 'timeline-block.json' );

    // Child timeline-item block — must be registered separately.
    register_block_type( WPTL_DIR . 'timeline-item-block.json' );

    load_plugin_textdomain(
        'wp-timeline',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );
}

/**
 * Register Block Patterns.
 *
 * Patterns are registered in PHP (not JS) so they appear in the pattern
 * library immediately without waiting for editor JS to load.
 */
add_action( 'init', 'wptl_register_patterns' );
function wptl_register_patterns(): void {
    register_block_pattern_category(
        'wp-timeline',
        array( 'label' => __( 'Timeline', 'wp-timeline' ) )
    );

    register_block_pattern(
        'wp-timeline/company-history-4',
        array(
            'title'       => __( '4-Step Company History', 'wp-timeline' ),
            'description' => __( 'Alternating vertical timeline with four company milestones.', 'wp-timeline' ),
            'categories'  => array( 'wp-timeline', 'featured' ),
            'content'     => '<!-- wp:wp-timeline/timeline {"layout":"alternate","orientation":"vertical","connectorStyle":"solid"} -->
<!-- wp:wp-timeline/timeline-item {"date":"2018","title":"Company Founded","dotColor":"#0073aa"} -->
<!-- wp:core/paragraph --><p>Started in a small garage with a big idea and three passionate founders.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- wp:wp-timeline/timeline-item {"date":"2020","title":"First Product Launch","dotColor":"#00a32a"} -->
<!-- wp:core/paragraph --><p>Released our flagship product to 500 early customers.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- wp:wp-timeline/timeline-item {"date":"2022","title":"Series A Funding","dotColor":"#d63638"} -->
<!-- wp:core/paragraph --><p>Raised $4M to expand the team and launch internationally.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- wp:wp-timeline/timeline-item {"date":"2024","title":"10,000 Customers","dotColor":"#f0b849"} -->
<!-- wp:core/paragraph --><p>Crossed 10,000 active customers across 40 countries.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- /wp:wp-timeline/timeline -->',
        )
    );

    register_block_pattern(
        'wp-timeline/horizontal-process-3',
        array(
            'title'       => __( '3-Step Horizontal Process', 'wp-timeline' ),
            'description' => __( 'Horizontal dashed connector steps for a workflow or hiring process.', 'wp-timeline' ),
            'categories'  => array( 'wp-timeline' ),
            'content'     => '<!-- wp:wp-timeline/timeline {"orientation":"horizontal","layout":"center","connectorStyle":"dashed"} -->
<!-- wp:wp-timeline/timeline-item {"date":"Step 1","title":"Apply Online","dotColor":"#0073aa"} -->
<!-- wp:core/paragraph --><p>Fill in the form — takes under 5 minutes.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- wp:wp-timeline/timeline-item {"date":"Step 2","title":"Get Reviewed","dotColor":"#0073aa"} -->
<!-- wp:core/paragraph --><p>Our team reviews your application within 48 hours.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- wp:wp-timeline/timeline-item {"date":"Step 3","title":"Start Working","dotColor":"#00a32a"} -->
<!-- wp:core/paragraph --><p>Onboard and hit the ground running on day one.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- /wp:wp-timeline/timeline -->',
        )
    );

    register_block_pattern(
        'wp-timeline/project-roadmap',
        array(
            'title'       => __( 'Project Roadmap', 'wp-timeline' ),
            'description' => __( 'Left-aligned dotted vertical roadmap with quarterly milestones.', 'wp-timeline' ),
            'categories'  => array( 'wp-timeline' ),
            'content'     => '<!-- wp:wp-timeline/timeline {"orientation":"vertical","layout":"left","connectorStyle":"dotted"} -->
<!-- wp:wp-timeline/timeline-item {"date":"Q1 2025","title":"Discovery & Planning","dotColor":"#0073aa"} -->
<!-- wp:core/paragraph --><p>Stakeholder interviews, requirements gathering, and project scoping.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- wp:wp-timeline/timeline-item {"date":"Q2 2025","title":"Design & Prototype","dotColor":"#9b51e0"} -->
<!-- wp:core/paragraph --><p>Wireframes, high-fidelity designs, and interactive prototype review.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- wp:wp-timeline/timeline-item {"date":"Q3 2025","title":"Development","dotColor":"#00a32a"} -->
<!-- wp:core/paragraph --><p>Full-stack implementation, API integration, and QA testing.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- wp:wp-timeline/timeline-item {"date":"Q4 2025","title":"Launch","dotColor":"#f0b849"} -->
<!-- wp:core/paragraph --><p>Public launch, performance monitoring, and post-launch support.</p><!-- /wp:core/paragraph -->
<!-- /wp:wp-timeline/timeline-item -->
<!-- /wp:wp-timeline/timeline -->',
        )
    );
}