/**
 * src/timeline/index.js — Parent Timeline block entry point (JSX source).
 * FILE: wp-timeline/src/timeline/index.js
 * Compiled to: build/timeline/index.js
 */
import { registerBlockType } from '@wordpress/blocks';
import { __ } from '@wordpress/i18n';
import Edit     from './edit';
import save     from './save';
import metadata from '../../timeline-block.json';
import './style.scss';
import './editor.scss';

registerBlockType( metadata.name, {
    edit: Edit,
    save,
    variations: [
        {
            name:        'company-history',
            title:       __( 'Company History', 'wp-timeline' ),
            description: __( 'Vertical timeline with alternating left/right layout.', 'wp-timeline' ),
            icon:        'building',
            attributes:  { orientation: 'vertical', layout: 'alternate', connectorStyle: 'solid' },
            isActive:    ( { layout } ) => layout === 'alternate',
        },
        {
            name:        'process-steps',
            title:       __( 'Process Steps', 'wp-timeline' ),
            description: __( 'Horizontal steps for a workflow or process.', 'wp-timeline' ),
            icon:        'arrow-right-alt2',
            attributes:  { orientation: 'horizontal', layout: 'center', connectorStyle: 'dashed' },
            isActive:    ( { orientation } ) => orientation === 'horizontal',
        },
        {
            name:        'project-roadmap',
            title:       __( 'Project Roadmap', 'wp-timeline' ),
            description: __( 'Left-aligned dotted vertical roadmap.', 'wp-timeline' ),
            icon:        'flag',
            attributes:  { orientation: 'vertical', layout: 'left', connectorStyle: 'dotted' },
            isActive:    ( { layout, connectorStyle } ) => layout === 'left' && connectorStyle === 'dotted',
        },
    ],
} );