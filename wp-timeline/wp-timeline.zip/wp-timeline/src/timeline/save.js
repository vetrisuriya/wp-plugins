/**
 * src/timeline/save.js — Parent Timeline block static save.
 * FILE: wp-timeline/src/timeline/save.js
 */
import { useBlockProps, useInnerBlocksProps } from '@wordpress/block-editor';

export default function save( { attributes } ) {
    const { orientation, connectorStyle, layout, showConnector, dotSize } = attributes;

    const classes = [
        `is-${ orientation }`,
        `is-layout-${ layout }`,
        `connector-${ connectorStyle }`,
        !showConnector ? 'no-connector' : '',
    ].filter( Boolean );

    const blockProps = useBlockProps.save( {
        className: classes.join( ' ' ),
        style: { '--timeline-dot-size': `${ dotSize }px` },
    } );

    const innerBlocksProps = useInnerBlocksProps.save( blockProps );
    return <div { ...innerBlocksProps } />;
}