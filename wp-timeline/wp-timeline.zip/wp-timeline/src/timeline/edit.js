/**
 * src/timeline/edit.js — Parent Timeline Edit component (JSX source).
 * FILE: wp-timeline/src/timeline/edit.js
 * from reference (correct as-is — no bugs, updated block name only).
 */
import {
    useBlockProps,
    useInnerBlocksProps,
    InspectorControls,
    BlockControls,
} from '@wordpress/block-editor';
import {
    PanelBody, SelectControl, RangeControl, ToggleControl, ToolbarGroup, ToolbarButton,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';

const TEMPLATE = [
    [ 'wp-timeline/timeline-item', { date: '2024', title: __( 'First Milestone',  'wp-timeline' ) } ],
    [ 'wp-timeline/timeline-item', { date: '2025', title: __( 'Second Milestone', 'wp-timeline' ) } ],
];
const ALLOWED_BLOCKS = [ 'wp-timeline/timeline-item' ];

export default function Edit( { attributes, setAttributes } ) {
    const { orientation, connectorStyle, layout, showConnector, dotSize } = attributes;

    const blockProps = useBlockProps( {
        className: [ `is-${ orientation }`, `is-layout-${ layout }`, `connector-${ connectorStyle }` ].join(' '),
        style: { '--timeline-dot-size': `${ dotSize }px` },
    } );

    const innerBlocksProps = useInnerBlocksProps( blockProps, {
        allowedBlocks:  ALLOWED_BLOCKS,
        template:       TEMPLATE,
        templateLock:   false,
        orientation:    orientation === 'horizontal' ? 'horizontal' : 'vertical',
        renderAppender: useInnerBlocksProps.ButtonBlockAppender,
    } );

    return (
        <>
            <InspectorControls>
                <PanelBody title={ __( 'Timeline Layout', 'wp-timeline' ) } initialOpen>
                    <SelectControl label={ __('Orientation','wp-timeline') } value={orientation}
                        options={[{value:'vertical',label:__('Vertical','wp-timeline')},{value:'horizontal',label:__('Horizontal','wp-timeline')}]}
                        onChange={ (v) => setAttributes({orientation:v}) } />
                    <SelectControl label={ __('Item Position','wp-timeline') } value={layout}
                        options={[{value:'left',label:__('All Left','wp-timeline')},{value:'right',label:__('All Right','wp-timeline')},{value:'alternate',label:__('Alternating','wp-timeline')},{value:'center',label:__('Centered','wp-timeline')}]}
                        onChange={ (v) => setAttributes({layout:v}) }
                        help={ __('Only applies to vertical orientation.','wp-timeline') } />
                    <SelectControl label={ __('Connector Style','wp-timeline') } value={connectorStyle}
                        options={[{value:'solid',label:__('Solid','wp-timeline')},{value:'dashed',label:__('Dashed','wp-timeline')},{value:'dotted',label:__('Dotted','wp-timeline')},{value:'none',label:__('None','wp-timeline')}]}
                        onChange={ (v) => setAttributes({connectorStyle:v}) } />
                    <ToggleControl label={__('Show Connector Line','wp-timeline')} checked={showConnector} onChange={(v)=>setAttributes({showConnector:v})} />
                    <RangeControl label={__('Dot Size (px)','wp-timeline')} value={dotSize} onChange={(v)=>setAttributes({dotSize:v})} min={8} max={40} />
                </PanelBody>
            </InspectorControls>
            <BlockControls>
                <ToolbarGroup>
                    <ToolbarButton icon="list-view" label={__('Vertical','wp-timeline')} isActive={orientation==='vertical'} onClick={()=>setAttributes({orientation:'vertical'})} />
                    <ToolbarButton icon="arrow-right-alt2" label={__('Horizontal','wp-timeline')} isActive={orientation==='horizontal'} onClick={()=>setAttributes({orientation:'horizontal'})} />
                </ToolbarGroup>
            </BlockControls>
            <div { ...innerBlocksProps } />
        </>
    );
}