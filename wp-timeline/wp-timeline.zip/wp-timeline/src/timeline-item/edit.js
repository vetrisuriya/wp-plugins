/**
 * src/timeline-item/edit.js — Child Timeline Item Edit component (JSX source).
 * FILE: wp-timeline/src/timeline-item/edit.js
 *
 * BUGS FIXED vs REFERENCE:
 *   Bug 2 — Removed unused `import { useContext } from '@wordpress/element'`.
 *            Context arrives as the `context` prop — no React hook needed.
 *   Bug 3 — <time> now has dateTime attribute in save.js (see src/timeline-item/save.js).
 */
import {
    useBlockProps,
    useInnerBlocksProps,
    InspectorControls,
    RichText,
    ColorPalette,
} from '@wordpress/block-editor';
import { PanelBody, SelectControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
// Note: useContext is NOT needed — context arrives as a function prop.
import { useSelect } from '@wordpress/data';

export default function Edit( { attributes, setAttributes, context, clientId } ) {
    const { date, title, dotColor, side } = attributes;

    // Read parent context (declared via usesContext in block.json)
    const orientation   = context[ 'wp-timeline/orientation' ]   ?? 'vertical';
    const layout        = context[ 'wp-timeline/layout' ]        ?? 'left';
    const dotSize       = context[ 'wp-timeline/dotSize' ]       ?? 16;
    const showConnector = context[ 'wp-timeline/showConnector' ] ?? true;

    // Get block index for alternating layout preview in the editor
    const blockIndex = useSelect(
        ( select ) => select( 'core/block-editor' ).getBlockIndex( clientId ),
        [ clientId ]
    );

    const effectiveSide = layout === 'alternate'
        ? ( blockIndex % 2 === 0 ? 'left' : 'right' )
        : ( side === 'auto' ? layout : side );

    const blockProps = useBlockProps( {
        className: `timeline-item--${ effectiveSide } is-${ orientation }`,
        style: {
            '--item-dot-color': dotColor,
            '--item-dot-size':  `${ dotSize }px`,
        },
    } );

    const innerBlocksProps = useInnerBlocksProps(
        { className: 'timeline-item__content' },
        {
            template:     [ [ 'core/paragraph', { placeholder: __( 'Add description…', 'wp-timeline' ) } ] ],
            templateLock: false,
        }
    );

    return (
        <>
            <InspectorControls>
                <PanelBody title={ __( 'Item Settings', 'wp-timeline' ) } initialOpen>
                    <p className="components-base-control__label">
                        { __( 'Dot Color', 'wp-timeline' ) }
                    </p>
                    <ColorPalette
                        value={ dotColor }
                        onChange={ ( v ) => setAttributes( { dotColor: v || '#0073aa' } ) }
                    />
                    { layout !== 'alternate' && (
                        <SelectControl
                            label={ __( 'Position Override', 'wp-timeline' ) }
                            value={ side }
                            options={ [
                                { value: 'auto',  label: __( 'Follow parent setting', 'wp-timeline' ) },
                                { value: 'left',  label: __( 'Left',  'wp-timeline' ) },
                                { value: 'right', label: __( 'Right', 'wp-timeline' ) },
                            ] }
                            onChange={ ( v ) => setAttributes( { side: v } ) }
                        />
                    ) }
                </PanelBody>
            </InspectorControls>

            <div { ...blockProps }>
                { showConnector && (
                    <div
                        className="timeline-item__dot"
                        style={ { backgroundColor: dotColor, width: `${ dotSize }px`, height: `${ dotSize }px` } }
                        aria-hidden="true"
                    />
                ) }
                <RichText
                    tagName="time"
                    className="timeline-item__date"
                    placeholder={ __( 'Date or year…', 'wp-timeline' ) }
                    value={ date }
                    onChange={ ( v ) => setAttributes( { date: v } ) }
                    allowedFormats={ [] }
                />
                <RichText
                    tagName="h3"
                    className="timeline-item__title"
                    placeholder={ __( 'Milestone or event title…', 'wp-timeline' ) }
                    value={ title }
                    onChange={ ( v ) => setAttributes( { title: v } ) }
                    allowedFormats={ [ 'core/bold', 'core/italic' ] }
                />
                <div { ...innerBlocksProps } />
            </div>
        </>
    );
}