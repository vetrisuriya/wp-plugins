/**
 * src/timeline-item/save.js — Child Timeline Item static save.
 * FILE: wp-timeline/src/timeline-item/save.js
 *
 * BUG FIXED: Added dateTime attribute to <time> element for accessibility.
 * Context is NOT available in save() — alternating layout handled by
 * CSS :nth-child() selectors on the parent.
 */
import { useBlockProps, useInnerBlocksProps, RichText } from '@wordpress/block-editor';

export default function save( { attributes } ) {
    const { date, title, dotColor, side } = attributes;

    const blockProps = useBlockProps.save( {
        className: `timeline-item--${ side === 'auto' ? 'auto' : side }`,
        style: { '--item-dot-color': dotColor },
    } );

    const innerBlocksProps = useInnerBlocksProps.save(
        { className: 'timeline-item__content' }
    );

    return (
        <div { ...blockProps }>
            <div
                className="timeline-item__dot"
                style={ { backgroundColor: dotColor } }
                aria-hidden="true"
            />
            { /* BUG FIX: dateTime attribute added for semantic HTML + a11y */ }
            <RichText.Content
                tagName="time"
                className="timeline-item__date"
                value={ date }
                dateTime={ date }
            />
            <RichText.Content
                tagName="h3"
                className="timeline-item__title"
                value={ title }
            />
            <div { ...innerBlocksProps } />
        </div>
    );
}