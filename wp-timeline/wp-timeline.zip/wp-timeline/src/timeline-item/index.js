/**
 * src/timeline-item/index.js — Child Timeline Item block entry point.
 * FILE: wp-timeline/src/timeline-item/index.js
 * Compiled to: build/timeline-item/index.js
 */
import { registerBlockType } from '@wordpress/blocks';
import metadata from '../../timeline-item-block.json';
import Edit from './edit';
import save from './save';

registerBlockType( metadata.name, { edit: Edit, save } );