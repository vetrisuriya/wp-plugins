=== WP Timeline Block ===
Contributors:      yourname
Tags:              timeline, history, roadmap, process steps, milestones, gutenberg block
Requires at least: 6.4
Tested up to:      6.7
Stable tag:        1.0.0
Requires PHP:      8.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A structured parent/child timeline block for company history, project roadmaps, process steps, and event schedules.

== Description ==

**WP Timeline Block** adds a fully structured timeline layout to the WordPress block editor using an InnerBlocks parent/child architecture.

= Key Features =

* **Parent + child blocks** — Parent (Timeline) contains children (Timeline Items). Each item is a full Gutenberg block with its own toolbar, supports, and inner content.
* **Block Context** — Parent passes orientation, layout, and dot size to children via the WordPress Block Context API. Children respond live when parent settings change.
* **Vertical & Horizontal** — Toggle between vertical column and horizontal row layout from the toolbar or sidebar.
* **4 layout positions** — All Left, All Right, Alternating (left/right), Centered. Alternating uses CSS :nth-child() — zero JavaScript.
* **Connector styles** — Solid, Dashed, Dotted, or None. Toggle connector line on/off.
* **Per-item colour** — Each timeline item has a colour picker for its dot accent colour.
* **Full inner content** — Each item body is an InnerBlocks area accepting any block (paragraphs, images, lists, buttons).
* **3 Block Variations** — Company History, Process Steps, Project Roadmap presets.
* **3 Block Patterns** — Pre-filled 4-step history, 3-step horizontal process, 4-milestone roadmap.
* **Accessible** — `<time>` element with `dateTime` attribute, semantic heading structure.
* **No build step required** — Ships with pre-compiled `build/` directory.

== Installation ==

1. Upload and activate via **Plugins → Add New → Upload Plugin**
2. Search for **Timeline** in the block inserter
3. Insert — two starter timeline items appear automatically
4. Click **+ Timeline Item** to add more items
5. Configure orientation, connector style, and dot size in the right sidebar

== Frequently Asked Questions ==

= What is Block Context and why does this block use it? =
Block Context is the WordPress mechanism for passing data from a parent block to its children. The Timeline parent passes orientation, layout, dotSize, and showConnector to each child. Children receive these as a `context` prop and render accordingly. When you change the parent's orientation, all children update live.

= Why is the alternating layout done in CSS and not JavaScript? =
The save() function generates static HTML — context is unavailable at that point. CSS :nth-child(odd/even) selectors handle alternating left/right positioning without any JavaScript, making it faster, more reliable, and accessible.

= Can I put any content inside a timeline item? =
Yes. Each item body is an InnerBlocks area that accepts any block type — paragraphs, lists, images, buttons, media & text, and more.

= How do I reorder timeline items? =
Drag the ⠿ handle in the block toolbar of any Timeline Item. Or use the List View panel to drag-reorder items visually.

== Changelog ==

= 1.0.0 =
* Initial release. Parent/child InnerBlocks. Block Context API. Vertical + horizontal. 4 layout positions. 3 connector styles. Per-item colour picker. 3 Variations. 3 Patterns. Accessible time element.