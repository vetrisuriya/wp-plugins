wp-timeline/
├── wp-timeline.php                       ← wptl-wp-timeline.php
├── timeline-block.json                   ← at root (FIXED)
├── timeline-item-block.json              ← at root (FIXED)
├── uninstall.php / readme.txt / package.json
├── build/
│   ├── timeline/     index.js, index.asset.php, style-index.css, editor.css
│   └── timeline-item/ index.js, index.asset.php
└── src/
    ├── timeline/     index.js, edit.js, save.js, style.scss*, editor.scss*
    └── timeline-item/ index.js, edit.js, save.js